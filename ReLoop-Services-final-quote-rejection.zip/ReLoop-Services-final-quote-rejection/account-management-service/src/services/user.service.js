const mime = require('mime');
const { Op } = require('sequelize');
const Models = require('../models/index');
const s3UtilFunctions = require('../utils/s3.util');
const xlsx = require('../utils/xlsx.util');
const UserRepo = require('../repo/user.repo');
const ErrorTypes = require('../constants/error');

exports.getUserDatabyCognito = async function (cognitoId, bp) {
  let isBusinessDataPresent;
  const user = await Models.business_partner.findOne({
    where: {
      bp_userid: cognitoId,
      // Will be used when existing useer archive flag is set to false
      // [Op.not]: [{ archive: true }],
    },
    attributes: ['bp_id', 'bp_username', 'bp_email_id', 'bp_phone_number', 'loc_id',
      'gst_number', 'industry_type', 'cin', 'pan', 'is_part_of_pvt_nwk', 'profile_completion_status'],
  });
  if (!user) {
    const err = new Error('Invalid or inactive user');
    err.type = ErrorTypes.RES_NOT_FOUND;
    throw err;
  }
  const {
    bp_id, bp_username, bp_email_id, gst_number, bp_phone_number, industry_type, cin, pan,
    loc_id, is_part_of_pvt_nwk, profile_completion_status
  } = user;
  if (bp === 'gp') {
    isBusinessDataPresent = (gst_number !== null && bp_phone_number !== null
      && industry_type !== null && cin !== null && pan !== null && loc_id !== null);
  } else if (bp === 'rp') {
    const certificateQuery = {
      bp_id,
      cert_name: {
        [Op.or]: ['State Pollution Control Board Authorization', 'Authorization under Hazardous & Other Wastes'],
      },
    };
    const serviceableLoc = await Models.serviceable_location.findOne({ where: { rcy_id: bp_id }, attributes: [['serv_loc_id', 'servLocId']] });
    const certificates = await Models.certificate.findAll({ where: certificateQuery, attributes: ['cert_id'] });
    isBusinessDataPresent = (gst_number !== null && loc_id !== null
      && serviceableLoc !== null && bp_phone_number !== null
      && cin !== null && pan !== null && certificates.length >= 2);
  }
  const userData = {
    bp_id,
    bp_username,
    bp_email_id,
    isPartOfPvtNwk: is_part_of_pvt_nwk,
    isBusinessDataPresent,
    bpPhoneNumber: bp_phone_number,
    profileCompletionStatus: profile_completion_status,
  };
  return userData;
};

exports.getApproverDatabyCognito = async (cognitoId) => {
  const approver = await Models.approver.findOne({
    where: {
      approver_userid: cognitoId,
    },
    attributes: [['approver_id', 'approverId'],
    ['approver_role', 'approverRole'],
    ['approver_name', 'approverName'],
    ['approver_email_id', 'approverEmailId']],
  });
  return approver;
};
/*
  @desc service to create user data
*/
exports.register = async function (userData) {
  const user = { ...userData };
  user.archive = false;
  return UserRepo.createBpUser(user);
};

/*
  @desc service function to get user data
*/
exports.getUserData = async (cognitoId, userOptions) => {
  try {
    const { approver, bp } = userOptions;
    let userData = null;
    if (approver) userData = await exports.getApproverDatabyCognito(cognitoId);
    else userData = await exports.getUserDatabyCognito(cognitoId, bp);
    return Promise.resolve(userData);
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to read uploaded file from s3
*/
exports.downloadPrivacyStatement = async (req, res) => {
  const { key } = req.params;
  const result = await s3UtilFunctions.downloadFile(key, res);
  const { stream, data } = result;
  res.set('Content-Type', mime.getType(key));
  res.set('Content-Length', data.ContentLength);
  res.attachment(key);
  return stream;
};

exports.getGPPersonalDetails = async (userId) => {
  const userPersonalData = await UserRepo.getGPPersonalDetails(userId);
  const {
    bpUserName, bpEmailId, bpPhoneNumber, approvers, orders,
  } = userPersonalData;
  const userData = [{
    'Data Model': 'User',
    'Data Field': 'Business Username',
    'Data Value': bpUserName,
  }, {
    'Data Model': 'User',
    'Data Field': 'Business Email Id',
    'Data Value': bpEmailId,
  }, {
    'Data Model': 'User',
    'Data Field': 'Business Phone Number',
    'Data Value': bpPhoneNumber,
  }];
  if (approvers) {
    approvers.forEach((approver) => {
      const { approverName, approverEmailId } = approver.dataValues;
      userData.push({
        'Data Model': 'Approver',
        'Data Field': 'Approver Name',
        'Data Value': approverName,
      }, {
        'Data Model': 'Approver',
        'Data Field': 'Approver Email Id',
        'Data Value': approverEmailId,
      });
    });
  }
  if (orders) {
    orders.forEach((order) => {
      const { orderNo, logisticSpocName, logisticSpocNumber } = order.dataValues;
      if (logisticSpocName) {
        userData.push({
          'Data Model': `Order ${orderNo}`,
          'Data Field': 'Order Responsible Name',
          'Data Value': logisticSpocName,
        });
      }
      if (logisticSpocNumber) {
        userData.push({
          'Data Model': `Order ${orderNo}`,
          'Data Field': 'Order Responsible Phone Number',
          'Data Value': logisticSpocName,
        });
      }
    });
  }
  const buffer = xlsx.createExcelFromJSON(userData, 'Personal Data');
  return buffer;
};

exports.getRPPersonalDetails = async (userId) => {
  const userPersonalData = await UserRepo.getRPPersonalDetails(userId);
  const {
    bpUserName, bpEmailId, bpPhoneNumber, invitedOrders,
  } = userPersonalData;
  const userData = [{
    'Data Model': 'User',
    'Data Field': 'Business Username',
    'Data Value': bpUserName,
  }, {
    'Data Model': 'User',
    'Data Field': 'Business Email Id',
    'Data Value': bpEmailId,
  }, {
    'Data Model': 'User',
    'Data Field': 'Business Phone Number',
    'Data Value': bpPhoneNumber,
  }];
  if (invitedOrders) {
    invitedOrders.forEach((invitedOrder) => {
      const {
        orderNo, recyclerContactNumber,
        recyclerContactName, driverName, vehicleNumber,
      } = invitedOrder.dataValues.order.dataValues;
      if (recyclerContactName) {
        userData.push({
          'Data Model': `Order ${orderNo}`,
          'Data Field': 'Recycler Contact Name',
          'Data Value': recyclerContactName,
        });
      }
      if (recyclerContactNumber) {
        userData.push({
          'Data Model': `Order ${orderNo}`,
          'Data Field': 'Recycler Contact Phone Number',
          'Data Value': recyclerContactNumber,
        });
      }
      if (driverName) {
        userData.push({
          'Data Model': `Order ${orderNo}`,
          'Data Field': 'Driver Name',
          'Data Value': driverName,
        });
      }
      if (vehicleNumber) {
        userData.push({
          'Data Model': `Order ${orderNo}`,
          'Data Field': 'Vehicle Number',
          'Data Value': vehicleNumber,
        });
      }
    });
  }
  const buffer = xlsx.createExcelFromJSON(userData, 'Personal Data');
  return buffer;
};
