const { Op } = require('sequelize');
const Models = require('../models/index');
const authUtil = require('../utils/auth.util');
const ErrorTypes = require('../constants/error');
const kakfaUtil = require('../utils/kafka.util');
exports.getUserById = async (userId, options = {}) => {
  if (!options.projection) {
    options.projection = [];
  }
  const dbres = await Models.business_partner.findOne({
    where: { bp_id: userId },
    attributes: Models.business_partner.attributesAliasesHelper(options.projection),
  });
  return { ...dbres.dataValues };
};

exports.getGPPersonalDetails = async (userId) => {
  const dbres = await Models.business_partner.findOne({
    where: { bp_id: userId },
    attributes: [['bp_username', 'bpUserName'], ['bp_email_id', 'bpEmailId'], ['bp_phone_number', 'bpPhoneNumber']],
    include: [{
      model: Models.approver,
      as: 'approvers',
      attributes: [['approver_name', 'approverName'], ['approver_email_id', 'approverEmailId']],
    }, {
      model: Models.order,
      as: 'orders',
      attributes: [['order_no', 'orderNo'], ['logistic_spoc_name', 'logisticSpocName'], ['logistic_spoc_number', 'logisticSpocNumber']],
    }],
  });

  const response = { ...dbres.dataValues };
  return response;
};

exports.getRPPersonalDetails = async (userId) => {
  const dbres = await Models.business_partner.findOne({
    where: { bp_id: userId },
    attributes: [['bp_username', 'bpUserName'], ['bp_email_id', 'bpEmailId'], ['bp_phone_number', 'bpPhoneNumber']],
    include: [{
      model: Models.order_invited_business_partner,
      as: 'invitedOrders',
      attributes: ['order_id'],
      include: [{
        model: Models.order,
        as: 'order',
        attributes: [['order_no', 'orderNo'], ['vehicle_licence_no', 'vehicleNumber'], ['driver_name', 'driverName'], ['recycler_contact_name', 'recyclerContactName'], ['recycler_contact_number', 'recyclerContactNumber']],
      }],
    }],
  });

  const response = { ...dbres.dataValues };
  return response;
};

exports.getCertificateById = async (userId, certificateId, options = {}) => {
  if (!options.projection) {
    options.projection = [];
  }
  const dbres = await Models.certificate.findOne({
    where: Models.certificate.attributesAliasesHelper({
      businessPartnerId: userId, certificateId,
    }),
    attributes: Models.certificate.attributesAliasesHelper(options.projection),
  });
  if (!dbres) {
    const err = new Error('No certificate resource found for given request');
    err.type = ErrorTypes.RES_NOT_FOUND;
    throw err;
  }

  return { ...dbres.dataValues };
};

exports.createBpUser = async (payload) => {
  const userData = {
    bp_userid: payload.bp_userid,
    bp_username: payload.bp_username,
    bp_email_id: payload.bp_email_id,
    archive: payload.archive,
  };
  const result = await Models.business_partner.create(userData);
  const roleId = payload.role_id;
  const bpId = result.dataValues.bp_id;
  const roleMapping = {
    bp_id: bpId,
    role_id: roleId,
  };
  const res = await Models.role_bp_mapping.create(roleMapping);
  return res;
};

exports.getBusinessData = async (userId) => {
  const user = await Models.business_partner.findOne({
    where: { bp_id: userId },
    attributes: [
      ['bp_username', 'bpUsername'], ['bp_email_id', 'bpEmailId'], ['bp_phone_number', 'bpPhoneNumber'],
      ['gst_number', 'gstNumber'], ['industry_type', 'industryType'], ['loc_id', 'locId'], 'cin', 'pan',
      ['company_code', 'companyCode']],
  });
  let location = {};
  if (user.dataValues.locId) {
    const locDbRes = await Models.location.findOne({
      where: { loc_id: user.dataValues.locId },
      attributes: Models.location.attributesAliasesHelper([]),
      include: [
        { model: Models.state, as: 'state' },
        { model: Models.city, as: 'city' },
        { model: Models.country, as: 'country' }],
    });

    const locData = locDbRes.dataValues;
    location = {
      countryId: locData.countryId,
      stateId: locData.stateId,
      cityId: locData.cityId,
      locId: locData.locationId,
      state: locData.state.state_name,
      city: locData.city.city_name,
      country: locData.country.country_name,
      locDetails: locData.locationDetails,
      pincode: locData.pincode,
    };
  }
  return { ...user.dataValues, location };
};

const notifyBusinessPartner = async (type, userEmail, userName) => {
  const notification = {
    type,
    receivers: [{ receiverType: 'bp', email: userEmail }],
    values: {
      username: userName,
    },
  };
  kakfaUtil.runProducer('user-notification', notification);
};

const updateProfileCompletionStatus = async (userId, status) => {
  await Models.business_partner.update(
    { profile_completion_status: status },
    {
      where: {
        [Op.and]: [
          {
            bp_id: userId,
          },
          {
            profile_completion_status: {
              [Op.lt]: status,
            },
          },
        ],
      },
    },
  );
};

exports.updateProfileCompletionStatus = updateProfileCompletionStatus;

exports.updateUserBusinessData = async (userId, payload) => {
  const updatePayload = { ...payload };
  const user = await Models.business_partner.findOne({ where: { bp_id: userId } });
  const { location } = updatePayload;

  if (location) {
    const {
      stateId, cityId, country, pincode,
      locId, locDetails,
    } = location;
    const locData = {
      country_id: country,
      state_id: stateId,
      city_id: cityId,
      loc_details: locDetails,
      pincode: pincode ? pincode.trim() : pincode,
    };
    if (locId) {
      const loc = await Models.location.findOne({ where: { loc_id: locId } });
      await loc.update(locData);
    } else {
      const loc = await Models.location.create(locData);
      delete updatePayload.location;
      updatePayload.locationId = loc.loc_id;
    }
  }

  if (!user) {
    const err = new Error('User not found');
    err.type = ErrorTypes.RES_NOT_FOUND;
    throw err;
  }

  const {
    bpEmailId, bpUsername, gstNumber,
    industryType, locationId, cin, pan, bpPhoneNumber, companyCode,
  } = updatePayload;
  const userDataObj = {
    bp_email_id: bpEmailId ? bpEmailId.toString().trim() : bpEmailId,
    bp_phone_number: bpPhoneNumber ? bpPhoneNumber.toString().trim() : bpPhoneNumber,
    bp_username: bpUsername,
    gst_number: gstNumber ? gstNumber.toString().trim() : gstNumber,
    industry_type: industryType,
    loc_id: locationId,
    cin: cin ? cin.toString().trim() : cin,
    pan: pan ? pan.toString().trim() : pan,
    company_code: companyCode,
  };
  await user.update(userDataObj);
  if (payload.firstTimeNotification === true) {
    notifyBusinessPartner('welcome to everloop', bpEmailId, bpUsername);
  }
  await updateProfileCompletionStatus(userId, 1);
};

exports.getPrivateNetworks = async (userId) => {
  const promise = Models.bp_private_nwk.findAll({
    where: { nwk_owner: userId },
    attributes: ['bp_nwk_id', 'nwk_member', 'nwk_owner'],
    include: [{
      model: Models.business_partner,
      attributes: ['bp_email_id', 'bp_username', 'bp_phone_number', 'account_contact_name'],
      as: 'nwk_member_business_partner',
    }],
  });
  return promise;
};

exports.createPrivateNetworkUsers = async (ownerId, bpType, members) => {
  // Loop and check if recycler exist and add to private network else create recycler
  await Promise.all(members.map(async (pvtMember) => {
    let {
      emailId, username, contactName,
    } = pvtMember;
    emailId = emailId.toString().toLowerCase().trim();
    username = username.toString().trim();
    contactName = username.toString().trim();
    const { phoneNumber } = pvtMember;

    const groupName = bpType === 'gp' ? authUtil.ROLES.RP_USER : authUtil.ROLES.GP_USER;
    let nwkMemberBP = await Models.business_partner.findOne({ where: { bp_email_id: emailId } });
    if (!nwkMemberBP) {
      const cognitoUserData = {
        Username: emailId,
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
        TemporaryPassword: 'Welcome@12345', // To be removed , just for test data creation
      };
      const congitoUserGroupData = {
        GroupName: groupName,
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
      };
      const cognitoUser = await authUtil.createCognitouser(cognitoUserData, congitoUserGroupData);
      nwkMemberBP = await Models.business_partner.create({
        bp_email_id: emailId,
        bp_userid: cognitoUser, // cognito id after creation
        bp_username: username,
        account_contact_name: contactName,
        bp_phone_number: phoneNumber,
        is_part_of_pvt_nwk: true,
      });
    } else if (nwkMemberBP.archive === true) nwkMemberBP.update({ archive: false });
    else {
      const existingNtw = await Models.bp_private_nwk.findOne({
        where: {
          nwk_member: nwkMemberBP.bp_id,
          nwk_owner: ownerId,
        },
      });
      if (existingNtw) {
        const err = new Error('Network already exists');
        err.type = ErrorTypes.NOT_ALLOWED_REDO;
        throw err;
      }
    }
    await Models.bp_private_nwk.create({
      nwk_member: nwkMemberBP.bp_id,
      nwk_owner: ownerId,
    });
  }));
  await Models.business_partner.update({ has_pvt_network: true }, { where: { bp_id: ownerId } });
  const status = bpType === 'gp' ? 2 : 4;
  await updateProfileCompletionStatus(ownerId, status);
};

exports.updatePrivateNetworkMembers = async (ownerId, members) => {
  // Loop and check if recycler exist and add to private network else create recycler
  await Promise.all(members.map(async (pvtRecycler) => {
    const { emailId, username, phoneNumber } = pvtRecycler;
    let recyclerBP = await Models.business_partner.findOne({ where: { bp_email_id: emailId } });
    if (!recyclerBP) {
      const cognitoUser = await authUtil.createCognitouser({
        Username: emailId,
      });
      recyclerBP = await Models.business_partner.create({
        bp_email_id: emailId,
        bp_userid: cognitoUser, // cognito id after creation
        bp_username: username,
        bp_phone_number: phoneNumber,
      });

      await Models.bp_private_nwk.create({
        nwk_member: recyclerBP.bp_id,
        nwk_owner: ownerId,
      });
    } else {
      const { cognitoUserId } = pvtRecycler;
      await recyclerBP.update({
        bp_email_id: emailId,
        bp_userid: cognitoUserId, // cognito id after creation
        bp_username: username,
      });
    }
  }));
};

exports.deletePrivateNetworkMembers = async (ownerId, members) => {
  // Loop and delete private network and disable business partner
  await Promise.all(members.map(async (pvtNetwork) => {
    const { networkId, recyclerId } = pvtNetwork;
    // eslint-disable-next-line max-len
    const recyclerExist = await Models.order_invited_business_partner.findOne({
      where: { invited_bp_id: recyclerId },
      include: [{ model: Models.order, where: { order_position: ['In Progress', 'Draft'] }, as: 'order' }],
    });
    if (recyclerExist) {
      const err = new Error('Private Network cannot be deleted as being used in ongoing/draft orders');
      err.type = ErrorTypes.NOT_ALLOWED_ACTION;
      throw err;
    }
    await Models.bp_private_nwk.destroy(
      { where: { bp_nwk_id: networkId } },
    );
    const recycler = await Models.business_partner.findOne({ where: { bp_id: recyclerId } });
    await recycler.update({ archive: true });
  }));
};

exports.createCertificates = async (userId, userCertificates) => {
  // allowNewFields: false will not take unnecessary fields other than db column fields
  const dbRecordsToCreate = Models.certificate.attributesAliasesHelper(userCertificates, {
    allowNewFields: false, method: 'in',
  });
  const options = {
    updateOnDuplicate: ['cert_details', 'authorization_number', 'rcy_unit_capacity', 'valid_period', 'issued_date'],
  };
  const dbRecords = await Models.certificate.bulkCreate(dbRecordsToCreate, options);
  await updateProfileCompletionStatus(userId, 3);
  const dbRecordsTransformed = dbRecords.map((item) => item.dataValues);
  return Models.certificate.attributesAliasesHelper(dbRecordsTransformed, { method: 'out' });
};

exports.getAllCertificatesForUser = async (userId) => {
  const dbRecords = await Models.certificate.findAll({
    where: Models.certificate.attributesAliasesHelper({ businessPartnerId: userId }),
  });
  const dbRecordsTransformed = dbRecords.map((item) => item.dataValues);
  return Models.certificate.attributesAliasesHelper(dbRecordsTransformed, { method: 'out' });
};

async function addRecyclerServicableLocation(serviceLocations, servLocId) {
  await Promise.all(serviceLocations.map(async (serviceLocation) => {
    const existingServiceableState = await Models.serviceable_state.findOne({
      where: {
        serv_loc_id: servLocId,
        state_id: serviceLocation.state,
      },
      attributes: [['state_id', 'stateId']],
    });
    if (!existingServiceableState) {
      if (serviceLocation.isAllCitySelected) {
        await Models.serviceable_state.create({
          serv_loc_id: servLocId,
          state_id: serviceLocation.state,
          state_name: serviceLocation.stateName,
          is_all_city: true,
        });
      } else {
        const serviceLocationCities = serviceLocation.city;
        const serviceableState = await Models.serviceable_state.create({
          serv_loc_id: servLocId,
          state_id: serviceLocation.state,
          state_name: serviceLocation.stateName,
          is_all_city: false,
        });
        await Promise.all(serviceLocationCities.map(async (serviceLocationCity) => {
          await Models.serviceable_city.create({
            serv_loc_state_id: serviceableState.serv_loc_state_id,
            city_id: serviceLocationCity.cityId,
            city_name: serviceLocationCity.cityName,
          });
        }));
      }
    }
  }));
}

const removeServicableLocation = async (isAllState, existingServiceableLocation, statesDetail) => {
  if (isAllState === true) {
    await Models.serviceable_location.update({ is_all_state: false },
      { where: { serv_loc_id: existingServiceableLocation.dataValues.servLocId } });
    await Models.serviceable_state.destroy(
      {
        where: {
          serv_loc_id: existingServiceableLocation.dataValues.servLocId,
        },
      },
    );
  } else {
    await Models.serviceable_state.destroy(
      {
        where: {
          state_id: statesDetail,
          serv_loc_id: existingServiceableLocation.dataValues.servLocId,
        },
      },
    );
  }
};

exports.saveServicableLocations = async (userId, details) => {
  const { serviceLocations, isAllStateSelected, countryId } = details;
  const existingServiceableLocation = await Models.serviceable_location.findOne({
    where: {
      rcy_id: userId,
    },
    attributes: [['serv_loc_id', 'servLocId'], ['is_all_state', 'isAllState']],
  });

  if (isAllStateSelected) {
    if (!existingServiceableLocation) {
      await Models.serviceable_location.create({
        rcy_id: userId,
        country_id: countryId,
        is_all_state: true,
      });
    } else {
      await removeServicableLocation(true, existingServiceableLocation);
      await Models.serviceable_location.update({
        is_all_state: true,
      }, {
        where: {
          rcy_id: userId,
          serv_loc_id: existingServiceableLocation.dataValues.servLocId,
        },
      });
    }
  } else {
    let servLocId;
    if (existingServiceableLocation) {
      servLocId = existingServiceableLocation.dataValues.servLocId;
      await Models.serviceable_location.update({
        is_all_state: isAllStateSelected,
      }, {
        where: {
          rcy_id: userId,
          serv_loc_id: servLocId,
        },
      });
      await addRecyclerServicableLocation(serviceLocations, servLocId);
    } else {
      const serviceableLocation = await Models.serviceable_location.create({
        rcy_id: userId,
        country_id: countryId,
        is_all_state: false,
      });
      servLocId = serviceableLocation.serv_loc_id;
      await addRecyclerServicableLocation(serviceLocations, servLocId);
    }
  }
  await updateProfileCompletionStatus(userId, 2);
};

exports.getServicableLocationsForUser = async (recyclerId) => {
  const promise = Models.serviceable_location.findAll({
    where: { rcy_id: recyclerId },
    attributes: [['serv_loc_id', 'servLocId'], ['is_all_state', 'isAllState'], ['country_id', 'countryId']],
    include: [{
      model: Models.serviceable_state,
      attributes: [['state_id', 'stateId'], ['state_name', 'stateName'], ['is_all_city', 'isAllCity']],
      as: 'serviceable_states',
      include: [
        {
          model: Models.serviceable_city,
          attributes: [['city_id', 'cityId'], ['city_name', 'cityName']],
          as: 'serviceable_cities',
        }],
    }],
  });
  return promise;
};

exports.deleteServicableLocations = async (userId, details) => {
  const { statesDetail, isAllState } = details;
  const existingServiceableLocation = await Models.serviceable_location.findOne({
    where: {
      rcy_id: userId,
    },
    attributes: [['serv_loc_id', 'servLocId'], ['is_all_state', 'isAllState']],
  });
  await removeServicableLocation(isAllState, existingServiceableLocation, statesDetail);
};
