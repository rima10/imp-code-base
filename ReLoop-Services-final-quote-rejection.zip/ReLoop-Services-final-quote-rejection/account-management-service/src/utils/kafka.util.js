const { Kafka } = require('kafkajs');
const dotenv = require('dotenv');

dotenv.config();

const {NODE_ENV} = process.env;

const broker = NODE_ENV == 'production' ? ['kafka:29092'] : ['localhost:29092'];

const config = { clientId: 'account-management', brokers: broker };
// 1.Instantiating kafka
const kafka = new Kafka(config);
// 2.Creating Kafka Producer
const producer = kafka.producer();

exports.runProducer = async function (topic, message) {
  await producer.connect();
  await producer.send({
    topic,
    messages:
          [{ value: JSON.stringify(message) }],
  });
};
