const AWS = require('aws-sdk');
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
const got = require('got');
const jwkToPem = require('jwk-to-pem');
const { CloudWatchEvents } = require('aws-sdk');
const cache = require('./cache.util');

dotenv.config();

const {
  COGNITO_USER_POOL_ID, COGNITO_CLIENT_ID, POOL_REGION, COGNITO_ACCESS_ID, COGNITO_SECRET_KEY,
  GP_CLIENT_ID, APPROVER_CLIENT_ID, RP_CLIENT_ID,
} = process.env;

const poolData = {
  UserPoolId: COGNITO_USER_POOL_ID,
  ClientId: COGNITO_CLIENT_ID,
};
const poolRegion = POOL_REGION;

AWS.config.update(
  {
    accessKeyId: COGNITO_ACCESS_ID,
    secretAccessKey: COGNITO_SECRET_KEY,
    region: POOL_REGION,
  },
);

const COGNITO_CLIENT = new AWS.CognitoIdentityServiceProvider({
  region: POOL_REGION,
});

const clientIdMap = {
  gp: GP_CLIENT_ID,
  approver: APPROVER_CLIENT_ID,
  rp: RP_CLIENT_ID,
};

const ROLES = {
  gp: 'ReLoopGreenPartner',
  rp: 'ReLoopRecyclerPartner',
  approver: 'ReLoopGPApprover',
};

/*
  @desc Fetch JSONWebKeys from cognito to validate the JWT token
  @desc JWKs is fetched dynamically everytime for security resons as well as it can change in future
  @return Object - pems
*/
async function fetchJwks() {
  const url = `https://cognito-idp.${poolRegion}.amazonaws.com/${poolData.UserPoolId}/.well-known/jwks.json`;
  const jwks = await got(url, { responseType: 'json' });
  const pems = {};
  const { keys } = jwks.body;
  for (let i = 0; i < keys.length; i += 1) {
    const keyId = keys[i].kid;
    const jwk = { kty: keys[i].kty, n: keys[i].n, e: keys[i].e };
    const pem = jwkToPem(jwk);
    pems[keyId] = pem;
  }
  return pems;
}

async function fetchJWTwithRefreshToken(refreshToken, app) {
  const options = {
    UserPoolId: poolData.UserPoolId,
    AuthFlow: 'REFRESH_TOKEN_AUTH',
    AuthParameters: {
      REFRESH_TOKEN: refreshToken,
    },
    ClientId: clientIdMap[app],
  };
  return new Promise((resolve, reject) => {
    COGNITO_CLIENT.adminInitiateAuth(options, (err, data) => {
      if (err) {
        reject(err);
      }
      resolve(data.AuthenticationResult.IdToken);
    });
  });
}

const checkUserRole = (groups, applicationKey) => {
  if (!groups.includes(ROLES[applicationKey])) {
    throw new Error('Unauthorized');
  }
};

/*
  @desc validates JWT token with pems
  @param Object pems
  @param String token
  @return Object - pems
*/
async function validateJWT(pems, token) {
  const decodedJwt = jwt.decode(token, { complete: true });
  if (!decodedJwt) {
    throw new Error('not a valid access token');
  }
  const { kid } = decodedJwt.header;
  const pem = pems[kid];
  if (!pem) {
    throw new Error('not a valid access token');
  }
  const result = jwt.verify(token, pem);
  return result;
}

// returns an object with the cookies' name as keys
function getCookies(req) {
  // We extract the raw cookies from the request headers
  if (!req.headers.cookie) return false;
  const rawCookies = req.headers.cookie.split('; ');
  const parsedCookies = {};
  rawCookies.forEach((rawCookie) => {
    const parsedCookie = rawCookie.split('=');
    const [key, val] = parsedCookie;
    parsedCookies[key] = val;
  });
  return parsedCookies;
}

/*
  @desc controller function to validate JWT token
  @desc JWKs is fetched dynamically everytime for security resons as well as it can change in future
*/
exports.validate = async function validate(req, res, next) {
  try {
    const whiteListedHosts = ['localhost', 'ec2-3-109-206-177.ap-south-1.compute.amazonaws.com', 'api-gateway', 'service.qa.ever-loop.io', /\.amplifyapp\.com$/];
    if (!whiteListedHosts.includes(req.hostname)) throw new Error('Untrusted Host');
    const pems = await fetchJwks();
    let { authorization } = req.headers;
    let { refresh } = req.headers;
    const { app } = req.query;
    let cookies;
    if (!authorization) {
      authorization = getCookies(req).authorization;
      if (!authorization) throw new Error('Unauthorized');
      cookies = true;
    } else {
      const [, token] = authorization.split(' ');
      authorization = token;
      cookies = false;
    }
    let user;
    try {
      user = await validateJWT(pems, authorization);
    } catch (error) {
      const decodedJwt = jwt.decode(authorization, { complete: true });
      const refreshToken = cache.get(decodedJwt.payload['cognito:username']);
      if (!refreshToken) throw new Error('not a valid access token');
      const newToken = await fetchJWTwithRefreshToken(refreshToken, app);
      user = await validateJWT(pems, newToken, true);
      authorization = newToken;
      cookies = false;
      refresh = refreshToken;
    }
    const cognitoId = user['cognito:username'];
    const cognitoGroups = user['cognito:groups'];
    checkUserRole(cognitoGroups, app);
    if (!cookies) {
      cache.set(cognitoId, refresh); // Store refresh token
      res.cookie('authorization', authorization,
        {
          domain: req.hostname, // 'service.qa.ever-loop.io',
          maxAge: 3600000,
          // You can't access these tokens in the client's javascript
          httpOnly: true,
          // Forces to use https in production
          sameSite: 'none',
          secure: true,

        });
    }
    res.status(200).json({});
  } catch (error) {
    res.status(401).json({
      error: {
        message: error.message,
      },
    });
    next(error);
  }
};

/*
  @desc controller function to validate JWT token
  @desc JWKs is fetched dynamically everytime for security resons as well as it can change in future
  @return Object - pems
*/
exports.validateMiddleware = async function validateMiddleware(req, res, next) {
  try {
    const pems = await fetchJwks();
    let { authorization } = req.headers;
    if (!authorization) {
      authorization = getCookies(req).authorization;
    } else {
      const [, token] = authorization.split(' ');
      authorization = token;
    }
    const decodedJWT = await validateJWT(pems, authorization);
    req.userInfo = decodedJWT;
    next();
  } catch (error) {
    res.status(401).json({
      error: {
        message: error.message,
      },
    });
    next(error);
  }
};

exports.logout = async (req, res) => {
  res.clearCookie('authorization', { path: '/' });
  res.send(200);
};
