const ErrorTypes = require('../constants/error');
const utilFunctions = require('../utils/commonFunctions.util');

const docService = require('./doc.service');
const OrderWorkflowService = require('./orderWorkflow.service');

const OrderRepo = require('../repo/order.repo');
const OrderItemRepo = require('../repo/order_item.repo');
const OrderWorkflowRepo = require('../repo/order_workflow.repo');
const ApprovalRepo = require('../repo/approval.repo');

const readExcel = async (file, orderType) => {
  const excelRows = utilFunctions.convertExcelToJson(file.buffer);
  const { isValid, errors, validRows } = OrderItemRepo.validateAssetExcelRows(excelRows, orderType);
  if (!isValid) {
    const err = new Error('Asset list excel validation failed');
    err.type = ErrorTypes.DATA_VALIDATION_ERR;
    // group errors by type and column name
    const groupedErrors = {};
    errors.forEach((errItem) => {
      const groupName = `${errItem.columnName}||${errItem.type}`;
      if (!groupedErrors[groupName]) {
        groupedErrors[groupName] = {
          columnName: errItem.columnName,
          columnHeading: errItem.columnHeading,
          message: errItem.message,
          type: errItem.type,
          rows: [],
        };
      }

      groupedErrors[groupName].rows.push(errItem.row);
    });
    err.message = [...Array.from(Object.keys(groupedErrors), (key) => groupedErrors[key])];
    throw err;
  }
  return validRows;
};
exports.readExcel = readExcel;

const assetExcelHandler = async (userId, orderDetails, excelFile, orderType) => {
  try {
    const { order_no, order_id } = orderDetails;
    const excelRows = await readExcel(excelFile, orderType);

    // delete existing asset rows for an order
    await OrderItemRepo.deleteOrderItemsForOrder(order_id);

    await OrderItemRepo.createOrderItems(excelRows, userId, order_id, orderType);

    // after creating the order, save the asset file
    const docItemReq = {
      files: { document: [excelFile] },
      params: { orderId: order_id },
      body: { documentName: 'Asset List', orderNo: order_no },
      userInfo: { userId },
    };
    await docService.uploadDocument(docItemReq);

    return Promise.resolve(true);
  } catch (err) {
    return Promise.reject(err);
  }
};
exports.assetExcelHandler = assetExcelHandler;

exports.updateAssetExcelOrderItems = async (userId, orderId, assetExcelFile) => {
  const dbOrder = await OrderRepo.getOrder(orderId);
  const orderDetails = dbOrder.dataValues;

  // check if order asset list can be updated
  const rejectedWorkflow = await OrderWorkflowRepo.checkOrderHasRejectedWorkflow(orderId, '1');
  if (orderDetails.order_position !== 'Draft' && !rejectedWorkflow) {
    const err = new Error('Cannot update ongoing order data.');
    err.type = ErrorTypes.NOT_ALLOWED_ACTION;
    throw err;
  }

  // created new asset list items in db
  await assetExcelHandler(userId, orderDetails, assetExcelFile, orderDetails.order_type);

  // for rejected workflow scenario, recreate new workflow approver pipeline newly
  if (rejectedWorkflow) {
    const { orderWorkflowId } = rejectedWorkflow;
    await OrderWorkflowRepo.updateOrderWorkflowPipelineInactive(orderWorkflowId);
    await OrderWorkflowService.createOrderWorkflowData(
      userId,
      {
        processStageSequence: orderDetails.current_sequence,
        processType: orderDetails.order_type,
        orderId,
        commentsForApprover: 'Asset list is updated',
      },
    );
    await ApprovalRepo.updateWorkflowOverallStatus(orderWorkflowId);
  }

  const dbRows = await OrderRepo.getOrderItems(orderId, orderDetails.order_type);
  return Promise.resolve(dbRows);
};
