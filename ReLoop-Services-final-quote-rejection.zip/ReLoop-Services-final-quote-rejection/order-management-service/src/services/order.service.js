const Models = require('../models/index');
const orderItemService = require('./orderItem.service');
const docService = require('./doc.service');
const orderWorkflowService = require('./orderWorkflow.service');
const orderDataFormatUtil = require('../utils/order/dataFormat.util');
const orderRepo = require('../repo/order.repo');
const quotationRepo = require('../repo/quotation.repo');
const quotationService = require('./quotation.service');
const ErrorTypes = require('../constants/error');

const kakfaUtil = require('../utils/kafka.util');

exports.createOrder = async (userId, orderDetails, files) => {
  const { processStageSequence, orderType } = orderDetails;
  const orderPosition = 'In Progress';
  const orderHeader = await orderRepo.createOrderHeader(orderDetails, userId, files, orderPosition);

  // after creating the order, add the order item and link the order with the order item
  await orderItemService.assetExcelHandler(userId, orderHeader, files.assetExcel[0], orderType);

  await orderWorkflowService.createOrderWorkflowData(
    userId,
    {
      processStageSequence,
      processType: orderType,
      orderId: orderHeader.order_id,
      commentsForApprover: orderDetails.commentsForApprover,
    },
  );

  const orders = await orderRepo.getOrdersForGP(userId);
  return orders;
};

exports.saveOrderAsDraft = async (userId, orderDetails, files) => {
  const { orderType } = orderDetails;
  const orderPosition = 'Draft';
  const orderHeader = await orderRepo.createOrderHeader(orderDetails, userId,
    files, orderPosition);

  if (files && files.assetExcel[0]) {
    await orderItemService.assetExcelHandler(userId, orderHeader, files.assetExcel[0], orderType);
  }

  await orderWorkflowService.createOrderWorkflowData(
    userId,
    {
      processStageSequence: '1',
      processType: orderType,
      orderId: orderHeader.order_id,
      addApprovers: 'false',
    },
  );
  const order = await orderRepo.getOrderDataByOrderId(
    orderHeader.order_id,
    false,
  );
  return order;
};

exports.updateOrderHeaderData = async (userId, orderId, updatePayload) => {
  try {
    const dbOrder = await orderRepo.getOrder(orderId);
    if (dbOrder.dataValues.order_position !== 'Draft') {
      const err = new Error('Cannot update ongoing order data.');
      err.type = ErrorTypes.NOT_ALLOWED_ACTION;
      throw err;
    }
    await orderRepo.updateOrderHeaderData(userId, dbOrder.dataValues, updatePayload);

    const order = await orderRepo.getOrderDataByOrderId(orderId, false, '1', dbOrder.dataValues.order_type);
    return Promise.resolve(order);
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to get orders based on business partner id
*/
exports.getOrdersForGP = async (gpUserId) => orderRepo.getOrdersForGP(gpUserId);

/*
  @desc service function to to cancel an order
*/
exports.cancelOrder = async (orderId) => {
  try {
    // check if an order can be cancelled
    const order = await orderRepo.getOrder(orderId);
    if (!order) {
      const err = new Error('Order not found');
      err.type = ErrorTypes.RES_NOT_FOUND;
      throw err;
    }

    if (order.current_sequence >= 3) {
      const err = new Error('Cannot cancel the order which is already submitted to recyclers');
      err.type = ErrorTypes.NOT_ALLOWED_ACTION;
      throw err;
    }

    const response = {};
    if (order.order_position !== 'Cancelled') {
      const update = {
        orderPosition: 'Cancelled',
      };
      await orderRepo.updateOrderById(orderId, update);
      response.message = 'Order is cancelled successfully';
    } else {
      response.message = 'Order was already cancelled.';
    }
    return Promise.resolve(response);
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to make order as completed
*/
exports.completeOrder = async (orderId) => {
  try {
    // check if an order can be cancelled
    const order = await orderRepo.getOrder(orderId);
    if (!order) {
      const err = new Error('Order not found');
      err.type = ErrorTypes.RES_NOT_FOUND;
      throw err;
    }

    if (order.current_sequence < 6) {
      const err = new Error('Cannot mark order as completed. Order is on going.');
      err.type = ErrorTypes.NOT_ALLOWED_ACTION;
      throw err;
    }

    const response = {};
    if (order.order_position !== 'Completed') {
      const update = {
        orderPosition: 'Completed',
      };
      await orderRepo.updateOrderById(orderId, update);
      response.message = 'Order is marked as completed successfully';
    } else {
      response.message = 'Order was already marked as completed.';
    }
    return Promise.resolve(response);
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to get orders based on order id
*/
exports.getRecycleOrderByOrderId = async (orderId) => {
  const isRefurbish = false;
  const order = await orderRepo.getOrderDataByOrderId(orderId, true, '1', isRefurbish);
  return order;
};

/*
  @desc service function to get orders based on order id
*/
exports.getRefurbishOrderByOrderId = async (orderId) => {
  const isRefurbish = true;
  const order = await orderRepo.getOrderDataByOrderId(orderId, true, '1', isRefurbish);
  return order;
};

const getRefurbishConsolidatedOrderData = async (orderId) => {
  const order = await orderRepo.getOrderDataByOrderId(
    orderId,
    true,
    '2',
    true,
  );
  const consolidatedOrderData = orderDataFormatUtil.createConsolidatedOrderData(order);
  order.orderItems = consolidatedOrderData;
  return order;
};
exports.getRefurbishConsolidatedOrderData = getRefurbishConsolidatedOrderData;

exports.getConsolidatedOrderDataForRP = async (rpUserId, orderId) => {
  const isQuoteSubmitted = await orderRepo.getOrderItemAfterQuoteSubmission(
    orderId,
    rpUserId,
  );
  if (isQuoteSubmitted != null) {
    return isQuoteSubmitted;
  }
  const order = await getRefurbishConsolidatedOrderData(orderId);
  return order;
};

exports.getOrderItemAfterQuoteSubmission = async (req) => {
  const { orderId } = req.params;
  const { userId } = req.params;
  const quotes = await orderRepo.getOrderItemAfterQuoteSubmission(orderId, userId);
  return quotes;
};

/*
  @desc service function to get asset file url based on order id
*/
exports.getFileURL = async (req, res, next) => {
  const { orderId } = req.params;
  const s3Key = await exports.getFileKeyForDownload(orderId);
  const s3URLForTemplate = await s3UtilFunctions.getUrlForDownloadTemplate(
    s3Key,
  );
  return s3URLForTemplate;
};

/*
  @desc service function to get OrderType
*/
exports.getAllOrderTypes = async () => orderRepo.getAllOrderTypes();

exports.createOrderTypes = async (processTypes) => orderRepo.createOrderTypes(processTypes);

exports.getFileKeyForDownload = async (orderId) => {
  const fileKey = await Models.order.findOne({
    where: { order_id: orderId },
    attributes: ['asset_excel_loc', 'assetExcelLoc'],
  });
  return fileKey;
};

exports.getOrderWorkflowByStage = async (orderId, processType, processStageSequence) => {
  const approvals = await orderRepo.getOrderWorkflowByStage(
    orderId,
    processType,
    processStageSequence,
  );
  return approvals;
};

async function notifyRecyclersForOrder(userId, orderId, options = {}) {
  let { order, user } = options;
  if (!order) {
    order = await orderRepo.getOrder(orderId);
    order = order.dataValues;
  }
  if (!user) {
    user = await Models.business_partner.findOne({
      where: Models.business_partner.attributesAliasesHelper({ userId }),
      attributes: Models.business_partner.attributesAliasesHelper(['emailId', 'username', 'userId']),
    });
    user = user.dataValues;
  }
  const dbres = await Models.order_invited_business_partner.findAll({
    where: Models.order_invited_business_partner.attributesAliasesHelper({ orderId }),
    include: [{
      model: Models.business_partner,
      attributes: Models.business_partner.attributesAliasesHelper(['emailId', 'username', 'userId']),
      as: 'invited_bp',
    }],
  });
  const invitedRecyclers = dbres.map((item) => {
    // eslint-disable-next-line no-shadow
    const { emailId, userId, username } = item.invited_bp.dataValues;
    return { emailId, userId, username };
  });

  const notification = {
    type: 'invite recyclers',
    receivers: invitedRecyclers.map((item) => ({ receiverType: 'bp', email: item.emailId })),
    values: {
      orderNo: order.order_no,
      greenPartnerName: user.username,
    },
  };
  kakfaUtil.runProducer('user-notification', notification);
  return Promise.resolve(invitedRecyclers);
}

exports.moveOrderToNextStep = async (userId, orderId, nextStage, addApprovers) => {
  const update = { order_id: orderId, current_sequence: nextStage };
  const [rowsUpdate, [order]] = await orderRepo.updateOrderById(orderId, update);

  if (!rowsUpdate || !order) {
    const err = new Error('Order update is not successful');
    err.type = ErrorTypes.FAILED_UPDATE;
    throw err;
  }

  const orderType = order.order_type;
  // Do not add approvers for quotation step
  await orderWorkflowService.createOrderWorkflowData(
    userId,
    {
      processStageSequence: nextStage, processType: orderType, orderId, addApprovers,
    },
  );
  // notify recyclers about the quotation submission
  if (nextStage.toString() === '3') {
    await notifyRecyclersForOrder(userId, orderId, { order: order.dataValues });
  }
  return order;
};

async function createAssetGradingDocument(orderId, quoteId, userId) {
  try {
    const wbBuffer = await quotationService.getOrderItemsGradingListInExcel(orderId, quoteId);
    const documentName = 'Asset Grading';
    const fileName = `AssetGrading_${orderId}_${quoteId}.xlsx`;
    const file = {
      buffer: wbBuffer,
    };
    const document = await docService.uploadDocToS3(orderId, documentName, file, fileName, userId);
    return Promise.resolve(document);
  } catch (e) {
    return Promise.reject(e);
  }
}
exports.notifyRecycler = async (type, userId, orderId) => {
  const data = await orderRepo.getOrderNotificationData(orderId, userId);
  const notification = {
    type,
    receivers: [{ receiverType: 'bp', email: data.recyclerDetail }],
    values: {
      orderNo: data.orderNo,
      greenPartnerName: data.greenPartnerDetail,
    },
  };
  kakfaUtil.runProducer('user-notification', notification);
};

exports.scheduleLogistics = async (userId, orderId, details) => {
  // create asset grading file document and push to s3
  const orderQuote = await quotationRepo.getAcceptedQuoteForOrder(orderId);
  if (!orderQuote) {
    const err = new Error('Accepted order quotation is not found');
    err.type = ErrorTypes.RES_NOT_AVAILABLE;
    throw err;
  }

  createAssetGradingDocument(orderId, orderQuote.quoteId, userId);

  const { scheduledLogisticDate, logisticSpocName, logisticSpocContactNumber } =
    details;

  const update = {
    logisticsScheduledTime: scheduledLogisticDate,
    updatedByUserId: userId,
    logisticSpocName,
    logisticSpocContactNumber,
  };
  const [rowsUpdate, [order]] = await orderRepo.updateOrderById(
    orderId,
    update,
  );
  if (!rowsUpdate || !order) {
    const err = new Error('Order update is not successful');
    err.type = ErrorTypes.FAILED_UPDATE;
    throw err;
  }
  // notify Recycler that Logistics is scheduled
  exports.notifyRecycler('accept logistics', userId, orderId);
  return order;
};

exports.acceptLogistics = async (userId, orderId, details) => {
  const {
    vehicleType,
    vehicleNumber,
    driverName,
    logisticProvider,
    recyclerContactName,
    recyclerContactNumber,
  } = details;

  const update = {
    vehicleType,
    vehicleNumber,
    driverName,
    logisticProvider,
    recyclerContactName,
    recyclerContactNumber,
    updatedByUserId: userId,
  };
  const [rowsUpdate, [order]] = await orderRepo.updateOrderById(orderId, update);
  if (!rowsUpdate || !order) {
    const err = new Error('Order update is not successful');
    err.type = ErrorTypes.FAILED_UPDATE;
    throw err;
  }
  return order;
};

/*
  @desc service function to get header data of the order
*/
exports.getOrderHeaderData = async (userId, orderId) => orderRepo.getOrderHeaderData(userId, orderId);

exports.getOrdersForRP = async (rpUserId) => orderRepo.getOrdersForRP(rpUserId);

exports.getRecycleOrderItemsForRP = async (userId, orderId) => orderRepo.getRecycleOrderItemsForRP(userId, orderId);

exports.getLogisticsData = async (orderId) => orderRepo.getLogisticsData(orderId);
