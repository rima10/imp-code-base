const ErrorTypes = require('../constants/error');
const approvalService = require('./approval.service');
const OrderWorkflowRepo = require('../repo/order_workflow.repo');
const OrderRepo = require('../repo/order.repo');
const ApprovalRepo = require('../repo/approval.repo');
const QuotationRepo = require('../repo/quotation.repo');

exports.createOrderWorkflow = async (userId, orderId, workflowData) => {
  const update = { orderPosition: 'In Progress' };
  const [rowsUpdate, [order]] = await OrderRepo.updateOrderById(orderId, update);
  if (!rowsUpdate || !order) {
    const err = new Error('Invalid Order Id');
    err.type = ErrorTypes.FAILED_UPDATE;
    throw err;
  }

  return exports.createOrderWorkflowData(userId, workflowData);
};

exports.createOrderWorkflowData = async (userId, workflowData) => {
  const {
    orderId, processStageSequence, processType, addApprovers, commentsForApprover,
  } = workflowData;
  const workflow = await OrderWorkflowRepo.getWorkflow(userId, processStageSequence, processType);
  if (workflow) {
    const orderWorkflow = await OrderWorkflowRepo.createOrderWorkflowSkeleton(orderId, workflow.workflow_id);
    if (addApprovers !== 'false') {
      const { order_workflow_id, workflow_id } = orderWorkflow;
      await approvalService.createOrderWfApprover(orderId, workflow_id, order_workflow_id, '1');
    }

    if (commentsForApprover) {
      const orderNotes = {
        orderId,
        activityName: `${workflow.process_stage_name} comments from GP`,
        activityComment: commentsForApprover,
        activityIdentifier: `pss_${processStageSequence}|gp_${userId}`,
        isInternal: true,
        userId,
      };
      await ApprovalRepo.createOrderNotes(orderNotes);
    }

    return orderWorkflow;
  }
};

exports.resetOrderToInitialQuoteWorkflow = async (userId, orderId) => {
  const dbOrder = await OrderRepo.getOrder(orderId);
  const orderDetails = dbOrder.dataValues;

  // order should have accepted quotation
  const orderQuote = await QuotationRepo.getAcceptedQuoteForOrder(orderId);
  if (!orderQuote) {
    const err = new Error('Order does not have any accepted quotation');
    err.type = ErrorTypes.RES_NOT_AVAILABLE;
    throw err;
  }

  // order should have been rejected by one of the final quote approvers
  const rejectedFinalQuoteWorkflow = await OrderWorkflowRepo.checkOrderHasRejectedWorkflow(orderId, '5');
  if (!rejectedFinalQuoteWorkflow) {
    const err = new Error('Reset order to intial quote operation is not allowed as no final quote is rejected.');
    err.type = ErrorTypes.NOT_ALLOWED_ACTION;
    throw err;
  }
  if (!rejectedFinalQuoteWorkflow.orderWorkflowApprovers) {
    throw new Error('Missing data of rejected workflow approver for an order');
  }

  // update existing accepted quote to rejected
  const quoteUpdate = {
    quoteStatus: 'Rejected',
  };
  await QuotationRepo.updateOrderQuote(userId, orderId, orderQuote.quoteId, quoteUpdate);

  // update existing final quote order_workflow_approver row as is_active:false
  await OrderWorkflowRepo.updateOrderWorkflowPipelineInactive(rejectedFinalQuoteWorkflow.orderWorkflowId);

  // update existing intial quote order_workflow_approver row as is_active:false
  const initialQuoteWorkflow = await OrderRepo.getOrderWorkflowByStage(
    orderId,
    orderDetails.order_type,
    '3',
  );
  if (initialQuoteWorkflow) {
    await OrderWorkflowRepo.updateOrderWorkflowPipelineInactive(initialQuoteWorkflow.orderWorkflowId);

    // create new workflow
    await exports.createOrderWorkflowData(userId, {
      processStageSequence: '3',
      processType: orderDetails.order_type,
      orderId,
    });
  }

  await OrderRepo.updateOrderById(orderId, { current_sequence: '3' });

  return true;
};
