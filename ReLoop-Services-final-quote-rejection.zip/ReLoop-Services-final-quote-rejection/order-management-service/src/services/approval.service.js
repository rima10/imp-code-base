const Models = require('../models/index');
const kakfaUtil = require('../utils/kafka.util');
const orderRepo = require('../repo/order.repo');
const ApprovalRepo = require('../repo/approval.repo');
/*
  @desc helper function to get order list
  @param String - approverId
  @return Array - orderList
*/
exports.getAllOrdersByApproverId = async (approverId) => ApprovalRepo.getAllOrdersByApproverId(approverId);

/*
  @desc service function to get an order for Approver UI
*/
exports.getOrderForApprover = async (orderId, orderWorkflowApproverId) => {
  const orderType = await orderRepo.getOrderTypeForOrderId(orderId);
  const orderWorkflowApprover = await ApprovalRepo.getOrderWorkflowApproverById(orderWorkflowApproverId);

  // get order for based on current order_workflow_approver id
  const { processStageSequence } = orderWorkflowApprover?.orderWorkflow?.workflow;
  const order = await orderRepo.getOrderDataByOrderId(orderId, true, processStageSequence || '1', orderType === '1');

  const { quoteId } = orderWorkflowApprover.orderWorkflow;
  if (quoteId) {
    const quoteDbRes = await Models.order_quote.findOne({
      where: {
        order_id: orderId,
        id: quoteId,
      },
      attributes: [['id', 'quoteId'], ['asset_grading_comments', 'assetGradeComments']],
    });
    order.acceptedOrderQuote = quoteDbRes.dataValues;
  }
  return order;
};

const notifyBP = async (type, orderId, comment, approverId) => {
  const data = await ApprovalRepo.getApprovalNotificationData(orderId, approverId);
  const notification = {
    type,
    receivers: [{ receiverType: 'bp', email: data.receiver.emailId }],
    values: {
      orderNo: data.order.orderNumber,
      approver: data.approver.approverName,
      comment,
    },
  };
  kakfaUtil.runProducer('user-notification', notification);
};

exports.notifyApprover = async (type, orderId, receiver) => {
  const order = await Models.order.findOne({
    where: { order_id: orderId },
    attributes: ['order_id', 'order_no'],
  });
  const notification = {
    type,
    receivers: [{ receiverType: 'approver', email: receiver }],
    values: {
      orderNo: order.order_no,
    },
  };
  kakfaUtil.runProducer('user-notification', notification);
};

exports.createOrderWfApprover = async (orderId, workflowId, orderWorkflowId, sequence) => {
  const workflow = await ApprovalRepo.createOrderWfApprover(workflowId, orderWorkflowId, sequence);
  if (workflow) {
    exports.notifyApprover('approval requested', orderId, workflow.approver.approverEmailId);
  }
  return workflow;
};

const requestNextApproverInWorkflow = async (orderWorkflowId, orderId, currentSequence) => {
  const { workflowId, nextSequence } = await ApprovalRepo.getNextSequenceInApprovalWorkflow(orderWorkflowId, currentSequence);
  if (nextSequence) {
    await exports.createOrderWfApprover(orderId, workflowId, orderWorkflowId, nextSequence);
  }
};

function formApprovalActivityIdentifier(pss, approverId, orderWorkflowApproverId) {
  return `pss_${pss}|gpapp_${approverId}|wkappid_${orderWorkflowApproverId}`;
}

exports.approve = async (approverId, orderId, orderWorkflowApproverId, details) => {
  const { comment } = details;
  const orderWorkflowApprover = await ApprovalRepo.updateOrderWorkflowApproverById(orderWorkflowApproverId, { status: 'Approved' });

  if (comment) {
    const workflowDoc = orderWorkflowApprover?.orderWorkflow?.workflow;
    const orderNotes = {
      orderId,
      activityName: `Approval of ${workflowDoc.processStageName}`,
      activityComment: comment,
      activityIdentifier: formApprovalActivityIdentifier(
        workflowDoc.processStageSequence,
        approverId,
        orderWorkflowApprover.workflowApproverId,
      ),
      isInternal: true,
      approverUserId: approverId,
    };
    await ApprovalRepo.createOrderNotes(orderNotes);
  }

  // Async tasks will run in the backgorund
  const { orderWorkflowId, approverSequence } = orderWorkflowApprover;
  requestNextApproverInWorkflow(orderWorkflowId, orderId, approverSequence);
  notifyBP('request accepted', orderId, comment, approverId);
  ApprovalRepo.updateWorkflowOverallStatus(orderWorkflowId);

  const orderList = await ApprovalRepo.getAllOrdersByApproverId(approverId);
  return orderList;
};

exports.reject = async (approverId, orderId, orderWorkflowApproverId, details) => {
  const { comment } = details;
  const orderWorkflowApprover = await ApprovalRepo.updateOrderWorkflowApproverById(
    orderWorkflowApproverId,
    {
      status: 'Rejected',
    },
  );

  if (comment) {
    const workflowDoc = orderWorkflowApprover?.orderWorkflow?.workflow;
    const orderNotes = {
      orderId,
      activityName: `Rejection of ${workflowDoc.processStageName}`,
      activityComment: comment,
      activityIdentifier: formApprovalActivityIdentifier(
        workflowDoc.processStageSequence,
        approverId,
        orderWorkflowApprover.workflowApproverId,
      ),
      isInternal: true,
      approverUserId: approverId,
    };
    await ApprovalRepo.createOrderNotes(orderNotes);
  }

  const orderList = await ApprovalRepo.getAllOrdersByApproverId(approverId);
  // Async task will run in the backgorund
  notifyBP('request rejected', orderId, comment, approverId);
  const { orderWorkflowId } = orderWorkflowApprover;
  ApprovalRepo.updateWorkflowOverallStatus(orderWorkflowId);

  return orderList;
};

exports.resendApprovalRequest = async (userId, orderId, orderWorkflowApproverId, details) => {
  // update existing order_workflow_approver row as is_active:false
  const updatePayload = {
    is_active: false,
  };
  const orderWorkflowApprover = await ApprovalRepo.updateOrderWorkflowApproverById(
    orderWorkflowApproverId,
    updatePayload,
  );
  const workflowDoc = orderWorkflowApprover?.orderWorkflow?.workflow;
  const { orderWorkflowId, approverSequence } = orderWorkflowApprover;

  // recreate order_workflow_approver row for same rejected request
  await exports.createOrderWfApprover(orderId, workflowDoc.workflowId, orderWorkflowId, approverSequence);

  // create comments as order_notes for approver
  const { comment } = details;
  if (comment) {
    const orderNotes = {
      orderId,
      activityName: `${workflowDoc.processStageName} comments from GP`,
      activityComment: comment,
      activityIdentifier: `pss_${workflowDoc.processStageSequence}|gp_${userId}`,
      isInternal: true,
      userId,
    };
    await ApprovalRepo.createOrderNotes(orderNotes);
  }
};
