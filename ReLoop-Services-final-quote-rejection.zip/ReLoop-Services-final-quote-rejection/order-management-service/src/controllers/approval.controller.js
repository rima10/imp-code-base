const approvalService = require('../services/approval.service');

/*
  @desc controller function get pending approvals
*/
exports.getAllOrdersByApproverId = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const assignedOrders = await approvalService.getAllOrdersByApproverId(userId);
    res.json(assignedOrders);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get orders based on order id for approvers
*/
exports.getOrderForApprover = async function (req, res, next) {
  try {
    const { orderId, orderWorkflowApproverId } = req.params;
    const order = await approvalService.getOrderForApprover(orderId, orderWorkflowApproverId);
    res.json(order);
  } catch (error) {
    next(error);
  }
};

exports.approve = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { orderId, orderWorkflowApproverId } = req.params;
    const details = req.body;
    const assignedOrders = await approvalService.approve(userId, orderId, orderWorkflowApproverId, details);
    res.status(200).json(assignedOrders);
  } catch (error) {
    next(error);
  }
};

exports.reject = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { orderId, orderWorkflowApproverId } = req.params;
    const details = req.body;
    const assignedOrders = await approvalService.reject(userId, orderId, orderWorkflowApproverId, details);
    res.status(200).json(assignedOrders);
  } catch (error) {
    next(error);
  }
};

exports.resendApprovalRequest = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { orderId, orderWorkflowApproverId } = req.params;
    const details = req.body;
    await approvalService.resendApprovalRequest(userId, orderId, orderWorkflowApproverId, details);
    res.status(200).json({ message: 'Approval request is submitted successfully' });
  } catch (error) {
    next(error);
  }
};
