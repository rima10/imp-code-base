// eslint-disable-next-line import/no-unresolved

const orderItemService = require('../services/orderItem.service');

exports.readExcel = async function (req, res, next) {
  try {
    const { file } = req;
    const { orderType } = req.body;
    const entries = await orderItemService.readExcel(file, orderType);
    res.json(entries);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to update excel asset list items
*/
exports.updateAssetExcelOrderItems = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const { userId } = req.userInfo;
    const { file } = req;
    const updatedRes = await orderItemService.updateAssetExcelOrderItems(userId, orderId, file);
    res.status(200).send(updatedRes);
  } catch (error) {
    next(error);
  }
};
