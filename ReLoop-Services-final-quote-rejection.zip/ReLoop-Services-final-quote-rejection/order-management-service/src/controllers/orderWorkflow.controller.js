const orderWorkflowService = require('../services/orderWorkflow.service');

/*
  @desc controller functionto create order workflow
*/
exports.createOrderWorkflow = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { orderId } = req.params;
    const workflowData = req.body;
    const orderWorkflow = await orderWorkflowService.createOrderWorkflow(userId, orderId, workflowData);
    res.status(201).json(orderWorkflow);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to reset an order with initial quote approval flow
*/
exports.resetOrderToInitialQuoteWorkflow = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { orderId } = req.params;
    await orderWorkflowService.resetOrderToInitialQuoteWorkflow(userId, orderId);
    res.status(200).json({});
  } catch (error) {
    next(error);
  }
};
