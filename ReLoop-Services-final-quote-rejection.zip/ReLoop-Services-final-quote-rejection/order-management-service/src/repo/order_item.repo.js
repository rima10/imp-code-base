const Models = require('../models/index');
const { ItemUnits } = require('../models/order_item');
const ErrorTypes = require('../constants/error');

function getModelMapKey(orderItem) {
  // delimiter used here is ||
  return `${orderItem.model}||${orderItem.make}||${orderItem.itemType}`;
}

const refurbishAssetListColumns = [{
  heading: 'Equipment No',
  key: 'equipmentNumber',
  required: true,
}, {
  heading: 'Asset No',
  key: 'assetNumber',
  required: true,
}, {
  heading: 'Company Name',
  key: 'companyName',
  required: true,
}, {
  heading: 'Comapany Code',
  key: 'companyCode',
  required: true,
}, {
  heading: 'Location',
  key: 'buildingLocation',
  required: true,
}, {
  heading: 'Bond Status',
  key: 'bondStatus',
  required: true,
}, {
  heading: 'Category',
  key: 'itemType',
  required: true,
}, {
  heading: 'Make',
  key: 'make',
  required: true,
}, {
  heading: 'Model',
  key: 'model',
  required: true,
}, {
  heading: 'Manuf. Serial No.',
  key: 'manufactureSerial',
  required: true,
}, {
  heading: 'Age in Years',
  key: 'ageInYear',
  required: true,
}, {
  heading: 'Purchase Year',
  key: 'purchaseYear',
  required: true,
}, {
  heading: 'Description',
  key: 'description',
}];

const recycleAssetListColumns = [{
  heading: 'Item',
  key: 'model',
  required: true,
}, {
  heading: 'Quantity',
  key: 'itemQuantity',
  required: true,
  typeValidation: (value, row, rowIndex) => {
    if (isNaN(value)) {
      return {
        message: 'Quantity should be a number',
      };
    }
    return false;
  },
}, {
  heading: 'Unit',
  key: 'recycleItemUnit',
  required: true,
  typeValidation: (value, row, rowIndex) => {
    if (value !== ItemUnits.KG && value !== ItemUnits.PIECE) {
      return {
        message: `Unit column can only be either ${ItemUnits.KG} or ${ItemUnits.PIECE}`
      };
    }
    return false;
  },
}, {
  heading: 'Location',
  key: 'buildingLocation',
  required: true,
}, {
  heading: 'Remarks',
  key: 'description',
}];

exports.validateAssetExcelRows = (excelRows, orderType) => {
  if (!excelRows || !excelRows.length) {
    const err = new Error('Asset list cannot be empty');
    err.type = ErrorTypes.NOT_ALLOWED_EMPTY_DATA;
    throw err;
  }
  const sampleExcelRow = excelRows[0];
  if (orderType === '1') { // refurbish
    if (!sampleExcelRow['Equipment No']) {
      const err = new Error('Uploaded Asset list does not contain Refurbish Order columns');
      err.type = ErrorTypes.DATA_VALIDATION_ERR;
      throw err;
    }
  }
  if (orderType === '2') { // Recycle
    if (!sampleExcelRow.Item) {
      const err = new Error('Uploaded Asset list does not contain Recycle Order columns');
      err.type = ErrorTypes.DATA_VALIDATION_ERR;
      throw err;
    }
  }

  const assetColumns = orderType === '1' ? refurbishAssetListColumns : recycleAssetListColumns;
  const errors = [];

  const validRows = [];
  excelRows.forEach((row, rowIndex) => {
    let isAllColumnsEmpty = true;
    const rowLevelErrors = [];
    assetColumns.forEach((colItem) => {
      // required field check
      const cellValue = row[colItem.heading];
      if (colItem.required) {
        if (cellValue === null || cellValue === undefined) {
          rowLevelErrors.push({
            type: 'mandatory',
            row: rowIndex,
            columnHeading: colItem.heading,
            columnName: colItem.key,
            message: `${colItem.heading} column cannot be empty.`,
          });
          return;
        }
      }
      // if atleast one column has value in a row, its considered as an asset row
      // otherwise, errors and the whole row can be ignored
      if (cellValue) {
        isAllColumnsEmpty = false;
      }
      // data type validation
      if (colItem.typeValidation) {
        const err = colItem.typeValidation(cellValue, row, rowIndex);
        if (err) {
          rowLevelErrors.push({
            type: 'data_type',
            row: rowIndex,
            columnHeading: colItem.heading,
            columnName: colItem.key,
            message: err.message,
          });
        }
      }
    });

    // if all columns are empty, then whole row can be ignored for order item creation 
    // and also for error handling
    if (!isAllColumnsEmpty) {
      validRows.push(row);
      if (rowLevelErrors.length) {
        errors.push(...rowLevelErrors);
      }
    }
  });

  return {
    isValid: !errors.length, errors, validRows,
  };
};

exports.createOrderItems = async (excelRows, userId, orderId, orderType) => {
  const columnsMap = orderType === '1' ? refurbishAssetListColumns : recycleAssetListColumns;
  const orderItems = excelRows.map((row) => {
    const orderItem = {};
    columnsMap.forEach((colItem) => {
      orderItem[colItem.key] = row[colItem.heading] || null;
    });
    // orderId, createdBy, updatedBy
    orderItem.orderId = orderId;
    orderItem.createdByUserId = userId;
    orderItem.updatedByUserId = userId;
    return orderItem;
  });

  return Models.order_item.bulkCreate(
    Models.order_item.attributesAliasesHelper(orderItems, { method: 'in', allowNewFields: false })
  );
};

exports.getOrderItemsWithOrderQuoteItems = async (orderId, orderQuoteId) => {
  const dbres = await Models.order_item.findAll({
    where: { order_id: orderId },
    attributes: Models.order_item.attributesAliasesHelper([
      'orderItemId',
      'equipmentNumber',
      'assetNumber',
      'buildingLocation',
      'bondStatus',
      'ageInYear',
      'description',
      'model',
      'make',
      'itemType',
    ]),
    include: [{
      model: Models.order_quote_item,
      as: 'order_quote_items',
      where: { order_quote_id: orderQuoteId },
      attributes: Models.order_quote_item.attributesAliasesHelper([], { method: 'out' }),
      required: false,
    }],
  });
  // unwind the exact quote item data from array structure, if available
  const orderItemsWithQuotes = dbres.map((element) => {
    let item = { ...element.dataValues };
    if (element.dataValues.order_quote_items && element.dataValues.order_quote_items.length) {
      item = { ...item, ...element.dataValues.order_quote_items[0].dataValues };
    }
    delete item.order_quote_items;
    return item;
  });

  const modelQuoteDbRes = await Models.model_quote.findAll({
    where: {
      order_quote_id: orderQuoteId,
    },
    attributes: Models.model_quote.attributesAliasesHelper([], { method: 'out' }),
  });

  const modelQuotesMap = new Map();
  modelQuoteDbRes.forEach((item) => {
    const modelKey = getModelMapKey(item.dataValues);
    modelQuotesMap.set(modelKey, item);
  });

  orderItemsWithQuotes.forEach((item, index) => {
    const modelKey = getModelMapKey(item);
    if (modelQuotesMap.has(modelKey)) {
      orderItemsWithQuotes[index].listPrice = modelQuotesMap.get(modelKey).price;
    }
  });

  return orderItemsWithQuotes;
};

exports.deleteOrderItemsForOrder = async (orderId) => {
  const promise = Models.order_item.destroy({
    where: {
      order_id: orderId,
    },
  });
  return promise;
};
