const Models = require('../models/index');

exports.getAllOrdersByApproverId = async (approverId) => {
  const pendingOrderApprovals = await Models.order_workflow_approver.findAll(
    {
      attributes: [['order_workflow_approver_id', 'orderWorkflowApproverId'], 'status'],
      order: [
        ['order_workflow_approver_id', 'DESC'],
      ],
      include: [{
        model: Models.workflow_approver,
        attributes: [['workflow_approver_id', 'workflowApproverId']],
        as: 'workflow_approver',
        where: { approver_id: approverId },
      },
      {
        model: Models.order_workflow,
        as: 'orderWorkflow',
        attributes: [['order_id', 'orderId'], ['workflow_id', 'workflowId']],
        include: [
          {
            model: Models.order,
            as: 'order',
            attributes: [
              ['order_no', 'orderNo'],
              ['order_type', 'orderType'],
              ['total_weight', 'totalWeight'],
              ['order_position', 'orderPosition'],
            ],
          },
          {
            model: Models.workflow,
            as: 'workflow',
            attributes: [
              ['process_stage_name', 'processStageName'],
              ['process_stage_sequence', 'processStageSequence']
            ],
          }],
      }],
    },
  );
  const orderList = [];
  pendingOrderApprovals.map((orderApproval) => {
    const orderApprovalData = orderApproval.dataValues;
    const orderWorkflowData = orderApprovalData.orderWorkflow.dataValues;
    const workflowData = orderApprovalData.orderWorkflow.dataValues.workflow.dataValues;
    const orderData = orderWorkflowData.order.dataValues;

    return orderList.push({
      orderId: orderWorkflowData.orderId,
      orderNo: orderData.orderNo,
      orderType: orderData.orderType,
      totalWeight: orderData.totalWeight,
      orderPosition: orderData.orderPosition,
      processStageName: workflowData.processStageName,
      processStageSequence: workflowData.processStageSequence,
      orderWorkflowApproverId: orderApprovalData.orderWorkflowApproverId,
      workflowApproverId: orderApprovalData.workflow_approver.dataValues.workflowApproverId,
      status: orderApprovalData.status,
    });
  });
  return orderList;
};

exports.getOrderWorkflowApproverById = async (orderWorkflowApproverId) => {
  const orderWorkflowApprover = await Models.order_workflow_approver.findOne({
    where: { order_workflow_approver_id: orderWorkflowApproverId },
    attributes: Models.order_workflow_approver.attributesAliasesHelper([]),
    include: [{
      model: Models.order_workflow,
      as: 'orderWorkflow',
      attributes: Models.order_workflow.attributesAliasesHelper([]),
      include: [{
        model: Models.workflow,
        as: 'workflow',
        attributes: Models.workflow.attributesAliasesHelper([]),
      }],
    }],
  });

  const response = { ...orderWorkflowApprover.dataValues };
  response.orderWorkflow = { ...orderWorkflowApprover.dataValues.orderWorkflow.dataValues };
  response.orderWorkflow.workflow = {
    ...orderWorkflowApprover.dataValues.orderWorkflow.dataValues.workflow.dataValues,
  };
  return response;
};

exports.updateOrderWorkflowApproverById = async (id, payload) => {
  await Models.order_workflow_approver.update(payload, {
    where: { order_workflow_approver_id: id },
  });

  return exports.getOrderWorkflowApproverById(id);
};

exports.createOrderNotes = async (payload) => {
  const dbPayload = Models.order_notes.attributesAliasesHelper(payload, { method: 'in' });
  return Models.order_notes.create(dbPayload);
};

exports.createOrderWfApprover = async (workflowId, orderWorkflowId, sequence) => {
  const workflow = await Models.workflow_approver.findOne({
    where: { workflow_id: workflowId, approver_sequence: sequence },
    include: [{ model: Models.approver, as: 'approver', attributes: [['approver_email_id', 'approverEmailId']] }],
  });
  if (workflow) {
    await Models.order_workflow_approver.create({
      order_workflow_id: orderWorkflowId,
      workflow_approver_id: workflow.workflow_approver_id,
      approver_sequence: sequence,
      is_active: true,
    });
    const response = { ...workflow.dataValues };
    response.approver = { ...workflow.dataValues.approver.dataValues };
    return response;
  }
};

exports.getApprovalNotificationData = async (orderId, approverId) => {
  const order = await Models.order.findOne({
    where: { order_id: orderId },
    attributes: Models.order.attributesAliasesHelper(['orderId', 'orderNumber']),
    include: [{
      model: Models.business_partner,
      as: 'businessPartner',
      attributes: Models.business_partner.attributesAliasesHelper(['emailId']),
    }],
  });
  const approver = await Models.approver.findOne({
    where: { approver_id: approverId },
    attributes: [['approver_name', 'approverName']],
  });
  const response = {};
  response.order = { ...order.dataValues };
  response.approver = { ...approver.dataValues };
  response.receiver = { ...order.dataValues.businessPartner.dataValues };
  return response;
};

exports.getNextSequenceInApprovalWorkflow = async (orderWorkflowId, currentSequence) => {
  const orderWorkflow = await Models.order_workflow.findOne(
    {
      where: { order_workflow_id: orderWorkflowId, is_active: true },
      attributes: [['order_workflow_id', 'orderWorkflowId']],
      include: [{
        model: Models.order_workflow_approver,
        as: 'order_workflow_approvers',
        attributes: [['order_workflow_approver_id', 'orderWorkflowApporverId']],
      },
      {
        model: Models.workflow,
        as: 'workflow',
        attributes: [['workflow_id', 'workflowId']],
        include: [{
          model: Models.workflow_approver,
          as: 'workflow_approvers',
          attributes: [['workflow_approver_id', 'workflowApproverId'], ['approver_sequence', 'approverSequence']],
        }],
      }],
    },
  );
  const index = currentSequence - 1;
  const { approverSequence } = orderWorkflow.workflow.workflow_approvers[index].dataValues;
  const nextSequence = (parseInt(approverSequence, 10) + 1).toString();
  const { workflowId } = orderWorkflow.workflow.dataValues;

  const nextWorkflowApprover = await Models.workflow_approver.findOne(
    {
      where: {
        workflow_id: workflowId,
        approver_sequence: nextSequence,
      },
      attributes: [['workflow_approver_id', 'workflowApproverId']],
      include: [{ model: Models.approver, as: 'approver', attributes: [['approver_email_id', 'approverEmailId']] }],
    },
  );
  return {
    workflowId,
    nextSequence: nextWorkflowApprover ? nextSequence : undefined,
  };
};

/*
  @desc background function to calculate and update overall workflow status
  @desc iterate over all order workflow approvers
  @desc if status of all is approved set status as accepted else rejected/pending
  @param String - orderWorkflowId
  @return Array - orderList
*/
exports.updateWorkflowOverallStatus = async (orderWorkflowId) => {
  const orderWorkflowApporvers = await Models.order_workflow_approver.findAll(
    {
      where: { order_workflow_id: orderWorkflowId, is_active: true },
      attributes: ['status'],
    },
  );
  let overallStatus = 'Pending';
  let isApproved = true;

  for (let i = 0; i < orderWorkflowApporvers.length; i += 1) {
    const { status } = orderWorkflowApporvers[i];
    if (status === 'Pending') {
      isApproved = false;
      break;
    } else if (status === 'Rejected') {
      isApproved = false;
      overallStatus = status;
      break;
    }
  }
  if (isApproved) overallStatus = 'Approved';
  await Models.order_workflow.update(
    { overall_status: overallStatus },
    { where: { order_workflow_id: orderWorkflowId } },
  );
};
