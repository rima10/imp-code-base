const Models = require('../models/index');

const QuotationRepo = require('./quotation.repo');

exports.createOrderWorkflowSkeleton = async (orderId, workflowId) => {
  const workflowDbres = await Models.workflow.findOne({
    where: {
      workflow_id: workflowId,
    },
    attributes: Models.workflow.attributesAliasesHelper(['processStageSequence', 'processStageName']),
  });

  // for 5th workflow which gp appr works on accepted quote
  let currentAcceptedQuote = null;
  if (workflowDbres.dataValues.processStageSequence === '5') {
    currentAcceptedQuote = await QuotationRepo.getAcceptedQuoteForOrder(orderId, {
      orderQuoteProjection: ['quoteId'],
    });
  }

  const existingOrderWorklow = await Models.order_workflow.findOne(
    { where: { order_id: orderId, workflow_id: workflowId, is_active: true } },
  );
  if (existingOrderWorklow) {
    return existingOrderWorklow;
  }
  const OrderWorkflowDetail = await Models.order_workflow.create({
    order_id: orderId,
    workflow_id: workflowId,
    is_active: true,
    quote_id: currentAcceptedQuote ? currentAcceptedQuote.quoteId : undefined,
  });
  return OrderWorkflowDetail;
};

/**
 * get the workflow id from the account management of a particular business user
 * for a specific process type(refurbish,recycle) and
 * process sequence(order creation,order submission)
 * */

exports.getWorkflow = async (userId, processStageSequence, ProcessType) => {
  const promise = Models.workflow
    .findOne({
      where:
      {
        bp_id: userId,
        process_type_id: ProcessType,
        process_stage_sequence: processStageSequence,
      },

    });
  return promise;
};

exports.checkOrderHasRejectedWorkflow = async (orderId, processStageSequence) => {
  const currentRejectedOrderWorflow = await Models.order_workflow.findOne({
    where: {
      order_id: orderId,
      overall_status: 'Rejected',
      is_active: true,
    },
    attributes: Models.order_workflow.attributesAliasesHelper([]),
    include: [{
      model: Models.workflow,
      as: 'workflow',
      attributes: Models.workflow.attributesAliasesHelper([]),
    }, {
      model: Models.order_workflow_approver,
      as: 'order_workflow_approvers',
      attributes: Models.order_workflow_approver.attributesAliasesHelper([]),
      where: { is_active: true },
      required: false,
    }],
  });

  if (!currentRejectedOrderWorflow) return null;

  const { workflow } = currentRejectedOrderWorflow.dataValues;
  if (workflow && workflow.dataValues.processStageSequence === processStageSequence) {
    return {
      ...currentRejectedOrderWorflow.dataValues,
      workflow: currentRejectedOrderWorflow.dataValues.workflow.dataValues,
      orderWorkflowApprovers:
        currentRejectedOrderWorflow.dataValues.order_workflow_approvers.map((item) => item.dataValues),
    };
  }
  return null;
};

exports.updateOrderWorkflowPipelineInactive = async (orderWorkflowId) => {
  const payload = { is_active: false };
  await Models.order_workflow_approver.update(payload, {
    where: {
      order_workflow_id: orderWorkflowId,
    },
  });

  await Models.order_workflow.update(payload, {
    where: { order_workflow_id: orderWorkflowId },
  });

  return true;
};
