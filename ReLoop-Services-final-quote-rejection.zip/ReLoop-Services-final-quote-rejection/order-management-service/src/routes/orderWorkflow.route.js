const router = require('express').Router();
const orderWorkflowController = require('../controllers/orderWorkflow.controller');
const authUtil = require('../utils/auth.util');
const validator = require('../utils/validate.util');

module.exports = (app) => {
  /**
 * @swagger
 * /api/order/workflow/{orderId}:
 *   post:
 *    description:  Endpoint to create order workflow
 *    tags:
 *      - Order Workflow
 *    parameters:
 *       - name: orderId
 *         description: id of the order
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            properties:
 *              processStageSequence:
 *                  type: string
 *              processType:
 *                  type: string
 *      responses:
 *       200:
 *         description: Order Workflow.
 *         content:
 *           application/json:
 *             schema:
 *              type: object
 *              items:
 *                  $ref: '#/components/schemas/OrderWorkflow'
 */
  router.post('/:orderId',
    [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isGPAsset],
    validator.createOrderWorkflowValidations, validator.validate,
    orderWorkflowController.createOrderWorkflow);

  /**
* @swagger
* /api/order/workflow/resetToInitalQuote/{orderId}:
*   put:
*    description:  Endpoint to reset an order with initial quote approval flow
*    tags:
*      - Order Workflow
*    parameters:
*       - name: orderId
*         description: id of the order
*         in: path
*         required: true
*         type: string
*    responses:
*       200:
*         description: Order Workflow.
*         content:
*           application/json:
*             schema:
*              type: object
*              items:
*                  $ref: '#/components/schemas/OrderWorkflow'
*/
  router.put('/resetToInitalQuote/:orderId',
    [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isGPAsset],
    orderWorkflowController.resetOrderToInitialQuoteWorkflow);
  app.use('/api/order/workflow', router);
};
