const {
  v1: uuidv1,
} = require('uuid');
const excelToJson = require('convert-excel-to-json');
const ErrorTypes = require('../constants/error');

exports.generateUUID = function () {
  const uuid = uuidv1();
  return uuid;
};

exports.camelCaseToUnderScore = function (obj) {
  const underScoreObj = {};
  Object.keys(obj).forEach((key) => {
    const underScoreKey = key.split(/(?=[A-Z])/).join('_').toLowerCase();
    underScoreObj[underScoreKey] = obj[key];
  });
  return underScoreObj;
};

exports.convertExcelToJson = function (file) {
  const jsonArr = excelToJson({
    source: file,
  });
  const excelData = jsonArr.AssetList;

  if (!excelData) {
    const err = new Error('`AssetList` should be the sheet name in excel workbook');
    err.type = ErrorTypes.MISSING_DATA;
    throw err;
  }
  const header = excelData.shift();
  const excelRows = [];
  excelData.forEach((row) => {
    const assetRow = {};
    Object.keys(row).forEach((key) => {
      const value = row[key];
      assetRow[header[key]] = value;
    });
    excelRows.push(assetRow);
  });
  return excelRows;
};
