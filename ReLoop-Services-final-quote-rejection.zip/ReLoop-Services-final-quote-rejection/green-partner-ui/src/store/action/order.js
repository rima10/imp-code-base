import { showMessage } from './toast';
import {
    orderDocumentsLoading,
    orderDocumentsFailed,
    orderDocumentsLoaded,
    setOrderItems,
    setOrderHeaderData,
    FETCH_ORDER_LIST,
    FETCH_REFURBISH_ORDER_INFO,
    FETCH_RECYCLE_ORDER_INFO,
    FETCH_CONSOLIDATED_ORDER_INFO,
    FETCH_APPROVER,
    FETCH_ONSITE_VISIT_INFO,
    FETCH_ORDER_DOCUMENTS,
    UPLOAD_DOCUMENT,
    SCHEDULE_LOGISTICS,
    CREATE_ORDER_WORKFLOW,
    CREATE_ORDER,
    CREATE_DRAFT_ORDER,
    FETCH_ORDER_TYPE,
    FETCH_CATEGORY,
    FETCH_SUB_CATEGORY,
    FETCH_NETWORK_RECYCLERS,
    FETCH_NETWORK_OWNER
} from '../actionType';
import http from '../../utils/httpService';
import getErrorMessage from '../../utils/errorMessage';
import StatusColor from '../../asset/constants/statusColor';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

export const getOrderList = () => async (dispatch) => {
    dispatch({
        type: FETCH_ORDER_LIST,
        payload: http.get(`${API_BASE_URL}order/`, {
            withCredentials: true
        })
    });
};

export const getRefurbishOrderItemInfo = (orderId) => async (dispatch) => {
    dispatch({
        type: FETCH_REFURBISH_ORDER_INFO,
        payload: http.get(`${API_BASE_URL}order/refurbish/${orderId}`, {
            withCredentials: true
        })
    });
};

export const getRecycleOrderItemInfo = (orderId) => async (dispatch) => {
    dispatch({
        type: FETCH_RECYCLE_ORDER_INFO,
        payload: http.get(`${API_BASE_URL}order/recycle/${orderId}`, {
            withCredentials: true
        })
    });
};

export const getConsolidatedOrderItemInfo = (orderId) => async (dispatch) => {
    dispatch({
        type: FETCH_CONSOLIDATED_ORDER_INFO,
        payload: http.get(`${API_BASE_URL}order/refurbish/consolidated/${orderId}`, {
            withCredentials: true
        })
    });
};

export const setMoveToNextStep = (orderId, nextStage, orderType, addApprovers) => async (dispatch, getState) => {
    try {
        let url = `${API_BASE_URL}order/moveOrderToNextStep/${orderId}/${nextStage}`;
        if (addApprovers === false) url += '?addApprovers=false';
        await http.post(
            url,
            {},
            {
                withCredentials: true
            }
        );
        if (orderType === '1') await getRefurbishOrderItemInfo(orderId)(dispatch, getState);
        else await getRecycleOrderItemInfo(orderId)(dispatch, getState);
    } catch (error) {
        getErrorMessage(error);
    }
};

export const getApprover = (orderId, processType, sequenceNo) => async (dispatch) => {
    dispatch({
        type: FETCH_APPROVER,
        payload: http.get(
            `${API_BASE_URL}order/workflow/${orderId}?processType=${processType}&processStageSequence=${sequenceNo}`,
            {
                withCredentials: true
            }
        )
    });
};

export const getOnsiteVisitDetails = (orderId) => async (dispatch) => {
    dispatch({
        type: FETCH_ONSITE_VISIT_INFO,
        payload: http.get(`${API_BASE_URL}order/quotation/onsiteSchedule/${orderId}`, {
            withCredentials: true
        })
    });
};

export const getOrderDocuments = (orderId) => async (dispatch) => {
    dispatch({
        type: FETCH_ORDER_DOCUMENTS,
        payload: http.get(`${API_BASE_URL}order/document/${orderId}`, {
            withCredentials: true
        })
    });
};

export const downloadDocument = (orderId, key) => async (dispatch) => {
    try {
        dispatch(orderDocumentsLoading());
        const response = await http.get(`${API_BASE_URL}order/document/downloadDocument/${orderId}/${key}`, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([response.data]);
        const url = window.URL.createObjectURL(responseBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = key;
        a.click();
        dispatch(orderDocumentsLoaded());
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(orderDocumentsFailed(errorMessage));
    }
};

export const uploadDocument = (orderId, payload) => async (dispatch) => {
    dispatch(orderDocumentsLoading());
    await dispatch({
        type: UPLOAD_DOCUMENT,
        payload: http.post(`${API_BASE_URL}order/document/uploadDocument/${orderId}`, payload, {
            withCredentials: true
        })
    });
    dispatch(getOrderDocuments(orderId));
    dispatch(orderDocumentsLoaded());
    dispatch(showMessage({ message: 'Successfully uploaded the document', status: StatusColor.Positive }));
};

export const generateDCDocument = (orderId, payload) => async (dispatch) => {
    try {
        dispatch(orderDocumentsLoading());
        const response = await http.post(`${API_BASE_URL}order/document/generateDC/${orderId}`, payload, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([response.data]);
        const url = window.URL.createObjectURL(responseBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Delivery_Challan_${payload.orderNo}.pdf`;
        a.click();
        dispatch(getOrderDocuments(orderId));
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(orderDocumentsFailed(errorMessage));
    }
};

export const scheduleLogistics = (orderId, orderType, payload) => async (dispatch, getState) => {
    await dispatch({
        type: SCHEDULE_LOGISTICS,
        payload: http.post(`${API_BASE_URL}order/scheduleLogistics/${orderId}`, payload, {
            withCredentials: true
        })
    });
    dispatch(setMoveToNextStep(orderId, '6', orderType));
    dispatch(showMessage({ message: 'Successfully Scheduled the Logistics', status: StatusColor.Positive }));
};

export const createOrderWorkflow = (payload) => async (dispatch) => {
    await dispatch({
        type: CREATE_ORDER_WORKFLOW,
        payload: http.post(`${API_BASE_URL}order/workflow/${payload.orderId}`, payload, {
            withCredentials: true
        })
    });
    if (payload.processType === '1') {
        dispatch(getRefurbishOrderItemInfo(payload.orderId));
    } else {
        dispatch(getRecycleOrderItemInfo(payload.orderId));
    }
    dispatch(showMessage({ message: 'Updated Successfully', status: StatusColor.Positive }));
};

export const resendApprovalRequest = (orderId, rejectedOrderWorkflowApprId, payload) => async (dispatch) => {
    await dispatch({
        type: CREATE_ORDER_WORKFLOW,
        payload: http.post(`${API_BASE_URL}order/approval/${orderId}/resend/${rejectedOrderWorkflowApprId}`,
            payload,
            {
                withCredentials: true
            })
    });
    if (payload.processType === '1') {
        dispatch(getRefurbishOrderItemInfo(orderId));
    } else {
        dispatch(getRecycleOrderItemInfo(orderId));
    }
    dispatch(showMessage({ message: 'Approval request submitted successfully.', status: StatusColor.Positive }));
};

export const downloadAssetGradeList = (orderId, quoteId) => async () => {
    const downloadPromise = http.get(`${API_BASE_URL}order/quotation/refurbish/grading/${orderId}/${quoteId}/excel`, {
        responseType: 'arraybuffer',
        withCredentials: true
    });
    return downloadPromise;
};

export const cancelOrder = (orderId) => async (dispatch) => {
    try {
        const res = await http.patch(
            `${API_BASE_URL}order/${orderId}/cancel`,
            {},
            {
                withCredentials: true
            }
        );
        dispatch(getOrderList());
        return Promise.resolve(res);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showMessage({ message: errorMessage, status: 'Negative' }));
        return Promise.reject(error);
    }
};

export const updateAssetListFromExcel = (orderId, processType, payload) => async (dispatch) => {
    try {
        const response = await http.put(`${API_BASE_URL}order/orderItem/excel/${orderId}`, payload, {
            withCredentials: true
        });
        dispatch(setOrderItems(response.data));
        if (processType === '1') {
            dispatch(getRefurbishOrderItemInfo(orderId));
        } else {
            dispatch(getRecycleOrderItemInfo(orderId));
        }
        dispatch(showMessage({ message: 'Asset list is updated successfully', status: StatusColor.Positive }));
        return response;
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        return Promise.reject(errorMessage);
    }
};

export const updateOrderHeaderData = (orderId, payload) => async (dispatch) => {
    try {
        const response = await http.patch(`${API_BASE_URL}order/headerData/${orderId}`, payload, {
            withCredentials: true
        });
        dispatch(setOrderHeaderData(response.data));
        return Promise.resolve(response);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showMessage({ message: errorMessage, status: 'Negative' }));
        return Promise.reject(error);
    }
};

export const completeOrder = (orderId) => async (dispatch) => {
    try {
        const res = await http.patch(
            `${API_BASE_URL}order/${orderId}/complete`,
            {},
            {
                withCredentials: true
            }
        );
        dispatch(getOrderList());
        return Promise.resolve(res);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showMessage({ message: errorMessage, status: 'Negative' }));
        return Promise.reject(error);
    }
};

export const updateOrderInfo = (payload) => async (dispatch) => {
    await dispatch({
        type: CREATE_ORDER,
        payload: http.post(`${API_BASE_URL}order/`, payload, {
            withCredentials: true
        })
    });
    dispatch(getOrderList());
    dispatch(showMessage({ message: 'Successfully created the order', status: StatusColor.Positive }));
};

export const updateDraftOrderInfo = (payload) => async (dispatch) => {
    await dispatch({
        type: CREATE_DRAFT_ORDER,
        payload: http.post(`${API_BASE_URL}order/draft`, payload, {
            withCredentials: true
        })
    });
    dispatch(getOrderList());
    dispatch(showMessage({ message: 'Successfully created the draft order', status: StatusColor.Positive }));
};

export const getOrderType = () => async (dispatch) => {
    dispatch({
        type: FETCH_ORDER_TYPE,
        payload: http.get(`${API_BASE_URL}order/orderTypes`, {
            withCredentials: true
        })
    });
};

export const getCategory = () => async (dispatch) => {
    dispatch({
        type: FETCH_CATEGORY,
        payload: http.get(`${API_BASE_URL}wasteCategory/`, {
            withCredentials: true
        })
    });
};

export const getSubCategory = () => async (dispatch) => {
    dispatch({
        type: FETCH_SUB_CATEGORY,
        payload: http.get(`${API_BASE_URL}wasteCategory/subcategory/1`, {
            withCredentials: true
        })
    });
};

export const getPrivateNetworkRecyclers = () => async (dispatch) => {
    dispatch({
        type: FETCH_NETWORK_RECYCLERS,
        payload: http.get(`${API_BASE_URL}order/privatenetwork`, {
            withCredentials: true
        })
    });
};

export const getPrivateNetworkOwner = () => async (dispatch) => {
    dispatch({
        type: FETCH_NETWORK_OWNER,
        payload: http.get(`${API_BASE_URL}order/getNetworkOwner`, {
            withCredentials: true
        })
    });
};

export const resendOrderToIntialQuoteApproval = (orderId, processType) => async (dispatch) => {
    await dispatch({
        type: CREATE_ORDER_WORKFLOW,
        payload: http.put(`${API_BASE_URL}order/workflow/resetToInitalQuote/${orderId}`, {}, { withCredentials: true })
    });
    dispatch(showMessage({ message: 'Initial quote approval request is submitted successfully.', status: StatusColor.Positive }));
};
