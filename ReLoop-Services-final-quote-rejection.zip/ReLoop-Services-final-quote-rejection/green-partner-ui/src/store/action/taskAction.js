import { setUserInfo, loadInProgress, loadCompleted, setPreviewOrderItemInfo } from '../actionType';
import { getToken } from '../../utils/authUtils';
import http from '../../utils/httpService';
import getErrorMessage from '../../utils/errorMessage';
import { showMessage, showErrorMessage } from './toast';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

export const validateUser = (tokenObj) => async (dispatch, getState) => {
    try {
        const { isLoggedIn } = getState().userInfo;
        if (!isLoggedIn) {
            dispatch(loadInProgress());
            const params = {
                withCredentials: true
            };
            if (tokenObj) {
                params.headers = {
                    authorization: `Bearer ${tokenObj.idToken}`,
                    refresh: tokenObj.refreshToken
                };
            }
            await http.axiosPost(`${API_BASE_URL}auth/validate?app=gp`, null, params);
            const userData = await http.get(`${API_BASE_URL}user/cognito?bp=gp`, {
                withCredentials: true
            });
            const csrfData = await http.head(`${API_BASE_URL}getCsrf`, { withCredentials: true });
            const csrf = csrfData.headers['csrf-token'];
            dispatch(setUserInfo(userData.data, true, csrf));
            dispatch(loadCompleted());
        }
    } catch (error) {
        dispatch(setUserInfo(null, false));
        dispatch(loadCompleted());
    }
};

export const getAccessToken = () => async (dispatch, getState) => {
    const tokenObj = await getToken();
    await validateUser(tokenObj)(dispatch, getState);
};

export const logout = () => async () => {
    await http.post(`${API_BASE_URL}auth/logout`, null, {
        withCredentials: true
    });
};

export const readExcelInfo = (payload) => async (dispatch) => {
    try {
        const response = await http.post(`${API_BASE_URL}order/orderItem/readExcel`, payload, {
            withCredentials: true
        });
        if (response.data.length === 0) {
            dispatch(showMessage({ message: 'Asset list cannot be empty', status: 'Negative' }));
            throw new Error('Asset list cannot be empty');
        } else {
            dispatch(setPreviewOrderItemInfo(response.data));
        }
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        return Promise.reject(errorMessage);
    }
};

export const downloadFile = async (orderId, key) => {
    try {
        const response = await http.get(`${API_BASE_URL}order/document/downloadDocument/${orderId}/${key}`, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([response.data]);
        const url = window.URL.createObjectURL(responseBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = key;
        a.click();
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        console.log(errorMessage);
    }
};

export const getUserData = () => async (dispatch) => {
    try {
        const userData = await http.get(`${API_BASE_URL}user/cognito?bp=gp`, {
            withCredentials: true
        });
        dispatch(setUserInfo(userData.data, true));
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showErrorMessage(errorMessage));
    }
};

export const downloadPrivacyStatement = (key) => async () => {
    try {
        const downloadPromise = await http.get(`${API_BASE_URL}user/privacyStatement/${key}`, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([downloadPromise.data], { type: downloadPromise.headers['content-type'] });
        const url = window.URL.createObjectURL(responseBlob);
        window.open(url, '_blank');
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        console.log(errorMessage);
    }
};

export const getGPPersonalData = () => async () => {
    try {
        const response = await http.get(`${API_BASE_URL}user/getGPPersonalData`, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([response.data]);
        const url = window.URL.createObjectURL(responseBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `EverLoop_Personal_Data_${new Date().toLocaleString()}.xlsx`;
        a.click();
    } catch (error) {
        console.log(error);
    }
};
