import React from 'react';
import {
    Label,
    Button,
    Toolbar,
    Input,
    Table,
    TableColumn,
    ToolbarSpacer,
    TableRow,
    TableCell,
    Text,
    Select,
    Option,
    CheckBox,
    MultiComboBox,
    MultiComboBoxItem,
    TextArea,
    Loader
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';

const AccountTable = ({
    rows = [],
    columns = [],
    buttons = [],
    text,
    isLoading,
    onInputChange,
    height,
    onRowSelection,
    mode
}) => {
    const getTableStyle = () => {
        const style = { border: '1px solid #888888', overflowX: 'auto' };
        if (height) {
            style.height = height;
        }
        return style;
    };

    const getCell = (cell, rowNumber, field) => {
        switch (cell.type) {
            case 'text':
                return (
                    <Text className="tableCellText" tooltip={cell.value} wrapping style={cell?.style}>
                        {cell.value}
                    </Text>
                );
            case 'input':
                return (
                    <Input
                        type={cell.dataType ? cell.dataType : 'Text'}
                        id={field + rowNumber}
                        value={cell.value}
                        valueState={cell.valueState}
                        valueStateMessage={cell.valueStateMessage}
                        onInput={(e) => onInputChange(rowNumber, field, e)}
                    />
                );
            case 'select':
                return (
                    <Select
                        id={field + rowNumber}
                        valueState={cell.valueState}
                        valueStateMessage={cell.valueStateMessage}
                        onChange={(e) => onInputChange(rowNumber, field, e)}
                    >
                        <Option id="-1" value="-1">
                            Select a Value
                        </Option>
                        {cell.options.map((option, idx) => (
                            <Option
                                key={`${field}|${rowNumber}|${option.value}|${idx}`}
                                data-id={option.value}
                                selected={option.value === cell.value}
                            >
                                {option.text}
                            </Option>
                        ))}
                    </Select>
                );
            case 'multiComboBox':
                return (
                    <MultiComboBox
                        id={field + rowNumber}
                        valueState={cell.valueState}
                        valueStateMessage={cell.valueStateMessage}
                        onSelectionChange={(e) => onInputChange(rowNumber, field, e)}
                        placeholder={`Select ${cell.property.name}`}
                    >
                        <MultiComboBoxItem id="-1" value="-1" text={`All ${cell.property.name}`} />
                        {cell.options.map((option) => (
                            <MultiComboBoxItem
                                key={option[cell.property.id]}
                                id={option[cell.property.id]}
                                selected={option[cell.property.value] === cell.value.name}
                                text={option[cell.property.value]}
                                value={option[cell.property.value]}
                            />
                        ))}
                    </MultiComboBox>
                );
            case 'checkbox':
                return (
                    <CheckBox
                        id={field + rowNumber}
                        onChange={(e) => onInputChange(rowNumber, field, e)}
                        style={{ zoom: '0.7' }}
                        disabled={cell.readonly}
                        checked={cell.value}
                    />
                );
            case 'textarea':
                return (
                    <TextArea
                        id={field + rowNumber}
                        growing
                        growingMaxLines={5}
                        value={cell.value}
                        onChange={(e) => onInputChange(rowNumber, field, e)}
                    />
                );
            default:
                return null;
        }
    };

    const getRowCells = (row, rowIndex) =>
        Object.keys(row).map(
            (cell, idx) =>
                cell !== 'isSelected' && (
                    <TableCell style={{ verticalAlign: 'middle', width: '5rem' }} key={idx}>
                        {getCell(row[cell], rowIndex, cell)}
                    </TableCell>
                )
        );

    const getColumns = () =>
        columns.map((column, idx) => (
            <TableColumn key={idx} style={{ width: '5rem', border: '1px' }}>
                <Label style={{ fontSize: 'var(--sapFontSize)' }}>{column}</Label>
            </TableColumn>
        ));

    const renderFunction = () => (
        <div style={{ width: '100%' }}>
            {buttons.length ? (
                <Toolbar style={{ ...spacing.sapUiLargeMarginTop, fontSize: '1.1rem' }}>
                    <Label style={{ fontSize: '1rem', fontWeight: 'bold' }}>{text}</Label>
                    <ToolbarSpacer />
                    <div>
                        {buttons.map((button, idx) => (
                            <span key={button.name}>
                                {!button.hide && (
                                    <Button
                                        id={idx}
                                        onClick={button.onClick}
                                        icon={button.icon}
                                        style={{ marginLeft: '10px' }}
                                        disabled={button.disabled}
                                        design={button.design ? button.design : ''}
                                    >
                                        {button.name}
                                    </Button>
                                )}
                            </span>
                        ))}
                    </div>
                </Toolbar>
            ) : null}
            {isLoading && <Loader />}
            <Table
                style={getTableStyle()}
                stickyColumnHeader={!!height}
                noDataText="No data available"
                columns={getColumns()}
                mode={mode}
                onSelectionChange={(e) => onRowSelection(e)}
            >
                {rows.map((row, idx) => (
                    <TableRow selected={row?.isSelected?.value} id={row?.isSelected?.id} key={idx}>
                        {getRowCells(row, idx)}
                    </TableRow>
                ))}
            </Table>
        </div>
    );
    return renderFunction();
};

export default AccountTable;
