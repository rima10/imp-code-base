import React from 'react';
import PropTypes from 'prop-types';
import { Wizard, WizardStep } from '@ui5/webcomponents-react';
import Workflow from '../account/Workflow';

const WorkflowWizard = ({ steps, processTypeId, onNextClick }) => (
        <Wizard style={{ height: '400px', overflow: 'hidden' }}>
            {Object.keys(steps).map((idx) => (
                <WizardStep
                    branching
                    titleText={steps[idx].name}
                    selected={steps[idx].selected}
                    disabled={steps[idx].disabled}
                    key={idx}
                >
                    <Workflow
                        approvers={steps[idx].approvers}
                        processTypeId={processTypeId}
                        processStageName={steps[idx].name}
                        processStageSequence={idx}
                        showTable={steps[idx].showTable}
                        workflowId={steps[idx].workflowId}
                    />
                </WizardStep>
            ))}
        </Wizard>
    );

WorkflowWizard.propTypes = {
    steps: PropTypes.object,
    processTypeId: PropTypes.oneOf(['1', '2']),
    onNextClick: PropTypes.func.isRequired
};

WorkflowWizard.defaultProps = {
    steps: {}
};

export default WorkflowWizard;
