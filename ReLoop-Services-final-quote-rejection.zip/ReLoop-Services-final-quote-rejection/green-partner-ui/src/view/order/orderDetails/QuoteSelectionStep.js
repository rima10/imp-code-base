import React, { useRef, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Button, Toolbar, ToolbarSpacer, Label } from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import { useHistory } from 'react-router-dom';
import moment from 'moment';
import CalendarDialog from '../../common/CalendarDialog';
import AccountTable from '../../common/Table';
import { getApprover, createOrderWorkflow } from '../../../store/action/order';
import { acceptQuote, rejectQuote, temporaryAcceptQuote } from '../../../store/action/quote';
import { showMessage } from '../../../store/action/toast';
import RecycleQuotesTable from './RecycleQuotesTable';
import RefurbishQuotesTable from './RefurbishQuotesTable';
import { getOrderItemData, getOrderItemQuoteData, getOrderApproverStep3Data } from '../../../selectors/common';
import StatusColor from '../../../asset/constants/statusColor';

const QuoteSelection = ({
    orderItemInfo,
    approver,
    orderId,
    orderType,
    orderQuotation,
    totalWeight,
    startGetApprover,
    startAcceptQuote,
    startShowMessage,
    startCreateOrderWorkflow,
    currentSequence
}) => {
    const dialogRef = useRef(null);
    const history = useHistory();
    const [approverRows, setApproverRows] = useState([]);
    const approverColumns = ['Sequence', 'Approver Role', 'Approver Name', 'Approval Status', 'Comments'];

    const processStageSequence = 3;
    const getApproverActivityId = (workflowApprover) =>
        `pss_${processStageSequence}|gpapp_${workflowApprover.approverId}|wkappid_${workflowApprover.workflowApproverId}`;
    const getApproverDetails = (approvers) => {
        const newRows = [];
        approvers.sort((a, b) => a.approverSequence - b.approverSequence);
        approvers.forEach((apprItem) => {
            const row = [];
            row.push({ name: approverColumns[0], value: apprItem.approverSequence, type: 'text' });
            row.push({ name: approverColumns[1], value: apprItem.approverRole, type: 'text' });
            row.push({ name: approverColumns[2], value: apprItem.approverName, type: 'text' });
            row.push({ name: approverColumns[3], value: apprItem.status, type: 'text' });

            const approverComments = orderItemInfo.orderNotes.find(
                (item) => (item.activity_identifier === getApproverActivityId(apprItem)
                    && (apprItem.status === 'Approved' || apprItem.status === 'Rejected'))
            );
            row.push({
                name: approverColumns[4],
                value: approverComments ? approverComments.comment : '-',
                type: 'text'
            });
            newRows.push(row);
        });
        return newRows;
    };

    useEffect(() => {
        if (approver.length !== 0) {
            const row = getApproverDetails(approver);
            setApproverRows(row);
        }
    }, [approver]);

    useEffect(() => {
        startGetApprover(orderId, orderType, '3');
    }, []);

    const onCancel = () => {
        dialogRef.current.close();
    };

    const onSubmit = (calendarPayload) => {
        const { date, time, estimatedTime, comment } = calendarPayload;
        let formattedDate = new Date(`${date} ${time}`);
        formattedDate = formattedDate.toISOString();
        const payload = {
            scheduledOnsiteDate: formattedDate,
            estimatedTime,
            comment
        };
        startAcceptQuote(orderId, payload);
        dialogRef.current.close();
        startShowMessage({
            message: `A confirmation about the selected Quote has been sent to the recycler`,
            status: StatusColor.Positive
        });
        history.push('/order/previousOrder');
    };

    const onAcceptClick = () => {
        dialogRef.current.show();
    };

    const onSubmitForInternalApproval = () => {
        const payload = {
            orderId,
            processStageSequence,
            processType: orderType
        };
        startCreateOrderWorkflow(payload);
    };

    const renderFooterButton = () => {
        const btnData = {
            text: 'Schedule Onsite Visit',
            onClick: onAcceptClick,
            disabled: true
        };
        if (approver.length !== 0) {
            const notAssigned = approver.every((app) => app.status === 'Not Assigned');
            const approved = approver.every((app) => app.status === 'Approved');
            if (notAssigned) {
                btnData.text = 'Send Quotes for Internal Approval';
                btnData.onClick = onSubmitForInternalApproval;
                if (orderQuotation.quotesData && orderQuotation.quotesData.length) {
                    btnData.disabled = false;
                }
            } else if (
                approved &&
                (orderQuotation.quotesOverallStatus === 'Accepted' ||
                    orderQuotation.quotesOverallStatus === 'Temporarily Accepted')
            ) {
                btnData.disabled = false;
            }
        } else if (!approver.length && orderQuotation.quotesOverallStatus === 'Temporarily Accepted') {
            btnData.disabled = false;
        }
        if (currentSequence >= 4) {
            btnData.disabled = true;
        }
        return (
            <Button design="Emphasized" disabled={btnData.disabled} onClick={btnData.onClick}>
                {btnData.text}
            </Button>
        );
    };

    const calendarOptions = {
        minDate: moment().format('YYYY-MM-DD'),
        dateRequired: true,
        timeRequired: true,
        estimatedTimeRequired: true
    };

    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <Label style={{ fontSize: '1rem', fontWeight: 'bold', marginBottom: '10px' }}>Quotes From Recyclers</Label>
            {orderType === '1' ? (
                <RefurbishQuotesTable
                    currentSequence={currentSequence}
                    orderType={orderType}
                    orderId={orderId}
                    orderQuotation={orderQuotation}
                    approverLength={approverRows.length}
                />
            ) : (
                <RecycleQuotesTable
                    currentSequence={currentSequence}
                    orderType={orderType}
                    orderId={orderId}
                    orderQuotation={orderQuotation}
                    approverLength={approverRows.length}
                    totalWeight={totalWeight}
                />
            )}
            <AccountTable
                columns={approverColumns}
                edit={false}
                text="Initial Quote Approval Workflow"
                rows={approverRows}
            />
            <Toolbar toolbarStyle="Clear">
                <ToolbarSpacer />
                {renderFooterButton()}
            </Toolbar>
            <CalendarDialog
                ref={dialogRef}
                onCancel={onCancel}
                onSubmit={onSubmit}
                headerText="Schedule Onsite Visit"
                options={calendarOptions}
            />
        </div>
    );
};

const mapStateToProps = (state) => ({
    approver: getOrderApproverStep3Data(state),
    orderItemQuotation: getOrderItemQuoteData(state),
    orderItemInfo: getOrderItemData(state)
});

const mapDispatchToProps = (dispatch) => ({
    startAcceptQuote: (orderId, payload, orderType) => dispatch(acceptQuote(orderId, payload, orderType)),
    startRejectQuote: (orderId, quoteId, orderType) => dispatch(rejectQuote(orderId, quoteId, orderType)),
    startTemporaryAcceptQuote: (orderId, quoteId, orderType) =>
        dispatch(temporaryAcceptQuote(orderId, quoteId, orderType)),
    startGetApprover: (orderId, processType, sequenceNo) => dispatch(getApprover(orderId, processType, sequenceNo)),
    startShowMessage: (payload) => dispatch(showMessage(payload)),
    startCreateOrderWorkflow: (payload) => dispatch(createOrderWorkflow(payload))
});

QuoteSelection.propTypes = {
    orderItemInfo: PropTypes.instanceOf(Object).isRequired,
    orderQuotation: PropTypes.instanceOf(Object),
    currentSequence: PropTypes.string,
    approver: PropTypes.instanceOf(Array).isRequired,
    orderId: PropTypes.string,
    orderType: PropTypes.string,
    totalWeight: PropTypes.string,
    startGetApprover: PropTypes.func.isRequired,
    startTemporaryAcceptQuote: PropTypes.func.isRequired,
    startRejectQuote: PropTypes.func.isRequired,
    startAcceptQuote: PropTypes.func.isRequired,
    startShowMessage: PropTypes.func.isRequired,
    startCreateOrderWorkflow: PropTypes.func.isRequired
};

export default connect(mapStateToProps, mapDispatchToProps)(QuoteSelection);
