import React, { useRef, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Button, Toolbar, ToolbarSpacer } from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import { useHistory } from 'react-router-dom';
import moment from 'moment';
import AccountTable from '../../common/Table';
import { getApprover, scheduleLogistics, resendOrderToIntialQuoteApproval } from '../../../store/action/order';
import { getRecycleOrderItemLevelQuote } from '../../../store/action/quote';
import {
    getOrderCurrentSequence,
    getOrderApproverStep5Data,
    getQuotesData,
    getOrderItemQuoteData,
    getOnsiteDetailsData,
    getOrderItemData
} from '../../../selectors/common';
import CalendarDialog from '../../common/CalendarDialog';

const ApproveFinalQuote = ({
    orderItemInfo,
    approver,
    startGetApprover,
    orderItemQuotation,
    orderId,
    orderType,
    onSiteVisitDetails,
    startGetItemQuote,
    startScheduleLogistics,
    startResendOrderToInitialQuoteApproval,
    currentSequence,
    orderQuotation
}) => {
    const dialogRef = useRef(null);
    const history = useHistory();
    const [recyclerInfoRows, setRecyclerInfoRows] = useState([]);
    const [assetRows, setAssetRows] = useState([]);
    const assetColumns = ['Item', 'Final Quantity', 'Unit', 'Price/Unit (INR)', 'Total Price (INR)'];

    const selectedRecyclerInfoColumns = ['Selected Recycler Company', 'Total Price'];

    const [approverRows, setApproverRows] = useState([]);
    const approverColumns = ['Approver Sequence', 'Approver Role', 'Approver Name', 'Status', 'Comments'];
    const [rejectedWorkflow, setRejectedWorkflow] = useState(false);

    const getVisitDetails = () => {
        const newRows = [];
        const row = [];
        row.push({
            name: selectedRecyclerInfoColumns[0],
            value: onSiteVisitDetails.createdByBP.recyclerName,
            type: 'text',
            wrapping: true,
            style: { 'lineHeight': ' 1.5rem', '-webkit-line-clamp': 5 }
        });
        row.push({
            name: selectedRecyclerInfoColumns[1],
            value: orderItemQuotation.totalPrice,
            type: 'text'
        });
        newRows.push(row);
        return newRows;
    };

    useEffect(() => {
        if (Object.keys(onSiteVisitDetails).length !== 0) {
            const row = getVisitDetails();
            setRecyclerInfoRows(row);
        }
    }, [onSiteVisitDetails, orderItemQuotation]);

    const getOrderQuoteItemsToDisplay = (orderQuoteItems) => {
        const newRows = [];
        orderQuoteItems.forEach((orderItem) => {
            const row = [];
            row.push({ name: assetColumns[0], value: orderItem.item, type: 'text' });
            row.push({ name: assetColumns[1], value: orderItem.finalQty, type: 'text' });
            row.push({ name: assetColumns[2], value: orderItem.unit, type: 'text' });
            row.push({ name: assetColumns[3], value: orderItem.pricePerUnit, type: 'text' });
            row.push({ name: assetColumns[4], value: orderItem.totalPrice, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };

    const processStageSequence = 5;
    const getApproverActivityId = (workflowApprover) =>
        `pss_${processStageSequence}|gpapp_${workflowApprover.approverId}|wkappid_${workflowApprover.workflowApproverId}`;
    const getApproverDetails = (approvers) => {
        approvers.sort((a, b) => a.approverSequence.localeCompare(b.approverSequence));
        const newRows = [];
        approvers.forEach((appr) => {
            const row = [];
            row.push({ name: approverColumns[0], value: appr.approverSequence, type: 'text' });
            row.push({ name: approverColumns[1], value: appr.approverRole, type: 'text' });
            row.push({ name: approverColumns[2], value: appr.approverName, type: 'text' });
            row.push({ name: approverColumns[3], value: appr.status, type: 'text' });

            const approverComments = orderItemInfo.orderNotes.find(
                (item) => (item.activity_identifier === getApproverActivityId(appr)
                    && (appr.status === 'Approved' || appr.status === 'Rejected'))
            );
            row.push({
                name: approverColumns[4],
                value: approverComments ? approverComments.comment : '-',
                type: 'text'
            });
            newRows.push(row);
        });
        return newRows;
    };

    const [currentAcceptedQuote, setCurrentAcceptedQuote] = useState();
    useEffect(() => {
        const acceptedOrderQuotation = orderQuotation.find(
            (item) => item.quoteStatus === 'Accepted' && item.assetGradeSubmitted
        );
        if (acceptedOrderQuotation) {
            setCurrentAcceptedQuote(acceptedOrderQuotation);
            startGetApprover(orderId, '2', '5');
            startGetItemQuote(orderId, acceptedOrderQuotation.quoteId);
        }
    }, []);

    function checkIfWorkflowRejected() {
        if (approver) {
            const rejectedApprover = approver.find((workflowApprover) => workflowApprover.status === "Rejected");
            if (rejectedApprover) {
                setRejectedWorkflow(rejectedApprover);
            }
        }
    };

    useEffect(() => {
        if (approver && approver.length !== 0) {
            const row = getApproverDetails(approver);
            setApproverRows(row);
            checkIfWorkflowRejected();
        }
    }, [approver]);

    useEffect(() => {
        if (orderItemQuotation.orderQuoteItems) {
            const newrows = getOrderQuoteItemsToDisplay(orderItemQuotation.orderQuoteItems);
            setAssetRows(newrows);
        }
    }, [orderItemQuotation]);

    const onCancel = () => {
        dialogRef.current.close();
    };
    const onSubmit = (calendarPayload) => {
        const { date, time, logisticSpocName, logisticSpocContactNumber } = calendarPayload;
        let formattedDate = new Date(`${date} ${time}`);
        formattedDate = formattedDate.toISOString();
        const payload = {
            scheduledLogisticDate: formattedDate,
            logisticSpocName,
            logisticSpocContactNumber
        };
        startScheduleLogistics(orderId, orderType, payload);
        dialogRef.current.close();
    };
    const onScheduleClick = () => {
        dialogRef.current.show();
    };

    const onResendToInitialQuoteApproval = () => {
        startResendOrderToInitialQuoteApproval(orderId, '2')
            .then((response) => {
                history.push('/order/previousOrder');
            })
    };

    const renderButton = () => {
        const showButtons = currentSequence <= 5;
        let btnDisabled = false;
        // btn is disabled, if anyone of this below conditions are met
        if (approver && approver.length) {
            const isAllApproved = approver.filter((x) => x.status === 'Approved').length === approver.length;
            if (!isAllApproved) {
                btnDisabled = true;
            }
        }
        if (!currentAcceptedQuote) {
            btnDisabled = true;
        }
        return (
            <>
                {showButtons && (
                    <Toolbar toolbarStyle="Clear">
                        <ToolbarSpacer />
                        {
                            rejectedWorkflow &&
                            <Button design="Emphasized" onClick={onResendToInitialQuoteApproval}>
                                Resend Quotes for Internal Approval
                            </Button>
                        }
                        <Button design="Emphasized" onClick={onScheduleClick} disabled={btnDisabled}>
                            Schedule Pick up date
                        </Button>
                    </Toolbar>
                )}
            </>
        );
    };

    const calendarOptions = {
        minDate: moment().format('YYYY-MM-DD'),
        dateRequired: true,
        timeRequired: true
    };
    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <AccountTable
                columns={selectedRecyclerInfoColumns}
                edit={false}
                text="Selected Recycler"
                rows={recyclerInfoRows}
            />
            <AccountTable
                columns={assetColumns}
                edit={false}
                text="Asset List"
                rows={orderItemQuotation?.isFinalQuoteSubmitted ? assetRows : []}
            />
            <AccountTable
                text="Final Quote Approval Workflow"
                columns={approverColumns}
                edit={false}
                rows={approverRows} />
            {renderButton()}
            <CalendarDialog
                ref={dialogRef}
                onCancel={onCancel}
                onSubmit={onSubmit}
                headerText="Schedule Pickup Date for your Assets"
                showEstHours={false}
                options={calendarOptions}
            />
        </div>
    );
};

const mapStateToProps = (state) => ({
    approver: getOrderApproverStep5Data(state),
    orderItemQuotation: getOrderItemQuoteData(state),
    onSiteVisitDetails: getOnsiteDetailsData(state),
    currentSequence: getOrderCurrentSequence(state),
    orderQuotation: getQuotesData(state),
    orderItemInfo: getOrderItemData(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetApprover: (orderId, processType, sequenceNo) => dispatch(getApprover(orderId, processType, sequenceNo)),
    startGetItemQuote: (orderId, quoteId) => dispatch(getRecycleOrderItemLevelQuote(orderId, quoteId)),
    startScheduleLogistics: (orderId, orderType, payload) => dispatch(scheduleLogistics(orderId, orderType, payload)),
    startResendOrderToInitialQuoteApproval: (orderId, processType) =>
        dispatch(resendOrderToIntialQuoteApproval(orderId, processType))
});

ApproveFinalQuote.propTypes = {
    orderItemInfo: PropTypes.instanceOf(Object).isRequired,
    approver: PropTypes.instanceOf(Array).isRequired,
    startGetApprover: PropTypes.func.isRequired,
    startGetItemQuote: PropTypes.func.isRequired,
    startScheduleLogistics: PropTypes.func.isRequired,
    startResendOrderToInitialQuoteApproval: PropTypes.func.isRequired,
    orderId: PropTypes.string.isRequired,
    orderType: PropTypes.string.isRequired,
    onSiteVisitDetails: PropTypes.instanceOf(Object).isRequired,
    orderItemQuotation: PropTypes.instanceOf(Object).isRequired,
    currentSequence: PropTypes.string.isRequired,
    orderQuotation: PropTypes.instanceOf(Array).isRequired
};

export default connect(mapStateToProps, mapDispatchToProps)(ApproveFinalQuote);
