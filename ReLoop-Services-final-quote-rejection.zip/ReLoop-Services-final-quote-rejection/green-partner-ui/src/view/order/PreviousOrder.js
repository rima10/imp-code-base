import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Panel, List, CustomListItem, Label, FlexBox, Text, Bar, Icon } from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import { useHistory } from 'react-router-dom';
import { getOrderList } from '../../store/action/order';
import { getOrderListData, isOrderListLoading } from '../../selectors/common';
import LoadingIndicator from '../common/Loading';

const PreviousOrder = ({ isLoading, orderInfo, startGetOrderInfo }) => {
    useEffect(() => {
        startGetOrderInfo();
    }, []);

    const history = useHistory();

    const onSelectionChange = (orderNumber) => {
        history.push({
            pathname: `/order/previousOrder/${orderNumber}`
        });
    };

    const getDataWithSpecificStatus = (status) => orderInfo.filter((order) => order.orderPosition === status);

    const orderTypeFontColor = {
        1: '#0065c5',
        2: '#107e3e'
    };

    const uniqueStatus = [{
        status: 'Draft',
        color: '#0A6EDA'
    }, {
        status: 'In Progress',
        color: '#EC890C'
    }, {
        status: 'Completed',
        color: '#107e3e'
    }, {
        status: 'Cancelled',
        color: '#DC143C'
    }];

    return (
        <>
            {isLoading && <LoadingIndicator />}
            <Label style={{ fontSize: '1.3rem', fontWeight: 'Bold', marginBottom: '20px' }}>Previous Orders</Label>
            {uniqueStatus.map((item, index) => {
                const data = getDataWithSpecificStatus(item.status);
                return (
                    <Panel headerText={`${item.status} Orders (${data.length})`} key={index}>
                        <List
                            noDataText={`No ${item.status} Orders`}
                            mode="SingleSelect"
                            separators="All"
                            growing="Scroll"
                            onSelectionChange={(e) => onSelectionChange(e.detail.selectedItems[0].dataset.id)}
                        >
                            {data.map((order, idx) => (
                                <CustomListItem
                                    data-id={order.orderNumber}
                                    key={idx}
                                    style={{
                                        height: '5rem'
                                    }}
                                >
                                    <Bar
                                        className="active-hover"
                                        style={{
                                            height: '5rem'
                                        }}
                                        endContent={
                                            <div>
                                                <br />
                                                <span style={{ color: item.color }}>
                                                    {order.orderPosition}
                                                </span>
                                            </div>
                                        }
                                        startContent={
                                            <FlexBox>
                                                <Icon showTooltip name="order-status" tooltip="Order" />
                                                <div style={spacing.sapUiTinyMarginBeginEnd}>
                                                    <div>
                                                        <Text>{order.orderNumber}</Text>
                                                        <div style={spacing.sapUiTinyMarginTop}>
                                                            <span>
                                                                <strong
                                                                    style={{
                                                                        color: orderTypeFontColor[order.orderType]
                                                                    }}
                                                                >
                                                                    {order.orderProcessType.processTypeName}
                                                                </strong>
                                                                &nbsp;|&nbsp; {order.orderNetwork} Network
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </FlexBox>
                                        }
                                    />
                                </CustomListItem>
                            ))}
                        </List>
                    </Panel>
                );
            })}
        </>
    );
};

const mapStateToProps = (state) => ({
    orderInfo: getOrderListData(state),
    isLoading: isOrderListLoading(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetOrderInfo: () => dispatch(getOrderList())
});

PreviousOrder.propTypes = {
    orderInfo: PropTypes.instanceOf(Array).isRequired,
    isLoading: PropTypes.bool.isRequired,
    startGetOrderInfo: PropTypes.func.isRequired
};

export default connect(mapStateToProps, mapDispatchToProps)(PreviousOrder);
