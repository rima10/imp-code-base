import React, { useState, useRef } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FlexBox, Title, Button, ObjectStatus, Text, Icon, Form, FormItem, Input } from '@ui5/webcomponents-react';
import GenerateDocDialog from './GenerateDocDialog';
import UploadDocDialog from './UploadDocDialog';
import { getOrderCurrentSequence } from '../../../selectors/common';

const DocumentCard = ({
    currentSequence,
    title,
    status,
    date,
    onDownload,
    onGenerate,
    onUpload,
    createdBy,
    newDoc,
    noUpload,
    openDialog,
    docKey,
    onGenerateDC,
    type
}) => {
    const [payloadData, setPayloadData] = useState({ gst: '18', hsnCode: '8471' });
    const [genType, setGenType] = useState('');
    const docsNotToUpload = ['Form 6', 'Form 2', 'Data Destruction Certificate', 'Delivery Challan'];
    const docsToGenerate = ['Delivery Challan'];
    const getStatusData = (isIcon, status) => {
        let result = '';
        switch (status) {
            case 'Created':
                result = isIcon ? 'accept' : 'Success';
                break;
            case 'Pending':
                result = isIcon ? 'pending' : 'Warning';
                break;
            default:
                result = isIcon ? 'pending' : 'Warning';
                break;
        }
        return result;
    };
    const dialogRef = useRef(null);
    const uploadDialogRef = useRef(null);
    const onCancel = () => {
        dialogRef.current.close();
        uploadDialogRef.current.close();
    };

    const onSubmit = () => {
        dialogRef.current.close();
        uploadDialogRef.current.close();
        const updatedPayloadData = { ...payloadData };
        onGenerateDC(updatedPayloadData);
    };
    const onInputChange = (event) => {
        const { name, value } = event.target;
        const updatedDcData = { ...payloadData };
        updatedDcData[name] = value;
        setPayloadData(updatedDcData);
    };

    const onDocUpload = (payload) => {
        uploadDialogRef.current.close();
        onUpload(payload);
    };

    const onDownloadClick = (docKey, title) => {
        onDownload(docKey);
    };

    const onGenerateClick = (docKey, title) => {
        if (title === 'Delivery Challan') {
            setGenType('dc');
            onGenerate(dialogRef, docKey);
        } else onGenerate(null, docKey);
    };
    const onUploadClick = (docKey, title) => {
        openDialog(uploadDialogRef);
    };

    const getComponents = (type) => {
        if (type === 'dc') {
            return (
                <>
                    <Form>
                        <FormItem label="Delivery Challan Number">
                            <Input name="dcNo" onChange={onInputChange} />
                        </FormItem>
                        <FormItem label="HSN Code for goods">
                            <Input name="hsnCode" value="8471" onChange={onInputChange} />
                        </FormItem>
                        <FormItem label="GST (%)">
                            <Input name="gst" value="18" onChange={onInputChange} />
                        </FormItem>
                    </Form>
                </>
            );
        }
    };
    return (
        <div className="docCard">
            <FlexBox
                direction="Column"
                justifyContent="SpaceBetween"
                displayInline
                style={{ height: '100%', width: '100%' }}
                children={
                    <>
                        <Title wrappingType="Normal" tooltip={title}>{title}</Title>
                        {newDoc ? (
                            <Icon
                                name="add"
                                interactive
                                onClick={() => {
                                    onUploadClick(docKey, title);
                                }}
                                style={{ height: '8rem', width: '4rem', margin: '0 auto', color: 'rgb(8, 84, 160)' }}
                            />
                        ) : (
                            <>
                                <ObjectStatus
                                    icon={<Icon name={getStatusData(true, status)} />}
                                    state={getStatusData(false, status)}
                                    style={{ fontSize: '1rem' }}
                                >
                                    {status}
                                </ObjectStatus>

                                {status !== 'Pending' && (
                                    <Text style={{ fontSize: '1rem' }}>
                                        {`Created on: ${new Date(date).toDateString()}`}
                                    </Text>
                                )}
                                <FlexBox direction="Row" justifyContent="End">
                                    {!noUpload && !docsNotToUpload.includes(title) && (
                                        <Button
                                            icon="upload"
                                            disabled={currentSequence<=5}
                                            tooltip="Upload Document"
                                            onClick={() => {
                                                onUploadClick(docKey, title);
                                            }}
                                            style={{
                                                bottom: 0,
                                                border: 'none'
                                            }}
                                        />
                                    )}
                                    {docsToGenerate.includes(title) && (
                                        <Button
                                            icon="create-entry-time"
                                            disabled={currentSequence<=5}
                                            tooltip="Generate Document"
                                            onClick={() => {
                                                onGenerateClick(docKey, title);
                                            }}
                                            style={{
                                                bottom: 0,
                                                border: 'none'
                                            }}
                                        />
                                    )}
                                    {status !== 'Pending' && (
                                        <Button
                                            icon="download"
                                            tooltip="Download Document"
                                            onClick={() => {
                                                onDownloadClick(docKey, title);
                                            }}
                                            style={{
                                                bottom: 0,
                                                border: 'none'
                                            }}
                                        />
                                    )}
                                </FlexBox>
                            </>
                        )}
                    </>
                }
            />
            <GenerateDocDialog
                ref={dialogRef}
                onCancel={onCancel}
                onSubmit={onSubmit}
                onInputChange={onInputChange}
                headerText={`Generate Document:${title}`}
                components={getComponents(genType)}
            />
            <UploadDocDialog
                ref={uploadDialogRef}
                onCancel={onCancel}
                onSubmit={onSubmit}
                onDocUpload={onDocUpload}
                onUpload={onUpload}
                onInputChange={onInputChange}
                headerText={title}
                newDoc={newDoc}
                type={type}
            />
        </div>
    );
};
const mapStateToProps = (state) => ({
    currentSequence: getOrderCurrentSequence(state)
});

DocumentCard.propTypes = {
    title: PropTypes.string,
    status: PropTypes.string,
    date: PropTypes.string,
    onDownload: PropTypes.func,
    onGenerate: PropTypes.func,
    onUpload: PropTypes.func.isRequired,
    createdBy: PropTypes.string,
    newDoc: PropTypes.bool,
    noUpload: PropTypes.bool,
    openDialog: PropTypes.func.isRequired,
    docKey: PropTypes.string,
    onGenerateDC: PropTypes.func,
    type: PropTypes.string
};

export default connect(mapStateToProps)(DocumentCard);
