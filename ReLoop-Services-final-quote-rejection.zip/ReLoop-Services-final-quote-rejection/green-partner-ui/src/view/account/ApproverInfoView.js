import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Label, Title } from '@ui5/webcomponents-react';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport';
import bg from '../../asset/images/background-image.png';
import AccountTable from '../common/ModifiedTable';
import { getApproverInfoData, isApproverInfoLoading } from '../../selectors/common';
import { getApproverInfo, registerBPApproverInfo, deleteBPApproverInfo } from '../../store/action/account';
import validateInput from '../../validation/ApproverData';
import { camelCaseToSentence } from '../../utils/formatter';
import { showMessage } from '../../store/action/toast';
import StatusColor from '../../asset/constants/statusColor';

const ApproverInfoView = ({
    startGetApproverInfo,
    startRegisterBPApproverInfo,
    approverInfo,
    isLoading,
    startDeleteBPApproverInfo,
    startShowMessage
}) => {
    const [rows, setRows] = useState([]);
    const [isNewRow, setIsNewRow] = useState(false);
    const [rowsToDelete, setRowsToDelete] = useState([]);

    const initializeState = () => {
        setIsNewRow(false);
        setRowsToDelete([]);
    };

    const getRowsFromApproverInfo = () => {
        let existingRows = [...rows];
        existingRows = [];
        if (!approverInfo.length) {
            setRows([]);
        } else {
            approverInfo.forEach((approver) => {
                existingRows.push({
                    isSelected: {
                        id: approver.approver_id,
                        value: false
                    },
                    approverRole: {
                        value: approver.approver_role,
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    },
                    approverName: {
                        value: approver.approver_name,
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    },
                    emailAddress: {
                        value: approver.approver_email_id,
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    }
                });
            });
            setRows(existingRows);
        }
    };

    useEffect(() => {
        startGetApproverInfo();
    }, []);

    useEffect(() => {
        getRowsFromApproverInfo();
        initializeState();
    }, [approverInfo]);

    const getAddedRows = () => {
        const newRows = [];
        rows.forEach((row) => {
            if ('isNewRecord' in row.isSelected) {
                newRows.push(row);
            }
        });
        return newRows;
    };

    const checkIfRoleExists = () => {
        const existingRows = [...rows];
        const existingApproverRoles = [];
        existingRows.forEach((row) => {
            if (!('isNewRecord' in row.isSelected)) {
                existingApproverRoles.push(row.approverRole.value.trim().toLowerCase());
            }
        });
        const addedRows = getAddedRows();
        const isDuplicate = addedRows.some((val) =>
            existingApproverRoles.includes(val.approverRole.value.trim().toLowerCase())
        );
        return isDuplicate;
    };

    const saveApproverInfo = async (event) => {
        event.preventDefault();
        let isValid = true;
        const existingRows = [...rows];
        if (checkIfRoleExists()) {
            isValid = false;
            startShowMessage({
                message: 'Approver Role cannot be repeated',
                status: StatusColor.Negative
            });
        } else if (!existingRows.length) {
            isValid = false;
        } else {
            existingRows.forEach((input, idx) => {
                Object.keys(input).forEach((field) => {
                    // check to find whether value is empty for required fields
                    if (existingRows[idx][field].required && existingRows[idx][field].value === '') {
                        const fieldName = camelCaseToSentence(field);
                        existingRows[idx][field].valueState = 'Error';
                        existingRows[idx][field].valueStateMessage = <span>{fieldName} is required</span>;
                        isValid = false;
                    }
                    // check to find whether any field has error state
                    if (existingRows[idx][field].valueState === 'Error') {
                        isValid = false;
                    }
                });
            });
        }
        if (isValid) {
            const addedRows = getAddedRows();
            if (addedRows.length) {
                const payload = { approvers: [] };
                addedRows.forEach((row) => {
                    payload.approvers.push({
                        approverEmailId: row.emailAddress.value,
                        approverName: row.approverName.value,
                        approverRole: row.approverRole.value
                    });
                });
                startRegisterBPApproverInfo(payload);
            }
        } else {
            setRows(existingRows);
        }
    };

    const onInputChange = (rowIndex, field, event) => {
        const tempRows = [...rows];
        const idx = rowIndex;
        if (field !== 'isSelected') {
            let { value } = event.target;
            if (field === 'emailAddress') {
                value = value.toLowerCase();
            }
            const { isValid, errorMessage } = validateInput(value, field, tempRows[idx][field]);
            tempRows[idx][field].value = value;
            tempRows[idx][field].valueStateMessage = <span>{errorMessage}</span>;
            if (isValid) {
                tempRows[idx][field].valueState = 'None';
            } else {
                tempRows[idx][field].valueState = 'Error';
            }
        }
        setRows(tempRows);
    };

    const onAddRowClick = () => {
        setIsNewRow(true);
        const existingRows = [
            ...rows,
            {
                isSelected: {
                    isNewRecord: true,
                    value: false
                },
                approverRole: {
                    value: '',
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'input',
                    required: true
                },
                approverName: {
                    value: '',
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'input',
                    required: true
                },
                emailAddress: {
                    value: '',
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'input',
                    required: true
                }
            }
        ];
        setRows(existingRows);
    };

    const onCancel = async (event) => {
        event.preventDefault();
        initializeState();
        getRowsFromApproverInfo();
    };

    const onDeleteClick = async (event) => {
        event.preventDefault();
        if (rowsToDelete.length) {
            const payload = { approvers: [] };
            approverInfo.forEach((approver) => {
                if (rowsToDelete.includes(approver.approver_id)) {
                    payload.approvers.push({
                        approverId: approver.approver_id
                    });
                }
            });
            if (payload.approvers.length === 0 || payload.approvers.length !== rowsToDelete.length) {
                startShowMessage({
                    message: 'Unsaved Data cannot be deleted',
                    status: StatusColor.Negative
                });
            } else {
                startDeleteBPApproverInfo(payload);
            }
        }
    };

    const onRowSelection = (e) => {
        const { selectedRows } = e.detail;
        const rowsToBeDeleted = [];
        selectedRows.forEach((row) => {
            rowsToBeDeleted.push(row.id);
        });
        const currentRows = [...rows];
        currentRows.forEach((row) => {
            if (rowsToBeDeleted.includes(row.isSelected.id)) {
                // eslint-disable-next-line no-param-reassign
                row.isSelected.value = true;
            }
        });
        setRows(currentRows);
        setRowsToDelete(rowsToBeDeleted);
    };

    const buttons = [
        {
            name: 'Save',
            icon: 'save',
            onClick: saveApproverInfo,
            disabled: !isNewRow
        },
        {
            name: 'Cancel',
            icon: 'decline',
            onClick: onCancel,
            disabled: !isNewRow
        },
        {
            name: 'Add',
            icon: 'add',
            onClick: onAddRowClick,
            disabled: false
        },
        {
            name: 'Delete',
            icon: 'delete',
            onClick: onDeleteClick,
            disabled: !rowsToDelete.length
        }
    ];

    const columns = ['Approver Role', 'Approver Name', 'Approver Email ID'];

    return (
        <div style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ backgroundImage: `url(${bg})`, width: '100%', height: '270px', textAlign: 'center' }}>
                <Title
                    style={{
                        fontSize: 'x-large',
                        textAlign: 'center',
                        marginTop: '80px',
                        color: '#000000'
                    }}
                >
                    <b>Approver Information</b>
                </Title>
                <Label
                    wrappingType="Normal"
                    style={{
                        fontSize: 'large',
                        textAlign: 'center',
                        marginTop: '20px',
                        color: '#000000'
                    }}
                >
                    In case you want to create an Approval Workflow please add data about your approver team
                </Label>
            </div>
            <AccountTable
                isLoading={isLoading}
                buttons={buttons}
                columns={columns}
                rows={rows}
                onInputChange={onInputChange}
                onRowSelection={onRowSelection}
                mode="MultiSelect"
            />
        </div>
    );
};

const mapStateToProps = (state) => ({
    approverInfo: getApproverInfoData(state),
    isLoading: isApproverInfoLoading(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetApproverInfo: async () => dispatch(getApproverInfo()),
    startRegisterBPApproverInfo: (payload) => dispatch(registerBPApproverInfo(payload)),
    startDeleteBPApproverInfo: (payload) => dispatch(deleteBPApproverInfo(payload)),
    startShowMessage: (payload) => dispatch(showMessage(payload))
});

ApproverInfoView.propTypes = {
    startGetApproverInfo: PropTypes.func.isRequired,
    startRegisterBPApproverInfo: PropTypes.func.isRequired,
    approverInfo: PropTypes.instanceOf(Array),
    isLoading: PropTypes.bool.isRequired,
    startDeleteBPApproverInfo: PropTypes.func.isRequired,
    startShowMessage: PropTypes.func.isRequired
};

ApproverInfoView.defaultProps = {
    approverInfo: []
};

export default connect(mapStateToProps, mapDispatchToProps)(ApproverInfoView);
