import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Label, Title } from '@ui5/webcomponents-react';
import bg from '../../asset/images/background-image.png';
import AccountTable from '../common/Table';
import { getNetworkInfo, registerBPNetworkInfo, deleteBPNetworkInfo } from '../../store/action/account';
import { getNetworkInfoState, isNetworkInfoLoading } from '../../selectors/common';
import validateInput from '../../validation/PrivateNetworkData';
import { camelCaseToSentence } from '../../utils/formatter';
import { isEmpty } from '../../validation/common';
import StatusColor from '../../asset/constants/statusColor';
import { showMessage } from '../../store/action/toast';

const NetworkInfoView = ({
    startGetNetworkInfo,
    startRegisterBPNetworkInfo,
    networkInfo,
    isLoading,
    startDeleteBPNetworkInfo,
    startShowMessage
}) => {
    const [rows, setRows] = useState([]);
    const [isNewRow, setIsNewRow] = useState(false);
    const [rowsToDelete, setRowsToDelete] = useState([]);

    const initializeState = () => {
        setIsNewRow(false);
        setRowsToDelete([]);
    };

    const getRowsFromNetworkInfo = () => {
        let existingRows = [...rows];
        existingRows = [];
        if (!networkInfo.length) {
            setRows([]);
        } else {
            networkInfo.forEach((network) => {
                existingRows.push({
                    isSelected: {
                        value: false,
                        id: network.bp_nwk_id
                    },
                    companyName: {
                        value: network.nwk_member_business_partner.bp_username,
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    },
                    contactName: {
                        value: network.nwk_member_business_partner.account_contact_name,
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    },
                    emailAddress: {
                        value: network.nwk_member_business_partner.bp_email_id,
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    },
                    phoneNumber: {
                        value: network.nwk_member_business_partner.bp_phone_number,
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    }
                });
            });
            setRows(existingRows);
        }
    };

    useEffect(() => {
        startGetNetworkInfo();
    }, []);

    useEffect(() => {
        getRowsFromNetworkInfo();
        initializeState();
    }, [networkInfo]);

    const getAddedRows = () => {
        const newRows = [];
        rows.forEach((row) => {
            if ('isNewRecord' in row.isSelected) {
                newRows.push(row);
            }
        });
        return newRows;
    };

    const saveNetworkInfo = async (event) => {
        event.preventDefault();
        let isValid = true;
        const existingRows = [...rows];
        if (!existingRows.length) {
            isValid = false;
        } else {
            existingRows.forEach((input, idx) => {
                Object.keys(input).forEach((field) => {
                    // check to find whether value is empty for required fields
                    if (existingRows[idx][field].required && existingRows[idx][field].value === '') {
                        const fieldName = camelCaseToSentence(field);
                        existingRows[idx][field].valueState = 'Error';
                        existingRows[idx][field].valueStateMessage = <span>{fieldName} is required</span>;
                        isValid = false;
                    }
                    // check to find whether any field has error state
                    if (existingRows[idx][field].valueState === 'Error') {
                        isValid = false;
                    }
                });
            });
        }
        if (isValid) {
            const addedRows = getAddedRows();
            if (addedRows.length) {
                const payload = { pvtNwkMembers: [] };
                addedRows.forEach((row) => {
                    const phoneNumber = isEmpty(row.phoneNumber.value) ? null : row.phoneNumber.value;
                    payload.pvtNwkMembers.push({
                        emailId: row.emailAddress.value,
                        username: row.companyName.value,
                        phoneNumber,
                        contactName: row.contactName.value
                    });
                });
                startRegisterBPNetworkInfo(payload);
            }
        } else {
            setRows(existingRows);
        }
    };

    const onInputChange = (rowIndex, field, event) => {
        const tempRows = [...rows];
        const idx = rowIndex;
        if (field !== 'isSelected') {
            let { value } = event.target;
            if (field === 'emailAddress') {
                value = value.toLowerCase();
            }
            const { isValid, errorMessage } = validateInput(value, field, tempRows[idx][field]);
            tempRows[idx][field].value = value;
            tempRows[idx][field].valueStateMessage = <span>{errorMessage}</span>;
            if (isValid) {
                tempRows[idx][field].valueState = 'None';
            } else {
                tempRows[idx][field].valueState = 'Error';
            }
        }
        setRows(tempRows);
    };

    const onAddRowClick = () => {
        setIsNewRow(true);
        const existingRows = [
            ...rows,
            {
                isSelected: {
                    value: false,
                    isNewRecord: true
                },
                companyName: {
                    value: '',
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'input',
                    required: true
                },
                contactName: {
                    value: '',
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'input',
                    required: false
                },
                emailAddress: {
                    value: '',
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'input',
                    required: true
                },
                phoneNumber: {
                    value: '',
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'input',
                    required: false
                }
            }
        ];
        setRows(existingRows);
    };

    const onCancel = async (event) => {
        event.preventDefault();
        initializeState();
        getRowsFromNetworkInfo();
    };

    const onRowSelection = (e) => {
        const { selectedRows } = e.detail;
        const rowsToBeDeleted = [];
        selectedRows.forEach((row) => {
            rowsToBeDeleted.push(row.id);
        });
        const currentRows = [...rows];
        currentRows.forEach((row) => {
            if (rowsToBeDeleted.includes(row.isSelected.id)) {
                // eslint-disable-next-line no-param-reassign
                row.isSelected.value = true;
            }
        });
        setRows(currentRows);
        setRowsToDelete(rowsToBeDeleted);
    };

    const onDeleteClick = async (event) => {
        event.preventDefault();
        if (rowsToDelete.length) {
            const payload = { pvtNetworks: [] };
            networkInfo.forEach((network) => {
                if (rowsToDelete.includes(network.bp_nwk_id)) {
                    payload.pvtNetworks.push({
                        recyclerId: network.nwk_member,
                        networkId: network.bp_nwk_id
                    });
                }
            });
            if (payload.pvtNetworks.length === 0 || payload.pvtNetworks.length !== rowsToDelete.length) {
                startShowMessage({
                    message: 'Unsaved Data cannot be deleted',
                    status: StatusColor.Negative
                });
            } else {
                startDeleteBPNetworkInfo(payload);
            }
        }
    };

    const buttons = [
        {
            name: 'Save',
            icon: 'save',
            onClick: saveNetworkInfo,
            disabled: !isNewRow
        },
        {
            name: 'Cancel',
            icon: 'decline',
            onClick: onCancel,
            disabled: !isNewRow
        },
        {
            name: 'Add',
            icon: 'add',
            onClick: onAddRowClick,
            disabled: false
        },
        {
            name: 'Delete',
            icon: 'delete',
            onClick: onDeleteClick,
            disabled: !rowsToDelete.length
        }
    ];

    const columns = ['Company Name', 'Contact Name', 'Email Address', 'Phone Number'];

    return (
        <div style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ backgroundImage: `url(${bg})`, width: '100%', height: '270px', textAlign: 'center' }}>
                <Title
                    style={{
                        fontSize: 'x-large',
                        textAlign: 'center',
                        marginTop: '80px',
                        color: '#000000'
                    }}
                >
                    <b>Private Network</b>
                </Title>
                <Label
                    wrappingType="Normal"
                    style={{
                        fontSize: 'large',
                        textAlign: 'center',
                        marginTop: '20px',
                        color: '#000000'
                    }}
                >
                    Set your Private Network adding all the vendors you are currently working with
                </Label>
            </div>
            <AccountTable
                isLoading={isLoading}
                buttons={buttons}
                columns={columns}
                rows={rows}
                onInputChange={onInputChange}
                onRowSelection={onRowSelection}
                mode="MultiSelect"
            />
        </div>
    );
};

const mapStateToProps = (state) => ({
    networkInfo: getNetworkInfoState(state),
    isLoading: isNetworkInfoLoading(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetNetworkInfo: () => dispatch(getNetworkInfo()),
    startRegisterBPNetworkInfo: (payload) => dispatch(registerBPNetworkInfo(payload)),
    startDeleteBPNetworkInfo: (payload) => dispatch(deleteBPNetworkInfo(payload)),
    startShowMessage: (payload) => dispatch(showMessage(payload))
});

NetworkInfoView.propTypes = {
    startGetNetworkInfo: PropTypes.func.isRequired,
    startRegisterBPNetworkInfo: PropTypes.func.isRequired,
    startDeleteBPNetworkInfo: PropTypes.func.isRequired,
    networkInfo: PropTypes.instanceOf(Array),
    isLoading: PropTypes.bool.isRequired,
    startShowMessage: PropTypes.func.isRequired
};

NetworkInfoView.defaultProps = {
    networkInfo: []
};

export default connect(mapStateToProps, mapDispatchToProps)(NetworkInfoView);
