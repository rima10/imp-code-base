import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import {
    Label,
    Title,
    Toolbar,
    Switch,
    ToolbarSpacer,
    Table,
    TableRow,
    TableColumn,
    TableCell,
    Button,
    MultiComboBox,
    MultiComboBoxItem,
    Select,
    Option,
    Text,
    CheckBox,
    Loader
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import bg from '../../asset/images/background-image.png';
import { getServiceLocation, createServiceLocation, deleteServiceLocation } from '../../store/action/account';
import {
    getServiceLocationState,
    isServiceLocationLoading,
    getStatesInfo,
    getCitiesInfo
} from '../../selectors/common';
import { camelCaseToSentence } from '../../utils/formatter';
import { getStates, getCities } from '../../store/action/location';
import { isEmpty } from '../../validation/common';
import StatusColor from '../../asset/constants/statusColor';
import { showMessage } from '../../store/action/toast';

const ServiceLocationView = ({
    startGetServiceLocation,
    startCreateServiceLocation,
    serviceLocation,
    isLoading,
    startDeleteServiceLocation,
    states,
    cities,
    startGetStates,
    startGetCities,
    startShowMessage
}) => {
    const [rows, setRows] = useState([]);
    const [isNewRow, setIsNewRow] = useState(false);
    const [rowsToDelete, setRowsToDelete] = useState([]);
    const [isAllState, setIsAllState] = useState(false);

    const initializeState = () => {
        setIsNewRow(false);
        setRowsToDelete([]);
        setIsAllState(serviceLocation[0]?.isAllState);
    };

    const getRowsFromServiceLocation = () => {
        let existingRows = [...rows];
        existingRows = [];
        if (!serviceLocation.length) {
            setRows([]);
        } else {
            setIsAllState(serviceLocation[0].isAllState);
            if (serviceLocation[0].serviceable_states.length) {
                serviceLocation[0].serviceable_states.forEach((location) => {
                    let cityNames = [];
                    const servicableCities = location.serviceable_cities;
                    if (servicableCities.length) {
                        servicableCities.forEach((city) => {
                            cityNames.push(city.cityName);
                        });
                        // cityNames = cityNames.substring(2);
                    } else {
                        cityNames = ['All'];
                    }
                    existingRows.push({
                        isSelected: {
                            value: false,
                            id: location.stateId
                        },
                        state: {
                            value: { stateId: location.stateId, stateName: location.stateName },
                            valueState: 'None',
                            valueStateMessage: '',
                            type: 'text'
                        },
                        cities: {
                            value: cityNames,
                            valueState: 'None',
                            valueStateMessage: '',
                            type: 'text'
                        }
                    });
                });
            }
            if (serviceLocation[0].isAllState) {
                existingRows.push({
                    isSelected: {
                        value: false,
                        id: 'All'
                    },
                    state: {
                        value: { stateId: '', stateName: 'All' },
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    },
                    cities: {
                        value: ['All'],
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    }
                });
            }
            setRows(existingRows);
        }
    };

    useEffect(() => {
        startGetServiceLocation();
        startGetStates();
    }, []);

    useEffect(() => {
        const tempRows = [...rows];
        tempRows.forEach((row, idx) => {
            const { stateId } = row.state.value;
            if (cities[stateId]) {
                const cityList = cities[stateId];
                tempRows[idx].cities.options = cityList;
            }
        });
        setRows(tempRows);
    }, [cities]);

    useEffect(() => {
        getRowsFromServiceLocation();
        initializeState();
    }, [serviceLocation]);

    const getAddedRows = () => {
        const newRows = [];
        rows.forEach((row) => {
            if ('isNewRecord' in row.isSelected) {
                newRows.push(row);
            }
        });
        return newRows;
    };

    const saveNetworkInfo = async () => {
        let isValid = true;
        const tempInputBox = [...rows];
        if (isAllState) {
            isValid = true;
        } else if (!tempInputBox.length) {
            isValid = false;
        } else {
            tempInputBox.forEach((input, idx) => {
                Object.keys(input).forEach((field) => {
                    // check to find whether value is empty for required fields
                    if (field === 'cities') {
                        if (isEmpty(tempInputBox[idx][field].value)) {
                            const fieldName = camelCaseToSentence(field);
                            tempInputBox[idx][field].valueState = 'Error';
                            tempInputBox[idx][field].valueStateMessage = <span>{fieldName} is required</span>;
                            isValid = false;
                        }
                    }
                    if (field === 'state') {
                        if (!Object.values(tempInputBox[idx][field].value).some((x) => x !== null && x !== '')) {
                            const fieldName = camelCaseToSentence(field);
                            tempInputBox[idx][field].valueState = 'Error';
                            tempInputBox[idx][field].valueStateMessage = <span>{fieldName} is required</span>;
                            isValid = false;
                        }
                    }
                    // check to find whether any field has error state
                    if (tempInputBox[idx][field].valueState === 'Error') {
                        isValid = false;
                    }
                });
            });
        }
        if (isValid) {
            const addedRows = getAddedRows();
            if (addedRows.length || isAllState) {
                const payload = { countryId: '1' };
                if (isAllState) {
                    payload.isAllStateSelected = isAllState;
                } else {
                    payload.serviceLocations = [];
                    addedRows.forEach((row) => {
                        const isAllCitySelected = row.cities.isAllSelected;
                        const cityList = [];
                        if (!isAllCitySelected) {
                            row.cities.value.forEach((city) => {
                                cityList.push({
                                    cityId: city.city_id,
                                    cityName: city.city_name
                                });
                            });
                        }
                        payload.serviceLocations.push({
                            state: row.state.value.stateId,
                            stateName: row.state.value.stateName,
                            isAllCitySelected,
                            city: cityList
                        });
                    });
                }
                startCreateServiceLocation(payload);
            }
        } else {
            setRows(tempInputBox);
        }
    };

    const onInputChange = (event) => {
        const tempRows = [...rows];
        const { id } = event.target;
        const split = id.split('-');
        const field = split[0];
        const idx = split[1];
        if (field !== 'isSelected') {
            if (field === 'state') {
                const stateName = event.detail.selectedOption.attributes.value.value;
                const stateId = event.detail.selectedOption.attributes.id.value;
                tempRows[idx][field].value.stateName = stateName;
                tempRows[idx][field].value.stateId = stateId;
                tempRows[idx][field].valueState = 'None';
                tempRows[idx][field].valueStateMessage = <span />;
                // Empty the cities entry since state has changed
                tempRows[idx].cities.value = [];
                tempRows[idx].cities.isAllSelected = false;
                startGetCities(stateId);
            }
            if (field === 'cities') {
                // isAllCity checks if All Cities is selected from UI
                // let isAllCity = event.detail.items.some((element) => element.attributes.id.value === '-1');
                let isAllCity = false;
                const selectedCities = [];
                event.detail.items.forEach((selectedItem) => {
                    const id = selectedItem.attributes.id.value;
                    const { value } = selectedItem.attributes.value;
                    if (id === '-1') {
                        isAllCity = true;
                    } else {
                        selectedCities.push({ city_id: id, city_name: value });
                    }
                });
                // All Cities Option is true and Other city is deselceted
                if (tempRows[idx][field].isAllSelected && selectedCities.length < tempRows[idx][field].options.length) {
                    tempRows[idx][field].isAllSelected = false;
                    isAllCity = false;
                }
                tempRows[idx][field].value = selectedCities;
                tempRows[idx][field].valueState = 'None';
                tempRows[idx][field].valueStateMessage = <span />;
                // All Cities Option was unselected
                if (!isAllCity && tempRows[idx][field].isAllSelected) {
                    tempRows[idx][field].isAllSelected = false;
                    tempRows[idx][field].value = [];
                } else if (isAllCity) {
                    // All Cities Option was selected
                    tempRows[idx][field].isAllSelected = true;
                    tempRows[idx][field].value = tempRows[idx][field].options;
                }
            }
        }
        setRows(tempRows);
    };

    // function to check if a city is selected or not
    const isCitySelected = (cityId) =>
        rows.length && rows?.some((row) => row?.cities?.value?.some((cityObj) => cityObj.city_id === cityId));

    // function to check if a state is selected or not
    const isStateSelected = (stateId, currentRowStateId) =>
        rows.length && rows?.some((row) => row.state.value.stateId === stateId && currentRowStateId !== stateId);

    const onAddRowClick = () => {
        setIsNewRow(true);
        const existingRows = [
            ...rows,
            {
                isSelected: {
                    value: false,
                    isNewRecord: true
                },
                state: {
                    value: { stateId: '', stateName: '' },
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'select',
                    options: states
                },
                cities: {
                    value: [],
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'multiComboBox',
                    options: [],
                    isAllSelected: false
                }
            }
        ];
        setRows(existingRows);
    };

    const onCancel = async (event) => {
        event.preventDefault();
        setIsNewRow(false);
        setRowsToDelete([]);
        getRowsFromServiceLocation();
    };

    const onRowSelection = (e) => {
        const { selectedRows } = e.detail;
        const rowsToBeDeleted = [];
        selectedRows.forEach((row) => {
            rowsToBeDeleted.push(row.id);
        });
        const currentRows = [...rows];
        currentRows.forEach((row) => {
            if (rowsToBeDeleted.includes(row.isSelected.id)) {
                // eslint-disable-next-line no-param-reassign
                row.isSelected.value = true;
            }
        });
        setRows(currentRows);
        setRowsToDelete(rowsToBeDeleted);
    };

    const onDeleteClick = async (event) => {
        event.preventDefault();
        if (rowsToDelete.length) {
            let payload = { statesDetail: [], isAllState: false };
            rowsToDelete.forEach((row) => {
                if (row === 'All') {
                    payload = { statesDetail: [], isAllState: true };
                }
                payload.statesDetail.push(row);
            });
            if (payload.isAllState) {
                payload.statesDetail = [];
            }
            if (!payload.isAllState && payload.statesDetail.includes('')) {
                startShowMessage({
                    message: 'Unsaved Data cannot be deleted',
                    status: StatusColor.Negative
                });
            } else {
                startDeleteServiceLocation(payload);
            }
        }
    };

    const buttons = [
        {
            name: 'Save',
            icon: 'save',
            onClick: saveNetworkInfo,
            disabled: (!isNewRow && !isAllState) || serviceLocation[0]?.isAllState
        },
        {
            name: 'Cancel',
            icon: 'decline',
            onClick: onCancel,
            disabled: !isNewRow
        },
        {
            name: 'Add',
            icon: 'add',
            onClick: onAddRowClick,
            disabled: isAllState
        },
        {
            name: 'Delete',
            icon: 'delete',
            onClick: onDeleteClick,
            disabled: !rowsToDelete.length
        }
    ];

    const columns = ['State', 'Cities'];

    const getCell = (cell, rowNumber, field) => {
        switch (cell.type) {
            case 'text':
                return (
                    <Text className="tableCellText" tooltip={cell.value} wrapping>
                        {field === 'state' ? cell.value.stateName : cell.value?.join(', ')}
                    </Text>
                );
            case 'select':
                return (
                    <Select
                        id={`${field}-${rowNumber}`}
                        valueState={cell.valueState}
                        valueStateMessage={cell.valueStateMessage}
                        onChange={onInputChange}
                        disabled={cell.disabled}
                    >
                        <Option id="-1" value="-1">
                            Select a State
                        </Option>
                        {cell?.options?.map((option) => (
                            <Option
                                key={option.state_id}
                                id={option.state_id}
                                value={option.state_name}
                                disabled={isStateSelected(option.state_id, cell.value.stateId)}
                                selected={option.state_name === cell.value.stateName}
                            >
                                {option.state_name}
                            </Option>
                        ))}
                    </Select>
                );
            case 'multiComboBox':
                return (
                    <MultiComboBox
                        id={`${field}-${rowNumber}`}
                        valueState={cell.valueState}
                        valueStateMessage={cell.valueStateMessage}
                        onSelectionChange={onInputChange}
                        placeholder="Select Cities"
                        disabled={isAllState}
                    >
                        <MultiComboBoxItem id="-1" value="-1" text="All Cities" selected={cell.isAllSelected} />
                        {cell?.options?.map((option) => (
                            <MultiComboBoxItem
                                key={option.city_id}
                                id={option.city_id}
                                selected={isCitySelected(option.city_id)}
                                text={option.city_name}
                                value={option.city_name}
                            />
                        ))}
                    </MultiComboBox>
                );
            case 'checkbox':
                return (
                    <CheckBox
                        id={`${field}-${rowNumber}`}
                        onChange={onInputChange}
                        style={{ zoom: '0.7' }}
                        disabled={cell.readonly}
                        checked={cell.value}
                    />
                );
            default:
                return null;
        }
    };

    return (
        <div style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ backgroundImage: `url(${bg})`, width: '100%', height: '270px', textAlign: 'center' }}>
                <Title
                    style={{
                        fontSize: 'x-large',
                        textAlign: 'center',
                        marginTop: '80px',
                        color: '#000000'
                    }}
                >
                    <b>Service Locations</b>
                </Title>
                <Label
                    wrappingType="Normal"
                    style={{
                        fontSize: 'large',
                        textAlign: 'center',
                        marginTop: '20px',
                        color: '#000000'
                    }}
                >
                    Add any additional locations you are providing your services at
                </Label>
            </div>
            <Toolbar toolbarStyle="Clear">
                <ToolbarSpacer />
                <Label>Across PAN India</Label>
                <Switch
                    style={{ zoom: '0.7' }}
                    checked={isAllState}
                    onChange={() => {
                        setIsAllState(!isAllState);
                    }}
                    disabled={serviceLocation[0]?.isAllState}
                />
            </Toolbar>
            <div style={{ width: '100%' }}>
                <Toolbar style={{ ...spacing.sapUiLargeMarginTop, fontSize: '1.1rem' }}>
                    <ToolbarSpacer />
                    <div>
                        {buttons.map((button) => (
                            <Button
                                key={button.name}
                                onClick={button.onClick}
                                icon={button.icon}
                                style={{ marginLeft: '10px' }}
                                disabled={button.disabled}
                            >
                                {button.name}
                            </Button>
                        ))}
                    </div>
                </Toolbar>
                {isLoading && <Loader />}
                <Table
                    style={{ border: '1px solid #888888', overflowX: 'auto' }}
                    showNoData
                    noDataText="No data available"
                    columns={columns.map((column, idx) => (
                        <TableColumn key={idx} style={{ width: '5rem', border: '1px' }}>
                            <Label style={{ fontSize: 'var(--sapFontSize)' }}>{column}</Label>
                        </TableColumn>
                    ))}
                    mode="MultiSelect"
                    onSelectionChange={(e) => onRowSelection(e)}
                >
                    {rows.map((row, idx) => (
                        <TableRow selected={row?.isSelected?.value} id={row?.isSelected?.id} key={idx}>
                            {Object.keys(row).map(
                                (cell, id) =>
                                    cell !== 'isSelected' && (
                                        <TableCell style={{ verticalAlign: 'middle', width: '5rem' }} key={id}>
                                            {getCell(row[cell], idx, cell)}
                                        </TableCell>
                                    )
                            )}
                        </TableRow>
                    ))}
                </Table>
            </div>
        </div>
    );
};

const mapStateToProps = (state) => ({
    serviceLocation: getServiceLocationState(state),
    isLoading: isServiceLocationLoading(state),
    states: getStatesInfo(state),
    cities: getCitiesInfo(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetServiceLocation: () => dispatch(getServiceLocation()),
    startCreateServiceLocation: (payload) => dispatch(createServiceLocation(payload)),
    startDeleteServiceLocation: (payload) => dispatch(deleteServiceLocation(payload)),
    startGetStates: () => dispatch(getStates()),
    startGetCities: (stateId) => dispatch(getCities(stateId)),
    startShowMessage: (payload) => dispatch(showMessage(payload))
});

ServiceLocationView.propTypes = {
    startGetServiceLocation: PropTypes.func.isRequired,
    startCreateServiceLocation: PropTypes.func.isRequired,
    startDeleteServiceLocation: PropTypes.func.isRequired,
    startGetStates: PropTypes.func.isRequired,
    startGetCities: PropTypes.func.isRequired,
    serviceLocation: PropTypes.instanceOf(Array),
    isLoading: PropTypes.bool.isRequired,
    states: PropTypes.instanceOf(Array).isRequired,
    cities: PropTypes.instanceOf(Object).isRequired,
    startShowMessage: PropTypes.func.isRequired
};

ServiceLocationView.defaultProps = {
    serviceLocation: []
};

export default connect(mapStateToProps, mapDispatchToProps)(ServiceLocationView);
