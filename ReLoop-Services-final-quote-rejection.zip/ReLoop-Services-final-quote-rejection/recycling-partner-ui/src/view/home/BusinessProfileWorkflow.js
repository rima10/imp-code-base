import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Title, Label, FlexBox } from '@ui5/webcomponents-react';
import bg from '../../asset/images/background-image.png';
import BusinessProfileWizard from './BusinessProfileWizard';
import { getUserInfo } from '../../selectors/common';
import { isEmpty } from '../../validation/common';

const defaultSteps = {
    1: {
        name: 'Business Profile',
        selected: true,
        disabled: false
    },
    2: {
        name: 'Service Locations',
        selected: false,
        disabled: true
    },
    3: {
        name: 'Certificates',
        selected: false,
        disabled: true
    }
};

const BusinessProfileWorkflow = ({ userInfo }) => {
    const [steps, setSteps] = useState(defaultSteps);
    useEffect(() => {
        let wizardSteps = { ...defaultSteps };
        wizardSteps = {
            1: {
                name: 'Business Profile',
                selected: userInfo.profileCompletionStatus === 0,
                disabled: !(userInfo.profileCompletionStatus === 0)
            },
            2: {
                name: 'Service Locations',
                selected: userInfo.profileCompletionStatus === 1,
                disabled: !(userInfo.profileCompletionStatus === 1)
            },
            3: {
                name: 'Certificates',
                selected: userInfo.profileCompletionStatus === 2,
                disabled: !(userInfo.profileCompletionStatus === 2)
            }
        };
        if (isEmpty(userInfo.isPartOfPvtNwk) || userInfo.isPartOfPvtNwk === false) {
            wizardSteps[4] = {
                name: 'Private Network',
                selected: userInfo.profileCompletionStatus === 3,
                disabled: !(userInfo.profileCompletionStatus === 3)
            };
        }
        setSteps(wizardSteps);
    }, [userInfo.isPartOfPvtNwk, userInfo.profileCompletionStatus]);

    const onNextClick = (stepId) => {
        const newSteps = { ...steps };
        stepId = Number(stepId);
        Object.keys(newSteps).forEach((stepNo) => {
            if (stepId === Number(stepNo)) {
                newSteps[stepNo].selected = true;
                newSteps[stepNo].disabled = false;
            } else {
                newSteps[stepNo].disabled = true;
                newSteps[stepNo].selected = false;
            }
        });
        setSteps(newSteps);
    };

    return (
        <>
            <FlexBox alignItems="Center" style={{ backgroundImage: `url(${bg})`, height: '270px' }} direction="Column">
                <Title
                    style={{
                        fontSize: 'x-large',
                        textAlign: 'center',
                        marginTop: '60px',
                        color: '#000000'
                    }}
                >
                    <b>Welcome to EverLoop!</b>
                </Title>
                <Label
                    wrappingType="Normal"
                    style={{
                        fontSize: 'large',
                        textAlign: 'center',
                        marginTop: '20px',
                        color: '#000000'
                    }}
                >
                    The platform for recycling and refurbishing your electronic assets.
                </Label>
                <br />
                <Label
                    wrappingType="Normal"
                    style={{
                        fontSize: 'large',
                        textAlign: 'center',
                        color: '#000000'
                    }}
                >
                    In order to use the platform and be able to create orders, you have to pre-setup your account first.
                </Label>
            </FlexBox>
            <BusinessProfileWizard steps={steps} onNextClick={onNextClick} />
        </>
    );
};

const mapStateToProps = (state) => ({
    userInfo: getUserInfo(state)
});

BusinessProfileWorkflow.propTypes = {
    userInfo: PropTypes.instanceOf(Object).isRequired
};

export default connect(mapStateToProps)(BusinessProfileWorkflow);
