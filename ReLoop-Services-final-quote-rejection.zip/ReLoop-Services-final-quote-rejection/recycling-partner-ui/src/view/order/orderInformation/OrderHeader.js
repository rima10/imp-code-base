import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Form, FormItem, Text, Title, Link } from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import { downloadDocument } from '../../../store/action/order';
import { getOrderHeaderDataState } from '../../../selectors/common';

const OrderHeader = ({ orderHeaderData, startDownloadPicture }) => {
    const modifyDate = () => {
        if (orderHeaderData) {
            let newDate = new Date(orderHeaderData.submissionDeadline);
            newDate = newDate.toDateString();
            return newDate;
        }
        return '';
    };
    const downloadPicture = () => {
        startDownloadPicture(orderHeaderData.orderId, orderHeaderData.pictureLoc).then((response) => {
            const responseBlob = new Blob([response.data]);
            const url = window.URL.createObjectURL(responseBlob);
            const a = document.createElement('a');
            a.href = url;
            a.target = '_blank';
            a.download = orderHeaderData.pictureLoc;
            a.click();
        });
    };
    return (
        <>
            <Title level="H3" style={{ ...spacing.sapUiMediumMarginTopBottom }}>
                Order Details
            </Title>
            <Form columnsL={3} columnsM={3} columnsS={3} labelSpanM={5} style={{ ...spacing.sapUiLargeMarginBottom }}>
                <FormItem label="Category">
                    <Text style={spacing.sapUiTinyMargin}>{orderHeaderData.category}</Text>
                </FormItem>
                <FormItem label="Network">
                    <Text style={spacing.sapUiTinyMargin}>{orderHeaderData.orderNetwork}</Text>
                </FormItem>
                <FormItem label="Area">
                    <Text style={spacing.sapUiTinyMargin}>
                        {`${orderHeaderData.locCity}, ${orderHeaderData.locState}`}
                    </Text>
                </FormItem>
                <FormItem label="Subcategory">
                    <Text style={spacing.sapUiTinyMargin}>{orderHeaderData.subCategory}</Text>
                </FormItem>
                <FormItem label="Additional Information">
                    <Text style={spacing.sapUiTinyMargin}>
                        {orderHeaderData.additionalInfo == null ? 'No Information' : orderHeaderData.additionalInfo}
                    </Text>
                </FormItem>
                <FormItem label="PIN Code">
                    <Text style={spacing.sapUiTinyMargin}>{orderHeaderData.locPincode}</Text>
                </FormItem>
                <FormItem label="Quote Submission Deadline">
                    <Text style={spacing.sapUiTinyMargin}>{modifyDate()}</Text>
                </FormItem>
                <FormItem label="Picture">
                    {!orderHeaderData.pictureLoc && <Text style={spacing.sapUiTinyMargin}>No pictures</Text>}
                    {orderHeaderData.pictureLoc && (
                        <Link style={spacing.sapUiTinyMargin} target="_blank" onClick={downloadPicture}>
                            {orderHeaderData.pictureLoc}
                        </Link>
                    )}
                </FormItem>
                <FormItem label="Address">
                    <Text>{orderHeaderData.locDetails}</Text>
                </FormItem>
                {orderHeaderData.processType === 'Recycle' &&
                (<FormItem label="Total Weight">
                    <Text>{orderHeaderData.totalWeight} kg</Text>
                </FormItem> )}
            </Form>
        </>
    );
};

const mapStateToProps = (state) => ({
    orderHeaderData: getOrderHeaderDataState(state)
});

const mapDispatchToProps = (dispatch) => ({
    startDownloadPicture: (orderId, key) => dispatch(downloadDocument(orderId, key))
});

OrderHeader.propTypes = {
    orderHeaderData: PropTypes.object,
    startDownloadPicture: PropTypes.func.isRequired
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderHeader);
