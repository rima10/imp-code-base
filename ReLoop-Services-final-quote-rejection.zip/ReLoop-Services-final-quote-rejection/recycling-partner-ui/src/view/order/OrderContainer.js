import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import {
    ObjectPage,
    Breadcrumbs,
    BreadcrumbsItem,
    FlexBox,
    Title,
    Text,
    ObjectPageSection,
    DynamicPageTitle,
    DynamicPageHeader,
    ObjectStatus,
    Label
} from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import { useHistory, useParams } from 'react-router-dom';
import { getOrderHeaderData } from '../../store/action/order';
import {
    getOrderList,
    getOrderHeaderDataState,
    isOrderHeaderLoading,
    isOrderListLoading
} from '../../selectors/common';
import OrderWizardContainer from './orderInformation/OrderWizardContainer';
import OrderDocumentContainer from './orderDocumentation/OrderDocumentationContainer';
import LoadingIndicator from '../common/Loading';

const OrderContainer = ({
    orderList,
    startGetOrderHeaderData,
    orderHeaderData,
    isOrderListLoading,
    isOrderHeaderLoading
}) => {
    const { orderNumber } = useParams();
    useEffect(() => {
        if (orderList && orderList.length > 0) {
            // eslint-disable-next-line eqeqeq
            const order = orderList.find((order) => order.order_no == orderNumber);
            const id = order.order_id;
            startGetOrderHeaderData(id);
        }
    }, [orderList]);

    const history = useHistory();

    // This function is only to manipulate the date to return the time left
    const dateManipulation = () => {
        const today = new Date();
        const deadline = new Date(orderHeaderData.submissionDeadline);
        const diff = deadline - today;
        let finalString = '';
        if (diff > 0) {
            let seconds = Math.floor(diff / 1000);
            let minutes = Math.floor(seconds / 60);
            let hours = Math.floor(minutes / 60);
            let days = Math.floor(hours / 24);
            let months = Math.floor(days / 30);
            const years = Math.floor(days / 365);
            seconds %= 60;
            minutes %= 60;
            hours %= 24;
            days %= 30;
            months %= 12;
            finalString = years ? `${years}yy` : ' ';
            finalString += ` ${months}` ? `${months}m` : ' ';
            finalString += ` ${hours}` ? `${hours}h` : ' ';
            finalString += ` ${days}` ? `${days}d` : ' ';
            finalString += ` ${minutes}` ? `${minutes}min` : ' ';
        } else {
            finalString = 'Overdue';
        }
        return finalString;
    };

    if (isOrderHeaderLoading || isOrderListLoading) {
        return <LoadingIndicator />;
    }
    return (
        <ObjectPage
            style={{ height: '100%' }}
            headerContent={
                <DynamicPageHeader>
                    <FlexBox alignItems="Center" wrap="Wrap">
                        <FlexBox direction="Column">
                            <Title>Customer</Title>
                            <Text style={{ fontSize: '20px', marginTop: '1rem', color: '#0099ff' }}>
                                {orderHeaderData.bpUserName}
                            </Text>
                        </FlexBox>
                        <FlexBox direction="Column" style={{ padding: '30px' }}>
                            <Title>Total Assets</Title>
                            <Label style={{ fontSize: '20px', marginTop: '1rem', color: '#009933' }}>
                                {`${orderHeaderData.itemsCount} Assets`}
                            </Label>
                        </FlexBox>
                        <FlexBox direction="Column" style={{ padding: '30px' }}>
                            <Title>Total Price</Title>
                            <Label style={{ fontSize: '20px', marginTop: '1rem' }}>
                                {orderHeaderData.totalPrice ? orderHeaderData.totalPrice : '-'} INR
                            </Label>
                        </FlexBox>
                        <FlexBox direction="Column" style={{ padding: '30px' }}>
                            <Title>Remaining Time</Title>
                            <Text style={{ fontSize: '20px', marginTop: '1rem', color: '#ff9900' }}>
                                {dateManipulation()}
                            </Text>
                        </FlexBox>
                    </FlexBox>
                </DynamicPageHeader>
            }
            headerContentPinnable
            headerTitle={
                <DynamicPageTitle
                    breadcrumbs={
                        <Breadcrumbs onItemClick={() => history.push(`/order`)}>
                            <BreadcrumbsItem>Order Details</BreadcrumbsItem>
                            <BreadcrumbsItem>{orderNumber}</BreadcrumbsItem>
                        </Breadcrumbs>
                    }
                    header={`Order Number ${orderNumber}`}
                    subHeader={orderHeaderData?.processType}
                >
                    <ObjectStatus />
                </DynamicPageTitle>
            }
            imageShapeCircle
            selectedSectionId="orderInformation"
            showHideHeaderButton
        >
            <ObjectPageSection aria-label="Order Information" titleText="Order Information" id="orderInformation">
                <OrderWizardContainer orderHeaderData={orderHeaderData} />
            </ObjectPageSection>
            <ObjectPageSection aria-label="Order Documentation" titleText="Order Documentation" id="orderDocumentation">
                <OrderDocumentContainer />
            </ObjectPageSection>
        </ObjectPage>
    );
};

OrderContainer.propTypes = {
    orderList: PropTypes.instanceOf(Array),
    orderHeaderData: PropTypes.instanceOf(Object),
    startGetOrderHeaderData: PropTypes.func.isRequired,
    isOrderListLoading: PropTypes.bool.isRequired,
    isOrderHeaderLoading: PropTypes.bool.isRequired
};

const mapStateToProps = (state) => ({
    orderList: getOrderList(state),
    orderHeaderData: getOrderHeaderDataState(state),
    isOrderListLoading: isOrderListLoading(state),
    isOrderHeaderLoading: isOrderHeaderLoading(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetOrderHeaderData: (orderId) => dispatch(getOrderHeaderData(orderId))
});

export default connect(mapStateToProps, mapDispatchToProps)(OrderContainer);
