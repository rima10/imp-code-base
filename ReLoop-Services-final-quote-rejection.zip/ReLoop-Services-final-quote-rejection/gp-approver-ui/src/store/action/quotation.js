import {
    FETCH_ORDER_QUOTATION,
    FETCH_RECYCYLE_ITEM_LEVEL_QUOTE,
    FETCH_REFURBISH_ITEM_LEVEL_QUOTE,
    TEMPORARY_ACCEPT_QUOTE,
    REJECT_QUOTE
} from '../actionType';
import http from '../../utils/httpService';
import { showMessage } from './toast';
import StatusColor from '../../asset/constants/statusColor';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

export const getOrderQuotation = (orderId, orderType) => async (dispatch) => {
    const endpointName = orderType === '1' ? 'refurbish/initial' : 'recycle/initial';
    dispatch({
        type: FETCH_ORDER_QUOTATION,
        payload: http.get(`${API_BASE_URL}order/quotation/${endpointName}/${orderId}`, {
            withCredentials: true
        })
    });
};

export const getOrderItemLevelQuote = (orderId, quoteId, orderType) => async (dispatch) => {
    let url;
    if (orderType === '1') {
        url = `${API_BASE_URL}order/quotation/refurbish/grading/${orderId}/${quoteId}`;
    } else if (orderType === '2') {
        url = `${API_BASE_URL}order/quotation/recycle/final/${orderId}/${quoteId}`;
    }
    if (orderType === '1') {
        dispatch({
            type: FETCH_REFURBISH_ITEM_LEVEL_QUOTE,
            payload: http.get(url, {
                withCredentials: true
            })
        });
    } else if (orderType === '2') {
        dispatch({
            type: FETCH_RECYCYLE_ITEM_LEVEL_QUOTE,
            payload: http.get(url, {
                withCredentials: true
            })
        });
    }
};

export const temporaryAcceptQuote = (orderId, quoteId, orderType) => async (dispatch) => {
    await dispatch({
        type: TEMPORARY_ACCEPT_QUOTE,
        payload: http.post(
            `${API_BASE_URL}order/quotation/temporaryAcceptQuote/${orderId}/${quoteId}`,
            {},
            {
                withCredentials: true
            }
        )
    });
    dispatch(getOrderQuotation(orderId, orderType));
    dispatch(showMessage({ message: 'Successfully accepted the quote', status: StatusColor.Positive }));
};

export const rejectQuote = (orderId, quoteId, orderType) => async (dispatch) => {
    await dispatch({
        type: REJECT_QUOTE,
        payload: http.post(`${API_BASE_URL}order/quotation/rejectQuote/${orderId}/${quoteId}`, {
            withCredentials: true
        })
    });
    dispatch(getOrderQuotation(orderId, orderType));
    dispatch(showMessage({ message: 'Successfully rejected the quote', status: StatusColor.Positive }));
};
