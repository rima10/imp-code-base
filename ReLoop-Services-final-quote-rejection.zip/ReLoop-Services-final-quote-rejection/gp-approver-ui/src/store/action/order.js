import { FETCH_ORDER_LIST, FETCH_ORDER_INFO, APPROVE_REQUEST, REJECT_REQUEST } from '../actionType';
import http from '../../utils/httpService';
import { showMessage } from './toast';
import StatusColor from '../../asset/constants/statusColor';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

export const getOrderList = () => async (dispatch) => {
    dispatch({
        type: FETCH_ORDER_LIST,
        payload: http.get(`${API_BASE_URL}order/approval`, { withCredentials: true })
    });
};

export const getOrderInfo = (orderId, orderWorkflowApproverId) => async (dispatch) => {
    dispatch({
        type: FETCH_ORDER_INFO,
        payload: http.get(`${API_BASE_URL}order/approval/${orderId}/${orderWorkflowApproverId}`, { withCredentials: true })
    });
};

export const approveRequest = (orderId, orderWorkflowApproverId, payload) => async (dispatch) => {
    await dispatch({
        type: APPROVE_REQUEST,
        payload: http.post(`${API_BASE_URL}order/approval/${orderId}/approve/${orderWorkflowApproverId}`, payload, {
            withCredentials: true
        })
    });
    dispatch(showMessage({ message: 'Successfully approved the request', status: StatusColor.Positive }));
};

export const rejectRequest = (orderId, orderWorkflowApproverId, payload) => async (dispatch) => {
    await dispatch({
        type: REJECT_REQUEST,
        payload: http.post(`${API_BASE_URL}order/approval/${orderId}/reject/${orderWorkflowApproverId}`, payload, {
            withCredentials: true
        })
    });
    dispatch(showMessage({ message: 'Successfully rejected the request', status: StatusColor.Positive }));
};

export const downloadDocument = (orderId, key) => async () => {
    const response = await http.get(`${API_BASE_URL}order/document/downloadDocument/${orderId}/${key}`, {
        responseType: 'arraybuffer',
        withCredentials: true
    });
    return Promise.resolve(response);
};
