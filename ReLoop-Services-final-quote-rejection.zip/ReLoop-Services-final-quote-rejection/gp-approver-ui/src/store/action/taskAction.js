import { setUserInfo, loadInProgress, loadCompleted } from '../actionType';
import { getToken } from '../../utils/authUtils';
import http from '../../utils/httpService';
// import { getErrorMessage } from '../../utils/errorMessage';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

export const getUserData = () => async (dispatch) => {
    try {
        const response = await http.get(`${API_BASE_URL}user/cognito?approver=true`, {
            withCredentials: true
        });
        dispatch(setUserInfo(response.data, true));
        dispatch(loadCompleted());
    } catch (error) {
        dispatch(setUserInfo(null, false));
        dispatch(loadCompleted());
    }
};

export const validateUser = (tokenObj) => async (dispatch, getState) => {
    try {
        const { isLoggedIn } = getState().userInfo;
        if (!isLoggedIn) {
            dispatch(loadInProgress());
            const params = {
                withCredentials: true
            };
            if (tokenObj) {
                params.headers = {
                    authorization: `Bearer ${tokenObj.idToken}`,
                    refresh: tokenObj.refreshToken
                };
            }
            await http.axiosPost(`${API_BASE_URL}auth/validate?app=approver`, null, params);
            const userData = await http.get(`${API_BASE_URL}user/cognito?approver=true`, {
                withCredentials: true
            });
            const csrfData = await http.head(`${API_BASE_URL}getCsrf`, { withCredentials: true });
            const csrf = csrfData.headers['csrf-token'];
            dispatch(setUserInfo(userData.data, true, csrf));
            dispatch(loadCompleted());
        }
    } catch (error) {
        dispatch(setUserInfo(null, false));
        dispatch(loadCompleted());
    }
};

export const getAccessToken = () => async (dispatch, getState) => {
    const tokenObj = await getToken();
    await validateUser(tokenObj)(dispatch, getState);
};

export const logout = () => async () => {
    await http.post(`${API_BASE_URL}auth/logout`, null, {
        withCredentials: true
    });
};

export const downloadFile = async (orderId, key) => {
    try {
        const response = await http.get(`${API_BASE_URL}order/document/downloadDocument/${orderId}/${key}`, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([response.data]);
        const url = window.URL.createObjectURL(responseBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = key;
        a.click();
    } catch (error) {
        // let errorMessage = getErrorMessage(error);
        // console.log(errorMessage);
    }
};
