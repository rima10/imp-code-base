import React, { useState, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Button, Title, Text, Toolbar, ToolbarSpacer, Form, FormItem, FormGroup, ObjectStatus, Link } from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import CommentDialog from './CommentDialog';
import { getOrderInfo, approveRequest, rejectRequest } from '../../store/action/order';
import OrderCreationApprovalStep from './OrderCreationApprovalStep';
import QuoteSelectionApprovalStep from './QuoteSelectionApprovalStep';
import ApproveQuoteStep from './ApproveQuoteStep';
import { getOrderInfoState, getOrderQuotationState } from '../../selectors/common';
import StatusColor from '../../asset/constants/statusColor';
import { downloadDocument } from '../../store/action/order';

const OrderDetails = ({
    orderInfo = {},
    orderWorkflow = {},
    slot,
    startReject,
    startApprove,
    startGetOrderInfo,
    startDownloadPicture,
    orderQuotation }) => {
    const [action, setAction] = useState(null);
    const [comment, setComment] = useState();
    const [btnView, setBtnView] = useState(true);

    useEffect(() => {
        const { orderId, orderWorkflowApproverId } = orderWorkflow;
        if (orderId && orderWorkflowApproverId) {
            startGetOrderInfo(orderId, orderWorkflowApproverId);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [orderWorkflow]);

    const getStepContent = (processStageSequence) => {
        switch (processStageSequence) {
            case '1':
                return <OrderCreationApprovalStep />;
            case '3':
                return (
                    <QuoteSelectionApprovalStep
                        orderWorkflow={orderWorkflow}
                        orderType={orderWorkflow.orderType}
                        totalWeight={orderWorkflow.totalWeight}
                    />
                );
            case '5':
                return <ApproveQuoteStep orderType={orderWorkflow.orderType} />;
            default:
                return 'Unknown step';
        }
    };
    const dialogRef = useRef(null);

    const onButtonClick = (userAction) => {
        dialogRef.current.show();
        setAction(userAction);
    };

    const onCancel = () => {
        dialogRef.current.close();
    };

    const onSubmit = () => {
        dialogRef.current.close();
        const { orderId, orderWorkflowApproverId } = orderWorkflow;
        const payload = {
            comment
        };
        if (action === 'Accept') {
            startApprove(orderId, orderWorkflowApproverId, payload);
            orderWorkflow.status = 'Approved';
        } else {
            startReject(orderId, orderWorkflowApproverId, payload);
            orderWorkflow.status = 'Rejected';
        }
        setBtnView(!btnView);
    };
    const onCommentChange = (event) => {
        setComment(event.target.value);
    };

    const isApprovedActionAllowed = () => {
        if (['1', '5'].includes(orderWorkflow.processStageSequence)) return true;

        if (orderQuotation && orderQuotation.quotesData) {
            const acceptedQuote = orderQuotation.quotesData.find((quote) =>
                ['Accepted', 'Temporarily Accepted'].includes(quote.quoteStatus));
            if (acceptedQuote) return true;
        }
        return false;
    }

    const getButtons = () => {
        let approverStatus = orderWorkflow.status;
        if (orderWorkflow.orderPosition === 'Cancelled') {
            approverStatus = orderWorkflow.orderPosition;
        }
        let buttonsJSX = null;
        switch (approverStatus) {
            case 'Pending':
                buttonsJSX = (
                    <div style={{ float: 'right', margin: '3px', justifyContent: 'space-between' }}>
                        <Button
                            style={spacing.sapUiTinyMargin}
                            design="Positive"
                            icon="accept"
                            onClick={() => onButtonClick('Accept')}
                            disabled={!isApprovedActionAllowed()}
                        >
                            Approve
                        </Button>
                        <Button
                            style={spacing.sapUiTinyMargin}
                            design="Negative"
                            icon="decline"
                            disabled={['3'].includes(orderWorkflow.processStageSequence)}
                            onClick={() => onButtonClick('Reject')}
                        >
                            Reject
                        </Button>
                    </div>
                );
                break;
            case 'Approved':
                buttonsJSX = (
                    <div style={{ float: 'right', margin: '3px', justifyContent: 'space-between', display: 'flex' }}>
                        <ObjectStatus style={spacing.sapUiSmallMargin} state={StatusColor.Success}>
                            Approved
                        </ObjectStatus>
                    </div>
                );
                break;
            case 'Rejected':
                buttonsJSX = (
                    <div style={{ float: 'right', margin: '3px', justifyContent: 'space-between' }}>
                        <ObjectStatus style={spacing.sapUiTinyMargin} state={StatusColor.Error}>
                            Rejected
                        </ObjectStatus>
                    </div>
                );
                break;
            default:
                buttonsJSX = null;
        }
        return buttonsJSX;
    };

    function getColorForOrderPosition() {
        const pos = orderWorkflow.orderPosition;
        switch (pos) {
            case 'In Progress':
                return StatusColor.Warning;
            case 'Cancelled':
                return StatusColor.Error;
            case 'Completed':
                return StatusColor.Success;
            default:
                return StatusColor.None;
        }
    };
    function downloadPicture() {
        startDownloadPicture(orderInfo.orderId, orderInfo.pictureLoc).then((response) => {
            const responseBlob = new Blob([response.data]);
            const url = window.URL.createObjectURL(responseBlob);
            const a = document.createElement('a');
            a.href = url;
            a.target = '_blank';
            a.download = orderInfo.pictureLoc;
            a.click();
        });
    }
    return (
        <div slot={slot} style={spacing.sapUiMediumMarginBeginEnd}>
            <Toolbar style={spacing.sapUiTinyMarginTop}>
                <Title>Order Details : {orderInfo.orderNumber}</Title>
                <ToolbarSpacer />
                <ObjectStatus showDefaultIcon={false} state={getColorForOrderPosition()} className="sap-title-font">
                    {orderWorkflow.orderPosition}
                </ObjectStatus>
            </Toolbar>
            {getButtons()}
            <div style={{ clear: 'both' }} />
            <Form columnsL={2} columnsM={2} columnsS={2} labelSpanM={5} style={spacing.sapUiLargeMarginBottom}>
                <FormGroup>
                    <FormItem label="Order Type">
                        <Text style={spacing.sapUiTinyMargin}>{orderInfo.processType}</Text>
                    </FormItem>
                    <FormItem label="Category">
                        <Text style={spacing.sapUiTinyMargin}>{orderInfo.categoryName}</Text>
                    </FormItem>
                    <FormItem label="Subcategory">
                        <Text style={spacing.sapUiTinyMargin}>{orderInfo.subCategoryName}</Text>
                    </FormItem>
                    <FormItem label="Company Code">
                        <Text style={spacing.sapUiTinyMargin}>
                            {orderInfo && orderInfo.businessPartner ? orderInfo.businessPartner.companyCode : ''}
                        </Text>
                    </FormItem>
                    {orderInfo.totalWeight && (
                        <FormItem label="Total Weight">
                            <Text style={spacing.sapUiTinyMargin}>{`${orderInfo.totalWeight} kg`}</Text>
                        </FormItem>
                    )}
                </FormGroup>
                <FormGroup>
                    <FormItem label="Network">
                        <Text style={spacing.sapUiTinyMargin}>{orderInfo.orderNetwork} Network</Text>
                    </FormItem>
                    {orderInfo.recycleAssetType && (
                        <FormItem label="Asset Type">
                            <Text style={spacing.sapUiTinyMargin}>{orderInfo.recycleAssetType}</Text>
                        </FormItem>
                    )}
                    <FormItem label="Order Submission Deadline">
                        <Text style={spacing.sapUiTinyMargin}>
                            {orderInfo.submissionDeadline !== undefined
                                ? new Date(orderInfo.submissionDeadline).toDateString()
                                : ''}
                        </Text>
                    </FormItem>
                    <FormItem label="Additional information">
                        <Text style={spacing.sapUiTinyMargin}> {orderInfo.orderAdditionalInfo} </Text>
                    </FormItem>
                    <FormItem label="Picture">
                        {!orderInfo.pictureLoc && <Text style={spacing.sapUiTinyMargin}>No pictures</Text>}
                        {orderInfo.pictureLoc && (
                            <Link style={spacing.sapUiTinyMargin} target="_blank" onClick={downloadPicture}>
                                {orderInfo.pictureLoc}
                            </Link>
                        )}
                    </FormItem>
                </FormGroup>
            </Form>
            {getStepContent(orderWorkflow.processStageSequence)}
            <CommentDialog
                ref={dialogRef}
                onCancel={onCancel}
                onSubmit={onSubmit}
                onCommentChange={onCommentChange}
                btnText={action}
            />
        </div >
    );
};

OrderDetails.propTypes = {
    orderInfo: PropTypes.object,
    orderWorkflow: PropTypes.object,
    slot: PropTypes.string,
    startReject: PropTypes.func.isRequired,
    startApprove: PropTypes.func.isRequired,
    startGetOrderInfo: PropTypes.func.isRequired,
    orderQuotation: PropTypes.instanceOf(Object),
    startDownloadPicture: PropTypes.func.isRequired
};

const mapStateToProps = (state) => ({
    orderInfo: getOrderInfoState(state),
    orderQuotation: getOrderQuotationState(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetOrderInfo: (orderId, orderWorkflowApproverId) => dispatch(getOrderInfo(orderId, orderWorkflowApproverId)),
    startApprove: (orderId, orderWorkflowApproverId, payload) =>
        dispatch(approveRequest(orderId, orderWorkflowApproverId, payload)),
    startReject: (orderId, orderWorkflowApproverId, payload) =>
        dispatch(rejectRequest(orderId, orderWorkflowApproverId, payload)),
    startDownloadPicture: (orderId, key) => dispatch(downloadDocument(orderId, key))
});

export default connect(mapStateToProps, mapDispatchToProps)(OrderDetails);
