import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { spacing } from '@ui5/webcomponents-react-base';
import { Bar, Label, TextArea, Title } from '@ui5/webcomponents-react';
import AccountTable from '../common/Table';
import { getOrderItemLevelQuote } from '../../store/action/quotation';
import { getOrderInfoState, getOrderItemQuotationState } from '../../selectors/common';
import { isEmpty } from '../../validation/common';

const ApproveFinalQuote = ({ startGetItemQuote, orderItemQuotation, orderType, orderInfo }) => {
    const [assetRows, setAssetRows] = useState([]);
    const assetColumns = [
        'Equipment No.',
        'Asset No.',
        'Grade',
        'Blancco',
        'Report status',
        'List price',
        'To be invoiced',
        'service cost'
    ];

    const recycleAssetColumns = ['Item', 'Final Quantity', 'Unit', 'Price per Unit (INR)', 'Total Price (INR)'];

    const [totalRow, setTotalRows] = useState({ invoiceAmount: 0, serviceCost: 0 });
    const calculateTotalAmount = (assetGradeListRows, field1, field2) => {
        const totalRowCopy = { ...totalRow };
        totalRowCopy[field1] = 0;
        if (field2) {
            totalRowCopy[field2] = 0;
        }
        assetGradeListRows.forEach((item) => {
            totalRowCopy[field1] += item[field1] ? Number(item[field1]) : 0;
            if (field2) {
                totalRowCopy[field2] += item[field2] ? Number(item[field2]) : 0;
            }
        });
        if (field1) {
            totalRowCopy[field1] = Math.round(totalRowCopy[field1] * 100) / 100;
        }
        if (field2) {
            totalRowCopy[field2] = Math.round(totalRowCopy[field2] * 100) / 100;
        }
        setTotalRows(totalRowCopy);
    };

    const getOrderItemQuoteDetails = (orderQuoteItems, limit) => {
        if (!orderQuoteItems) return [];
        const limitedRows = orderQuoteItems.slice(0, limit);

        const newRows = [];
        if (orderType === '1') {
            limitedRows.forEach((orderItem) => {
                const row = [];
                row.push({ name: assetColumns[0], value: orderItem.equipmentNumber, type: 'text' });
                row.push({ name: assetColumns[1], value: orderItem.assetNumber, type: 'text' });
                row.push({ name: assetColumns[2], value: orderItem.grade, type: 'text' });
                row.push({ name: assetColumns[3], value: orderItem.dataWipeStatus, type: 'text' });
                row.push({ name: assetColumns[4], value: orderItem.reportStatus, type: 'text' });
                row.push({ name: assetColumns[5], value: orderItem.listPrice, type: 'text' });
                row.push({ name: assetColumns[7], value: orderItem.invoiceAmount, type: 'text' });
                row.push({ name: assetColumns[6], value: orderItem.serviceCost, type: 'text' });
                newRows.push(row);
            });
        } else {
            limitedRows.forEach((orderItem) => {
                const row = [];
                row.push({ name: assetColumns[0], value: orderItem.item, type: 'text' });
                row.push({ name: assetColumns[1], value: orderItem.finalQty, type: 'text' });
                row.push({ name: assetColumns[2], value: orderItem.unit, type: 'text' });
                row.push({ name: assetColumns[3], value: orderItem.pricePerUnit, type: 'text' });
                row.push({ name: assetColumns[4], value: orderItem.totalPrice, type: 'text' });
                newRows.push(row);
            });
        }
        return newRows;
    };

    const getColumns = () => (orderType === '1' ? assetColumns : recycleAssetColumns);
    const minDisplayRows = 10;
    const [minTableHeight, setMinTableHeight] = useState(undefined);

    const loadMoreAssetRows = () => {
        setAssetRows((previousRows) => [
            ...getOrderItemQuoteDetails(orderItemQuotation.orderQuoteItems, previousRows.length + minDisplayRows)
        ]);
    };

    useEffect(() => {
        if (!isEmpty(orderItemQuotation)) {
            if (orderItemQuotation.orderQuoteItems.length > minDisplayRows) {
                setMinTableHeight('400px');
            }
            const tempAssetRows = getOrderItemQuoteDetails(orderItemQuotation.orderQuoteItems, minDisplayRows);
            calculateTotalAmount(orderItemQuotation.orderQuoteItems, 'invoiceAmount', 'serviceCost');
            setAssetRows(tempAssetRows);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [orderItemQuotation]);

    useEffect(() => {
        if (!isEmpty(orderInfo)) {
            const { orderId, acceptedOrderQuote } = orderInfo;
            if (orderId && acceptedOrderQuote) {
                startGetItemQuote(orderInfo?.orderId, orderInfo?.acceptedOrderQuote?.quoteId, orderType);
            }
        }
    }, [orderInfo]);

    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <AccountTable
                text="Asset Grading List"
                columns={getColumns()}
                edit={false}
                rows={assetRows}
                lazyLoading={loadMoreAssetRows}
                height={minTableHeight}
            />
            {
                orderType === '1' &&
                <>
                    <Bar
                        startContent={
                            <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                                Total value to be Invoiced (exclude tax)
                            </Label>
                        }
                        endContent={
                            <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                                {totalRow && totalRow.invoiceAmount} INR
                            </Label>
                        }
                        style={{ background: '#f2f2f2' }}
                    />
                    <Bar
                        startContent={
                            <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>Total service costs (exclude tax) </Label>
                        }
                        endContent={
                            <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                                {totalRow && totalRow.serviceCost} INR
                            </Label>
                        }
                        style={{ background: '#f2f2f2' }}
                    />
                </>
            }
            <div style={spacing.sapUiMediumMarginTopBottom}>
                <Title style={spacing.sapUiTinyMarginBottom}>Additional comments from Recycling Partner</Title>
                <TextArea
                    readonly
                    value={orderInfo?.acceptedOrderQuote?.assetGradeComments}
                />
            </div>
        </div>
    );
};

const mapStateToProps = (state) => ({
    orderItemQuotation: getOrderItemQuotationState(state),
    orderInfo: getOrderInfoState(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetItemQuote: (orderId, quoteId, orderType) => dispatch(getOrderItemLevelQuote(orderId, quoteId, orderType))
});

ApproveFinalQuote.propTypes = {
    startGetItemQuote: PropTypes.func.isRequired,
    orderItemQuotation: PropTypes.object,
    orderType: PropTypes.string,
    orderInfo: PropTypes.object
};

export default connect(mapStateToProps, mapDispatchToProps)(ApproveFinalQuote);
