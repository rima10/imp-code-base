const path = require('path');
const HWP = require('html-webpack-plugin');
const webpack = require('webpack');
const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
const dotenv = require('dotenv').config({ path: __dirname + '/.env' });

module.exports = {
    entry: path.join(__dirname, '/src/index.js'),
    devServer: {
        historyApiFallback: true,
        hot: true,
        open: true,
        headers: {
            'X-Frame-Options': 'SAMEORIGIN'
        }
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: ['babel-loader', 'eslint-loader']
            },
            {
                test: /\.js|\.jsx$/,
                include: [path.resolve(__dirname, 'node_modules/react-jss/src')],
                exclude: /(node_modules|bower_components)/,
                use: ['babel-loader', 'eslint-loader']
            },
            {
                test: /\.(ico|svg|jpg|gif|png)$/,
                use: ['file-loader']
            },
            {
                test: /\.(ico?g)$/,
                use: ['file-loader?name=favicon.ico&publicPath=./&outputPath=./public/']
            }
        ]
    },
    plugins: [
        new webpack.DefinePlugin({
            'process.env': JSON.stringify(process.env)
        }),
        new HWP({
            favicon: './public/favicon.ico',
            template: path.join(__dirname, '/src/index.html')
        }),
        new BundleAnalyzerPlugin({
            analyzerMode: 'static',
            openAnalyzer: false
        })
    ]
};
