import React, { useState } from 'react';
import { Route, Switch, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import Home from './home/Home';
import BusinessInfo from './account/BusinessInfoRouter';
import PrivateRoute from './login/PrivateRoute';
import LoginSuccess from './login/loginSuccess';
import NewOrder from './order/NewOrder';
import NetworkInfoView from './account/NetworkInfoView';
import ApproverInfoView from './account/ApproverInfoView';
import WorkflowInfo from './account/WorkflowInfo';
import Header from './header/Header';
import NavBar from './home/NavBar';
import { Grid } from '@ui5/webcomponents-react';
import ErrorComponent from './common/Error';

const Main = ({ userInfo }) => {
    const [isSideNavOpen, setSideNavOpen] = useState(false);
    const handleSideNavCollapse = (e) => {
        setSideNavOpen(!isSideNavOpen);
    };
    return (
        <>
            <Header userName={userInfo.bp_username} handleSideNavCollapse={handleSideNavCollapse} />
            <Grid>
                <div data-layout-indent="XL0 L0 M0 S0" data-layout-span="XL1 L1 M1 S1">
                    <NavBar isSideNavOpen={isSideNavOpen} />
                </div>
                <div data-layout-indent="XL2 L0 M0 S0" data-layout-span="XL11 L11 M11 S11">
                    <Switch>
                        <Route path="/loginSuccessful">
                            <LoginSuccess />
                        </Route>
                        <PrivateRoute exact path="/newOrder" component={NewOrder} />
                        <PrivateRoute exact path="/ongoingOrder" component={Home} />
                        <PrivateRoute exact path="/completedOrder" component={Home} />
                        <PrivateRoute exact path="/businessInfo" component={BusinessInfo} />
                        <PrivateRoute exact path="/networkInfo" component={NetworkInfoView} />
                        <PrivateRoute exact path="/approverInfo" component={ApproverInfoView} />
                        <PrivateRoute exact path="/workflowInfo" component={WorkflowInfo} />
                        <PrivateRoute exact path="/dashboard" component={Home} />
                        <PrivateRoute exact path="/" component={Home} />
                        <PrivateRoute exact path="/404" component={() => <ErrorComponent text="Page Not Found" />} />
                        <Redirect from="/" to="/404" />
                    </Switch>
                </div>
            </Grid>
        </>
    );
};

const mapStateToProps = (state) => {
    return {
        userInfo: state.userInfo,
    };
};

export default connect(mapStateToProps)(Main);
