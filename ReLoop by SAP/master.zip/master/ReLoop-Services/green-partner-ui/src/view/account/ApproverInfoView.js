import React, { useState, useEffect, useRef } from 'react';
import { connect } from 'react-redux';
import { Label } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from '@ui5/webcomponents-react-base';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport.js';
import AccountTable from '../common/Table';
import {
    getApproverInfo,
    registerBPApproverInfo,
    deleteBPApproverInfo,
} from '../../store/action/taskAction';
import { getApproverInfoState } from '../../selectors/common';

const ApproverInfoView = ({
    startGetApproverInfo,
    startRegisterBPApproverInfo,
    approverInfo = {},
    startDeleteBPApproverInfo,
}) => {
    const [rows, setRows] = useState([]);
    const [selectedRow, setSelectedRow] = useState([]);
    const [newApprovers, setNewApprovers] = useState({});
    const stateRef = useRef();
    stateRef.current = selectedRow;
    const newAppRef = useRef({});
    newAppRef.current = newApprovers;

    const getRowsFromApproverInfo = (approverInfo) => {
        const newRows = [];
        if (Object.keys(approverInfo).length !== 0) {
            approverInfo.map((approver) => {
                const row = [
                    {
                        type: 'checkbox',
                        onInputChange: isRowSelected,
                        disabled: false,
                        checked: false,
                    },
                ];
                const keys = Object.keys(approver);
                keys.map((key) => {
                    if (['approver_email_id', 'approver_name', 'approver_role'].includes(key)) {
                        row.push({
                            name: key,
                            value: approver[key],
                            type: 'text',
                        });
                    }
                });
                newRows.push(row);
            });
        }
        return newRows;
    };

    const updateApproverList = (approverInfo) => {
        const newRows = getRowsFromApproverInfo(approverInfo);
        setRows(newRows);
    };

    useEffect(() => {
        startGetApproverInfo();
    }, []);

    useEffect(() => {
        updateApproverList(approverInfo);
    }, [approverInfo.length]);

    const saveApproverInfo = async (event) => {
        event.preventDefault();
        const payload = { approvers: [] };
        const approvers = newAppRef.current;
        for (const key in approvers) {
            const approver = approvers[key];
            payload.approvers.push({
                approverEmailId: approver.email,
                approverName: approver.name,
                approverRole: approver.role,
            });
        }
        startRegisterBPApproverInfo(payload);
        setNewApprovers({});
    };

    const inputChange = (event) => {
        const { slot } = event.currentTarget.parentElement.parentElement;
        const { name, value } = event.target;
        const { current } = newAppRef;
        const approvers = { ...current };
        if (approvers[slot]) approvers[slot][name] = value;
        else {
            approvers[slot] = {};
            approvers[slot][name] = value;
        }
        setNewApprovers(approvers);
    };

    const isRowSelected = (rowNumber) => {
        let row = stateRef.current;
        const index = row.indexOf(rowNumber);
        if (index > -1) {
            row.splice(index, 1);
        } else {
            row.push(rowNumber);
        }
        setSelectedRow(row);
    };

    const onAddRowClick = () => {
        const row = [];
        row.push({
            type: 'checkbox',
            onInputChange: isRowSelected,
            disabled: true,
            checked: false,
        });
        row.push({ name: 'email', value: 'email', type: 'input', onInputChange: inputChange });
        row.push({ name: 'name', value: 'name', type: 'input', onInputChange: inputChange });
        row.push({ name: 'role', value: 'role', type: 'input', onInputChange: inputChange });
        const existingRows = [...rows];
        existingRows.push(row);
        setRows(existingRows);
    };

    const onCancel = async (event) => {
        event.preventDefault();
        const newRows = getRowsFromApproverInfo(approverInfo);
        setRows(newRows);
    };

    const onDeleteClick = async (event) => {
        event.preventDefault();
        const rows = stateRef.current;
        const payload = { approvers: [] };
        rows.map((row) => {
            payload.approvers.push({
                approverId: approverInfo[row].approver_id,
            });
        });
        startDeleteBPApproverInfo(payload);
        setSelectedRow([]);
    };

    const buttons = [
        {
            name: 'Save',
            onClick: saveApproverInfo,
        },
        {
            name: 'Cancel',
            onClick: onCancel,
        },
        {
            name: 'Add',
            onClick: onAddRowClick,
        },
        {
            name: 'Delete',
            onClick: onDeleteClick,
        },
    ];

    const columns = ['', 'Approver Email ID', 'Approver Name', 'Approver Role'];

    return (
        <div style={{ display: 'flex', flexDirection: 'column', ...spacing.sapUiMediumMargin }}>
            <Label style={{ fontWeight: 'Bold' }}> Approver Information </Label>
            <AccountTable buttons={buttons} columns={columns} rows={rows} edit={false} />
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        approverInfo: getApproverInfoState(state),
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetApproverInfo: async () => dispatch(getApproverInfo()),
        startRegisterBPApproverInfo: (payload) => dispatch(registerBPApproverInfo(payload)),
        startDeleteBPApproverInfo: (payload) => dispatch(deleteBPApproverInfo(payload)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(ApproverInfoView);
