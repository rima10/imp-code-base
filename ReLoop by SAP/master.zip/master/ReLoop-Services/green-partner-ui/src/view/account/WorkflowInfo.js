import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import {
    Label,
    Panel,
    Switch,
    Toolbar,
    ToolbarSpacer,
    Title,
    Text,
} from "@ui5/webcomponents-react";
import { spacing } from "@ui5/webcomponents-react-base";
import RecyclingWorkflow from "./RecyclingWorkflow";
import RefurbishingWorkflow from "./RefurbishingWorkflow";
import { getWorkflowsInfo, getApproverInfo } from "../../store/action/taskAction";
import { getWorkflow } from "../../selectors/common";

const WorkflowInfo = ({ startGetWorkflowsInfo, startGetApproverInfo,  workflowsInfo = [] }) => {
    useEffect(() => {
        startGetWorkflowsInfo();
        startGetApproverInfo();
    }, []);
    const [isOnSiteRequestForRecycle, setIsOnSiteRequestForRecycle] = useState(true);
    const handleOnSiteRequestForRecycleToggle = () => {
        setIsOnSiteRequestForRecycle(!isOnSiteRequestForRecycle);
    };
    const [isOnSiteRequestForRefurbish, setIsOnSiteRequestForRefurbish] = useState(true);
    const handleOnSiteRequestForRefurbishToggle = () => {
        setIsOnSiteRequestForRefurbish(!isOnSiteRequestForRefurbish);
    };
    const recycleWorkflows = [];
    const refurbishWorkflows = [];
    if (workflowsInfo.length) {
        workflowsInfo.map((workflow) => {
            const { process_type_id } = workflow;
            if (process_type_id === "1") recycleWorkflows.push(workflow);
            else refurbishWorkflows.push(workflow);
        });
    }
    return (
        <div style={{ display: "flex", flexDirection: "column" }}>
            <Label style={{ fontWeight: "Bold", ...spacing.sapUiMediumMargin }} tooltip="">
                Define workflow for Approval Process
            </Label>
            <div style={spacing.sapUiMediumMargin}>
                <Panel
                    accessibleRole="Region"
                    className=""
                    headerLevel="H2"
                    headerText="Recycling"
                    header={
                        <Toolbar toolbarStyle="Clear">
                            <Text>Recycling</Text>
                            <ToolbarSpacer />
                            <Switch
                                checked={isOnSiteRequestForRecycle}
                                onChange={handleOnSiteRequestForRecycleToggle}
                            />
                        </Toolbar>
                    }
                    collapsed
                >
                    <RecyclingWorkflow
                        isOnSite={isOnSiteRequestForRecycle}
                        workflows={recycleWorkflows}
                    />
                </Panel>
                <Panel
                    accessibleRole="Region"
                    className=""
                    headerLevel="H2"
                    headerText="Refurbishing"
                    header={
                        <Toolbar toolbarStyle="Clear">
                            <Text>Refurbishing</Text>
                            <ToolbarSpacer />
                            <Switch
                                checked={isOnSiteRequestForRefurbish}
                                onChange={handleOnSiteRequestForRefurbishToggle}
                            />
                        </Toolbar>
                    }
                    collapsed
                >
                    <RefurbishingWorkflow
                        isOnSite={isOnSiteRequestForRefurbish}
                        workflows={refurbishWorkflows}
                    />
                </Panel>
            </div>
        </div>
    );
};
const mapStateToProps = (state) => {
    return {
        workflowsInfo: getWorkflow(state),
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetWorkflowsInfo: () => dispatch(getWorkflowsInfo()),
        startGetApproverInfo: () => dispatch(getApproverInfo())
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(WorkflowInfo);
