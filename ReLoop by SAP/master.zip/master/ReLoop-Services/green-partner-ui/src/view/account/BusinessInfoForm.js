import React, { useEffect } from 'react';
import { connect } from "react-redux";
import { Label, Input, Select, Option, Form, FormItem,
    TextArea, FormGroup, Button } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from "@ui5/webcomponents-react-base";
import "@ui5/webcomponents/dist/features/InputElementsFormSupport.js";
import { getBusinessInfo, updateBusinessInfo, getStates, getIndustry, getCities } from '../../store/action/taskAction';

const BusinessInfoForm = ({ startUpdateBusinessInfo, startGetStates, startGetCities,
    startGetIndustry, startGetBusinessInfo, businessInfo = {}, industry = [], states = [], cities = [], onBiSave }) => {
    useEffect(() => {
        startGetBusinessInfo();
        startGetIndustry();
        startGetStates();        
    }, []);
    useEffect(() => {
        if(businessInfo.location)
        {
            startGetCities(businessInfo.location.state_id);
        }        
    }, [businessInfo.location]);
    const getCity = (stateID) => {
        startGetCities(stateID);
    };
    const submitBusinessInfoForm = async (event) => {
        event.preventDefault();
        businessInfo.location.country = '1';
        startUpdateBusinessInfo(businessInfo);
        onBiSave();
    };
    const inputChange = (event) => {
        const { name, value } = event.target;
        if (name === 'addressLine' || name === 'pincode') {
            businessInfo.location = businessInfo.location ? businessInfo.location : {};
            businessInfo.location[name] = value;
        } else businessInfo[name] = value;
    };
    const selectStateChange = (e) => {
        businessInfo.location = businessInfo.location ? businessInfo.location : {};
        businessInfo.location.state = e.detail.selectedOption.value;
        getCity(e.detail.selectedOption.value);
    };
    const selectCityChange = (e) => {
        businessInfo.location = businessInfo.location ? businessInfo.location : {};
        businessInfo.location.city = e.detail.selectedOption.value;
    };
    const selectIndustryChange = (e) => {
        businessInfo[e.target.name] = e.detail.selectedOption.innerText;
    };    
    const { industry_type, tin_number, gst_number, location={} } = businessInfo;
    const {pincode,state,state_id,city_id,loc_details}=location;
    return (
        <div style={{ display: "flex", flexDirection: "row" }}>
            <Label
                style={{ fontWeight: 'Bold', ...spacing.sapUiMediumMargin }}
                tooltip=""
            >
                Business Information
            </Label>
            <div style={spacing.sapUiLargeMarginBegin}>
                <Form>
                    <Label />
                    <FormGroup>
                        <FormItem label="Industry type">
                            <Select name="industry_type" onChange={selectIndustryChange}>
                                {industry.map(indus => {
                                   return <Option selected={indus == industry_type ? true : false}  key={indus} value={indus}>{indus}</Option>;
                                })}

                            </Select>
                        </FormItem>
                        <FormItem label="Tin Number">
                            <Input value={tin_number} name="tin_number" onChange={(e) => { inputChange(e); }} />
                        </FormItem>
                        <FormItem label={<Label>GST Number</Label>}>
                            <Input value={gst_number} name="gst_number" onChange={(e) => { inputChange(e); }} />
                        </FormItem>
                        <FormItem label="State">                      
                            <Select name="state" onChange={(e) => { selectStateChange(e); }}>
                                {states.map((stateVal) =>                                
                                (<Option selected={stateVal.state_id == state_id? true : false } key={stateVal.state_id}
                                    value={stateVal.state_id}>{stateVal.state_name}</Option>))}
                            </Select>
                        </FormItem>
                        <FormItem label="City">
                            <Select name="city" onChange={(e) => { selectCityChange(e); }}
                                disabled={states.length}>
                                {cities.map((cityVal) => (<Option selected= {cityVal.city_id == city_id?true:false} key={cityVal.city_id}
                                    value={cityVal.city_id}>{cityVal.city_name}</Option>))}
                            </Select>
                        </FormItem>
                        <FormItem label="Pin Code">
                            <Input value={pincode} name="pincode" onChange={(e) => { inputChange(e); }} />
                        </FormItem>
                        <FormItem label="Address Line">
                            <TextArea
                                rows={3}
                                style={{
                                    width: '210px'
                                }}
                                value={loc_details} name="addressLine" onChange={(e) => { inputChange(e); }}
                            />
                        </FormItem>
                    </FormGroup>
                    <Button design="Emphasized" style={{position: "absolute",bottom: "8px",right: "16px"}} 
                    onClick={submitBusinessInfoForm}>Submit</Button>
                </Form>
            </div>
        </div>
    );
};

const mapStateToProps =  (state) => {
    return {
        businessInfo: state.account.businessInfo,
        industry: state.account.industry,
        states: state.account.states,
        cities: state.account.cities
    };
};

const mapDispatchToProps = dispatch => {
    return {
        startGetBusinessInfo: () => dispatch(getBusinessInfo()),
        startGetIndustry: () => dispatch(getIndustry()),
        startGetStates: () => dispatch(getStates()),
        startGetCities: (stateId) => dispatch(getCities(stateId)),
        startUpdateBusinessInfo: (payload) => dispatch(updateBusinessInfo(payload))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(BusinessInfoForm);
