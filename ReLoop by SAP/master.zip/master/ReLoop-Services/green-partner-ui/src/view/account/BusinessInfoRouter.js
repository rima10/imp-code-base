import React, { useState } from 'react';
import { connect } from 'react-redux';
import BusinessInfoForm from './BusinessInfoForm';
import BusinessInfoView from './BusinessInfoView';
import { getUserInfo } from '../../selectors/common';

const BusinessInfo = ({ userInfo = { isBusinessDataPresent: true } }) => {
    const [showBiForm, setShowBiForm] = useState(!userInfo.isBusinessDataPresent);
    const onEditClick = () => {
        setShowBiForm(true);
    };
    const onBiSave = () => {
        setShowBiForm(false);
    };
    const isBiView = !showBiForm && userInfo.isBusinessDataPresent;
    const component = isBiView ? (
        <BusinessInfoView onEditClick={onEditClick} />
    ) : (
        <BusinessInfoForm onBiSave={onBiSave} />
    );
    return component;
};
const mapStateToProps = (state) => {
    return {
        userInfo: getUserInfo(state),
    };
};

export default connect(mapStateToProps)(BusinessInfo);
