import React, { useEffect, useState, useRef } from "react";
import { connect } from "react-redux";
import { Label, Button } from "@ui5/webcomponents-react";
import "../../asset/style/style.css";
import { spacing } from "@ui5/webcomponents-react-base";
import "@ui5/webcomponents/dist/features/InputElementsFormSupport.js";
import AccountTable from "../common/Table";
import {
    getWorkflowsInfo,
    registerBPWorkflowInfo,
} from "../../store/action/taskAction";

const Workflow = ({
    processStageSequence,
    processStageName,
    processTypeId,
    approvers = [],
    approverInfo = [],
    startRegisterBPWorkflowInfo,
    showTable,
}) => {
    const [rows, setRows] = useState([]);
    const [table, setTable] = useState(showTable);
    const [newApprovers, setNewApprovers] = useState({
        processStageSequence,
        processStageName,
        processTypeId,
        approvers: {},
    });
    const newAppRef = useRef({});
    newAppRef.current = newApprovers.approvers;

    const newRowRef = useRef({});
    newRowRef.current = rows;

    const getRowsFromApprovers = (approvers) => {
        const newRows = [];
        approvers.map((app) => {
            const row = [];
            const { approver } = app;
            row.push({
                name: "approver_sequence",
                value: app.approver_sequence,
                type: "text",
            });
            row.push({
                name: "approver_role",
                value: approver.approver_role,
                type: "text",
            });
            row.push({
                name: "approver_name",
                value: approver.approver_name,
                type: "text",
            });
            newRows.push(row);
        });
        return newRows;
    };

    useEffect(() => {
        const rows = getRowsFromApprovers(approvers);
        setRows(rows);
    }, [approvers.length]);

    const saveWorkflowInfo = async (event) => {
        event.preventDefault();
        const payload = { ...newApprovers };
        const approvers = newAppRef.current;
        const approversPayload = [];
        for (const key in approvers) {
            const approver = approvers[key];
            approversPayload.push(approver);
        }
        payload.approvers = approversPayload;
        startRegisterBPWorkflowInfo(payload);
    };

    const inputChange = (event) => {
        const { slot } = event.currentTarget.parentElement.parentElement;
        let name = "";
        let value = "";
        if (event.detail) {
            name = "approverId";
            value = event.detail.selectedOption.attributes.id.value;
            const approver_name = event.detail.selectedOption.attributes.name.value;
            const { current } = newRowRef;
            const updatedRows = [...current];
            updatedRows[Number(slot.substr(-1)) - 1][2].value = approver_name;
            setRows(updatedRows);
        } else {
            name = event.target.name;
            value = event.target.value;
        }
        const { current } = newAppRef;
        const approvers = { ...current };
        if (approvers[slot]) approvers[slot][name] = value;
        else {
            approvers[slot] = {};
            approvers[slot][name] = value;
        }
        setNewApprovers({ ...newApprovers, approvers });
    };

    const onAddRowClick = () => {
        const row = [];
        row.push({
            name: "approverSequence",
            value: "email",
            type: "input",
            onInputChange: inputChange,
        });
        row.push({
            name: "role",
            value: "name",
            type: "select",
            options: approverInfo,
            onInputChange: inputChange,
        });
        row.push({ name: "name", value: "-", type: "text" });
        const { current } = newRowRef;
        const existingRows = [...current];
        existingRows.push(row);
        setRows(existingRows);
    };

    const onCancel = async (event) => {
        event.preventDefault();
        const newRows = getRowsFromApprovers(approvers);
        setRows(newRows);
    };

    const onAddWorkflow = (stepId) => {
        setTable(true);
        // showTable = true
        onAddRowClick();
    };

    const buttons = [
        {
            name: "Save",
            onClick: saveWorkflowInfo,
        },
        {
            name: "Cancel",
            onClick: onCancel,
        },
        {
            name: "Add",
            onClick: onAddRowClick,
        },
        {
            name: "Delete",
            onClick: onAddRowClick,
        },
    ];

    const columns = ["Approver Sequence", "Approver Role", "Approver Name"];

    return (
        <div
            style={{
                display: "flex",
                flexDirection: "column",
                ...spacing.sapUiMediumMargin,
            }}
        >
            <Label style={{ fontWeight: "Bold" }}>Workflow</Label>
            <>
                {showTable || table ? (
                    <AccountTable buttons={buttons} columns={columns} rows={rows} edit={false} />
                ) : (
                    <Button
                        data-layout-span="XL3"
                        onClick={() => onAddWorkflow()}
                        design="Emphasized"
                    >
                        Add Workflow
                    </Button>
                )}
            </>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        approverInfo: state.account.approverInfo,
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startRegisterBPWorkflowInfo: (payload) => dispatch(registerBPWorkflowInfo(payload)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(Workflow);
