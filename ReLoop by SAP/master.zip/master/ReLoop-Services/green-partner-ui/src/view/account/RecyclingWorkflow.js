import React, { useState, useEffect } from 'react';
import '../../asset/style/style.css';
import WorkflowWizard from '../common/WorkflowWizard';

const defaultSteps = {
    1: {
        name: 'Order Creation',
        selected: true,
        disabled: false,
        showTable: false,
    },
    2: {
        name: 'Order Submission',
        selected: false,
        disabled: true,
        showTable: false,
    },
    3: {
        name: 'Quotation Request',
        selected: false,
        disabled: true,
        showTable: false,
    },
    4: {
        name: 'Logistics',
        selected: false,
        disabled: true,
        showTable: false,
    },
};

const onSiteSteps = {
    1: {
        name: 'Order Creation',
        selected: true,
        disabled: false,
        showTable: false,
    },
    2: {
        name: 'Order Submission',
        selected: false,
        disabled: true,
        showTable: false,
    },
    3: {
        name: 'Quote Selection',
        selected: false,
        disabled: true,
        showTable: false,
    },
    4: {
        name: 'Schedule Onsite Visit',
        selected: false,
        disabled: true,
        showTable: false,
    },
    5: {
        name: 'Approval of Final Quote',
        selected: false,
        disabled: true,
        showTable: false,
    },
    6: {
        name: 'Logistics',
        selected: false,
        disabled: true,
        showTable: false,
    },
};

const RecyclingWorkflow = ({ workflows = [], isOnSite }) => {
    console.log('Onsite ', isOnSite);
    const [steps, setSteps] = useState(defaultSteps);

    useEffect(() => {
        isOnSite ? setSteps(onSiteSteps) : setSteps(defaultSteps);
    }, [isOnSite]);

    const onNextClick = (stepId) => {
        const newSteps = { ...steps };
        stepId = Number(stepId);
        if (stepId !== Object.keys(steps).length) {
            newSteps[stepId].selected = false;
            newSteps[stepId + 1].selected = true;
            newSteps[stepId + 1].disabled = false;
            setSteps(newSteps);
        }
    };

    if (workflows.length) {
        workflows.map((workflow) => {
            const { process_stage_sequence, workflow_approvers } = workflow;
            const step = steps[process_stage_sequence];
            step.approvers = workflow_approvers;
            step.showTable = true;
        });
    }

    return <WorkflowWizard steps={steps} processTypeId={'1'} onNextClick={onNextClick} />;
};

export default RecyclingWorkflow;
