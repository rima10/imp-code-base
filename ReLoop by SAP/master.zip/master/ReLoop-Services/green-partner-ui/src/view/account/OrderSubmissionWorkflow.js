import React, { Component } from 'react';
import { connect } from "react-redux";
import { Label, Button, Toolbar, Input, Table, TableColumn, ToolbarSpacer, TableRow, TableCell, Select, Option } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from "@ui5/webcomponents-react-base";
import "@ui5/webcomponents/dist/features/InputElementsFormSupport.js";

export class OrderSubmissionWorkflow extends Component {
    constructor (props) {
        super(props);
        this.state = {
            rows: [],
            showTable: false,
            orderSubmissionWorkflowInfo: {
                sequence: "",
                approverRole: "",
                approverName: ""
            }
        };
    }
    onAddWorkflowClick = () => {
        this.setState({
            showTable: true
        });
    }
    onAddRowClick = () => {
        const item = {
            sequence: "",
            approverRole: "",
            approverName: ""
        };
        this.setState({
            rows: [...this.state.rows, item]
        });
    }
    inputChange = (event) => {
        const { name, value } = event.target;
        const orderSubmissionWorkflowInfo = this.state.orderSubmissionWorkflowInfo;
        orderSubmissionWorkflowInfo[name] = value;
        this.setState({ orderSubmissionWorkflowInfo });
    }
    saveOrderSubmissionWorkflowInfo = async (event) => {
        event.preventDefault();
        //const orderCreationWorkflowInfo = this.state.orderCreationWorkflowInfo;
        //this.props.registerBPNetworkInfo(orderCreationWorkflowInfo);
    }
    showWorkflowTable = () => {
        const { sequence, approverRole, approverName } = this.state.orderSubmissionWorkflowInfo;
        const optionData = [
            { id: 1, text: 'Option 1' },
            { id: 2, text: 'Option 2' }
        ];
        return (
            <div>
                <Toolbar className="" slot="" style={{ ...spacing.sapUiMediumMarginTop }} tooltip="">
                    <Label for="workflowName">Workflow Name : </Label>
                    <Input id="workflowName" />
                    <ToolbarSpacer />
                    <div style={{ float: "right" }}>
                        <Button design="Transparent" onClick={this.saveOrderSubmissionWorkflowInfo}>Save</Button>
                        <Button design="Transparent" onClick={this.onAddRowClick}>Cancel</Button>
                        <Button design="Transparent" onClick={this.onAddRowClick}>Add</Button>
                        <Button design="Transparent" onClick={this.onAddRowClick}>Delete</Button>
                    </div>
                </Toolbar>
                <Table columns={<><TableColumn style={{ width: '24rem' }}><Label>Sequence</Label></TableColumn>
                    <TableColumn style={{ width: '24rem' }}><Label>Approver Role</Label></TableColumn>
                    <TableColumn style={{ width: '24rem' }}><Label>Approver Name</Label></TableColumn></>}>
                    {this.state.rows.map((item, idx) => (
                        <TableRow key={idx}>
                            <TableCell>
                                <Input value={sequence} name="sequence" onChange={(e) => { this.inputChange(e); }} />
                            </TableCell>
                            <TableCell>
                                <Select onChange={(e) => { this.inputChange(e); }}>
                                    {optionData.map((item) => (
                                        <Option key={item.id} data-id={item.id}>
                                            {item.text}
                                        </Option>
                                    ))}
                                </Select>
                                <Input value={approverRole} name="approverRole" onChange={(e) => { this.inputChange(e); }} />
                            </TableCell>
                            <TableCell>
                                <Input value={approverName} name="approverName" onChange={(e) => { this.inputChange(e); }} />
                            </TableCell>
                        </TableRow>
                    ))}
                </Table>
            </div>

        );
    }
    render () {
        return (

            <div>
                <Button style={spacing.sapUiMediumMarginTop}
                    design="Emphasized" onClick={this.onAddWorkflowClick}>Add Workflow</Button>
                {this.state.showTable ?
                    this.showWorkflowTable() :
                    null
                }
            </div>


        );
    }
}
const mapStateToProps = state => ({
    orderSubmissionWorkflowInfo: state.orderSubmissionWorkflowInfo
});

export default connect(mapStateToProps, {

})(OrderSubmissionWorkflow);
