import React, { useEffect } from 'react';
import { connect } from "react-redux";
import { Label, Form, FormItem,
    FormGroup, Button, Text } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from "@ui5/webcomponents-react-base";
import "@ui5/webcomponents/dist/features/InputElementsFormSupport.js";
import { getBusinessInfo } from '../../store/action/taskAction';

const BusinessInfoView = ({ startGetBusinessInfo, businessInfo = {}, onEditClick }) => {
    useEffect(() => {
        startGetBusinessInfo();
    }, []);

    const { industry_type, tin_number, gst_number, location = {} } = businessInfo;
    return (
        <div style={{ display: "flex", flexDirection: "row" }}>
            <Label
                style={{ fontWeight: 'Bold', ...spacing.sapUiMediumMargin }}
                tooltip=""
            >
                Business Information
            </Label>
            <div style={spacing.sapUiLargeMarginBegin}>
                <Form>
                    <Label />
                    <FormGroup>
                        <FormItem label="Industry type">
                            <Text> {industry_type} </Text>
                        </FormItem>
                        <FormItem label="Tin Number">
                            <Text> {tin_number} </Text>
                        </FormItem>
                        <FormItem label={<Label>GST Number</Label>}>
                            <Text> {gst_number} </Text>
                        </FormItem>
                        <FormItem label="State">
                            <Text> {location.state} </Text>
                        </FormItem>
                        <FormItem label="City">
                            <Text> {location.city} </Text>
                        </FormItem>
                        <FormItem label="Pin Code">
                            <Text> {location.pincode} </Text>
                        </FormItem>
                        <FormItem label="Address Line">
                            <Text> {location.loc_details} </Text>
                        </FormItem>
                    </FormGroup>
                    <Button design="Emphasized" onClick={onEditClick}>Edit</Button>
                </Form>
            </div>
        </div>
    );
};

const mapStateToProps = state => {
    return {
        businessInfo: state.account.businessInfo
    };
};

const mapDispatchToProps = dispatch => {
    return {
        startGetBusinessInfo: () => dispatch(getBusinessInfo())
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(BusinessInfoView);
