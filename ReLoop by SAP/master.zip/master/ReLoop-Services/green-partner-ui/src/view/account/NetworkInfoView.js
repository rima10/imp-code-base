import React, { useEffect, useState, useRef } from 'react';
import { connect } from 'react-redux';
import { Label } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from '@ui5/webcomponents-react-base';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport.js';
import AccountTable from '../common/Table';
import {
    getNetworkInfo,
    registerBPNetworkInfo,
    deleteBPNetworkInfo,
} from '../../store/action/taskAction';
import LoadingIndicator from '../common/Loading';
import { getNetworkInfoState } from '../../selectors/common';

const NetworkInfoView = ({
    startGetNetworkInfo,
    startRegisterBPNetworkInfo,
    networkInfo = {},
    isLoading,
    startDeleteBPNetworkInfo,
}) => {
    const [rows, setRows] = useState([]);
    const [selectedRow, setSelectedRow] = useState([]);
    const [newNetworks, setNewNetworks] = useState({});
    const stateRef = useRef();
    stateRef.current = selectedRow;
    const newNetRef = useRef({});
    newNetRef.current = newNetworks;

    const getRowsFromNetworkInfo = (networkInfo) => {
        const newRows = [];
        if (Object.keys(networkInfo).length !== 0) {
            networkInfo.map((network) => {
                const row = [
                    {
                        type: 'checkbox',
                        onInputChange: isRowSelected,
                        disabled: false,
                        checked: false,
                    },
                ];
                const keys = Object.keys(network.rcy);
                keys.map((key) => {
                    if (['bp_email_id', 'bp_phone_number', 'bp_username'].includes(key)) {
                        row.push({
                            name: key,
                            value: network.rcy[key],
                            type: 'text',
                        });
                    }
                });
                newRows.push(row);
            });
        }
        return newRows;
    };

    const updateNetworkList = (networkInfo) => {
        const newRows = getRowsFromNetworkInfo(networkInfo);
        setRows(newRows);
    };

    useEffect(() => {
        startGetNetworkInfo();
    }, []);

    useEffect(() => {
        updateNetworkList(networkInfo);
    }, [networkInfo.length]);

    const saveNetworkInfo = async (event) => {
        event.preventDefault();
        const payload = { pvtRecyclers: [] };
        const networks = newNetRef.current;
        for (const key in networks) {
            const network = networks[key];
            payload.pvtRecyclers.push({
                emailId: network.email,
                username: network.name,
                phoneNumber: network.number,
            });
        }
        startRegisterBPNetworkInfo(payload);
        setNewNetworks({});
    };

    const inputChange = (event) => {
        const existingRows = [...rows];
        const { slot } = event.currentTarget.parentElement.parentElement;
        const { name, value } = event.target;
        const { current } = newNetRef;
        const networks = { ...current };
        if (networks[slot]) networks[slot][name] = value;
        else {
            networks[slot] = {};
            networks[slot][name] = value;
        }
        setNewNetworks(networks);
    };

    const isRowSelected = (rowNumber) => {
        let row = stateRef.current;
        const index = row.indexOf(rowNumber);
        if (index > -1) {
            row.splice(index, 1);
        } else {
            row.push(rowNumber);
        }
        setSelectedRow(row);
    };

    const onAddRowClick = () => {
        const row = [];
        row.push({
            type: 'checkbox',
            onInputChange: isRowSelected,
            disabled: true,
            checked: false,
        });
        row.push({ name: 'email', value: 'email', type: 'input', onInputChange: inputChange });
        row.push({ name: 'name', value: 'name', type: 'input', onInputChange: inputChange });
        row.push({ name: 'number', value: 'number', type: 'input', onInputChange: inputChange });
        const existingRows = [...rows];
        existingRows.push(row);
        setRows(existingRows);
    };

    const onCancel = async (event) => {
        event.preventDefault();
        const newRows = getRowsFromNetworkInfo(networkInfo);
        setRows(newRows);
    };

    const onDeleteClick = async (event) => {
        event.preventDefault();
        const rows = stateRef.current;
        const payload = { pvtNetworks: [] };
        rows.map((row) => {
            payload.pvtNetworks.push({
                recyclerId: networkInfo[row].rcy_id,
                networkId: networkInfo[row].bp_nwk_id,
            });
        });
        startDeleteBPNetworkInfo(payload);
        setSelectedRow([]);
    };

    const buttons = [
        {
            name: 'Save',
            onClick: saveNetworkInfo,
        },
        {
            name: 'Cancel',
            onClick: onCancel,
        },
        {
            name: 'Add',
            onClick: onAddRowClick,
        },
        {
            name: 'Delete',
            onClick: onDeleteClick,
        },
    ];

    const columns = ['', 'Email ID', 'Name', 'Contact Number'];

    if (isLoading) {
        return <LoadingIndicator />;
    } else {
        return (
            <div style={{ display: 'flex', flexDirection: 'column', ...spacing.sapUiMediumMargin }}>
                <Label style={{ fontWeight: 'Bold' }}>Private Network </Label>
                <AccountTable buttons={buttons} columns={columns} rows={rows} edit={false} />
            </div>
        );
    }
};

const mapStateToProps = (state) => {
    return {
        networkInfo: getNetworkInfoState(state),
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetNetworkInfo: () => dispatch(getNetworkInfo()),
        startRegisterBPNetworkInfo: (payload) => dispatch(registerBPNetworkInfo(payload)),
        startDeleteBPNetworkInfo: (payload) => dispatch(deleteBPNetworkInfo(payload)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(NetworkInfoView);
