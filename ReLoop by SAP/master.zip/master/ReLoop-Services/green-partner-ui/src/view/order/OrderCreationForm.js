/* eslint-disable max-len */
import React, { useState, useEffect } from 'react';
import { connect } from "react-redux";
import { FileUploader, Button, Label, ToolbarSpacer, Text, Toolbar, Form, FormItem, TextArea, Option, Select, DateTimePicker, Switch, Bar } from '@ui5/webcomponents-react';
import { spacing } from "@ui5/webcomponents-react-base";
import '../../asset/style/style.css';
import AccountTable from '../common/Table';
import { updateOrderInfo, getWorkflowsInfo, readExcelInfo } from '../../store/action/taskAction';


const OrderCreationForm = ({ startUpdateOrderInfo, startGetWorkflowInfo, startReadExcelInfo, orderInfo = {}, workflowsInfo = [], orderItemInfo = [] }) => {
    const columns = ['Approver Sequence', 'Approver Role', 'Approver Name'];
    const assetColumns = ['Equipment No.', 'Asset No.', 'Location', 'Bond Status', 'Category', 'Make', 'Model', 'Manuf. Serial No.', 'Age in Years', 'Purchase Year', 'Description'];
    const [rows, setRows] = useState([]);
    const [assetRows, setAssetRows] = useState([]);
    //const [assetColumns, setAssetColumns] = useState([]);
    const [assetTableVisible, setAssetTableVisible] = useState(false);
    const getWorkflowDetails = (workflowsInfo) => {
        const newRows = [];
        const workflowApprover = [];
        if (workflowsInfo.length !== 0) {
            workflowApprover.push(workflowsInfo[0].workflow_approvers);
            workflowApprover[0].map(index => {
                const row = [];
                row.push({ name: 'approver_sequence', value: index.approver_sequence, type: 'text' });
                row.push({ name: 'approver_role', value: index.approver.approver_email_id, type: 'text' });
                row.push({ name: 'approver_name', value: index.approver.approver_name, type: 'text' });
                newRows.push(row);
            });
            return newRows;
        }
    };
    const getOrderItemDetails = (orderItemInfo) => {
        const newRows = [];
        orderItemInfo.map(index => {
            const row = [];
            row.push({ name: 'Equipment No.', value: index.A, type: 'text' });
            row.push({ name: 'Asset No.', value: index.B, type: 'text' });
            row.push({ name: 'Location', value: index.E, type: 'text' });
            row.push({ name: 'Bond Status', value: index.F, type: 'text' });
            row.push({ name: 'Category', value: index.G, type: 'text' });
            row.push({ name: 'Make', value: index.H, type: 'text' });
            row.push({ name: 'Model', value: index.I, type: 'text' });
            row.push({ name: 'Manuf. Serial No.', value: index.J, type: 'text' });
            row.push({ name: 'Age in Years', value: index.K, type: 'text' });
            row.push({ name: 'Purchase Year', value: index.L, type: 'text' });
            row.push({ name: 'Description', value: index.M, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };
    useEffect(() => {
        startGetWorkflowInfo();
    }, []);
    useEffect(() => {
        const rows = getWorkflowDetails(workflowsInfo);
        setRows(rows);
    }, [workflowsInfo.length]);
    useEffect(() => {
        if (orderItemInfo.length !== 0) {
            //setAssetColumns(Object.values(orderItemInfo[0]));
            const assetRows = getOrderItemDetails(orderItemInfo.slice(1));
            setAssetRows(assetRows);
        }
    }, [orderItemInfo.length]);
    const formdata = new FormData();
    const processes = [{
        name: "Refurbish",
        selected: false,
        disabled: false
    },
    {
        name: "Recycle",
        selected: false,
        disabled: false
    }
    ];
    const categories = [{
        name: "E-waste",
        selected: false,
        disabled: false
    },
    {
        name: "Plastic",
        selected: true,
        disabled: false
    }
    ];
    const subcategories = [{
        name: "Information technology and telecommunication equipment",
        selected: false,
        disabled: false
    },
    {
        name: "Consumer electrical and electronics",
        selected: true,
        disabled: false
    },
    {
        name: "Battery",
        selected: false,
        disabled: true
    },
    {
        name: "Medical",
        selected: false,
        disabled: true
    },
    {
        name: "Automotive",
        selected: false,
        disabled: true
    }
    ];
    const onSelectChange = (e) => {
        formdata.append(e.target.name, e.detail.selectedOption.value);
        //orderInfo[e.target.name] = e.detail.selectedOption.value;
    };
    const onSelectCatChange = (e) => {
        formdata.append(e.target.name, "1");
        //orderInfo[e.target.name] = e.detail.selectedOption.value;
    };
    const inputChange = (event) => {
        const { name, value } = event.target;
        formdata.append(name, value);
        //orderInfo[name] = value;
    };
    const onFileChangeHandler = (event) => {
        //const fileNameWithExt = event.detail.files[0].name;
        //const fileName = fileNameWithExt.substr(0, fileNameWithExt.lastIndexOf('.'));
        formdata.append(event.target.name, event.target.files[0]);
        if (event.target.name === 'assetExcel') {
            startReadExcelInfo(formdata);
            setAssetTableVisible(true);
        }
    };
    const submitOrderInfoForm = async (event) => {
        event.preventDefault();
        orderInfo = formdata;
        startUpdateOrderInfo(orderInfo);
    };
    const { orderType, category, subcategory, network, submissionDeadline, additionalInfo, orderLocation, assetExcel, picture } = orderInfo;
    return (
        <div style={spacing.sapUiMediumMargin}>
            <Label
                style={{ fontWeight: 'Bold' }}
                tooltip=""
            >
                1. Order Creation
            </Label>
            <Toolbar style={spacing.sapUiMediumMarginTop}
            >
                <Text>
                    Order Details
                </Text>
                <ToolbarSpacer />
                <Button onClick={submitOrderInfoForm}>Save</Button>
            </Toolbar>
            <Form>
                <FormItem label="This request is for">
                    <Select name="orderType" value={orderType} onChange={(e) => { onSelectChange(e); }}>
                        {processes.map(index => {
                            return <Option key={index.name} value={index.name} selected={index.selected} disabled={index.disabled}>{index.name}</Option>;
                        })}
                    </Select>
                </FormItem>
                <FormItem>
                    <Label />
                </FormItem>
                <FormItem label="Category">
                    <Select name="category" value={category} onChange={(e) => { onSelectCatChange(e); }}>
                        {categories.map(index => {
                            return <Option key={index.name} value={index.name} selected={index.selected} disabled={index.disabled}>{index.name}</Option>;
                        })}
                    </Select>
                </FormItem>
                <FormItem label="Picture">
                    <FileUploader name="picture" value={picture} onChange={onFileChangeHandler}
                    />
                </FormItem>
                <FormItem label="Subcategory">
                    <Select name="subcategory" value={subcategory} onChange={(e) => { onSelectCatChange(e); }}>
                        {subcategories.map(index => {
                            return <Option key={index.name} value={index} selected={index.selected} disabled={index.disabled}>{index.name}</Option>;
                        })}
                    </Select>
                </FormItem>
                <FormItem label="Private/Public Network">
                    <Select name="network" value={network} onChange={(e) => { onSelectChange(e); }}>
                        <Option selected value="Private">
                            Private
                        </Option>
                        <Option value="Public">
                            Public
                        </Option>
                    </Select>
                </FormItem>
                <FormItem label="Order Submission Deadline">
                    <DateTimePicker name="submissionDeadline" value={submissionDeadline} onChange={(e) => { inputChange(e); }} />
                </FormItem>
                <FormItem label="Additional information">
                    <TextArea
                        rows={3}
                        style={{
                            width: '210px'
                        }}
                        name="additionalInfo"
                        value={additionalInfo}
                        onChange={(e) => { inputChange(e); }}
                    />
                </FormItem>
                <FormItem label="Order Location">
                    <TextArea
                        rows={3}
                        style={{
                            width: '210px'
                        }}
                        name="orderLocation"
                        value={orderLocation}
                        onChange={(e) => { inputChange(e); }}
                    />
                </FormItem>
            </Form>

            {assetTableVisible === true ? <AccountTable columns={assetColumns} edit={false} text="Asset List" rows={assetRows}/> :
                <div>
                    <Toolbar>
                        <Text>
                    Asset List
                        </Text>
                        <ToolbarSpacer />
                        <Switch checked />
                    </Toolbar>
                    <Bar middleContent= {
                        <FileUploader name="assetExcel" hideInput value={assetExcel} onChange={onFileChangeHandler}>
                            <Button design="emphasized" style={spacing.sapUiMediumMargin}>
                        Upload file
                            </Button>
                        </FileUploader>} />
                </div>}
            <AccountTable columns={columns} edit={false} text="Internal Approval Workflow (Asset List)" rows={rows}/>
        </div>
    );
};
const mapStateToProps = state => {
    return {
        workflowsInfo: state.account.workflows,
        orderItemInfo: state.order.orderItemInfo
    };
};

const mapDispatchToProps = dispatch => {
    return {
        startGetWorkflowInfo: () => dispatch(getWorkflowsInfo()),
        startUpdateOrderInfo: (payload) => dispatch(updateOrderInfo(payload)),
        startReadExcelInfo: (payload) => dispatch(readExcelInfo(payload))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderCreationForm);

