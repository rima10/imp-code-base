import React from 'react';
import { Wizard, WizardStep, Button } from '@ui5/webcomponents-react';
import OrderCreationForm from './OrderCreationForm';

const OrderWizard = ({ steps = [], processTypeId, onNextClick, onAddWorkflow }) => {
    const getStepContent = (step, handleNext) => {
        switch (step) {
            case "1":
                return (<OrderCreationForm/>);

            default:
                return 'Unknown step';
        }
    };
    return (
        <Wizard id = "wizard" slot="" >
            {Object.keys(steps).map((idx) => {
                return (
                    <WizardStep branching heading={steps[idx].name} selected={steps[idx].selected}
                        disabled={steps[idx].disabled} key = {steps[idx].key}>
                        {getStepContent(idx)}
                        <Button
                            onClick={() => onNextClick(idx)}
                            design="Emphasized"
                        >Next</Button>
                    </WizardStep>
                );
            })}
        </Wizard>

    );
};

export default OrderWizard;
