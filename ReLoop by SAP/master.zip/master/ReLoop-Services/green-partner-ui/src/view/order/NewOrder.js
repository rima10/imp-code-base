import React, { useState } from 'react';
import '../../asset/style/style.css';
import OrderWizard from './OrderWizard';

const defaultSteps = {
    1: {
        name: "Order Creation",
        selected: true,
        disabled: false,
        showTable: false
    },
    2: {
        name: "Order Submission",
        selected: false,
        disabled: true,
        showTable: false
    },
    3: {
        name: "Quotation Request",
        selected: false,
        disabled: true,
        showTable: false
    },
    4: {
        name: "Logistics",
        selected: false,
        disabled: true,
        showTable: false
    }
};

const NewOrder = () => {
    const [steps, setSteps] = useState(defaultSteps);

    const onNextClick = (stepId) => {
        const newSteps = { ...steps };
        newSteps[Number(stepId)].selected = false;
        newSteps[Number(stepId) + 1].selected = true;
        newSteps[Number(stepId) + 1].disabled = false;
        setSteps(steps);
    };
    return (<OrderWizard steps={steps} processTypeId={'1'} onNextClick={onNextClick}/>);
};

export default NewOrder;
