import React, { useState, Fragment } from 'react';
import { connect } from "react-redux";
import NavBar from '../home/NavBar';
import Header from '../header/Header';
import NewOrder from './NewOrder';

const OrderInfo = ({ orderInfo }) => {
    const [path, setPath] = useState('');
    const callbackFunction = (childData) => {
        setPath(childData);
    };
    const getStepContent = (step) => {
        switch (step) {
            case '/order':
                return (<NewOrder/>);
            default:
                return (<NewOrder/>);
        }
    };
    return (
        <Fragment>
            <Header/>
            <div style = {{ display: "flex", flexDirection: "row" }}>
                <NavBar parentCallback = {callbackFunction}/>{getStepContent(path)}
            </div>
        </Fragment>
    );
};
const mapStateToProps = state => {
    return {
        orderInfo: state.orderInfo
    };
};


export default connect(mapStateToProps)(OrderInfo);
