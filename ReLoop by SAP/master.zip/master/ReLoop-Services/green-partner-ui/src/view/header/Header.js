import React from "react";
import {
    ShellBar,
    Toolbar,
    ShellBarItem,
    Avatar,
    Button,
    Text,
    FlexBox,
    FlexBoxDirection,
} from "@ui5/webcomponents-react";
export default function Header({ handleSideNavCollapse, userName }) {
    return (
        <ShellBar
            className=""
            primaryTitle="ReLoop by SAP"
            profile={
                // <FlexBox direction={FlexBoxDirection.Row}>
                // <Text style={{ color: "white" }}>Welcome {userName}</Text>
                <Avatar />
                // </FlexBox>
            }
            showNotifications
            showProductSwitch
            slot=""
            style={{}}
            tooltip=""
        >
            <Button slot="startButton" onClick={handleSideNavCollapse} icon="menu" />
        </ShellBar>
    );
}
