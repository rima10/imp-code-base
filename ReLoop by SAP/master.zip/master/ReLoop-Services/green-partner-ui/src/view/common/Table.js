import React from 'react';
import {
    Label,
    Button,
    Toolbar,
    Input,
    Table,
    TableColumn,
    ToolbarSpacer,
    TableRow,
    TableCell,
    Text,
    Select,
    Option,
    CheckBox,
} from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from '@ui5/webcomponents-react-base';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport.js';

const AccountTable = ({ rows = [], columns = [], buttons = [], edit = false, text }) => {
    const getCell = (cell, rowNumber) => {
        switch (cell.type) {
            case 'text':
                return <Text style={{}}>{cell.value}</Text>;
                break;
            case 'input':
                return (
                    <Input
                        key={cell.name}
                        name={cell.name}
                        onChange={(e) => {
                            cell.onInputChange(e);
                        }}
                    />
                );
                break;
            case 'select':
                return (
                    <Select
                        onChange={(e) => {
                            cell.onInputChange(e);
                        }}
                    >
                        <Option key="-1" id="-1" name="-" value="-">
                            Select Role
                        </Option>
                        {cell.options.map((item) => (
                            <Option
                                key={item.approver_id}
                                id={item.approver_id}
                                name={item.approver_name}
                                value={item.approver_role}
                            >
                                {item.approver_role}
                            </Option>
                        ))}
                    </Select>
                );
            case 'checkbox':
                return (
                    <CheckBox
                        className=""
                        onChange={(e) => {
                            cell.onInputChange(rowNumber);
                        }}
                        slot=""
                        style={{}}
                        tooltip=""
                        disabled={cell.disabled}
                        checked={cell.checked}
                    />
                );
        }
    };
    const renderFunction = () => {
        return (
            <div>
                <Toolbar
                    className=""
                    slot=""
                    style={{ ...spacing.sapUiMediumMarginTop }}
                    tooltip=""
                >
                    <Text>{text}</Text>
                    <ToolbarSpacer />
                    <div style={{ float: 'right' }}>
                        {buttons.map((button) => {
                            return (
                                <Button
                                    key={button.name}
                                    design="Transparent"
                                    onClick={button.onClick}
                                >
                                    {button.name}
                                </Button>
                            );
                        })}
                    </div>
                </Toolbar>
                <Table
                    showNoData
                    noDataText={'No data available'}
                    columns={columns.map((column) => {
                        return (
                            <TableColumn style={{ width: '33rem' }}>
                                <Label>{column}</Label>
                            </TableColumn>
                        );
                    })}
                >
                    {rows.map((row, idx) => (
                        <TableRow key={idx}>
                            {row.map((cell, id) => {
                                return <TableCell key={id}> {getCell(cell, idx)}</TableCell>;
                            })}
                        </TableRow>
                    ))}
                </Table>
            </div>
        );
    };
    return renderFunction();
};

export default AccountTable;
