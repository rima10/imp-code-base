import React from 'react';
import { Label } from '@ui5/webcomponents-react';

const ErrorComponent = ({ text = '' }) => {
    return (
        <Label style={{ position: 'fixed', zIndex: 100, top: '50%', left: '50%' }}>{text}</Label>
    );
};

export default ErrorComponent;
