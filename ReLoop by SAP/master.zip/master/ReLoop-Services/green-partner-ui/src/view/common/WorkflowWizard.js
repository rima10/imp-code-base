import React from 'react';
import { Wizard, WizardStep, Button } from '@ui5/webcomponents-react';
import Workflow from '../account/Workflow';

const WorkflowWizard = ({ steps = [], processTypeId, onNextClick }) => {
    return (
        <Wizard id="wizard" slot="" style={{ maxHeight: '400px', minHeight: '200px' }}>
            {Object.keys(steps).map((idx) => {
                return (
                    <WizardStep
                        branching
                        heading={steps[idx].name}
                        selected={steps[idx].selected}
                        disabled={steps[idx].disabled}
                        key={idx}
                    >
                        <Workflow
                            approvers={steps[idx].approvers}
                            processTypeId={processTypeId}
                            processStageName={steps[idx].name}
                            processStageSequence={idx}
                            showTable={steps[idx].showTable}
                        />
                        <Button onClick={() => onNextClick(idx)} design="Emphasized">
                            Next
                        </Button>
                    </WizardStep>
                );
            })}
        </Wizard>
    );
};

export default WorkflowWizard;
