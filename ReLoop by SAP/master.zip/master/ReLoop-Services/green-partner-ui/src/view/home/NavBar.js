import React, { Component } from 'react';
import { SideNavigation, SideNavigationItem, SideNavigationSubItem } from '@ui5/webcomponents-react';
import { withRouter } from 'react-router-dom';

class NavBar extends Component {
    constructor (props) {
        super(props);
        this.state = {
            activePath: '/',
            orderItems: [
                {
                    path: '/newOrder', /* path is used as id to check which NavItem is active basically */
                    name: 'New Order',
                    key: 'key1', /* Key is required, else console throws error. Does this please you Mr. Browser?! */
                    icon: 'home'
                },
                {
                    path: '/ongoingOrder',
                    name: 'Ongoing Order',
                    key: 'key2',
                    icon: 'home'
                },
                {
                    path: '/completedOrder',
                    name: 'Completed Order',
                    key: 'key3',
                    icon: 'home'
                }
            ],
            accountItems: [
                {
                    path: '/businessInfo', /* path is used as id to check which NavItem is active basically */
                    name: 'Business Information',
                    key: 'accountKey1', /* Key is required, else console throws error. Does this please you Mr. Browser?! */
                    icon: 'home'
                },
                {
                    path: '/networkInfo',
                    name: 'Private Network',
                    key: 'accountKey2',
                    icon: 'home'
                },
                {
                    path: '/approverInfo',
                    name: 'Approver Information',
                    key: 'accountKey3',
                    icon: 'home'
                },
                {
                    path: '/workflowInfo',
                    name: 'Workflow Information',
                    key: 'accountKey4',
                    icon: 'home'
                }
            ]
        };
    }
  onSelectionChange = (event) => {
      this.setState({ activePath: event.detail.item.getAttribute('path') });
      let path = event.detail.item.getAttribute('path');
      this.props.history.push(`${path}`);
  }
  render () {
      const { orderItems, accountItems, activePath } = this.state;
      return (
          <div>
              {/* position: 'fixed', top: '0', marginTop: '52px', bottom: '0' */}
              <SideNavigation
                  slot=""
                  style={{}}
                  tooltip=""
                  onSelectionChange={this.onSelectionChange}
                  collapsed={this.props.isSideNavOpen}>
                  <SideNavigationItem path="/dashboard" icon="chain-link" text="Dashboard"/>
                  <SideNavigationItem path="#" text="Order" expanded icon="chain-link">
                      {orderItems.map((item) => (
                          /* Return however many NavItems in array to be rendered */
                          <SideNavigationSubItem id={item.key} path={item.path} text={item.name} active={item.path === activePath} key={item.key} icon={item.icon}/>
                      ))}
                  </SideNavigationItem>
                  <SideNavigationItem path="#" text="Account" icon="chain-link">
                      {accountItems.map((item) => (
                          /* Return however many NavItems in array to be rendered */
                          <SideNavigationSubItem id={item.key} path={item.path} text={item.name} active={item.path === activePath} key={item.key} icon={item.icon}/>
                      ))}
                  </SideNavigationItem>
              </SideNavigation>
          </div>
      );
  }
}

export default withRouter(NavBar);
