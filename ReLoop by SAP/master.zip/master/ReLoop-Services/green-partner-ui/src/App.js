import { hot } from 'react-hot-loader';
import React, { Component } from "react";
import { ThemeProvider } from '@ui5/webcomponents-react';
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { store } from "./store/store";
import '@ui5/webcomponents/dist/Assets.js';
import Main from './view/Main'

class App extends Component {
    constructor (props) {
        super(props);
    }

    render () {
        return (
            <Provider store = {store}>
                <ThemeProvider>
                    <BrowserRouter>
                        <Main />
                    </BrowserRouter>
                </ThemeProvider>
            </Provider>
        );
    }
}
export default hot(module)(App);
