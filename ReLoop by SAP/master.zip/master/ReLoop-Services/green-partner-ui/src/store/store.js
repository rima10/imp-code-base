import account from './reducer/accountReducer';
import userInfo from './reducer/loginReducer';
import isLoading from './reducer/loadingReducer';
import order from './reducer/orderReducer';
import { createStore, applyMiddleware, combineReducers } from "redux";
import thunk from 'redux-thunk';
import { composeWithDevTools } from 'redux-devtools-extension';

const reducers = {
    account,
    userInfo,
    isLoading,
    order
};
const rootReducer = combineReducers(reducers);
export const store = createStore(rootReducer, composeWithDevTools(applyMiddleware(thunk)));
