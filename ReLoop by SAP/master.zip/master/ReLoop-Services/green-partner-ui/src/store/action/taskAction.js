import {
    setLoginInfo,
    loadInProgress,
    loadCompleted,
    setBusinessInfo,
    setNetworkInfo,
    setApproverInfo,
    setCitiesInfo,
    setStatesInfo,
    setIndustryInfo,
    setWorkflowInfo,
    setOrderItemInfo,
} from './type';
import { getToken } from '../../utils/authUtils';
import http from '../../utils/httpService';

const API_BASE_URL = 'http://localhost:5000/api/';

export const validateUser = (accessToken) => async (dispatch, getState) => {
    try {
        const isLoggedIn = getState().userInfo.isLoggedIn;
        if (!isLoggedIn) {
            dispatch(loadInProgress());
            let params = {
                withCredentials: true,
            };
            if (accessToken) {
                params.headers = {
                    authorization: 'Bearer ' + accessToken,
                };
            }
            const response = await http.post(API_BASE_URL + 'auth/validate', null, params);
            dispatch(setLoginInfo(response.data, true));
            dispatch(loadCompleted());
        }
    } catch (error) {
        dispatch(setLoginInfo(null, false));
        dispatch(loadCompleted());
    }
};

export const getAccessToken = () => async (dispatch, getState) => {
    console.log(getState);
    const idToken = await getToken();
    await validateUser(idToken)(dispatch, getState);
};

export const getBusinessInfo = () => async (dispatch, getState) => {
    const userId = getState().userInfo.bp_id;
    const response = await http.get(`${API_BASE_URL}user/getBusinessInfo/${userId}`, {
        withCredentials: true,
    });
    dispatch(setBusinessInfo(response.data));
};

export const getNetworkInfo = () => async (dispatch, getState) => {
    const userId = getState().userInfo.bp_id;
    const response = await http.get(`${API_BASE_URL}user/getprivatenetwork/${userId}`, {
        withCredentials: true,
    });
    dispatch(setNetworkInfo(response.data));
};

export const getApproverInfo = () => async (dispatch, getState) => {
    const userId = getState().userInfo.bp_id;
    const response = await http.get(`${API_BASE_URL}user/approver/getApprovers/${userId}`, {
        withCredentials: true,
    });
    dispatch(setApproverInfo(response.data));
};

export const getStates = () => async (dispatch, getState) => {
    const response = await http.get(`${API_BASE_URL}user/loc/getStatesbyCountry/1`, {
        withCredentials: true,
    });
    dispatch(setStatesInfo(response.data));
};

export const getCities = (stateId) => async (dispatch, getState) => {
    const response = await http.get(`${API_BASE_URL}user/loc/getCitiesbyState/${stateId}`, {
        withCredentials: true,
    });
    dispatch(setCitiesInfo(response.data));
};

export const getIndustry = () => async (dispatch, getState) => {
    dispatch(setIndustryInfo(['It & Telecom', 'Oil & Gas']));
};

export const updateBusinessInfo = (payload) => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.bp_id;
        await http.patch(`${API_BASE_URL}user/update/${userId}`, payload, {
            withCredentials: true,
        });
        await getBusinessInfo()(dispatch, getState);
    } catch (error) {
        console.log(error);
    }
};

export const registerBPApproverInfo = (payload) => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.bp_id;
        await http.post(`${API_BASE_URL}user/approver/addApprovers/${userId}`, payload, {
            withCredentials: true,
        });
        await getApproverInfo()(dispatch, getState);
    } catch (error) {
        console.log(error);
    }
};

export const registerBPNetworkInfo = (payload) => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.bp_id;
        await http.post(`${API_BASE_URL}user/createPrivateNetwork/${userId}`, payload, {
            withCredentials: true,
        });
        await getNetworkInfo()(dispatch, getState);
    } catch (error) {
        console.log(error);
    }
};

export const getWorkflowsInfo = () => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.bp_id;
        const response = await http.get(`${API_BASE_URL}user/workflow/getWorkflows/${userId}`, {
            withCredentials: true,
        });
        dispatch(setWorkflowInfo(response.data));
    } catch (error) {
        console.log(error);
    }
};

export const registerBPWorkflowInfo = (payload) => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.bp_id;
        await http.post(`${API_BASE_URL}user/workflow/addWorkflow/${userId}`, payload, {
            withCredentials: true,
        });
        await getWorkflowsInfo()(dispatch, getState);
    } catch (error) {
        console.log(error);
    }
};

export const updateOrderInfo = (payload) => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.bp_id;
        await http.post(`${API_BASE_URL}order/createOrder/${userId}`, payload, {
            withCredentials: true,
        });
    } catch (error) {
        console.log(error);
    }
};

export const deleteBPNetworkInfo = (payload) => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.bp_id;
        await http.delete(`${API_BASE_URL}user/deleteprivatenetwork/${userId}`, {
            data: payload,
            withCredentials: true,
        });
        await getNetworkInfo()(dispatch, getState);
    } catch (error) {
        console.log(error);
    }
};

export const deleteBPApproverInfo = (payload) => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.bp_id;
        const response = await http.delete(`${API_BASE_URL}user/approver/deleteApprovers/${userId}`, {
            data: payload,
            withCredentials: true,
        });
        dispatch(setApproverInfo(response.data));
    } catch (error) {
        console.log(error);
    }
};

export const readExcelInfo = (payload) => async (dispatch, getState) => {
    try {
        const response = await http.post(`${API_BASE_URL}order/orderItem/readExcel`,
            payload, { withCredentials: true });
        dispatch(setOrderItemInfo(response.data));
    } catch (error) {
        console.log(error);
    }
};
