export const FETCH_BP_BUSINESS_INFO = "FETCH_BP_BUSINESS_INFO";
export const SET_BP_RCYWORKFLOW_INFO = "SET_BP_RCYWORKFLOW_INFO";
export const SET_BP_RFBWORKFLOW_INFO = "SET_BP_RFBWORKFLOW_INFO";

export const SET_LOGIN_INFO = 'SET_LOGIN_INFO';
export const setLoginInfo = (userInfo, isLoggedIn) => ({
    type: SET_LOGIN_INFO,
    payload: { userInfo, isLoggedIn }
});

export const SET_LOAD_IN_PROGRESS = 'SET_LOAD_IN_PROGRESS';
export const loadInProgress = () => ({
    type: SET_LOAD_IN_PROGRESS
});

export const SET_LOAD_COMPLETED = 'SET_LOAD_COMPLETED';
export const loadCompleted = () => ({
    type: SET_LOAD_COMPLETED
});

export const SET_BP_BUSINESS_INFO = 'SET_BP_BUSINESS_INFO';
export const setBusinessInfo = (businessInfo) => ({
    type: SET_BP_BUSINESS_INFO,
    payload: businessInfo
});

export const SET_BP_NETWORK_INFO = "SET_BP_NETWORK_INFO";
export const setNetworkInfo = (networkInfo) => ({
    type: SET_BP_NETWORK_INFO,
    payload: networkInfo
});

export const SET_BP_APPROVER_INFO = "SET_BP_APPROVER_INFO";
export const setApproverInfo = (approverInfo) => ({
    type: SET_BP_APPROVER_INFO,
    payload: approverInfo
});

export const SET_STATES_INFO = "SET_STATES_INFO";
export const setStatesInfo = (stateInfo) => ({
    type: SET_STATES_INFO,
    payload: stateInfo
});

export const SET_CITIES_INFO = "SET_CITIES_INFO";
export const setCitiesInfo = (cityInfo) => ({
    type: SET_CITIES_INFO,
    payload: cityInfo
});

export const SET_INDUSTRY_INFO = "SET_INDUSTRY_INFO";
export const setIndustryInfo = (industryInfo) => ({
    type: SET_INDUSTRY_INFO,
    payload: industryInfo
});

export const SET_WORKFLOW_INFO = "SET_WORKFLOW_INFO";
export const setWorkflowInfo = (workflowInfo) => ({
    type: SET_WORKFLOW_INFO,
    payload: workflowInfo
});

export const SET_ORDER_INFO = "SET_ORDER_INFO";
export const setOrderInfo = (orderInfo) => ({
    type: SET_ORDER_INFO,
    payload: orderInfo
});

export const SET_ORDER_ITEM_INFO = "SET_ORDER_ITEM_INFO";
export const setOrderItemInfo = (orderItemInfo) => ({
    type: SET_ORDER_ITEM_INFO,
    payload: orderItemInfo
});
