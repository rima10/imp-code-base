import { SET_ORDER_INFO, SET_ORDER_ITEM_INFO } from "../action/type";

export default (state = {}, action) => {
    const { type, payload } = action;
    switch (type) {
        case SET_ORDER_INFO:
            return { ...state,
                orderInfo: payload };
        case SET_ORDER_ITEM_INFO:
            return { ...state,
                orderItemInfo: payload };
        default:
            return state;
    }
};


