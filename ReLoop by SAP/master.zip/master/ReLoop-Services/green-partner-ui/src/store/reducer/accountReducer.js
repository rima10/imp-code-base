import { SET_BP_BUSINESS_INFO, SET_BP_NETWORK_INFO, SET_BP_APPROVER_INFO,
    SET_CITIES_INFO, SET_STATES_INFO, SET_INDUSTRY_INFO, SET_WORKFLOW_INFO } from "../action/type";

export default (state = {}, action) => {
    const { type, payload } = action;
    switch (type) {
        case SET_BP_BUSINESS_INFO:
            return { ...state,
                businessInfo: payload };
        case SET_BP_NETWORK_INFO:
            return { ...state,
                networkInfo: payload };
        case SET_BP_APPROVER_INFO:
            return { ...state,
                approverInfo: payload };
        case SET_STATES_INFO:
            return { ...state,
                states: payload };
        case SET_CITIES_INFO:
            return { ...state,
                cities: payload };
        case SET_INDUSTRY_INFO:
            return { ...state,
                industry: payload };
        case SET_WORKFLOW_INFO:
            return { ...state,
                workflows: payload };
        default:
            return state;
    }
};


