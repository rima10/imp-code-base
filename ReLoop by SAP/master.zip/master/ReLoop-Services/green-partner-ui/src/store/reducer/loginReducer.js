import { SET_LOGIN_INFO } from "../action/type";

export default (state = {}, action) => {
    const { type, payload } = action;
    switch (type) {
        case SET_LOGIN_INFO:
            const { userInfo } = payload;
            return { ...userInfo, isLoggedIn: payload.isLoggedIn };
        default:
            return state;
    }
};
