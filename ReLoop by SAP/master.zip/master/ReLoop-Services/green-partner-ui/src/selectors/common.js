export const getWorkflow = (state) => state.account.workflows;

export const getNetworkInfoState = (state) => state.account.networkInfo;

export const getApproverInfoState = (state) => state.account.approverInfo;

export const getUserInfo = (state) => state.userInfo;
