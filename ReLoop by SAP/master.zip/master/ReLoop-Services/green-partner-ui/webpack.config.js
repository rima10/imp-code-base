const path = require("path");
 const HWP = require("html-webpack-plugin");
module.exports = {
  mode: 'development',
   entry: path.join(__dirname, "/src/index.js"),
   devtool: 'inline-source-map',
    output: {
       filename: "build.js",
       path: path.join(__dirname, "/dist")},
       devServer: {
         historyApiFallback: true,
         hot: true
       },
   module:{
       rules:[
          {
          test: /\.js$/,
           exclude: /node_modules/,
           use: ['babel-loader', 'eslint-loader'], // include eslint-loader
       },
       {
         test: /\.js|\.jsx$/,
         include: [
           path.resolve(__dirname, 'node_modules/react-jss/src'),
      
         
       ],
         exclude: /(node_modules|bower_components)/,
         
         use: ['babel-loader', 'eslint-loader'], // include eslint-loader
       },
       {
        test: /\.css$/,
        use: ["style-loader", "css-loader"],
      },
      {
        test: /\.png|svg|jpg|gif$/,
        use: ["file-loader"],
      },]
   },
   plugins:[
       new HWP(
          {template: path.join(__dirname,"/src/index.html")}
       )
  ]
  
}
