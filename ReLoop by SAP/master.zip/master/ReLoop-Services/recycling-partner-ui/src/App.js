

import React from "react";
import './App.css';
function App () {
    return (
        <div>
            <h1 className="App">Hello Recycling Partner</h1>
        </div>

    );
}

export default App;
