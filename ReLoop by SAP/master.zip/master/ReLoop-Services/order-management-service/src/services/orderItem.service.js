const dataTypes = require('sequelize').DataTypes;
const { sequelize } = require('../models/index');
const Order = require('../models/order')(sequelize, dataTypes);
const OrderItem = require('../models/order_item')(sequelize, dataTypes);
const utilFunctions = require('../utils/commonFunctions.util');

exports.createOrderItem = async function (req, res, next) {
  const assetList = utilFunctions.convertExcelToJson(req.file.buffer);
  const inputArr = assetList.slice(1);
  const order = await Order.findOne({ where: { order_no: req.order_no } });
  await Promise.all(inputArr.map(async (currElement) => {
    await OrderItem.create({
      order_id: order.order_id,
      equipment_no: currElement.A,
      asset_no: currElement.B,
      building_loc: currElement.E,
      bond_status: currElement.F,
      category_no: currElement.G,
      make: currElement.H,
      model: currElement.I,
      manufacture_serial: currElement.J,
      age_in_year: currElement.K,
      purchase_year: currElement.L,
      description: currElement.M,
      created_by: req.bpDetail,
      updated_by: req.bpDetail,
    });
  }));
};

exports.readExcel = async function (req) {
  const assetList = utilFunctions.convertExcelToJson(req.file.buffer);
  return assetList;
};
