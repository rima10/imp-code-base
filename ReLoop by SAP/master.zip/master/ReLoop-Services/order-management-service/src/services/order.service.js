const dataTypes = require('sequelize').DataTypes;
const { sequelize } = require('../models/index');
const Order = require('../models/order')(sequelize, dataTypes);
const utilFunctions = require('../utils/commonFunctions.util');
const s3UtilFunctions = require('../utils/s3.util');
const orderItemService = require('./orderItem.service');

exports.createOrder = async function (req) {
  const orderDetails = req.body;
  const bpDetail = req.params.userId;
  const uuid = utilFunctions.generateUUID();
  const s3FileLoc = await exports.pushFileToS3(req.files.picture[0]);
  await Order.create({
    order_no: uuid,
    order_type: orderDetails.orderType,
    category: orderDetails.category,
    sub_category: orderDetails.subcategory,
    order_network: orderDetails.network,
    order_loc: orderDetails.orderLocation,
    order_sub_text: orderDetails.additionalInfo,
    submission_deadline: orderDetails.submissionDeadline,
    picture_loc: s3FileLoc,
    created_by: bpDetail,
    updated_by: bpDetail,
  });
  const orderItemReq = {
    file: req.files.assetExcel[0],
    order_no: uuid,
    bpDetail,
  };
  orderItemService.createOrderItem(orderItemReq);
};

exports.pushFileToS3 = async function (req) {
  const s3Data = s3UtilFunctions.s3GetSignedURL(req);
  const s3FileLoc = await s3UtilFunctions.s3PutOrderImage(s3Data, req);
  return s3FileLoc;
};

exports.downloadTemplateFromS3 = async function (req) {
  const s3URLForTemplate = await s3UtilFunctions.getUrlForDownloadTemplate(req);
  const data = await s3UtilFunctions.s3DownloadTemplate(s3URLForTemplate);
  console.log(data);
  await utilFunctions.writeFile(data);
  // const readStream = s3UtilFunctions.s3DownloadTemplate(s3URLForTemplate);
  // return readStream;
};
