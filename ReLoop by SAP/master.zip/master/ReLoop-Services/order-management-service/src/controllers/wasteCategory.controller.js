const wasteCategoryService = require('../services/wasteCategory.service');

/*
  @desc controller function for Wate Category creation
*/
exports.createCategory = async function (req, res, next) {
  try {
    await wasteCategoryService.createCategory(req, res, next);
    res.send(200);
  } catch (error) {
    next(error);
  }
};

/*
    @desc controller function for fetching waste category
  */
exports.getCategory = async function (req, res, next) {
  try {
    await wasteCategoryService.getCategory(req, res, next);
    res.send(200);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function for Wate Category creation
*/
exports.createSubcategory = async function (req, res, next) {
  try {
    await wasteCategoryService.createSubcategory(req, res, next);
    res.send(200);
  } catch (error) {
    next(error);
  }
};

/*
    @desc controller function for fetching waste category
  */
exports.getsubCategory = async function (req, res, next) {
  try {
    await wasteCategoryService.getsubCategory(req, res, next);
    res.send(200);
  } catch (error) {
    next(error);
  }
};
