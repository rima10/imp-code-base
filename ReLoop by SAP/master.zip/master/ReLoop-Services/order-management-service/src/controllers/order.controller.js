const orderService = require('../services/order.service');

/*
  @desc controller function for user registeration
*/
exports.createOrder = async function (req, res, next) {
  try {
    await orderService.createOrder(req, res, next);
    res.send(200);
  } catch (error) {
    next(error);
  }
};

exports.pushFileToS3 = async function (req, res, next) {
  try {
    await orderService.pushFileToS3(req, res, next);
    res.send(200);
  } catch (error) {
    next(error);
  }
};

exports.downloadTemplateFromS3 = async function (req, res, next) {
  try {
    await orderService.downloadTemplateFromS3(req, res, next);
  } catch (error) {
    next(error);
  }
};
