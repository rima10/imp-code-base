const aws = require('aws-sdk');
const dotenv = require('dotenv');
const request = require('request');
const utilFunctions = require('./commonFunctions.util');

dotenv.config();
const s3Data = {
  accessKeyId: process.env.S3_ACCESS_KEY_ID,
  secretAccessKey: process.env.S3_SECRET_ACCESS_KEY,
  region: process.env.S3_REGION,
};

const S3_BUCKET = process.env.S3_Bucket;
aws.config.update(
  {
    accessKeyId: s3Data.accessKeyId,
    secretAccessKey: s3Data.secretAccessKey,
    region: s3Data.region,
    signatureVersion: 'v4',
  },
);
const s3 = new aws.S3();
exports.s3GetSignedURL = function (file) {
  const fileNamewithExt = file.originalname;
  const fileName = fileNamewithExt.substr(0, fileNamewithExt.lastIndexOf('.'));

  const fileType = file.mimetype; // the content-type of the file
  const s3Params = {
    Bucket: S3_BUCKET,
    Fields: {
      key: fileName + utilFunctions.generateUUID(),
    },
    Conditions: [
      ['content-length-range', 0, 100000000],
    ],
    ContentType: fileType,
  };

  const data = s3.createPresignedPost(s3Params);
  return data;
};

exports.s3PutOrderImage = async function (s3Detail, file) {
  const options = {
    method: 'POST',
    url: s3Detail.url,
    formData: {
      ...s3Detail.fields,
      file: file.buffer,
    },
  };

  return new Promise((resolve, reject) => {
    request(options, (error, response) => {
      resolve(response.headers.location);
      reject();
    });
  });
};

exports.getUrlForDownloadTemplate = function () {
  const s3Params = {
    Bucket: S3_BUCKET,
    Key: process.env.S3_Asset_Template,
    Expires: 60 * 5,
  };

  const urlData = s3.getSignedUrl('getObject', s3Params);
  return urlData;
};

exports.s3DownloadTemplate = async function (s3URLForTemplate) {
  const options = {
    url: s3URLForTemplate,
    method: 'GET',
    responseType: 'arrayBuffer',
    headers: {
      ContentType: 'application/json',
      Accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    },
  };
  return new Promise((resolve, reject) => {
    request(options, (error, response) => {
      resolve(response);
      reject();
    });
  });
};
