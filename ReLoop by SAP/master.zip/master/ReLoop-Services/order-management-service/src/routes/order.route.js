const router = require('express').Router();
const multer = require('multer');

const upload = multer();
const orderController = require('../controllers/order.controller');

module.exports = (app) => {
  /**
 * @swagger
 * /api/order/createOrder:
 *   post:
 *    description:  Endpoint to create Order
 *    tags:
 *      - Order
 *    parameters:
 *      - name: userId
 *        description: id of the green partner
 *        in: path
 *        required: true
 *        type: number
 *    requestBody:
 *      content:
 *        multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *              orderType:
 *                type: string
 *                example: Refurbish
 *              category:
 *                type: integer
 *                example: 1
 *              subcategory:
 *                type: integer
 *                example: 1
 *              network:
 *                type: string
 *                example: Private
 *              orderLocation:
 *                type: string
 *              additionalInfo:
 *                type: string
 *              submissionDeadline:
 *                type: string
 *              picture:
 *                type: string
 *                format: binary
 *              assetExcel:
 *                type: string
 *                format: binary
 */
  router.post('/createOrder/:userId', upload.fields([{
    name: 'picture', maxCount: 1,
  }, {
    name: 'assetExcel', maxCount: 1,
  }]), orderController.createOrder);
  router.get('/downloadTemplate', orderController.downloadTemplateFromS3);
  app.use('/api/order', router);
};
