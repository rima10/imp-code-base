const router = require('express').Router();
const wasteCategoryController = require('../controllers/wasteCategory.controller');

module.exports = (app) => {
  /**
 * @swagger
 * /api/wasteCategory/createCategory:
 *   post:
 *    description:  Endpoint to create Category
 *    tags:
 *      - Category
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              categoryName:
 *                type: string
 *                description: Category name.
 *                example: E-waste
 */
  router.post('/createCategory', wasteCategoryController.createCategory);

  /**
 * @swagger
 * /api/wasteCategory/createSubcategory:
 *   post:
 *    description:  Endpoint to create Sub Category
 *    tags:
 *      - SubCategory
 *    parameters:
 *       - name: categoryID
 *         description: id of the Category
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              subcategories:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    subcategoryName:
 *                      type: string
 *                      description: Sub Category name.
 *                      example: IT and telecom
 */
  router.post('/createSubcategory/:categoryID', wasteCategoryController.createSubcategory);
  /**
 * @swagger
 * /api/wasteCategory/getCategory:
 *   get:
 *    description:  Endpoint to get list of categories
 *    tags:
 *      - Category
 *    responses:
 *       200:
 *         description: A list of categories.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Category'
 */
  router.get('/getCategory', wasteCategoryController.getCategory);
  /**
 * @swagger
 * /api/wasteCategory/getsubCategory:
 *   get:
 *    description:  Endpoint to get list of sub categories
 *    tags:
 *      - SubCategory
 *    responses:
 *       200:
 *         description: A list of sub categories.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/SubCategory'
 */
  router.get('/getSubcategory', wasteCategoryController.getsubCategory);
  app.use('/api/wasteCategory', router);
};
