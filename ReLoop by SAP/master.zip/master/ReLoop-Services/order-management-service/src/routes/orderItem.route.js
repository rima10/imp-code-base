const router = require('express').Router();
const multer = require('multer');

const upload = multer();

const orderItemController = require('../controllers/orderItem.controller');

module.exports = (app) => {
  router.post('/createOrderItem', upload.single('assetExcel'), orderItemController.createOrderItem);
  // router.get('/readExcel', upload.single('assetExcel'), orderItemController.readExcel);
  /**
 * @swagger
 * /api/order/orderItem/readExcel:
 *   post:
 *    description:  Endpoint to post excel data
 *    tags:
 *      - OrderItem Details
 *    requestBody:
 *      content:
 *        multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *              assetExcel:
 *                type: string
 *                format: binary
 *      responses:
 *       200:
 *         description: A list of asset.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                type: object
 *                properties:
 *                  Equipment No:
 *                    type: string
 *                    description: Equipment Number
 *                    example: 5X86XXXX
 *                  Asset No:
 *                    type: string
 *                    description: Asset No
 *                    example: 5X86XXXX
 */
  router.post('/readExcel', upload.single('assetExcel'), orderItemController.readExcel);
  app.use('/api/order/orderItem', router);
};
