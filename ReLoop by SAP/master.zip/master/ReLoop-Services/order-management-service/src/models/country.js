const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('country', {
    country_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    country_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'country',
    schema: 'address',
    timestamps: false,
    indexes: [
      {
        name: 'country_pkey',
        unique: true,
        fields: [
          { name: 'country_id' },
        ],
      },
    ],
  });
};
