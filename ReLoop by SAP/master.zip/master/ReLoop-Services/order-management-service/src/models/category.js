/**
 * @swagger
 *  components:
 *    schemas:
 *      Category:
 *        type: object
 *        required:
 *        properties:
 *          category_id:
 *            type: string
 *          category_name:
 *            type: string
 *        example:
 *           category_id: 1
 *           category_name: E-waste
 */

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('category', {
    category_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    category_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'category',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'category_pkey',
        unique: true,
        fields: [
          { name: 'category_id' },
        ],
      },
    ],
  });
};
