module.exports = function (sequelize, DataTypes) {
  return sequelize.define('recycling_sub_category', {
    rcy_cat_map_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    rcy_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    subcat_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'sub_category',
        key: 'sub_category_id',
      },
    },
  }, {
    sequelize,
    tableName: 'recycling_sub_category',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'recycling_sub_category_pkey',
        unique: true,
        fields: [
          { name: 'rcy_cat_map_id' },
        ],
      },
    ],
  });
};
