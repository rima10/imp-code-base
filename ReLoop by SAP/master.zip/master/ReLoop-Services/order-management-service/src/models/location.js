module.exports = function (sequelize, DataTypes) {
  return sequelize.define('location', {
    loc_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    country_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'country',
        key: 'country_id',
      },
    },
    state_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'state',
        key: 'state_id',
      },
    },
    city_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'city',
        key: 'city_id',
      },
    },
    loc_details: {
      type: DataTypes.STRING(10),
      allowNull: false,
    },
    pincode: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'location',
    schema: 'address',
    timestamps: false,
    indexes: [
      {
        name: 'location_pkey',
        unique: true,
        fields: [
          { name: 'loc_id' },
        ],
      },
    ],
  });
};
