const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('order_workflow_approver', {
    order_workflow_approver_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_workflow_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order_workflow',
        key: 'order_workflow_id',
      },
    },
    workflow_approver_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'workflow_approver',
        key: 'workflow_approver_id',
      },
    },
    status: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'order_workflow_approver',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'order_workflow_approver_pkey',
        unique: true,
        fields: [
          { name: 'order_workflow_approver_id' },
        ],
      },
    ],
  });
};
