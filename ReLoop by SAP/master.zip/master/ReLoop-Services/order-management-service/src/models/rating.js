module.exports = function (sequelize, DataTypes) {
  return sequelize.define('rating', {
    rating_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    rating_star: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    bp_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    given_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    rating_comment: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'rating',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'rating_pkey',
        unique: true,
        fields: [
          { name: 'rating_id' },
        ],
      },
    ],
  });
};
