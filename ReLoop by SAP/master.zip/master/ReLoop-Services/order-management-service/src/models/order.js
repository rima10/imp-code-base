const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('order', {
    order_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_no: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: 'order_order_no_key',
    },
    order_sub_text: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    category: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'category',
        key: 'category_id',
      },
    },
    sub_category: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'sub_category',
        key: 'sub_category_id',
      },
    },
    order_type: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    created_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    updated_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    submission_deadline: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    preferred_pick_up_time: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    is_verification_reqd: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    order_loc: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    order_network: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    picture_loc: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'order',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'order_order_no_key',
        unique: true,
        fields: [
          { name: 'order_no' },
        ],
      },
      {
        name: 'order_pkey',
        unique: true,
        fields: [
          { name: 'order_id' },
        ],
      },
    ],
  });
};
