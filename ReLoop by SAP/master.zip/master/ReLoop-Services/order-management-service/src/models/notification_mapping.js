const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('notification_mapping', {
    notificatn_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    to_email: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    notification_body: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    notification_status: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    notification_text: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
  }, {
    sequelize,
    tableName: 'notification_mapping',
    schema: 'notification',
    timestamps: false,
    indexes: [
      {
        name: 'notification_mapping_pkey',
        unique: true,
        fields: [
          { name: 'notificatn_id' },
        ],
      },
    ],
  });
};
