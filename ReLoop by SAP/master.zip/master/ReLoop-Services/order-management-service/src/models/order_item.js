const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('order_item', {
    id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order',
        key: 'order_id',
      },
    },
    equipment_no: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    asset_no: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    category_no: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    make: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    description: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    grade: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    blancco: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    report_status: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    list_price: {
      type: DataTypes.DECIMAL,
      allowNull: true,
    },
    to_be_invoiced: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    service_cost: {
      type: DataTypes.DECIMAL,
      allowNull: true,
    },
    item_quantity: {
      type: DataTypes.DECIMAL,
      allowNull: true,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    created_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    updated_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    company_name: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    company_code: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    building_loc: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    manufacture_serial: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    bond_status: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    model: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    age_in_year: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    purchase_year: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'order_item',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'order_item_pkey',
        unique: true,
        fields: [
          { name: 'id' },
        ],
      },
    ],
  });
};
