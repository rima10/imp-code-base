module.exports = function (sequelize, DataTypes) {
  return sequelize.define('order_invited_business_partner', {
    order_invited_bp_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order',
        key: 'order_id',
      },
    },
    invited_bp_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
  }, {
    sequelize,
    tableName: 'order_invited_business_partner',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'order_invited_business_partner_pkey',
        unique: true,
        fields: [
          { name: 'order_invited_bp_id' },
        ],
      },
    ],
  });
};
