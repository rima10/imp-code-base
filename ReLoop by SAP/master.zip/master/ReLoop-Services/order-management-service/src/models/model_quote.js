module.exports = function (sequelize, DataTypes) {
  return sequelize.define('model_quote', {
    model_quote_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_quote_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order_quote',
        key: 'id',
      },
    },
    model_category: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    make: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    price_grade_a: {
      type: DataTypes.DECIMAL,
      allowNull: false,
    },
    price_grade_b: {
      type: DataTypes.DECIMAL,
      allowNull: false,
    },
    price_grade_c: {
      type: DataTypes.DECIMAL,
      allowNull: false,
    },
    price_grade_d: {
      type: DataTypes.DECIMAL,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'model_quote',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'model_quote_pkey',
        unique: true,
        fields: [
          { name: 'model_quote_id' },
        ],
      },
    ],
  });
};
