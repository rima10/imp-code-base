exports.options = {
  definition: {
    openapi: '3.0.1',
    info: {
      title: 'ReLoop Order Management swagger API',
      version: '0.1.0',
      description:
            'ReLoop Order Management service documented with swagger',
    },
    host: 'localhost:5002',
    basePath: '/api/order',
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
        },
      },
    },
    security: [{
      bearerAuth: [],
    }],
  },

  apis: ['./src/models/**.js', './src/routes/**.route.js'],
};
