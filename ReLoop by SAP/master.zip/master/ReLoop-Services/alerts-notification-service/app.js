const express = require('express');
const kafkaUtil = require('./src/utils/kafka.util');

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
module.exports = app;

// Run all kafka consumers
kafkaUtil.runConsumers();

// centralized error handler middleware for the app
// eslint-disable-next-line no-unused-vars
app.use((error, req, res, next) => {
  res.status(error.status || 500);
  res.json({
    error: {
      message: error.message,
    },
  });
});
