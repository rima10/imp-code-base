exports.sampleTemp = {
  Destination: {
    ToAddresses: [], // Email address/addresses that you want to send your email
  },
  Message: {
    Body: {
      Html: {
        // HTML Format of the email
        Charset: 'UTF-8',
        Data:
              "<html><body><h1>Hello  Amit</h1><p style='color:red'>Sample description</p> <p>Time 1517831318946</p></body></html>",
      },
      Text: {
        Charset: 'UTF-8',
        Data: 'Hello Amit Sample description time 1517831318946',
      },
    },
    Subject: {
      Charset: 'UTF-8',
      Data: 'Test email',
    },
  },
  Source: 'amit.sharma10@sap.com',
};
