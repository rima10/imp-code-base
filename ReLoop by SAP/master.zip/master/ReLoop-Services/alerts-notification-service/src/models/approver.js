module.exports = function (sequelize, DataTypes) {
  return sequelize.define('approver', {
    approver_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    approver_userid: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: 'approver_approver_userid_key',
    },
    approver_email_id: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: 'approver_approver_email_id_key',
    },
    approver_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    bp_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
  }, {
    sequelize,
    tableName: 'approver',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'approver_approver_email_id_key',
        unique: true,
        fields: [
          { name: 'approver_email_id' },
        ],
      },
      {
        name: 'approver_approver_userid_key',
        unique: true,
        fields: [
          { name: 'approver_userid' },
        ],
      },
      {
        name: 'approver_pkey',
        unique: true,
        fields: [
          { name: 'approver_id' },
        ],
      },
    ],
  });
};
