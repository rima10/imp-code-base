const { DataTypes } = require('sequelize');
const _approver = require('./approver');
const _business_partner = require('./business_partner');
const _event = require('./event');
const _notification = require('./notification');
const _bp_notification = require('./bp_notification');

function initModels(sequelize) {
  const approver = _approver(sequelize, DataTypes);
  const business_partner = _business_partner(sequelize, DataTypes);
  const event = _event(sequelize, DataTypes);
  const notification = _notification(sequelize, DataTypes);
  const bp_notification = _bp_notification(sequelize, DataTypes);

  approver.belongsTo(business_partner, { as: 'bp', foreignKey: 'bp_id' });
  business_partner.hasMany(approver, { as: 'approvers', foreignKey: 'bp_id' });

  notification.belongsTo(event, { as: 'event', foreignKey: 'event_id' });
  event.hasMany(notification, { as: 'notification', foreignKey: 'event_id' });

  bp_notification.belongsTo(notification, { as: 'notification', foreignKey: 'notification_id' });
  notification.hasMany(bp_notification, { as: 'notification', foreignKey: 'notification_id' });

  bp_notification.belongsTo(business_partner, { as: 'bp', foreignKey: 'bp_id' });
  business_partner.hasMany(bp_notification, { as: 'notification', foreignKey: 'bp_id' });

  bp_notification.belongsTo(approver, { as: 'approver', foreignKey: 'approver_id' });
  approver.hasMany(bp_notification, { as: 'notification', foreignKey: 'approver_id' });

  return {
    approver,
    business_partner,
    event,
    notification,
    bp_notification,
  };
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;
