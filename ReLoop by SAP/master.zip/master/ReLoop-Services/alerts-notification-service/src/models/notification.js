const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('notification', {
    notification_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    notification_body: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    notification_text: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    event_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'event',
        key: 'event_id',
      },
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
  }, {
    sequelize,
    tableName: 'notification',
    schema: 'notification',
    timestamps: false,
    indexes: [
      {
        name: 'notification_pkey',
        unique: true,
        fields: [
          { name: 'notification_id' },
        ],
      },
    ],
  });
};
