const ses = require('../utils/ses.util');
const dataTypes = require('sequelize').DataTypes;
const { sequelize } = require('../models/index');
const Models = require('../models/init-models')(sequelize, dataTypes);

const storeNotification = async (type, message, receivers) => {
  const event = await Models.event.findOne({ where: { event_type: type } });
  const notification = await Models.notification.create({
    event_id: event.event_id,
    notification_text: message,
    notification_body: message,
  });
  receivers.map(async (receiver) => {
    const { receiverType, email } = receiver;
    let receiverId = '';
    if (receiverType === 'bp') {
      const receiverUser = await Models.business_partner.findOne({ where: { bp_email_id: email } });
      receiverId = receiverUser.bp_id;
    } else {
      const receiverUser = await Models.approver.findOne({ where: { approver_email_id: email } });
      receiverId = receiverUser.approver_id;
    }
    await Models.bp_notification.create({
      notification_id: notification.notification_id,
      bp_id: receiverType === 'bp' ? receiverId : null,
      approver_id: receiverType === 'bp' ? null : receiverId,
    });
  });
};

const getMessage = (type, values = {}) => {
  const { orderId } = values;
  switch (type) {
    case 'new_Order':
      return 'A new order is added and waiting for your approval';
    case 'waiting approval':
      return `Order No: ${orderId} is awaiting for your approval`;
    default:
      return false;
  }
};

exports.notify = async function (message) {
  const messageJson = JSON.parse(message.value.toString());
  const { type, receivers, values } = messageJson;
  const messageText = getMessage(type, values);
  await storeNotification(type, messageText, receivers);
};
