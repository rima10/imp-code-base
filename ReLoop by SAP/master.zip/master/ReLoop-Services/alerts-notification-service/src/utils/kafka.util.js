const { Kafka } = require('kafkajs');
const alertService = require('../services/alert.service');

const CLIENT_ID = 'alerts-notification';
const config = { clientId: CLIENT_ID, brokers: ['localhost:29092'] };
const kafka = new Kafka(config);
const consumer = kafka.consumer({ groupId: CLIENT_ID });

async function kafkaConsumerHandler(topic, message) {
  switch (topic) {
    case 'user-notification':
      alertService.notify(message);
      break;
    default:
      console.log('invalid topic');
      break;
  }
}

async function runConsumer(topic) {
  await consumer.connect();
  await consumer.subscribe({ topic });
  await consumer.run({
    eachMessage: ({ message }) => {
      // here, we just log the message to the standard output
      kafkaConsumerHandler(topic, message);
    },
  });
}

exports.runConsumers = async function () {
  const topics = ['user-notification'];
  try {
    await Promise.all(topics.map(async (topic) => {
      await runConsumer(topic);
    }));
  } catch (error) {
    console.log(error);
  }
};
