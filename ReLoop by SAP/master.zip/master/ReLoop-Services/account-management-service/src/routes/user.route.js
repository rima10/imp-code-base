const router = require('express').Router();
const userController = require('../controllers/user.controller');
const validator = require('../utils/validate.util');
const authUtil = require('../utils/auth.util');

/*
  @desc router configuartion for /api/user endpoint
*/

module.exports = (app) => {
  /**
 * @swagger
 * /api/user/register:
 *   post:
 *    description:  Endpoint to register business partner
 *    tags:
 *      - Business Partner
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/User'
 */
  router.post('/register', validator.createUserValidations, validator.validate, userController.register);

  /**
 * @swagger
 * /api/user/update/{userId}:
 *   patch:
 *    description:  Endpoint to update business partner
 *    tags:
 *      - Business Partner
 *    parameters:
 *       - name: userId
 *         description: id of the business partner
 *         in: path
 *         required: true
 *         type: number
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/User'
 */
  router.patch('/update/:userId', [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isUserAsset], userController.updateUserBusinessData);

  /**
 * @swagger
 * /api/user/getBusinessInfo/{userId}:
 *   get:
 *    description:  Endpoint to update business partner
 *    tags:
 *      - Business Partner
 *    parameters:
 *       - name: userId
 *         description: id of the business partner
 *         in: path
 *         required: true
 *         type: number
 *    responses:
 *       200:
 *         description: A list of user's private networks.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/User'
 */
  router.get('/getBusinessInfo/:userId', [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isUserAsset], userController.getUserBusinessData);
  /**
 * @swagger
 * /api/user/createprivatenetwork/{userId}:
 *   post:
 *    description:  Endpoint to create business partner private network
 *    tags:
 *      - Private Network
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: number
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              pvtRecyclers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    emailId:
 *                      type: string
 *                      format: email
 *                      description: Email for the user, needs to be unique.
 *                      example: 0
 *                    username:
 *                      type: string
 *                      description: The Recycling partner user's name.
 *                      example: Cerebra
 */
  router.post('/createprivatenetwork/:userId', [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isUserAsset], userController.createUserPrivateNtw);

  /**
 * @swagger
 * /api/user/getprivatenetwork/{userId}:
 *   get:
 *    description:  Endpoint to get business partner private networks
 *    tags:
 *      - Private Network
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: number
 *    responses:
 *       200:
 *         description: A list of user's private networks.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/PrivateNetwork'
 */
  router.get('/getprivatenetwork/:userId', [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isUserAsset], userController.getUserPrivateNtw);

  /**
 * @swagger
 * /api/user/deleteprivatenetwork/{userId}:
 *   delete:
 *    description:  Endpoint to delete business partner private networks
 *    tags:
 *      - Private Network
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: number
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              pvtNetworks:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    recyclerId:
 *                      type: string
 *                      description: private recycler user id
 *                      example: 1
 *                    networkId:
 *                      type: string
 *                      description: private network id
 *                      example: 1
 *    responses:
 *       200:
 *         description: A list of user's private networks.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/PrivateNetwork'
 */
  router.delete('/deleteprivatenetwork/:userId', [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isUserAsset], userController.deleteUserPrivateNtw);

  /**
 * @swagger
 * /api/user/updateUserPrivateNetwork/{userId}:
 *   patch:
 *    description:  Endpoint to update business partner
 *    tags:
 *      - Private Network
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: number
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              pvtRecyclers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    emailId:
 *                      type: string
 *                      format: email
 *                      description: Email for the user, needs to be unique.
 *                      example: rpuser@domain.com
 *                    username:
 *                      type: string
 *                      description: The Recycling partner user's name.
 *                      example: Cerebra
 */
  router.patch('/updateUserPrivateNetwork/:userId', [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isUserAsset], userController.updateUserPrivateNtw);

  /**
 * @swagger
 * /api/user//getUserData/{cognitoId}:
 *   get:
 *    description:  Endpoint to get user data with cognito id
 *    tags:
 *      - Business Partner
 *    parameters:
 *       - name: cognitoId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: string
 *
 */
  router.get('/getUserData/:cognitoId', userController.getUserData);
  app.use('/api/user', router);
};
