const router = require('express').Router();
const workflowController = require('../controllers/workflow.controller');
const authUtil = require('../utils/auth.util');

module.exports = (app) => {
  /**
 * @swagger
 * /api/user/workflow/addWorkflows/{userId}:
 *   post:
 *    description:  Endpoint to create workflows data
 *    tags:
 *      - Workflow
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *              type: object
 *              required:
 *              properties:
 *              workflows:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    processStageSequence:
 *                      type: number
 *                      description: process stage sequence number
 *                      example: 1
 *                    processStageName:
 *                      type: string
 *                      description: process stage name.
 *                      example: Initial
 *                    processTypeId:
 *                      type: string
 *                      description: recycling or refurbishing process id.
 *                      example: admin
 *                    approvers:
 *                      type: array
 *                      description: list of approvers.
 *                      items:
 *                          type: object
 *                          properties:
 *                              approverId:
 *                                  type: string
 *                                  description: approver id
 *                                  example: 1
 *                              approverSequence:
 *                                  type: number
 *                                  description: approver sequence in workflow
 *                                  example: 1
 *
 */
  router.post('/addWorkflows/:userId', [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isUserAsset], workflowController.addWorkflows);

  /**
 * @swagger
 * /api/user/workflow/addWorkflow/{userId}:
 *   post:
 *    description:  Endpoint to create workflow data
 *    tags:
 *      - Workflow
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *              type: object
 *              required:
 *              properties:
 *                  processStageSequence:
 *                      type: number
 *                      description: process stage sequence number
 *                      example: 1
 *                  processStageName:
 *                      type: string
 *                      description: process stage name.
 *                      example: Initial
 *                  processTypeId:
 *                      type: string
 *                      description: recycling or refurbishing process id.
 *                      example: admin
 *                  approvers:
 *                      type: array
 *                      description: list of approvers.
 *                      items:
 *                          type: object
 *                          properties:
 *                              approverId:
 *                                  type: string
 *                                  description: approver id
 *                                  example: 1
 *                              approverSequence:
 *                                  type: number
 *                                  description: approver sequence in workflow
 *                                  example: 1
 *
 */
  router.post('/addWorkflow/:userId', [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isUserAsset], workflowController.addWorkflow);

  /**
 * @swagger
 * /api/user/workflow/getWorkflows/{userId}:
 *   get:
 *    description:  Endpoint to update approver data
 *    tags:
 *      - Workflow
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: A list of user's workflows.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Workflow'
 */
  router.get('/getWorkflows/:userId', [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isUserAsset], workflowController.getWorkflows);
  /**
 * @swagger
 * /api/user/workflow/deleteWorkflow/{userId}/{workflowId}:
 *   delete:
 *    description:  Endpoint to delete business partner workflow
 *    tags:
 *      - Workflow
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: number
 *       - name: workflowId
 *         description: id of the workflow
 *         in: path
 *         required: true
 *         type: number
 *    responses:
 *       201:
 *         description: workflow deleted successfully.
 */
  router.delete('/deleteWorkflow/:userId/:workflowId', [authUtil.validateMiddleware, authUtil.isGpUser], workflowController.deleteWorkflow);
  /**
 * @swagger
 * /api/user/workflow/deleteWorkflowApprover:
 *   delete:
 *    description:  Endpoint to delete business partner workflow approver
 *    tags:
 *      - Workflow
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              workflowApprovers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    workflowApproverId:
 *                      type: string
 *                      description: workflow approver id
 *                      example: 1
 *    responses:
 *       201:
 *         description: workflow approvers deleted
 */
  router.delete('/deleteWorkflowApprover', [authUtil.validateMiddleware, authUtil.isGpUser], workflowController.deleteWorkflowApprovers);
  app.use('/api/user/workflow', router);
};
