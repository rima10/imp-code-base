const router = require('express').Router();
const locController = require('../controllers/loc.controller');

/*
  @desc router configuartion for /api/user/location endpoint
*/

module.exports = (app) => {
  /**
 * @swagger
 * /api/user/loc/createAddress:
 *   post:
 *    description:  Endpoint to create location data
 *    tags:
 *      - Location
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              addresses:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    countryName:
 *                      type: string
 *                      description: Country Name
 *                      example: India
 *                    stateName:
 *                      type: string
 *                      description: State name.
 *                      example: Delhi
 *                    cityName:
 *                      type: string
 *                      description: City name.
 *                      example: New Delhi
 */
  router.post('/createAddress', locController.createAddress);

  /**
 * @swagger
 * /api/user/loc/createCountry:
 *   post:
 *    description:  Endpoint to create country data
 *    tags:
 *      - Location
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *              $ref: '#/components/schemas/Country'
 */
  router.post('/createCountry', locController.createCountry);

  /**
 * @swagger
 * /api/user/loc/createState:
 *   post:
 *    description:  Endpoint to create state data
 *    tags:
 *      - Location
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *              $ref: '#/components/schemas/State'
 */
  router.post('/createState', locController.createState);

  /**
 * @swagger
 * /api/user/loc/createCity:
 *   post:
 *    description:  Endpoint to create city data
 *    tags:
 *      - Location
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *              $ref: '#/components/schemas/City'
 */
  router.post('/createCity', locController.createCity);

  /**
 * @swagger
 * /api/user/loc/getCountryList:
 *   get:
 *    description:  Endpoint to get list of countries
 *    tags:
 *      - Location
 *    responses:
 *       200:
 *         description: A list of countries.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Country'
 */
  router.get('/getCountryList', locController.getCountryList);

  /**
 * @swagger
 * /api/user/loc/getCountry/{countryId}:
 *   get:
 *    description:  Endpoint to get list of countries
 *    tags:
 *      - Location
 *    parameters:
 *       - name: countryId
 *         description: id of the country
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: Details of the country.
 *         content:
 *           application/json:
 *             schema:
 *              type: object
 *              items:
 *                $ref: '#/components/schemas/Country'
 */
  router.get('/getCountry/:countryId', locController.getCountry);

  /**
 * @swagger
 * /api/user/loc/getStateList:
 *   get:
 *    description:  Endpoint to get list of state
 *    tags:
 *      - Location
 *    responses:
 *       200:
 *         description: A list of states.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/State'
 */
  router.get('/getStateList', locController.getStateList);

  /**
 * @swagger
 * /api/user/loc/getStatesbyCountry/{countryId}:
 *   get:
 *    description:  Endpoint to get list of state by country
 *    tags:
 *      - Location
 *    parameters:
 *       - name: countryId
 *         description: id of the country
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: list of states by the country.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/State'
 */
  router.get('/getStatesbyCountry/:countryId', locController.getStatesbyCountry);

  /**
 * @swagger
 * /api/user/loc/getState/{stateId}:
 *   get:
 *    description:  Endpoint to get state
 *    tags:
 *      - Location
 *    parameters:
 *       - name: stateId
 *         description: id of the state
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: state object.
 *         content:
 *           application/json:
 *             schema:
 *              type: object
 *              items:
 *                $ref: '#/components/schemas/State'
 */
  router.get('/getState/:stateId', locController.getState);

  /**
 * @swagger
 * /api/user/loc/getCityList:
 *   get:
 *    description:  Endpoint to get list of city
 *    tags:
 *      - Location
 *    responses:
 *       200:
 *         description: A list of cities.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/City'
 */
  router.get('/getCityList', locController.getCityList);

  /**
 * @swagger
 * /api/user/loc/getCitiesByState/{stateId}:
 *   get:
 *    description:  Endpoint to get list of cities by state
 *    tags:
 *      - Location
 *    parameters:
 *       - name: stateId
 *         description: id of the state
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: list of cities by state.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/city'
 */
  router.get('/getCitiesByState/:stateId', locController.getCitiesByState);

  /**
 * @swagger
 * /api/user/loc/getCity/{cityId}:
 *   get:
 *    description:  Endpoint to get city
 *    tags:
 *      - Location
 *    parameters:
 *       - name: cityId
 *         description: id of the state
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: city object
 *         content:
 *           application/json:
 *             schema:
 *              type: object
 *              items:
 *                $ref: '#/components/schemas/city'
 */
  router.get('/getCity/:cityId', locController.getCity);
  app.use('/api/user/loc', router);
};
