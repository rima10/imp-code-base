const router = require('express').Router();
const swaggerUi = require('swagger-ui-express');
const swaggerJSDoc = require('swagger-jsdoc');
const swaggerConfig = require('../config/swaggerConfig');

/*
  @desc router configuartion for /api/user endpoint
*/
module.exports = (app) => {
  const swaggerSpec = swaggerJSDoc(swaggerConfig.options);
  router.use('/', swaggerUi.serve, swaggerUi.setup(swaggerSpec, { explorer: true }));
  app.use('/api-docs', router);
};
