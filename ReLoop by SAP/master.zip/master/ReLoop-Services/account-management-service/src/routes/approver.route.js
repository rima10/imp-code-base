const router = require('express').Router();
const approverController = require('../controllers/approver.controller');
const authUtil = require('../utils/auth.util');

module.exports = (app) => {
  /**
 * @swagger
 * /api/user/approver/addApprovers/{userId}:
 *   post:
 *    description:  Endpoint to create approver data
 *    tags:
 *      - Approver
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              approvers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    approverEmailId:
 *                      type: string
 *                      description: approver email id
 *                      example: fake@email.com
 *                    approverName:
 *                      type: string
 *                      description: approver name.
 *                      example: Raj
 *                    approverRole:
 *                      type: string
 *                      description: approver role.
 *                      example: admin
 */
  router.post('/addApprovers/:userId', [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isUserAsset], approverController.addApprovers);

  /**
 * @swagger
 * /api/user/approver/getApprovers/{userId}:
 *   get:
 *    description:  Endpoint to get list of GP approvers
 *    tags:
 *      - Approver
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: List of approvers.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Approver'
 */
  router.get('/getApprovers/:userId', [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isUserAsset], approverController.getApprovers);

  /**
 * @swagger
 * /api/user/approver/deleteApprovers/{userId}/{approverId}:
 *   delete:
 *    description:  Endpoint to delete GP approver
 *    tags:
 *      - Approver
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: string
 *       - name: approverId
 *         description: id of the approver
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       201:
 *         description: List of approvers.
 *         content:
 *           application/json:
 */
  router.delete('/deleteApprovers/:userId/:approverId', [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isUserAsset], approverController.deleteApprover);
  /**
 * @swagger
 * /api/user/approver/deleteApprovers/{userId}:
 *   delete:
 *    description:  Endpoint to delete GP approver
 *    tags:
 *      - Approver
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              approvers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    approverId:
 *                      type: string
 *                      description: approver user id
 *                      example: 1
 *    responses:
 *       201:
 *         description: List of approvers.
 *         content:
 *           application/json:
 */
  router.delete('/deleteApprovers/:userId', [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isUserAsset], approverController.deleteApprovers);

  /**
 * @swagger
 * /api/user/approver/updateApprovers/{userId}:
 *   patch:
 *    description:  Endpoint to update approver data
 *    tags:
 *      - Approver
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              approvers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    approverEmailId:
 *                      type: string
 *                      description: approver email id
 *                      example: fake@email.com
 *                    approverName:
 *                      type: string
 *                      description: approver name.
 *                      example: Raj
 *                    approverRole:
 *                      type: string
 *                      description: approver role.
 *                      example: admin
 */
  router.patch('/updateApprovers/:userId', [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isUserAsset], approverController.updateApprovers);
  app.use('/api/user/approver', router);
};
