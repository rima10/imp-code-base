const userService = require('../services/user.service');
const businessDataService = require('../services/businessData.service');
const privateNtwService = require('../services/privateNtw.service');

/*
  @desc controller function for user registeration
*/
exports.register = async (req, res, next) => {
  try {
    await userService.register(req);
    res.send(200);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for get user data
*/
exports.getUserBusinessData = async (req, res, next) => {
  try {
    const userData = await businessDataService.getUserBusinessData(req, res, next);
    res.json(userData);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for user business data update
*/
exports.updateUserBusinessData = async (req, res, next) => {
  try {
    const userData = await businessDataService.updateUserBusinessData(req, res, next);
    res.status(201).json(userData);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for user pvt ntw update
*/
exports.createUserPrivateNtw = async (req, res, next) => {
  try {
    const privateNetworks = await privateNtwService.createUserPrivateNtw(req, res, next);
    res.status(201).json(privateNetworks);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for user pvt ntw update
*/
exports.getUserPrivateNtw = async (req, res, next) => {
  try {
    const userPrivateNtws = await privateNtwService.getUserPrivateNtw(req, res, next);
    res.json(userPrivateNtws);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for user pvt ntw update
*/
exports.updateUserPrivateNtw = async (req, res, next) => {
  try {
    const privateNetworks = await privateNtwService.updateUserPrivateNtw(req, res, next);
    res.status(201).json(privateNetworks);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for user pvt ntw update
*/
exports.deleteUserPrivateNtw = async (req, res, next) => {
  try {
    const privateNetworks = await privateNtwService.deleteUserPrivateNtw(req, res, next);
    res.status(201).json(privateNetworks);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for get user data
*/
exports.getUserData = async (req, res, next) => {
  try {
    const userData = await userService.getUserData(req, res, next);
    res.status(200).json(userData);
  } catch (error) {
    next(error);
  }
};
