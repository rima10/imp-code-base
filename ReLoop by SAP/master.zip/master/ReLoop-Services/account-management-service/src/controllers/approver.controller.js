const approvalService = require('../services/approval.service');

/*
  @desc controller function to add approvers
*/
exports.addApprovers = async function (req, res, next) {
  try {
    const approvers = await approvalService.addApprovers(req, res, next);
    res.status(201).json(approvers);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get approvers
*/
exports.getApprovers = async function (req, res, next) {
  try {
    const approvers = await approvalService.getApprovers(req, res, next);
    res.json(approvers);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to delete approvers
*/
exports.deleteApprover = async function (req, res, next) {
  try {
    const approvers = await approvalService.deleteApprover(req, res, next);
    res.status(201).json(approvers);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to delete approvers
*/
exports.deleteApprovers = async function (req, res, next) {
  try {
    const approvers = await approvalService.deleteApprovers(req, res, next);
    res.status(201).json(approvers);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to update approvers
*/
exports.updateApprovers = async function (req, res, next) {
  try {
    const approvers = await approvalService.updateApprovers(req, res, next);
    res.status(201).json(approvers);
  } catch (error) {
    next(error);
  }
};
