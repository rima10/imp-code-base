const Sequelize = require('sequelize');
/**
 * @swagger
 *  components:
 *    schemas:
 *      PrivateNetwork:
 *        type: object
 *        required:
 *        properties:
 *          bp_nwk_id:
 *            type: string
 *          rcy_id:
 *            type: string
 *          gp_id:
 *            type: string
 *        example:
 *           bp_nwk_id: 1
 *           rcy_id: 2
 *           gp_id: 3
 */
module.exports = function (sequelize, DataTypes) {
  return sequelize.define('bp_private_nwk', {
    bp_nwk_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    rcy_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    gp_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    archive: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
  }, {
    sequelize,
    tableName: 'bp_private_nwk',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'bp_private_nwk_pkey',
        unique: true,
        fields: [
          { name: 'bp_nwk_id' },
        ],
      },
    ],
  });
};
