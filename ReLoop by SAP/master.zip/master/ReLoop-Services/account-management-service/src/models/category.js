module.exports = function (sequelize, DataTypes) {
  return sequelize.define('category', {
    category_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    category_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'category',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'category_pkey',
        unique: true,
        fields: [
          { name: 'category_id' },
        ],
      },
    ],
  });
};
