const WorkflowApprover = require('./workflow_approver');
/**
 * @swagger
 *  components:
 *    schemas:
 *      Workflow:
 *        type: object
 *        required:
 *        properties:
 *          workflow_id:
 *            type: string
 *          process_stage_name:
 *            type: string
 *          process_stage_sequence:
 *            type: string
 *          bp_id:
 *            type: string
 *          process_type_id:
 *            type: string
 *        example:
 *           workflow_id: 1
 *           process_stage_name: Initial
 *           process_stage_sequence: 1
 *           process_type_id: 1
 *           bp_id: 1
 */
module.exports = function (sequelize, DataTypes) {
  return sequelize.define('workflow', {
    workflow_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    process_stage_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    process_stage_sequence: {
      type: DataTypes.DECIMAL,
      allowNull: false,
    },
    bp_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    process_type_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'process_type',
        key: 'process_type_id',
      },
    },
  }, {
    sequelize,
    tableName: 'workflow',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'workflow_pkey',
        unique: true,
        fields: [
          { name: 'workflow_id' },
        ],
      },
    ],
  });
};
