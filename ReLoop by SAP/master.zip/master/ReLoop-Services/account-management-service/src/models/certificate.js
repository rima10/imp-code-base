module.exports = function (sequelize, DataTypes) {
  return sequelize.define('certificate', {
    cert_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    cert_type: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    cert_details: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    bp_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
  }, {
    sequelize,
    tableName: 'certificate',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'certificate_pkey',
        unique: true,
        fields: [
          { name: 'cert_id' },
        ],
      },
    ],
  });
};
