/**
 * @swagger
 *  components:
 *    schemas:
 *      City:
 *        type: object
 *        required:
 *        properties:
 *          city_name:
 *            type: string
 *          state_id:
 *            type: string
 *          country_id:
 *            type: string
 *        example:
 *           city_name: New Delhi
 *           state_name: Delhi
 *           country_id: 1
 */
module.exports = function (sequelize, DataTypes) {
  return sequelize.define('city', {
    city_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    city_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    state_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'state',
        key: 'state_id',
      },
    },
  }, {
    sequelize,
    tableName: 'city',
    schema: 'address',
    timestamps: false,
    indexes: [
      {
        name: 'city_pkey',
        unique: true,
        fields: [
          { name: 'city_id' },
        ],
      },
    ],
  });
};
