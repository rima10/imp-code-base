/**
 * @swagger
 *  components:
 *    schemas:
 *      State:
 *        type: object
 *        required:
 *        properties:
 *          state_id:
 *            type: string
 *          state_name:
 *            type: string
 *          country_id:
 *            type: string
 *        example:
 *           state_id: 1
 *           state_name: Delhi
 *           country_id: 1
 */
module.exports = function (sequelize, DataTypes) {
  return sequelize.define('state', {
    state_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    state_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    country_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'country',
        key: 'country_id',
      },
    },
  }, {
    sequelize,
    tableName: 'state',
    schema: 'address',
    timestamps: false,
    indexes: [
      {
        name: 'state_pkey',
        unique: true,
        fields: [
          { name: 'state_id' },
        ],
      },
    ],
  });
};
