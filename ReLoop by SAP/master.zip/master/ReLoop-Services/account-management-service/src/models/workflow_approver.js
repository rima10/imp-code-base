module.exports = function (sequelize, DataTypes) {
  return sequelize.define('workflow_approver', {
    workflow_approver_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    workflow_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'workflow',
        key: 'workflow_id',
      },
    },
    approver_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'approver',
        key: 'approver_id',
      },
    },
    approver_sequence: {
      type: DataTypes.DECIMAL,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'workflow_approver',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'workflow_approver_pkey',
        unique: true,
        fields: [
          { name: 'workflow_approver_id' },
        ],
      },
    ],
  });
};
