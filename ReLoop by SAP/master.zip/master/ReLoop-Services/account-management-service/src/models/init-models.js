const { DataTypes } = require('sequelize');
const _approver = require('./approver');
const _bp_private_nwk = require('./bp_private_nwk');
const _business_partner = require('./business_partner');
const _category = require('./category');
const _certificate = require('./certificate');
const _city = require('./city');
const _country = require('./country');
const _location = require('./location');
const _process_type = require('./process_type');
const _state = require('./state');
const _workflow = require('./workflow');
const _workflow_approver = require('./workflow_approver');

function initModels(sequelize) {
  const approver = _approver(sequelize, DataTypes);
  const bp_private_nwk = _bp_private_nwk(sequelize, DataTypes);
  const business_partner = _business_partner(sequelize, DataTypes);
  const category = _category(sequelize, DataTypes);
  const certificate = _certificate(sequelize, DataTypes);
  const city = _city(sequelize, DataTypes);
  const country = _country(sequelize, DataTypes);
  const location = _location(sequelize, DataTypes);
  const process_type = _process_type(sequelize, DataTypes);
  const state = _state(sequelize, DataTypes);
  const workflow = _workflow(sequelize, DataTypes);
  const workflow_approver = _workflow_approver(sequelize, DataTypes);

  location.belongsTo(city, { as: 'city', foreignKey: 'city_id' });
  city.hasMany(location, { as: 'locations', foreignKey: 'city_id' });
  location.belongsTo(country, { as: 'country', foreignKey: 'country_id' });
  country.hasMany(location, { as: 'locations', foreignKey: 'country_id' });
  location.belongsTo(state, { as: 'state', foreignKey: 'state_id' });
  state.hasMany(location, { as: 'locations', foreignKey: 'state_id' });
  workflow_approver.belongsTo(approver, {
    as: 'approver', foreignKey: 'approver_id',
  });
  approver.hasMany(workflow_approver, {
    as: 'workflow_approvers', foreignKey: 'approver_id', onDelete: 'cascade', hooks: true,
  });
  approver.belongsTo(business_partner, {
    as: 'bp', foreignKey: 'bp_id',
  });
  business_partner.hasMany(approver, {
    as: 'approvers', foreignKey: 'bp_id',
  });
  bp_private_nwk.belongsTo(business_partner, { as: 'gp', foreignKey: 'gp_id' });
  business_partner.hasMany(bp_private_nwk, { as: 'bp_private_nwks', foreignKey: 'gp_id' });
  bp_private_nwk.belongsTo(business_partner, { as: 'rcy', foreignKey: 'rcy_id' });
  business_partner.hasMany(bp_private_nwk, { as: 'rcy_bp_private_nwks', foreignKey: 'rcy_id' });
  certificate.belongsTo(business_partner, { as: 'bp', foreignKey: 'bp_id' });
  business_partner.hasMany(certificate, { as: 'certificates', foreignKey: 'bp_id' });
  workflow.belongsTo(business_partner, { as: 'bp', foreignKey: 'bp_id' });
  business_partner.hasMany(workflow, { as: 'workflows', foreignKey: 'bp_id' });
  business_partner.belongsTo(location, { as: 'loc', foreignKey: 'loc_id' });
  location.hasMany(business_partner, { as: 'business_partners', foreignKey: 'loc_id' });
  workflow.belongsTo(process_type, { as: 'process_type', foreignKey: 'process_type_id' });
  process_type.hasMany(workflow, { as: 'workflows', foreignKey: 'process_type_id' });
  workflow_approver.belongsTo(workflow, {
    as: 'workflow', foreignKey: 'workflow_id',
  });
  workflow.hasMany(workflow_approver, {
    as: 'workflow_approvers', foreignKey: 'workflow_id', onDelete: 'cascade', hooks: true,
  });

  return {
    approver,
    bp_private_nwk,
    business_partner,
    category,
    certificate,
    city,
    country,
    process_type,
    workflow,
    workflow_approver,
    location,
    state,
  };
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;
