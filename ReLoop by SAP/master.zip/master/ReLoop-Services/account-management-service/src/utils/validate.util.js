const { check, validationResult } = require('express-validator');

exports.createUserValidations = [
  check('bp_userid').exists(),
  check('bp_username').exists(),
];

exports.validate = async function (req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.status(400).json({ errors: errors.array() });
    next(errors);
  } else next();
};
