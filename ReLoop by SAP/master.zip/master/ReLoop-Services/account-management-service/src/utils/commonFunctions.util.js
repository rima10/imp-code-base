exports.camelCaseToUnderScore = function (obj) {
  const underScoreObj = {};
  Object.keys(obj).forEach((key) => {
    const underScoreKey = key.split(/(?=[A-Z])/).join('_').toLowerCase();
    underScoreObj[underScoreKey] = obj[key];
  });
  return underScoreObj;
};
