const dataTypes = require('sequelize').DataTypes;
const { sequelize } = require('../models/index');
const User = require('../models/business_partner')(sequelize, dataTypes);
const Location = require('../models/location')(sequelize, dataTypes);
const Models = require('../models/init-models')(sequelize, dataTypes);

async function getBusinessData(userId) {
  const user = await User.findOne({ where: { bp_id: userId }, attributes: ['bp_username', 'bp_email_id', 'bp_phone_number', 'gst_number', 'tin_number', 'industry_type'] });
  let location = {};
  if (user.loc_id) {
    const locData = await Models.location.findOne({ where: { loc_id: user.loc_id }, atrributes: ['pincode', 'loc_details'], include: [{ model: Models.state, as: 'state' }, { model: Models.city, as: 'city' }, { model: Models.country, as: 'country' }] });
    const {
      state_id, city_id, country, pincode, addressLine, loc_id,
    } = location;
    const locData = {
      country_id: country,
      state_id: state_id,
      city_id: city_id,
      loc_details: addressLine,
      pincode,
      loc_details,
    };
  }
  return { ...user.dataValues, location };
}
/*
  @desc service to get user data
*/
exports.getUserBusinessData = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const user = await getBusinessData(userId);
    return user;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to update business partner data
*/
exports.updateUserBusinessData = async function (req, res, next) {
  try {
    const { userId } = req.params;
    const user = await User.findOne({ where: { bp_id: req.params.userId } });
    const { location } = req.body;
    if (location) {
      const {
        state, city, country, pincode, addressLine, loc_id,
      } = location;
      const locData = {
        country_id: country,
        state_id: state,
        city_id: city,
        loc_details: addressLine,
        pincode,
      };
      if (loc_id) {
        const loc = await Location.findOne({ where: { loc_id } });
        await loc.update(locData);
      } else {
        const loc = await Location.create(locData);
        delete req.body.location;
        req.body.loc_id = loc.loc_id;
      }
    }
    if (user) {
      await user.update(req.body);
      const userData = await getBusinessData(userId);
      return userData;
    } throw new Error('user not found');
  } catch (error) {
    return next(error);
  }
};
