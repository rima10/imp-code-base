const dataTypes = require('sequelize').DataTypes;
const { sequelize } = require('../models/index');
const Workflow = require('../models/workflow')(sequelize, dataTypes);
const WorkflowApprover = require('../models/workflow_approver')(sequelize, dataTypes);
const models = require('../models/init-models')(sequelize, dataTypes);

async function getWorkflows(userId) {
  const workflows = await models.workflow
    .findAll({
      where:
      { bp_id: userId },
      attributes: ['workflow_id', 'process_stage_name', 'process_stage_sequence', 'process_type_id'],
      include: [{
        model: models.workflow_approver, attributes: ['approver_sequence'], include: { model: models.approver, as: 'approver', attributes: ['approver_id', 'approver_email_id', 'approver_name', 'approver_role'] }, as: 'workflow_approvers',
      }],
    });
  return workflows;
}
/*
  @desc helper function to create workflow
  @param Object - workflowData
  @param Array - approvers
  @return Oject - newWorkflow
*/
async function createWorkflow(workflowData, approvers) {
  const newWorkflow = await Workflow.create(workflowData);
  await Promise.all(approvers.map(async (approver) => {
    const { approverId, approverSequence } = approver;
    await WorkflowApprover.create({
      approver_id: approverId,
      approver_sequence: approverSequence,
      workflow_id: newWorkflow.workflow_id,
    });
  }));
  return newWorkflow;
}

/*
  @desc service function to add workflows
*/
exports.addWorkflows = async function (req, res, next) {
  const { workflows } = req.body;
  const { userId } = req.params;
  await Promise.all(workflows.map(async (workflow) => {
    const {
      processStageSequence, processStageName, processTypeId, approvers,
    } = workflow;
    await createWorkflow({
      process_stage_name: processStageName,
      process_stage_sequence: processStageSequence,
      bp_id: userId,
      process_type_id: processTypeId,
    }, approvers);
  }));
};

/*
  @desc service function to add workflow
*/
exports.addWorkflow = async (req, res, next) => {
  try {
    const workflow = req.body;
    const { userId } = req.params;
    const {
      processStageSequence, processStageName, processTypeId, approvers,
    } = workflow;
    const existingWorkflow = await Workflow.findOne({
      where: {
        bp_id: userId,
        process_type_id:
     processTypeId,
        process_stage_sequence: processStageSequence,
      },
    });
    if (existingWorkflow) {
      existingWorkflow.update({
        process_stage_name: processStageName,
        process_type_id: processTypeId,
      }, approvers);
    }
    await createWorkflow({
      process_stage_name: processStageName,
      process_stage_sequence: processStageSequence,
      bp_id: userId,
      process_type_id: processTypeId,
    }, approvers);
    const workflows = await getWorkflows(userId);
    return workflows;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to get workflows
*/
exports.getWorkflows = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const workflows = await getWorkflows(userId);
    return workflows;
  } catch (error) {
    return next(error);
  }
};

exports.deleteWorkflow = async (req, res, next) => {
  try {
    const { userId, workflowId } = req.params;
    await models.workflow.destroy({ where: { bp_id: userId, workflow_id: workflowId } });
    const workflows = await getWorkflows(userId);
    return workflows;
  } catch (error) {
    return next(error);
  }
};

exports.deleteWorkflowApprovers = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { workflowApprovers } = req.body;
    await new Promise(workflowApprovers.map(async (approver) => {
      const { workflowApproverId } = approver;
      await models.workflow_approver.destroy(
        { where: { workflow_approver_id: workflowApproverId } },
      );
    }));
    const workflows = await getWorkflows(userId);
    return workflows;
  } catch (error) {
    next(error);
  }
};
