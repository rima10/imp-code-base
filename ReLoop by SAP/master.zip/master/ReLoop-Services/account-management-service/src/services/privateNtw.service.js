const dataTypes = require('sequelize').DataTypes;
const { sequelize } = require('../models/index');
const User = require('../models/business_partner')(sequelize, dataTypes);
const PrivateNwk = require('../models/bp_private_nwk')(sequelize, dataTypes);
const Models = require('../models/init-models')(sequelize, dataTypes);
const authUtil = require('../utils/auth.util');

async function getPrivateNetworks(userId) {
  const pvtNetworks = await Models.bp_private_nwk.findAll({
    where: { gp_id: userId },
    attributes: ['bp_nwk_id', 'rcy_id', 'gp_id'],
    include: [{ model: Models.business_partner, attributes: ['bp_email_id', 'bp_username', 'bp_phone_number'], as: 'rcy' }],
  });
  return pvtNetworks;
}
/*
  @desc service function to create user private network
  @desc check if pvt network user exist, if not create cognito user aswell
*/
exports.createUserPrivateNtw = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { pvtRecyclers } = req.body;
    // Loop and check if recycler exist and add to private network else create recycler
    await Promise.all(pvtRecyclers.map(async (pvtRecycler) => {
      const { emailId, username, phoneNumber } = pvtRecycler;
      let recyclerBP = await User.findOne({ where: { bp_email_id: emailId } });
      if (!recyclerBP) {
        const cognitoUserData = {
          Username: emailId,
          UserPoolId: process.env.COGNITO_USER_POOL_ID,
        };
        const congitoUserGroupData = {
          GroupName: authUtil.ROLES.RP_USER,
          UserPoolId: process.env.COGNITO_USER_POOL_ID,
        };
        const cognitoUser = await authUtil.createCognitouser(cognitoUserData, congitoUserGroupData);
        recyclerBP = await User.create({
          bp_email_id: emailId,
          bp_userid: cognitoUser.data.User.Username, // cognito id after creation
          bp_username: username,
          bp_phone_number: phoneNumber,
          is_part_of_pvt_nwk: true,
        });
      } else if (recyclerBP.archive === true) recyclerBP.update({ archive: false });
      else {
        const existingNtw = PrivateNwk.findOne({
          where: {
            rcy_id: recyclerBP.bp_id,
            gp_id: userId,
          },
        });
        if (existingNtw) throw new Error('network already exists ');
      }
      await PrivateNwk.create({
        rcy_id: recyclerBP.bp_id,
        gp_id: userId,
      });
    }));
    const userPrivateNtws = await getPrivateNetworks(userId);
    return userPrivateNtws;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to get private network
*/
exports.getUserPrivateNtw = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const userPrivateNtws = await getPrivateNetworks(userId);
    return userPrivateNtws;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to update private network
*/
exports.updateUserPrivateNtw = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { pvtRecyclers } = req.body;
    // Loop and check if recycler exist and add to private network else create recycler
    await Promise.all(pvtRecyclers.map(async (pvtRecycler) => {
      const { emailId, username, phoneNumber } = pvtRecycler;
      let recyclerBP = await User.findOne({ where: { bp_email_id: emailId } });
      if (!recyclerBP) {
        const cognitoUser = await authUtil.createCognitouser({
          Username: emailId,
        });
        recyclerBP = await User.create({
          bp_email_id: emailId,
          bp_userid: cognitoUser.User.Username, // cognito id after creation
          bp_username: username,
          bp_phone_number: phoneNumber,
        });

        await PrivateNwk.create({
          rcy_id: recyclerBP.bp_id,
          gp_id: userId,
        });
      } else {
        const { cognitoUserId } = pvtRecycler;
        await recyclerBP.update({
          bp_email_id: emailId,
          bp_userid: cognitoUserId, // cognito id after creation
          bp_username: username,
        });
      }
    }));
    const userPrivateNtws = await getPrivateNetworks(userId);
    return userPrivateNtws;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to update private network
*/
exports.deleteUserPrivateNtw = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { pvtNetworks } = req.body;
    // Loop and delete private network and disable business partner
    await Promise.all(pvtNetworks.map(async (pvtNetwork) => {
      const { networkId, recyclerId } = pvtNetwork;
      await Models.bp_private_nwk.destroy(
        { where: { bp_nwk_id: networkId } },
      );
      const recycler = await User.findOne({ where: { bp_id: recyclerId } });
      await recycler.update({ archive: true });
    }));
    const userPrivateNtws = await getPrivateNetworks(userId);
    return userPrivateNtws;
  } catch (error) {
    return next(error);
  }
};
