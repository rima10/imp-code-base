const { DataTypes, Op } = require('sequelize');
const { sequelize } = require('../models/index');
const User = require('../models/business_partner')(sequelize, DataTypes);
const businessDataService = require('./businessData.service');
const privateNtwService = require('./privateNtw.service');
const Location = require('../models/location')(sequelize, DataTypes);
const Models = require('../models/init-models')(sequelize, DataTypes);

async function createBpUser(userData) {
  await User.create(userData);
}

exports.getUserDatabyCognito = async function (cognitoId) {
  const user = await User.findOne({
    where: {
      bp_userid: cognitoId,
      // Will be used when existing useer archive flag is set to false
      // [Op.not]: [{ archive: true }],
    },
    atrributes: ['bp_id', 'bp_username', 'bp_email_id'],
  });
  if (!user) throw new Error('Invalid or inactive user');
  const {
    bp_id, bp_username, bp_email_id, tin_number, gst_number,
  } = user;
  const isBusinessDataPresent = tin_number !== null && gst_number !== null;
  const userData = {
    bp_id,
    bp_username,
    bp_email_id,
    isBusinessDataPresent,
  };
  return userData;
};
/*
  @desc service to create user data
*/
exports.register = async function (req) {
  const userData = req.body;
  userData.archive = false;
  await createBpUser(req.body);
};

/*
  @desc service function to get user data
*/
exports.getUserData = async function (req, res, next) {
  try {
    const { cognitoId } = req.params;
    const userData = await exports.getUserDatabyCognito(cognitoId);
    return userData;
  } catch (error) {
    res.status(401).json({
      message: error.message,
    });
    next(error);
  }
};
