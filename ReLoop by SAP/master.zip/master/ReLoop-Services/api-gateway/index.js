const express = require('express');
const dotenv = require('dotenv');
const app = require('./app');

dotenv.config();

const port = process.env.PORT;
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.listen(port, () => {
  console.log(`App running on port ${port}.`);
});
