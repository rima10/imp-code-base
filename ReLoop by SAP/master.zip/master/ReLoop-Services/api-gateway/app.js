const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');

const app = express();
app.use(cors({
  origin: 'http://localhost:3001',
  optionsSuccessStatus: 200,
  methods: ['POST', 'PATCH', 'GET', 'OPTIONS', 'HEAD', 'DELETE'],
  credentials: true,
}));
app.use(cookieParser());
module.exports = app;

// Add auth route to the application

require('./src/routes/order.route')(app);
require('./src/routes/auth.route')(app);
require('./src/routes/user.route')(app);

// centralized error handler middleware for the app
// eslint-disable-next-line no-unused-vars
app.use((error, req, res, next) => {
  res.status(error.status || 500);
  res.json({
    error: {
      message: error.message,
    },
  });
});
