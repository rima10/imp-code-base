const AWS = require('aws-sdk');
const got = require('got');
const jwkToPem = require('jwk-to-pem');
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');

dotenv.config();

const poolData = {
  UserPoolId: process.env.COGNITO_USER_POOL_ID,
  ClientId: process.env.COGNITO_CLIENT_ID,
};
const poolRegion = process.env.POOL_REGION;

AWS.config = new AWS.Config({
  credentials: new AWS.CognitoIdentityCredentials({
    IdentityPoolId: poolData.UserPoolId,
  }),
  region: poolRegion,
});

const ACCOUNT_MGT_URL = 'http://localhost:5001';
const USER_DATA_ENDPOINT = '/api/user/getUserData/';

/*
  @desc Fetch JSONWebKeys from cognito to validate the JWT token
  @desc JWKs is fetched dynamically everytime for security resons as well as it can change in future
  @return Object - pems
*/
async function fetchJwks() {
  const url = `https://cognito-idp.${poolRegion}.amazonaws.com/${poolData.UserPoolId}/.well-known/jwks.json`;
  const jwks = await got(url, { responseType: 'json' });
  const pems = {};
  const { keys } = jwks.body;
  for (let i = 0; i < keys.length; i += 1) {
    const keyId = keys[i].kid;
    const jwk = { kty: keys[i].kty, n: keys[i].n, e: keys[i].e };
    const pem = jwkToPem(jwk);
    pems[keyId] = pem;
  }
  return pems;
}

/*
  @desc validates JWT token with pems
  @param Object pems
  @param String token
  @return Object - pems
*/
async function validateJWT(pems, token) {
  const decodedJwt = jwt.decode(token, { complete: true });
  if (!decodedJwt) {
    throw new Error('not a valid access token');
  }
  const { kid } = decodedJwt.header;
  const pem = pems[kid];
  if (!pem) {
    throw new Error('not a valid access token');
  }
  await jwt.verify(token, pem);
  return decodedJwt;
}

// returns an object with the cookies' name as keys
function getCookies(req) {
  // We extract the raw cookies from the request headers
  if (!req.headers.cookie) return req.headers.cookie;
  const rawCookies = req.headers.cookie.split('; ');
  const parsedCookies = {};
  rawCookies.forEach((rawCookie) => {
    const parsedCookie = rawCookie.split('=');
    const [key, val] = parsedCookie;
    parsedCookies[key] = val;
  });
  return parsedCookies;
}

/*
  @desc controller function to validate JWT token
  @desc JWKs is fetched dynamically everytime for security resons as well as it can change in future
*/
exports.validate = async function validate(req, res, next) {
  try {
    const pems = await fetchJwks();
    let { authorization } = req.headers;
    let cookies;
    if (!authorization) {
      authorization = getCookies(req).authorization;
      cookies = true;
    } else {
      const [, token] = authorization.split(' ');
      authorization = token;
      cookies = false;
    }
    const user = await validateJWT(pems, authorization);
    const userData = await got(ACCOUNT_MGT_URL + USER_DATA_ENDPOINT
      + user.payload['cognito:username']);
    if (!cookies) {
      res.cookie('authorization', authorization,
        {
          domain: 'localhost',
          maxAge: 3600000,
          // You can't access these tokens in the client's javascript
          httpOnly: true,
          // Forces to use https in production
          secure: process.env.NODE_ENV === 'production',
        });
    }
    res.status(200).json(JSON.parse(userData.body));
  } catch (error) {
    res.status(401).json({
      error: {
        message: error.message,
      },
    });
    next(error);
  }
};

/*
  @desc controller function to validate JWT token
  @desc JWKs is fetched dynamically everytime for security resons as well as it can change in future
  @return Object - pems
*/
exports.validateMiddleware = async function validateMiddleware(req, res, next) {
  try {
    const pems = await fetchJwks();
    let { authorization } = req.headers;
    if (!authorization) {
      authorization = getCookies(req).authorization;
    } else {
      const [, token] = authorization.split(' ');
      authorization = token;
    }
    const decodedJWT = await validateJWT(pems, authorization);
    req.userInfo = decodedJWT.payload;
    next();
  } catch (error) {
    res.status(401).json({
      error: {
        message: error.message,
      },
    });
    next(error);
  }
};
