const proxy = require('express-http-proxy');

/*
  @desc reverse proxy the original request to the respected service
  @param String REST API path
  @param String REST API service endpoint
  @return Object - API response
  @example getCustomProxy('https://sampleUrl.com')
*/
exports.getCustomProxy = function (endpoint) {
  return proxy(endpoint, {
    proxyReqPathResolver(req) {
      return req.originalUrl;
    },
  });
};
