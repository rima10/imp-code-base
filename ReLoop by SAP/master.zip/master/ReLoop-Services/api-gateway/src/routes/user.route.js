const router = require('express').Router();
const proxy = require('../utils/proxy.util');
const authUtil = require('../utils/auth.util');

// const PATH_SUFFIX = '/api/user/register';
const ACCOUNT_MGT_URL = 'http://localhost:5001';

/*
  @desc router for /api/user endpoint
*/
module.exports = (app) => {
  router.all('/user*', authUtil.validateMiddleware, proxy.getCustomProxy(ACCOUNT_MGT_URL));
  app.use('/api', router);
};
