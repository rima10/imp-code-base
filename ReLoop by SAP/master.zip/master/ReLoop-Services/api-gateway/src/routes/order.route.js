const router = require('express').Router();
const proxy = require('../utils/proxy.util');

// const PATH_SUFFIX = '/api/user/register';
const ORDER_MGT_URL = 'http://localhost:5002';

/*
  @desc router for /api/user endpoint
*/
module.exports = (app) => {
  router.all('/order*', proxy.getCustomProxy(ORDER_MGT_URL));
  router.all('/wasteCategory*', proxy.getCustomProxy(ORDER_MGT_URL));
  app.use('/api', router);
};
