const router = require('express').Router();
const authUtil = require('../utils/auth.util');

/*
  @desc router for /api/auth endpoint
*/
module.exports = (app) => {
  router.post('/auth/validate', authUtil.validate);
  app.use('/api', router);
};
