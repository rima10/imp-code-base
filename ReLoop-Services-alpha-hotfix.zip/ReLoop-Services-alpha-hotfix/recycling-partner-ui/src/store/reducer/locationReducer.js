import { FETCH_STATES_INFO, FETCH_CITIES_INFO, CLEAR_LOCATION_INFO } from '../actionType';
import { ActionType } from 'redux-promise-middleware';

const initialState = {
    states: [],
    cities: {}
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_STATES_INFO}_${ActionType.Fulfilled}`:
            return { ...state, states: payload.data };

        case `${FETCH_CITIES_INFO}_${ActionType.Fulfilled}`:
            let stateId = payload.data[0].state_id;
            if (Object.keys(state.cities).includes(stateId)) {
                return state;
            } else {
                let obj = {};
                obj[stateId] = payload.data;
                return { ...state, cities: { ...state.cities, ...obj } };
            }
        case CLEAR_LOCATION_INFO:
            return { ...state, states: [], cities: {} };

        default:
            return state;
    }
};
