// User Info Related Action Types
export const SET_USER_INFO = 'SET_USER_INFO';
export const setUserInfo = (userInfo, isLoggedIn, csrf) => ({
    type: SET_USER_INFO,
    payload: { userInfo, isLoggedIn, csrf }
});

export const SET_LOAD_IN_PROGRESS = 'SET_LOAD_IN_PROGRESS';
export const loadInProgress = () => ({
    type: SET_LOAD_IN_PROGRESS
});

export const SET_LOAD_COMPLETED = 'SET_LOAD_COMPLETED';
export const loadCompleted = () => ({
    type: SET_LOAD_COMPLETED
});

// Location Info Related Action Types
export const FETCH_STATES_INFO = 'FETCH_STATES_INFO';
export const FETCH_CITIES_INFO = 'FETCH_CITIES_INFO';
export const CLEAR_LOCATION_INFO = 'CLEAR_LOCATION_INFO';

// Business Info Related Action Types
export const FETCH_BP_BUSINESS_INFO = 'FETCH_BP_BUSINESS_INFO';
export const UPDATE_BP_BUSINESS_INFO = 'UPDATE_BP_BUSINESS_INFO';

// Private Network Info Related Action Types
export const FETCH_BP_NETWORK_INFO = 'FETCH_BP_NETWORK_INFO';
export const CREATE_BP_NETWORK_INFO = 'CREATE_BP_NETWORK_INFO';
export const DELETE_BP_NETWORK_INFO = 'DELETE_BP_NETWORK_INFO';

// RP user certificates related action types
export const POST_CERTIFICATES = 'POST_CERTIFICATES';
export const GET_CERTIFICATES = 'GET_CERTIFICATES';
export const DOWNLOAD_CERTIFICATE = 'DOWNLOAD_CERTIFICATE';

// Message Toast Related Action Types
export const SHOW_MSG_TOASTER = 'SHOW_MSG_TOASTER';
export const HIDE_MSG_TOASTER = 'HIDE_MSG_TOASTER';

// Notification Related Action Types
export const SET_NOTIFICATION_LIST_INFO = 'SET_NOTIFICATION_LIST_INFO';
export const setNotificationsInfo = (notificationList) => ({
    type: SET_NOTIFICATION_LIST_INFO,
    payload: notificationList
});
export const SET_NOTIFICATION_READ = 'SET_NOTIFICATION_READ';
export const setNotificationRead = (notification) => ({
    type: SET_NOTIFICATION_READ,
    payload: notification
});


// Service Location Related Action Types
export const FETCH_SERVICE_LOCATION = 'FETCH_SERVICE_LOCATION';
export const CREATE_SERVICE_LOCATION = 'CREATE_SERVICE_LOCATION';
export const DELETE_SERVICE_LOCATION = 'DELETE_SERVICE_LOCATION';

// Logistics Related Action Types
export const ACCEPT_LOGISTIC_SCHEDULE = 'ACCEPT_LOGISTIC_SCHEDULE';

// Order Related Action Types
export const FETCH_ORDER_LIST = 'FETCH_ORDER_LIST';
export const FETCH_ORDER_HEADER_DATA = 'FETCH_ORDER_HEADER_DATA';
export const FETCH_CONSOLIDATED_ORDER_ITEMS_INFO = 'FETCH_CONSOLIDATED_ORDER_ITEMS_INFO';

// Submit First Level Quote Action Types
export const SUBMIT_FIRST_LEVEL_QUOTE = 'SUBMIT_FIRST_LEVEL_QUOTE';

export const SET_ONSITE_VISIT_DETAILS = 'SET_ONSITE_VISIT_DETAILS';

export const SET_ONSITE_VISIT_SCHEDULE = 'SET_ONSITE_VISIT_SCHEDULE';
export const SET_ORDER_DOCUMENTS = 'SET_ORDER_DOCUMENTS';

// Recycle Order Items Action Type
export const FETCH_RECYCLE_ORDER_ITEMS = 'FETCH_RECYCLE_ORDER_ITEMS';

// Submit Recycle Initial Order Quote Action Type
export const SUBMIT_RECYCLE_FIRST_LEVEL_QUOTE = 'SUBMIT_RECYCLE_FIRST_LEVEL_QUOTE';

// Recycle Consolidated Order Items Action Type
export const FETCH_RECYCLE_CONSOLIDATED_ORDER_ITEMS = 'FETCH_RECYCLE_CONSOLIDATED_ORDER_ITEMS';

// Submit Recycle Initial Order Quote Action Type
export const SUBMIT_RECYCLE_FINAL_QUOTE = 'SUBMIT_RECYCLE_FINAL_QUOTE';

// Logistics Data Related Action Type
export const FETCH_LOGISTICS_DATA = 'FETCH_LOGISTICS_DATA';
