const express = require('express');
const cors = require('cors');
const kafkaUtil = require('./src/utils/kafka.util');

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cors({
  origin: ['http://localhost:3001', 'http://localhost:3002'],
  optionsSuccessStatus: 200,
  methods: ['POST', 'PUT', 'GET', 'OPTIONS', 'HEAD'],
  credentials: true,
}));
module.exports = app;

require('./src/routes/notification.route')(app);

// Run all kafka consumers
kafkaUtil.runConsumers();

// centralized error handler middleware for the app
// eslint-disable-next-line no-unused-vars
app.use((error, req, res, next) => {
  res.status(error.status || 500);
  res.json({
    error: {
      message: error.message,
    },
  });
});

// Default entrypoint
app.use('/', (req, res) => {
  res.send(200);
});