const express = require('express');

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json({ limit: '50mb' })); // Temproary for pushing location data
module.exports = app;

// Add routes to the application
require('./src/routes/user.route')(app);
require('./src/routes/location.route')(app);
require('./src/routes/swagger.route')(app);
require('./src/routes/approver.route')(app);
require('./src/routes/workflow.route')(app);

app.use((req, res, next) => {
  const error = new Error('method not found');
  res.status(404).json({
    error: {
      message: 'method not found',
    },
  });
  next(error);
});

// centralized error handler middleware for the app
// eslint-disable-next-line no-unused-vars
app.use((error, req, res, next) => {
  if (!res.headersSent) {
    res.status(500).json({
      error: {
        message: error.message,
      },
    });
  }
});

// Default entrypoint
app.use('/', (req, res) => {
  res.send(200);
});