const dataTypes = require('sequelize').DataTypes;
const { sequelize } = require('../models/index');
const Approver = require('../models/approver')(sequelize, dataTypes);
const Models = require('../models/init-models')(sequelize, dataTypes);
const authUtil = require('../utils/auth.util');

/*
  @desc helper function to create approvers
  @desc approver user created in cognito
  @param Object - approverData
  @return Oject - newApprover
*/
async function createApprover(approverData) {
  const cognitoUserData = {
    Username: approverData.approver_email_id,
    UserPoolId: process.env.COGNITO_USER_POOL_ID,
    //TemporaryPassword: 'Welcome@12345', // To be removed , just for test data creation
  };
  const congitoUserGroupData = {
    GroupName: authUtil.ROLES.GP_APPORVER,
    UserPoolId: process.env.COGNITO_USER_POOL_ID,
  };
  const cognitoUser = await authUtil.createCognitouser(cognitoUserData, congitoUserGroupData);
  const approver = { ...approverData };
  approver.approver_userid = cognitoUser;
  const newApprover = await Approver.create(approver);
  return newApprover;
}

async function removeApprover(userId, approverId) {
  const existingApprover = await Approver.findOne({ where: { approver_id: approverId } });
  if (existingApprover) {
    const cognitoUserData = {
      Username: existingApprover.approver_email_id,
      UserPoolId: process.env.COGNITO_USER_POOL_ID,
    };
    await authUtil.deleteCognitouser(cognitoUserData);
    await Approver.destroy({ where: { bp_id: userId, approver_id: approverId } });
  } else {
    throw new Error('Approver does not exist');
  }
}

async function getApproversData(userId) {
  const approvers = await Models.approver.findAll({ where: { bp_id: userId }, attributes: ['approver_id', 'approver_email_id', 'approver_name', 'approver_role'] });
  return approvers;
}
/*
  @desc service function to add approvers
  @desc loop over approvers list and create approvers
*/
exports.addApprovers = async (req, res, next) => {
  try {
    const { approvers } = req.body;
    const { userId } = req.userInfo;
    await Promise.all(approvers.map(async (approver) => {
      const { approverEmailId, approverName, approverRole } = approver;
      // eslint-disable-next-line max-len
      const existingApprover = await Models.approver.findAll({ where: { approver_email_id: approverEmailId , bp_id: userId} });
      if (existingApprover.length > 0) {
        throw new Error('Approver already exist');
      }
      await createApprover({
        approver_email_id: approverEmailId,
        approver_name: approverName,
        bp_id: userId,
        approver_role: approverRole,
      });
    }));
    const newApprovers = await getApproversData(userId);
    return newApprovers;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to get approvers
*/
exports.getApprovers = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const approvers = await getApproversData(userId);
    return approvers;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to delete approvers
*/
exports.deleteApprover = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { approverId } = req.params;
    await removeApprover(userId, approverId);
    const approvers = await getApproversData(userId);
    return approvers;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to delete approvers
*/
exports.deleteApprovers = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { approvers } = req.body;
    const existingOrderStatus = await Models.order.findAll({ where: { created_by: userId, order_position: 'In Progress' }, attributes: [['order_position', 'orderPosition']] });
    if (existingOrderStatus.length !== 0) {
      throw new Error('Approver cannot be deleted as being used in ongoing orders');
    } else {
      await Promise.all(approvers.map(async (approver) => {
        const { approverId } = approver;
        await removeApprover(userId, approverId);
      }));
      const newApprovers = await getApproversData(userId);
      return newApprovers;
    }
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to update approvers
  @desc loop over approvers list and update approvers
*/
exports.updateApprovers = async (req, res, next) => {
  try {
    const { approvers } = req.body;
    const { userId } = req.userInfo;
    await Promise.all(approvers.map(async (approver) => {
      const { approverEmailId, approverName, approverRole } = approver;
      const existingApprover = await Approver
        .findOne({ where: { bp_id: userId, approver_email_id: approverEmailId } });
      if (existingApprover) {
        existingApprover.update({
          approver_name: approverName,
          approver_role: approverRole,
        });
      } else {
        await createApprover({
          approver_email_id: approverEmailId,
          approver_name: approverName,
          bp_id: userId,
          approver_role: approverRole,
        });
      }
    }));
    const newApprovers = await getApproversData(userId);
    return (newApprovers);
  } catch (error) {
    return next(error);
  }
};
