const { Kafka } = require('kafkajs');
const dotenv = require('dotenv');

dotenv.config();

const {NODE_ENV, KAFKA_HOST} = process.env;

const broker = [KAFKA_HOST];

const config = { clientId: 'order-management', brokers: broker };
// Instantiating kafka
const kafka = new Kafka(config);
// Creating Kafka Producer
const producer = kafka.producer();

exports.runProducer = async (topic, message) => {
  await producer.connect();
  await producer.send({
    topic,
    messages:
          [{ value: JSON.stringify(message) }],
  });
};
