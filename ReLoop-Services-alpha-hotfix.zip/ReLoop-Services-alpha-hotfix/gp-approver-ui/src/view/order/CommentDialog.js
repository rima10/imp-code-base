import React, { useState } from 'react';
import { spacing } from "@ui5/webcomponents-react-base";
import PropTypes from 'prop-types';
import { Button, Form,
    FormItem, TextArea, Dialog } from '@ui5/webcomponents-react';
const CommentDialog = React.forwardRef(({ onSubmit, onCancel, onCommentChange, btnText }, ref) => {
    const [comment, setComment] = useState();
    const onAccept = (ev) => {
        setComment('');
        onSubmit();
    };

    const onClose = (ev) => {
        setComment('');
        onCancel();
    };

    const onComment = (ev) => {
        setComment(ev.target.value);
        onCommentChange(ev);
    };
    return (<Dialog
        className=""
        ref={ref}
        footer={<div style={spacing.sapUiSmallMargin}>
            <Button style={spacing.sapUiTinyMargin} onClick={onClose}>Close</Button>
            <Button style={spacing.sapUiTinyMargin} onClick={onAccept}>{btnText}</Button></div>}
        headerText="Add Comments"
    >
        <Form>
            <FormItem label="Comments">
                <TextArea value={comment} onChange={onComment}/>
            </FormItem>
        </Form>
    </Dialog>);
});
CommentDialog.propTypes = {
    onSubmit: PropTypes.func,
    onCancel: PropTypes.func,
    onCommentChange: PropTypes.func,
    btnText: PropTypes.string
};
export default CommentDialog;
