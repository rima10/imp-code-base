const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const csurf = require('csurf');
const morgan = require('morgan');
const helmet = require('helmet');
const winston = require('./src/utils/logger.util');

const app = express();
app.use(morgan('combined', { stream: winston.stream }));
const csrfProtection = csurf({ cookie: true }); // csurf({ cookie: { domain: 'service.qa.ever-loop.io', sameSite: 'none', secure: true, httpOnly: true } });

app.use(cors({
  origin: ['http://localhost:3001', 'http://localhost:3002', 'http://localhost:3003', /\.amplifyapp\.com$/],
  optionsSuccessStatus: 200,
  methods: ['POST', 'PUT', 'PATCH', 'GET', 'OPTIONS', 'HEAD', 'DELETE'],
  allowedHeaders: ['Content-Type', 'authorization', 'cookie', 'refresh', 'CSRF-Token'],
  exposedHeaders: ['csrf-token'],
  credentials: true,
}));
app.use(cookieParser());
app.use(helmet());
module.exports = app;

// Add auth route to the application

require('./src/routes/order.route')(app);
require('./src/routes/auth.route')(app);
require('./src/routes/user.route')(app);
require('./src/routes/notification.route')(app);

// centralized error handler middleware for the app
// eslint-disable-next-line no-unused-vars
app.use((error, req, res, next) => {
  res.status(error.status || 500);
  res.json({
    error: {
      message: error.message,
    },
  });
});

// Get csrf Token
app.head('/api/getCsrf', csrfProtection, (req, res) => {
  res.setHeader('csrf-token', req.csrfToken());
  res.send(200);
});
