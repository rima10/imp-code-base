const proxy = require('express-http-proxy');

/*
  @desc reverse proxy the original request to the respected service
  @param String REST API path
  @param String REST API service endpoint
  @return Object - API response
  @example getCustomProxy('https://sampleUrl.com')
*/
exports.getCustomProxy = function (endpoint) {
  return proxy(endpoint, {
    proxyReqPathResolver(req) {
      return req.originalUrl;
    },
    proxyReqOptDecorator(proxyReqOpts, srcReq) {
      const { cookie } = srcReq.headers;
      const updatedProxyOpts = { ...proxyReqOpts };
      const cookieArray = cookie.split(';');
      const cookieMap = cookieArray.reduce((acc, cookiePair) => {
        const [key, val] = cookiePair.split('=');
        acc[key.trim()] = val;
        return acc;
      }, {});

      updatedProxyOpts.headers.authorization = `Bearer ${cookieMap.authorization}`;
      return proxyReqOpts;
    },
  });
};
