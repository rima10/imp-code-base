const Models = require('../models/index');

async function getBusinessData(userId) {
  const user = await Models.business_partner.findOne({ where: { bp_id: userId }, attributes: [['bp_username', 'bpUsername'], ['bp_email_id', 'bpEmailId'], ['bp_phone_number', 'bpPhoneNumber'], ['gst_number', 'gstNumber'], ['industry_type', 'industryType'], ['loc_id', 'locId'], 'cin', 'pan', ['company_code', 'companyCode']] });
  let location = {};
  if (user.dataValues.locId) {
    const locData = await Models.location.findOne({ where: { loc_id: user.dataValues.locId }, atrributes: ['pincode', ['loc_details', 'locDetails']], include: [{ model: Models.state, as: 'state' }, { model: Models.city, as: 'city' }, { model: Models.country, as: 'country' }] });
    const {
      state_id, city_id, country_id, pincode, loc_details, loc_id, state, city,
    } = locData.dataValues;
    location = {
      countryId: country_id,
      stateId: state_id,
      cityId: city_id,
      locId: loc_id,
      state: state.state_name,
      city: city.city_name,
      locDetails: loc_details,
      pincode,
    };
  }
  return { ...user.dataValues, location };
  // commenting this line for now, once tested the complete flow it needs to be removed
  // const isBusinessDataPresent = user.dataValues.gstNumber !== null;
  // return { ...user.dataValues, location, isBusinessDataPresent };
}
/*
  @desc service to get user data
*/
exports.getUserBusinessData = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const user = await getBusinessData(userId);
    return user;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to update business partner data
*/
exports.updateUserBusinessData = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;
    const user = await Models.business_partner.findOne({ where: { bp_id: userId } });
    const { location } = req.body;
    if (location) {
      const {
        stateId, cityId, country, pincode,
        locId, locDetails,
      } = location;
      const locData = {
        country_id: country,
        state_id: stateId,
        city_id: cityId,
        loc_details: locDetails,
        pincode,
      };
      if (locId) {
        const loc = await Models.location.findOne({ where: { loc_id: locId } });
        await loc.update(locData);
      } else {
        const loc = await Models.location.create(locData);
        delete req.body.location;
        req.body.loc_id = loc.loc_id;
      }
    }
    if (user) {
      const {
        bpEmailId, bpUsername, gstNumber,
        industryType, loc_id, cin, pan, bpPhoneNumber, companyCode,
      } = req.body;
      const userDataObj = {
        bp_email_id: bpEmailId,
        bp_phone_number: bpPhoneNumber,
        bp_username: bpUsername,
        gst_number: gstNumber,
        industry_type: industryType,
        loc_id,
        cin,
        pan,
        company_code: companyCode,
      };
      // eslint-disable-next-line no-console
      await user.update(userDataObj, { logging: console.log(`update values ${JSON.stringify(userDataObj)}`) });
      const userData = await getBusinessData(userId);
      return userData;
    } throw new Error('user not found');
  } catch (error) {
    return next(error);
  }
};
