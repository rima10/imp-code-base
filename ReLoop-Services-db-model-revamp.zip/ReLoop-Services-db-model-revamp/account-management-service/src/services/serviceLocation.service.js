const Models = require('../models/index');

async function getServicableLocation(recyclerId) {
  const serviceableLocations = await Models.serviceable_location.findAll({
    where: { rcy_id: recyclerId },
    attributes: [['serv_loc_id', 'servLocId'], ['is_all_state', 'isAllState'], ['country_id', 'countryId']],
    include: [{
      model: Models.serviceable_state,
      attributes: [['state_id', 'stateId'], ['state_name', 'stateName'], ['is_all_city', 'isAllCity']],
      as: 'serviceable_states',
      include: [
        {
          model: Models.serviceable_city,
          attributes: [['city_id', 'cityId'], ['city_name', 'cityName']],
          as: 'serviceable_cities',
        }],
    }],
  });
  return serviceableLocations;
}
async function deleteServicableLocation(isAllState, existingServiceableLocation, statesDetail) {
  if (isAllState === true) {
    await Models.serviceable_location.update({ is_all_state: false },
      { where: { serv_loc_id: existingServiceableLocation.dataValues.servLocId } });
    await Models.serviceable_state.destroy(
      {
        where: {
          serv_loc_id: existingServiceableLocation.dataValues.servLocId,
        },
      },
    );
  } else {
    await Models.serviceable_state.destroy(
      {
        where: {
          state_id: statesDetail,
          serv_loc_id: existingServiceableLocation.dataValues.servLocId,
        },
      },
    );
  }
}
async function addRecyclerServicableLocation(serviceLocations, servLocId) {
  await Promise.all(serviceLocations.map(async (serviceLocation) => {
    const existingServiceableState = await Models.serviceable_state.findOne({
      where: {
        serv_loc_id: servLocId,
        state_id: serviceLocation.state,
      },
      attributes: [['state_id', 'stateId']],
    });
    if (!existingServiceableState) {
      if (serviceLocation.isAllCitySelected) {
        await Models.serviceable_state.create({
          serv_loc_id: servLocId,
          state_id: serviceLocation.state,
          state_name: serviceLocation.stateName,
          is_all_city: true,
        });
      } else {
        const serviceLocationCities = serviceLocation.city;
        const serviceableState = await Models.serviceable_state.create({
          serv_loc_id: servLocId,
          state_id: serviceLocation.state,
          state_name: serviceLocation.stateName,
          is_all_city: false,
        });
        await Promise.all(serviceLocationCities.map(async (serviceLocationCity) => {
          await Models.serviceable_city.create({
            serv_loc_state_id: serviceableState.serv_loc_state_id,
            city_id: serviceLocationCity.cityId,
            city_name: serviceLocationCity.cityName,
          });
        }));
      }
    }
  }));
}

/*
  @desc service function to create service location for a recycler
*/
exports.addServicableLocation = async function (req) {
  const { userId } = req.userInfo;
  const { serviceLocations, isAllStateSelected, countryId } = req.body;
  const existingServiceableLocation = await Models.serviceable_location.findOne({
    where: {
      rcy_id: userId,
    },
    attributes: [['serv_loc_id', 'servLocId'], ['is_all_state', 'isAllState']],
  });

  if (isAllStateSelected) {
    if (!existingServiceableLocation) {
      await Models.serviceable_location.create({
        rcy_id: userId,
        country_id: countryId,
        is_all_state: true,
      });
    } else {
      await deleteServicableLocation(true, existingServiceableLocation);
      await Models.serviceable_location.update({
        is_all_state: true,
      }, {
        where: {
          rcy_id: userId,
          serv_loc_id: existingServiceableLocation.dataValues.servLocId,
        },
      });
    }
  } else {
    let servLocId;
    if (existingServiceableLocation) {
      servLocId = existingServiceableLocation.dataValues.servLocId;
      await Models.serviceable_location.update({
        is_all_state: isAllStateSelected,
      }, {
        where: {
          rcy_id: userId,
          serv_loc_id: servLocId,
        },
      });
      await addRecyclerServicableLocation(serviceLocations, servLocId);
    } else {
      const serviceableLocation = await Models.serviceable_location.create({
        rcy_id: userId,
        country_id: countryId,
        is_all_state: false,
      });
      servLocId = serviceableLocation.serv_loc_id;
      await addRecyclerServicableLocation(serviceLocations, servLocId);
    }
  }
};

/*
  @desc service function to get servicable Location of a recycler
*/
exports.getRecyclerServicableLocation = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const rcyServicableLocation = await getServicableLocation(userId);
    return rcyServicableLocation;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to delete service location
*/
exports.deleteServiceableLocation = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { statesDetail, isAllState } = req.body;
    const existingServiceableLocation = await Models.serviceable_location.findOne({
      where: {
        rcy_id: userId,
      },
      attributes: [['serv_loc_id', 'servLocId'], ['is_all_state', 'isAllState']],
    });
    deleteServicableLocation(isAllState, existingServiceableLocation, statesDetail);
    const rcyServicableLocation = await getServicableLocation(userId);
    return rcyServicableLocation;
  } catch (error) {
    return next(error);
  }
};
