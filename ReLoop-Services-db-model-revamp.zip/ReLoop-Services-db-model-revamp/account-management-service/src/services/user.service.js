const mime = require('mime');
const { Op } = require('sequelize');
const Models = require('../models/index');
const s3UtilFunctions = require('../utils/s3.util');
const xlsx = require('../utils/xlsx.util');

async function createBpUser(payload) {
  const userData = {
    bp_userid: payload.bp_userid,
    bp_username: payload.bp_username,
    bp_email_id: payload.bp_email_id,
    archive: payload.archive,
  };
  const result = await Models.business_partner.create(userData);
  const roleId = payload.role_id;
  const bpId = result.dataValues.bp_id;
  const roleMapping = {
    bp_id: bpId,
    role_id: roleId,
  };
  await Models.role_bp_mapping.create(roleMapping);
}

exports.getUserDatabyCognito = async function (cognitoId, bp) {
  let isBusinessDataPresent;
  const user = await Models.business_partner.findOne({
    where: {
      bp_userid: cognitoId,
      // Will be used when existing useer archive flag is set to false
      // [Op.not]: [{ archive: true }],
    },
    atrributes: ['bp_id', 'bp_username', 'bp_email_id', 'bp_phone_number', 'loc_id',
      'gst_number', 'industry_type', 'cin', 'pan', 'is_part_of_pvt_nwk'],
  });
  if (!user) throw new Error('Invalid or inactive user');
  const {
    bp_id, bp_username, bp_email_id, gst_number, bp_phone_number, industry_type, cin, pan,
    loc_id, is_part_of_pvt_nwk,
  } = user;
  if (bp === 'gp') {
    isBusinessDataPresent = (gst_number !== null && bp_phone_number !== null
      && industry_type !== null && cin !== null && pan !== null && loc_id !== null);
  } else if (bp === 'rp') {
    const certificateQuery = {
      bp_id,
      cert_name: {
        [Op.or]: ['State Pollution Control Board Authorization', 'Authorization under Hazardous & Other Wastes'],
      },
    };
    const serviceableLoc = await Models.serviceable_location.findOne({ where: { rcy_id: bp_id }, attributes: [['serv_loc_id', 'servLocId']] });
    const certificates = await Models.certificate.findAll({ where: certificateQuery, attributes: ['cert_id'] });
    isBusinessDataPresent = (gst_number !== null && loc_id !== null
      && serviceableLoc !== null && bp_phone_number !== null
      && cin !== null && pan !== null && certificates.length >= 2);
  }
  const userData = {
    bp_id,
    bp_username,
    bp_email_id,
    isPartOfPvtNwk: is_part_of_pvt_nwk,
    isBusinessDataPresent,
    bpPhoneNumber: bp_phone_number,
  };
  return userData;
};

exports.getApproverDatabyCognito = async (cognitoId) => {
  const approver = await Models.approver.findOne({
    where: {
      approver_userid: cognitoId,
    },
    attributes: [['approver_id', 'approverId'],
      ['approver_role', 'approverRole'],
      ['approver_name', 'approverName'],
      ['approver_email_id', 'approverEmailId']],
  });
  return approver;
};
/*
  @desc service to create user data
*/
exports.register = async function (req) {
  const userData = req.body;
  userData.archive = false;
  await createBpUser(req.body);
};

/*
  @desc service function to get user data
*/
exports.getUserData = async (req, res, next) => {
  try {
    const { cognitoId } = req.params;
    const { approver, bp } = req.query;
    let userData = null;
    if (approver) userData = await exports.getApproverDatabyCognito(cognitoId);
    else userData = await exports.getUserDatabyCognito(cognitoId, bp);
    return userData;
  } catch (error) {
    res.status(401).json({
      message: error.message,
    });
    return next(error);
  }
};

/*
  @desc service function to read uploaded file from s3
*/
exports.downloadPrivacyStatement = async (req, res) => {
  const { key } = req.params;
  const result = await s3UtilFunctions.downloadFile(key, res);
  const { stream, data } = result;
  res.set('Content-Type', mime.getType(key));
  res.set('Content-Length', data.ContentLength);
  res.attachment(key);
  return stream;
};

exports.getGPPersonalDetails = async (userId) => {
  const userPersonalData = await Models.business_partner.findOne({
    where: { bp_id: userId },
    attributes: [['bp_username', 'bpUserName'], ['bp_email_id', 'bpEmailId'], ['bp_phone_number', 'bpPhoneNumber']],
    include: [{
      model: Models.approver,
      as: 'approvers',
      attributes: [['approver_name', 'approverName'], ['approver_email_id', 'approverEmailId']],
    }, {
      model: Models.order,
      as: 'orders',
      attributes: [['order_no', 'orderNo'], ['logistic_spoc_name', 'logisticSpocName'], ['logistic_spoc_number', 'logisticSpocNumber']],
    }],
  });
  const {
    bpUserName, bpEmailId, bpPhoneNumber, approvers, orders,
  } = userPersonalData.dataValues;
  const userData = [{
    'Data Model': 'User',
    'Data Field': 'Business Username',
    'Data Value': bpUserName,
  }, {
    'Data Model': 'User',
    'Data Field': 'Business Email Id',
    'Data Value': bpEmailId,
  }, {
    'Data Model': 'User',
    'Data Field': 'Business Phone Number',
    'Data Value': bpPhoneNumber,
  }];
  if (approvers) {
    approvers.forEach((approver) => {
      const { approverName, approverEmailId } = approver.dataValues;
      userData.push({
        'Data Model': 'Approver',
        'Data Field': 'Approver Name',
        'Data Value': approverName,
      }, {
        'Data Model': 'Approver',
        'Data Field': 'Approver Email Id',
        'Data Value': approverEmailId,
      });
    });
  }
  if (orders) {
    orders.forEach((order) => {
      const { orderNo, logisticSpocName, logisticSpocNumber } = order.dataValues;
      if (logisticSpocName) {
        userData.push({
          'Data Model': `Order ${orderNo}`,
          'Data Field': 'Order Responsible Name',
          'Data Value': logisticSpocName,
        });
      }
      if (logisticSpocNumber) {
        userData.push({
          'Data Model': `Order ${orderNo}`,
          'Data Field': 'Order Responsible Phone Number',
          'Data Value': logisticSpocName,
        });
      }
    });
  }
  const buffer = xlsx.createExcelFromJSON(userData, 'Personal Data');
  return buffer;
};

exports.getRPPersonalDetails = async (userId) => {
  const userPersonalData = await Models.business_partner.findOne({
    where: { bp_id: userId },
    attributes: [['bp_username', 'bpUserName'], ['bp_email_id', 'bpEmailId'], ['bp_phone_number', 'bpPhoneNumber']],
    include: [{
      model: Models.order_invited_business_partner,
      as: 'invitedOrders',
      attributes: ['order_id'],
      include: [{
        model: Models.order,
        as: 'order',
        attributes: [['order_no', 'orderNo'], ['vehicle_licence_no', 'vehicleNumber'], ['driver_name', 'driverName'], ['recycler_contact_name', 'recyclerContactName'], ['recycler_contact_number', 'recyclerContactNumber']],
      }],
    }],
  });
  const {
    bpUserName, bpEmailId, bpPhoneNumber, invitedOrders,
  } = userPersonalData.dataValues;
  const userData = [{
    'Data Model': 'User',
    'Data Field': 'Business Username',
    'Data Value': bpUserName,
  }, {
    'Data Model': 'User',
    'Data Field': 'Business Email Id',
    'Data Value': bpEmailId,
  }, {
    'Data Model': 'User',
    'Data Field': 'Business Phone Number',
    'Data Value': bpPhoneNumber,
  }];
  if (invitedOrders) {
    invitedOrders.forEach((invitedOrder) => {
      const {
        orderNo, recyclerContactNumber,
        recyclerContactName, driverName, vehicleNumber,
      } = invitedOrder.dataValues.order.dataValues;
      if (recyclerContactName) {
        userData.push({
          'Data Model': `Order ${orderNo}`,
          'Data Field': 'Recycler Contact Name',
          'Data Value': recyclerContactName,
        });
      }
      if (recyclerContactNumber) {
        userData.push({
          'Data Model': `Order ${orderNo}`,
          'Data Field': 'Recycler Contact Phone Number',
          'Data Value': recyclerContactNumber,
        });
      }
      if (driverName) {
        userData.push({
          'Data Model': `Order ${orderNo}`,
          'Data Field': 'Driver Name',
          'Data Value': driverName,
        });
      }
      if (vehicleNumber) {
        userData.push({
          'Data Model': `Order ${orderNo}`,
          'Data Field': 'Vehicle Number',
          'Data Value': vehicleNumber,
        });
      }
    });
  }
  const buffer = xlsx.createExcelFromJSON(userData, 'Personal Data');
  return buffer;
};
