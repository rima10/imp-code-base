/* eslint-disable max-len */
/* eslint-disable no-param-reassign */
const Models = require('../models/index');
const s3UtilFunctions = require('../utils/s3.util');

const uploadCertificatesToS3 = async (certificates) => {
  const uploadedFileKeys = await Promise.all(certificates.map(async (file) => s3UtilFunctions.pushFileToS3(file.certificateFile, file.uniqueFilename)));
  return uploadedFileKeys;
};

/*
  @desc service function to save certificate details of user
  @desc also uploads the certificate file into s3
*/
exports.saveUserCertificates = async (userId, userCertificates) => {
  try {
    const dbRes = await Models.business_partner.findOne({
      where: { bp_id: userId },
      attributes: ['bp_id', 'bp_username'],
    });
    const userData = dbRes.dataValues;

    const certificateFiles = userCertificates.map((certItem) => {
      const fileNamewithExt = certItem.certificateFile.originalname;
      const fileExt = fileNamewithExt.substr(fileNamewithExt.lastIndexOf('.') + 1);
      const uniqueFilename = `${userData.bp_username}_${userData.bp_id}_${certItem.certificateName}.${fileExt}`;
      return { certificateFile: certItem.certificateFile, uniqueFilename };
    });

    const uploadedFileKeys = await uploadCertificatesToS3(certificateFiles);
    userCertificates.forEach((certItem, index) => {
      certItem.certificateStorageMeta = uploadedFileKeys[index];
    });

    // allowNewFields: false will not take unnecessary fields other than db column fields
    const dbRecordsToCreate = Models.certificate.attributesMapHelper(userCertificates, { allowNewFields: false, method: 'in' });

    const options = {
      updateOnDuplicate: ['cert_details', 'authorization_number', 'rcy_unit_capacity', 'valid_period', 'issued_date'],
    };
    const dbRecords = await Models.certificate.bulkCreate(dbRecordsToCreate, options);

    const dbRecordsTransformed = dbRecords.map((item) => item.dataValues);
    return Promise.resolve(Models.certificate.attributesMapHelper(dbRecordsTransformed, { method: 'out' }));
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to get all certificate details of an user
*/
exports.getAllCertificatesForUser = async (userId) => {
  try {
    const dbRecords = await Models.certificate.findAll({
      where: Models.certificate.attributesMapHelper({ businessPartnerId: userId }),
    });
    const dbRecordsTransformed = dbRecords.map((item) => item.dataValues);
    return Promise.resolve(Models.certificate.attributesMapHelper(dbRecordsTransformed, { method: 'out' }));
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to read uploaded file from s3
*/
exports.downloadUserCertificateById = async (userId, certId) => {
  try {
    const certificateDbRecord = await Models.certificate.findOne({
      where: Models.certificate.attributesMapHelper({ businessPartnerId: userId, certificateId: certId }),
    });
    if (!certificateDbRecord) {
      throw new Error('No certificate resource found for given request');
    }

    const { cert_details } = certificateDbRecord.dataValues;
    const result = await s3UtilFunctions.downloadFile(cert_details);
    const { stream, data } = result;
    return Promise.resolve({ stream, data, filename: cert_details });
  } catch (error) {
    return Promise.reject(error);
  }
};
