const Models = require('../models/index');
const authUtil = require('../utils/auth.util');

async function getPrivateNetworks(userId) {
  const pvtNetworks = await Models.bp_private_nwk.findAll({
    where: { nwk_owner: userId },
    attributes: ['bp_nwk_id', 'nwk_member', 'nwk_owner'],
    include: [{ model: Models.business_partner, attributes: ['bp_email_id', 'bp_username', 'bp_phone_number', 'account_contact_name'], as: 'nwk_member_business_partner' }],
  });
  return pvtNetworks;
}
/*
  @desc service function to create user private network
  @desc check if pvt network user exist, if not create cognito user aswell
*/
exports.createUserPrivateNtw = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { pvtNwkMembers } = req.body;
    const { bp } = req.query;
    // Loop and check if recycler exist and add to private network else create recycler
    await Promise.all(pvtNwkMembers.map(async (pvtMember) => {
      const {
        emailId, username, phoneNumber, contactName,
      } = pvtMember;
      const groupName = bp === 'gp' ? authUtil.ROLES.RP_USER : authUtil.ROLES.GP_USER;
      let nwkMemberBP = await Models.business_partner.findOne({ where: { bp_email_id: emailId } });
      if (!nwkMemberBP) {
        const cognitoUserData = {
          Username: emailId,
          UserPoolId: process.env.COGNITO_USER_POOL_ID,
          TemporaryPassword: 'Welcome@12345', // To be removed , just for test data creation
        };
        const congitoUserGroupData = {
          GroupName: groupName,
          UserPoolId: process.env.COGNITO_USER_POOL_ID,
        };
        const cognitoUser = await authUtil.createCognitouser(cognitoUserData, congitoUserGroupData);
        nwkMemberBP = await Models.business_partner.create({
          bp_email_id: emailId,
          bp_userid: cognitoUser, // cognito id after creation
          bp_username: username,
          account_contact_name: contactName,
          bp_phone_number: phoneNumber,
          is_part_of_pvt_nwk: true,
        });
      } else if (nwkMemberBP.archive === true) nwkMemberBP.update({ archive: false });
      else {
        const existingNtw = await Models.bp_private_nwk.findOne({
          where: {
            nwk_member: nwkMemberBP.bp_id,
            nwk_owner: userId,
          },
        });
        if (existingNtw) throw new Error('Network already exists ');
      }
      await Models.bp_private_nwk.create({
        nwk_member: nwkMemberBP.bp_id,
        nwk_owner: userId,
      });
    }));
    await Models.business_partner.update({ has_pvt_network: true }, { where: { bp_id: userId } });
    const userPrivateNtws = await getPrivateNetworks(userId);
    return userPrivateNtws;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to get private network
*/
exports.getUserPrivateNtw = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const userPrivateNtws = await getPrivateNetworks(userId);
    return userPrivateNtws;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to update private network
*/
exports.updateUserPrivateNtw = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { pvtNwkMembers } = req.body;
    // Loop and check if recycler exist and add to private network else create recycler
    await Promise.all(pvtNwkMembers.map(async (pvtRecycler) => {
      const { emailId, username, phoneNumber } = pvtRecycler;
      let recyclerBP = await Models.business_partner.findOne({ where: { bp_email_id: emailId } });
      if (!recyclerBP) {
        const cognitoUser = await authUtil.createCognitouser({
          Username: emailId,
        });
        recyclerBP = await Models.business_partner.create({
          bp_email_id: emailId,
          bp_userid: cognitoUser, // cognito id after creation
          bp_username: username,
          bp_phone_number: phoneNumber,
        });

        await Models.bp_private_nwk.create({
          nwk_member: recyclerBP.bp_id,
          nwk_owner: userId,
        });
      } else {
        const { cognitoUserId } = pvtRecycler;
        await recyclerBP.update({
          bp_email_id: emailId,
          bp_userid: cognitoUserId, // cognito id after creation
          bp_username: username,
        });
      }
    }));
    const userPrivateNtws = await getPrivateNetworks(userId);
    return userPrivateNtws;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to update private network
*/
exports.deleteUserPrivateNtw = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { pvtNetworks } = req.body;
    // Loop and delete private network and disable business partner
    await Promise.all(pvtNetworks.map(async (pvtNetwork) => {
      const { networkId, recyclerId } = pvtNetwork;
      // eslint-disable-next-line max-len
      const recyclerExist = await Models.order_invited_business_partner.findOne({
        where: { invited_bp_id: recyclerId },
        include: [{ model: Models.order, where: { order_position: ['In Progress', 'Draft'] }, as: 'order' }],
      });
      if (recyclerExist) {
        throw new Error('Private Network cannot be deleted as being used in ongoing/draft orders');
      }
      await Models.bp_private_nwk.destroy(
        { where: { bp_nwk_id: networkId } },
      );
      const recycler = await Models.business_partner.findOne({ where: { bp_id: recyclerId } });
      await recycler.update({ archive: true });
    }));
    const userPrivateNtws = await getPrivateNetworks(userId);
    return userPrivateNtws;
  } catch (error) {
    return next(error);
  }
};
