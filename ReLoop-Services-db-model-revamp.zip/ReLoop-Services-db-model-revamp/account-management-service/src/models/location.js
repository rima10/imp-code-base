module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('location', {
    loc_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    country_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'country',
        key: 'country_id',
      },
    },
    state_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'state',
        key: 'state_id',
      },
    },
    city_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'city',
        key: 'city_id',
      },
    },
    loc_details: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    pincode: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'location',
    schema: 'address',
    timestamps: false,
    indexes: [
      {
        name: 'location_pkey',
        unique: true,
        fields: [
          { name: 'loc_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.city, { as: 'city', foreignKey: 'city_id' });
    model.belongsTo(models.country, { as: 'country', foreignKey: 'country_id' });
    model.belongsTo(models.state, { as: 'state', foreignKey: 'state_id' });
    model.hasMany(models.business_partner, { as: 'business_partners', foreignKey: 'loc_id' });
  };

  return model;
};
