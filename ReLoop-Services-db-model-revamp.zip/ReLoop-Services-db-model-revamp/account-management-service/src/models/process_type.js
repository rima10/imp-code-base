const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('process_type', {
    process_type_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    process_type_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'process_type',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'process_type_pkey',
        unique: true,
        fields: [
          { name: 'process_type_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.hasMany(models.workflow, { as: 'workflows', foreignKey: 'process_type_id' });
  };

  return model;
};
