const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('doc', {
    doc_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    doc_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    storage_metadata: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
  }, {
    sequelize,
    tableName: 'doc',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'doc_pkey',
        unique: true,
        fields: [
          { name: 'doc_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
  };

  return model;
};
