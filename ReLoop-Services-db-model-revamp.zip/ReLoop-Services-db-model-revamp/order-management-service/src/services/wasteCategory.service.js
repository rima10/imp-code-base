const Models = require('../models/index');

exports.createCategory = async function (req, res, next) {
  try {
    const { categories } = req.body;
    await Promise.all(categories.map(async (category) => {
      await Models.category.create({ category_name: category.categoryName });
    }));
  } catch (error) {
    next(error);
  }
};

exports.getCategory = async function (req, res, next) {
  try {
    const categories = await Models.category.findAll({ attributes: [['category_id', 'categoryId'], ['category_name', 'categoryName']] });
    res.json(categories);
  } catch (error) {
    next(error);
  }
};

exports.createSubcategory = async function (req, res, next) {
  try {
    const { subcategories } = req.body;
    const { categoryID } = req.params;
    await Promise.all(subcategories.map(async (subcategory) => {
      const { subcategoryName } = subcategory;
      await Models.sub_category.create({
        category_id: categoryID,
        sub_category_name: subcategoryName,
      });
    }));
  } catch (error) {
    next(error);
  }
};

exports.getsubCategory = async function (req, res, next) {
  const { categoryID } = req.params;
  try {
    const subcategories = await Models.sub_category.findAll({
      where: { category_id: categoryID },
      attributes: [['sub_category_id', 'subcategoryId'], ['category_id', 'categoryId'], ['sub_category_name', 'subcategoryName']],
    });
    res.json(subcategories);
  } catch (error) {
    next(error);
  }
};
