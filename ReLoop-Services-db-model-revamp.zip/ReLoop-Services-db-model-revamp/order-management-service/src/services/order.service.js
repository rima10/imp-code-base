const { Op } = require('sequelize');
const Models = require('../models/index');
const orderItemService = require('./orderItem.service');
const docService = require('./doc.service');
const orderWorkflowService = require('./orderWorkflow.service');
const orderDataFormatUtil = require('../utils/order/dataFormat.util');
const orderRepo = require('../repo/order.repo');
const bpNetworkRepo = require('../repo/bp_network.repo');
const quotationService = require('./quotation.service');

const kakfaUtil = require('../utils/kafka.util');

exports.createOrder = async (req) => {
  const orderDetails = req.body;
  const { processStageSequence, orderType } = orderDetails;
  const { userId } = req.userInfo;
  const { files } = req;
  const orderPosition = 'In Progress';
  const orderHeader = await orderRepo.createOrderHeader(orderDetails, userId, files, orderPosition);

  // after creating the order, add the order item and link the order with the order item
  await orderItemService.assetExcelHandler(userId, orderHeader, req.files.assetExcel[0], orderType);

  await orderWorkflowService.createOrderWorkflowData(
    userId,
    {
      processStageSequence,
      processType: orderType,
      orderId: orderHeader.order_id,
      commentsForApprover: orderDetails.commentsForApprover,
    },
  );

  const orders = await orderRepo.getOrdersByUserId(userId);
  return orders;
};

exports.saveOrderAsDraft = async (req, res, next) => {
  try {
    const orderDetails = req.body;
    const { userId } = req.userInfo;
    const { orderType } = orderDetails;
    const { files } = req;
    const orderPosition = 'Draft';
    const orderHeader = await orderRepo.createOrderHeader(orderDetails, userId,
      files, orderPosition);

    if (req.files && req.files.assetExcel[0]) {
      await orderItemService.assetExcelHandler(userId, orderHeader, req.files.assetExcel[0], orderType);
    }

    await orderWorkflowService.createOrderWorkflowData(
      userId,
      {
        processStageSequence: '1',
        processType: orderType,
        orderId: orderHeader.order_id,
        addApprovers: 'false',
      },
    );
    const order = await orderRepo.getOrderDataByOrderId(
      orderHeader.order_id,
      false,
    );
    return order;
  } catch (error) {
    return next(error);
  }
};

exports.updateOrderHeaderData = async (userId, orderId, updatePayload) => {
  try {
    const dbOrder = await orderRepo.getOrder(orderId);
    if (dbOrder.dataValues.order_position !== 'Draft') {
      throw new Error('Cannot update ongoing order data.');
    }
    await orderRepo.updateOrderHeaderData(userId, dbOrder.dataValues, updatePayload);

    const order = await orderRepo.getOrderDataByOrderId(orderId, false, '1', dbOrder.dataValues.order_type);
    return Promise.resolve(order);
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to get orders based on business partner id
*/
exports.getOrders = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const order = await orderRepo.getOrdersByUserId(userId);
    return order;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to to cancel an order
*/
exports.cancelOrder = async (orderId) => {
  try {
    // check if an order can be cancelled
    const order = await orderRepo.getOrder(orderId);
    if (!order) throw new Error('Order not found');

    if (order.current_sequence >= 3) throw new Error('Cannot cancel the order which is already submitted to recyclers');

    const response = {};
    if (order.order_position !== 'Cancelled') {
      const update = {
        order_position: 'Cancelled',
      };
      await orderRepo.updateOrderById(orderId, update);
      response.message = 'Order is cancelled successfully';
    } else {
      response.message = 'Order was already cancelled.';
    }
    return Promise.resolve(response);
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to make order as completed
*/
exports.completeOrder = async (orderId) => {
  try {
    // check if an order can be cancelled
    const order = await orderRepo.getOrder(orderId);
    if (!order) throw new Error('Order not found');

    if (order.current_sequence < 6) throw new Error('Cannot mark order as completed. Order is on going.');

    const response = {};
    if (order.order_position !== 'Completed') {
      const update = {
        order_position: 'Completed',
      };
      await orderRepo.updateOrderById(orderId, update);
      response.message = 'Order is marked as Completed Successfully';
    } else {
      response.message = 'Order was already marked as Completed.';
    }
    return Promise.resolve(response);
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to get orders based on business partner id
*/
exports.getOrderForApprover = async (req, res, next) => {
  try {
    const { orderId } = req.params;
    const orderType = await orderRepo.getOrderType(orderId);
    const order = await orderRepo.getOrderDataByOrderId(orderId, true, '1', orderType === '1');
    return order;
  } catch (error) {
    return next(error);
  }
};
/*
  @desc service function to get orders based on order id
*/
exports.getRecycleOrderByOrderId = async (req, res, next) => {
  try {
    const { orderId } = req.params;
    const order = await orderRepo.getOrderDataByOrderId(orderId, true, '1', false);
    return order;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to get orders based on order id
*/
exports.getRefurbishOrderByOrderId = async (req, res, next) => {
  try {
    const { orderId } = req.params;
    const order = await orderRepo.getOrderDataByOrderId(orderId, true, '1', true);
    return order;
  } catch (error) {
    return next(error);
  }
};

exports.getConsolidatedOrderData = async (req, res, next) => {
  try {
    const { orderId } = req.params;
    const order = await orderRepo.getOrderDataByOrderId(
      orderId,
      true,
      '2',
      true,
    );
    const consolidatedOrderData = orderDataFormatUtil.createConsolidatedOrderData(order);
    order.orderItems = consolidatedOrderData;
    return order;
  } catch (error) {
    return next(error);
  }
};

exports.getRecyclerConsolidatedOrderData = async (req, res, next) => {
  try {
    const { orderId } = req.params;
    const { userId } = req.userInfo;
    const isQuoteSubmitted = await orderRepo.getOrderItemAfterQuoteSubmission(
      orderId,
      userId,
    );
    if (isQuoteSubmitted != null) {
      return isQuoteSubmitted;
    }
    const order = await orderRepo.getOrderDataByOrderId(
      orderId,
      true,
      '2',
      true,
    );
    const consolidatedOrderData = orderDataFormatUtil.createConsolidatedOrderData(order);
    order.orderItems = consolidatedOrderData;
    return order;
  } catch (error) {
    return next(error);
  }
};

exports.getOrderItemAfterQuoteSubmission = async (req) => {
  const { orderId } = req.params;
  const { userId } = req.params;
  const quotes = await orderRepo.getOrderItemAfterQuoteSubmission(orderId, userId);
  return quotes;
};

/*
  @desc service function to get asset file url based on order id
*/
exports.getFileURL = async (req, res, next) => {
  const { orderId } = req.params;
  const s3Key = await exports.getFileKeyForDownload(orderId);
  const s3URLForTemplate = await s3UtilFunctions.getUrlForDownloadTemplate(
    s3Key,
  );
  return s3URLForTemplate;
};

/*
  @desc service function to get OrderType
*/
exports.getOrderType = async (req, res, next) => {
  try {
    const orderType = await Models.process_type.findAll({
      attributes: [
        ['process_type_name', 'processTypeName'],
        ['process_type_id', 'processTypeId'],
      ],
    });
    return orderType;
  } catch (error) {
    next(error);
  }
};

exports.createOrderType = async (req, res, next) => {
  try {
    const { processTypes } = req.body;
    await Promise.all(
      processTypes.map(async (processType) => {
        const { processTypeName, processTypeId } = processType;
        await Models.process_type.create({
          process_type_id: processTypeId,
          process_type_name: processTypeName,
        });
      }),
    );
  } catch (error) {
    next(error);
  }
};

exports.getFileKeyForDownload = async (orderId) => {
  const fileKey = await Models.order.findOne({
    where: { order_id: orderId },
    attributes: ['asset_excel_loc', 'assetExcelLoc'],
  });
  return fileKey;
};

exports.getStageApprovalStatus = async (req) => {
  const { orderId } = req.params;
  const { processType, processStageSequence } = req.query;
  const approvals = await orderRepo.getStageApprovalStatus(
    orderId,
    processType,
    processStageSequence,
  );
  return approvals;
};

async function notifyRecyclersForOrder(userId, orderId, options = {}) {
  let { order, user } = options;
  if (!order) {
    order = await orderRepo.getOrder(orderId);
    order = order.dataValues;
  }
  if (!user) {
    user = await Models.business_partner.findOne({
      where: Models.business_partner.attributesMapHelper({ userId }),
      attributes: Models.business_partner.attributesMapHelper(['emailId', 'username', 'userId']),
    });
    user = user.dataValues;
  }
  const dbres = await Models.order_invited_business_partner.findAll({
    where: Models.order_invited_business_partner.attributesMapHelper({ orderId }),
    include: [{
      model: Models.business_partner,
      attributes: Models.business_partner.attributesMapHelper(['emailId', 'username', 'userId']),
      as: 'invited_bp',
    }],
  });
  const invitedRecyclers = dbres.map((item) => {
    // eslint-disable-next-line no-shadow
    const { emailId, userId, username } = item.invited_bp.dataValues;
    return { emailId, userId, username };
  });

  const notification = {
    type: 'invite recyclers',
    receivers: invitedRecyclers.map((item) => ({ receiverType: 'bp', email: item.emailId })),
    values: {
      orderNo: order.order_no,
      greenPartnerName: user.username,
    },
  };
  kakfaUtil.runProducer('user-notification', notification);
  return Promise.resolve(invitedRecyclers);
}

exports.moveOrderToNextStep = async (req) => {
  const { orderId, nextStage } = req.params;
  const { userId } = req.userInfo;
  const { addApprovers } = req.query;
  let order = await orderRepo.getOrder(orderId);
  if (!order) throw new Error('Invalid order id');
  const orderType = order.order_type;
  order = await order.update({ order_id: orderId, current_sequence: nextStage });
  // Do not add approvers for quotation step
  await orderWorkflowService.createOrderWorkflowData(
    userId,
    {
      processStageSequence: nextStage, processType: orderType, orderId, addApprovers,
    },
  );
  // notify recyclers about the quotation submission
  if (nextStage.toString() === '3') {
    await notifyRecyclersForOrder(userId, orderId, { order: order.dataValues });
  }
  return order;
};

async function createAssetGradingDocument(orderId, quoteId, userId) {
  try {
    const wbBuffer = await quotationService.getOrderItemsGradingListInExcel(orderId, quoteId);
    const documentName = 'Asset Grading';
    const fileName = `AssetGrading_${orderId}_${quoteId}.xlsx`;
    const file = {
      buffer: wbBuffer,
    };
    const document = await docService.uploadDocToS3(orderId, documentName, file, fileName, userId);
    return Promise.resolve(document);
  } catch (e) {
    return Promise.reject(e);
  }
}
exports.scheduleLogistics = async (req) => {
  const { orderId } = req.params;
  const { userId } = req.userInfo;
  // create asset grading file document and push to s3
  const orderQuote = await quotationService.getCurrentAcceptedOrderQuotation(orderId);
  if (!orderQuote) throw new Error('Accepted order quotation is not found');

  createAssetGradingDocument(orderId, orderQuote.quoteId, userId);

  const {
    scheduledLogisticDate, logisticSpocName, logisticSpocContactNumber,
  } = req.body;
  let order = await Models.order.findOne({ where: { order_id: orderId } });
  if (order) {
    order = order.update({
      logistics_scheduled_time: scheduledLogisticDate,
      updated_by: userId,
      logistic_spoc_name: logisticSpocName,
      logistic_spoc_number: logisticSpocContactNumber,
    });
  }
  return order;
};

exports.acceptLogistics = async (req) => {
  const { orderId } = req.params;
  const {
    vehicleType,
    vehicleNumber,
    driverName,
    logisticProvider,
    recyclerContactName,
    recyclerContactNumber,
    userId,
  } = req.body;
  let order = await Models.order.findOne(
    { where: { order_id: orderId } },
  );
  if (order) {
    order = order.update({
      vehicle_type: vehicleType,
      vehicle_licence_no: vehicleNumber,
      driver_name: driverName,
      logistic_provider: logisticProvider,
      recycler_contact_name: recyclerContactName,
      recycler_contact_number: recyclerContactNumber,
      updated_by: userId,
    });
  }
  return order;
};

/*
  @desc service function to get private network
*/
exports.getUserPrivateNtw = async (userId) => {
  try {
    const query = {
      ownerUserId: userId,
    };
    const userPrivateNtws = await bpNetworkRepo.getManyByQuery(query);
    return Promise.resolve(userPrivateNtws);
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to get header data of the order
*/
exports.getOrderHeaderData = async (orderId, userId) => {
  const order = await Models.order.findOne({
    where: { order_id: orderId },
    attributes: [
      ['order_id', 'orderId'],
      ['submission_deadline', 'submissionDeadline'],
      ['picture_loc', 'pictureLoc'],
      ['order_network', 'order_network'],
      ['order_sub_text', 'additionaInfo'],
      ['current_sequence', 'currentSequence'],
      ['logistic_spoc_name', 'logisticSpocName'],
      ['logistic_spoc_number', 'logisticSpocContactNumber'],
      ['logistics_scheduled_time', 'logisticsScheduledTime'],
      ['order_no', 'orderNo'],
      [Models.sequelize.fn('COUNT', Models.sequelize.col('orderItems.id')), 'itemsCount'],
    ],
    include: [
      {
        model: Models.order_item,
        as: 'orderItems',
        attributes: [],
      },
      {
        model: Models.process_type,
        as: 'orderProcessType',
        required: true,
        attributes: [['process_type_name', 'processType']],
      },
      {
        model: Models.category,
        as: 'order_category',
        attributes: [['category_name', 'categoryName']],
      },
      {
        model: Models.sub_category,
        as: 'order_sub_category',
        attributes: [['sub_category_name', 'subCategoryName']],
      },
      {
        required: false,
        model: Models.order_quote,
        as: 'order_quotes',
        where: { created_by: userId },
        attributes: ['id', ['total_price', 'totalPrice']],
      },
      {
        model: Models.business_partner,
        as: 'businessPartner',
        attributes: [['bp_username', 'bpUserName']],
        include: [
          {
            model: Models.location,
            as: 'loc',
            attributes: ['pincode', ['loc_details', 'locDetails']],
            include: [
              {
                model: Models.city,
                as: 'city',
                attributes: ['city_name'],
              },
              {
                model: Models.state,
                as: 'state',
                attributes: ['state_name', 'country_id'],
              },
            ],
          },
        ],
      },
    ],
    group: [
      'order.order_id',
      'businessPartner.bp_id',
      'businessPartner.loc.city.city_id',
      'businessPartner.loc.loc_id',
      'order_category.category_id',
      'order_sub_category.sub_category_id',
      'businessPartner.loc.state.state_id',
      'order_quotes.id',
      'orderProcessType.process_type_id',
    ],
  });
  const orderData = {
    orderId: order.dataValues.orderId,
    processType: order.dataValues.orderProcessType.dataValues.processType,
    submissionDeadline: order.dataValues.submissionDeadline,
    category: order.dataValues.order_category.dataValues.categoryName,
    subCategory: order.dataValues.order_sub_category.dataValues.subCategoryName,
    pictureLoc: order.dataValues.pictureLoc,
    orderNetwork: order.dataValues.order_network,
    additionalInfo: order.dataValues.additionalInfo || null,
    itemsCount: order.dataValues.itemsCount,
    currentSequence: order.dataValues.currentSequence,
    logisticSpocName: order.dataValues.logisticSpocName,
    logisticSpocContactNumber: order.dataValues.logisticSpocContactNumber,
    logisticsScheduledTime: order.dataValues.logisticsScheduledTime,
    orderNo: order.dataValues.orderNo,
    totalPrice: order.dataValues.order_quotes.length > 0
      ? order.dataValues.order_quotes[0].dataValues.totalPrice : null,
    bpUserName: order.dataValues.businessPartner
      ? order.dataValues.businessPartner.dataValues.bpUserName : null,
    // eslint-disable-next-line no-nested-ternary
    locPincode: order.dataValues.businessPartner
      ? order.dataValues.businessPartner.loc
        ? order.dataValues.businessPartner.loc.pincode : null : null,
    locDetails:
      // eslint-disable-next-line no-nested-ternary
      order.dataValues.businessPartner
        ? order.dataValues.businessPartner.loc
          ? order.dataValues.businessPartner.loc.dataValues.locDetails : null : null,
    // eslint-disable-next-line no-nested-ternary
    locCity: order.dataValues.businessPartner
      ? order.dataValues.businessPartner.loc
        ? order.dataValues.businessPartner.loc.city.city_name : null : null,
    // eslint-disable-next-line no-nested-ternary
    locState: order.dataValues.businessPartner
      ? order.dataValues.businessPartner.loc
        ? order.dataValues.businessPartner.loc.state.state_name : null : null,
  };
  return orderData;
};

exports.getOrdersForRP = async (recyclerId) => {
  const OrderDetails = await Models.order_invited_business_partner.findAll({
    attributes: [['invited_bp_id', 'invitedBpId']],
    where: { invited_bp_id: recyclerId },
    as: 'order_invited_business_partner',
    separate: true,
    include: [
      {
        model: Models.order,
        where: {
          current_sequence: { [Op.notIn]: ['1', '2'] },
        },
        required: true,
        attributes: [
          'order_no',
          'order_id',
          'created_date',
          'current_sequence',
          'order_position',
          'order_type',
        ],
        as: 'order',
        include: [
          {
            model: Models.business_partner,
            as: 'businessPartner',
            attributes: [['bp_username', 'bpUserName'], 'bp_id'],
          },
        ],
      },
    ],
  });
  const StatusValue = [];
  let finalStatus;
  /* eslint no-restricted-syntax: ["error", "FunctionExpression", "WithStatement",
  "BinaryExpression[operator='in']"] */
  for (const order of OrderDetails) {
    // eslint-disable-next-line no-await-in-loop
    const StatusDetails = await Models.order_quote.findOne({
      attributes: Models.order_quote.attributesMapHelper(['quoteId', 'quoteStatus', 'orderId', 'createdByUserId', 'assetGradeSubmitted']),
      where: {
        created_by: recyclerId,
        order_id: order.order.dataValues.order_id,
      },
    });
    if (StatusDetails) {
      // eslint-disable-next-line prefer-destructuring
      finalStatus = StatusDetails.dataValues.quoteStatus;
      if (finalStatus === 'Accepted') {
        if (order.order.dataValues.current_sequence > 6
          || order.order.dataValues.order_position === 'Completed') {
          finalStatus = 'Completed';
        } else if (
          order.order.dataValues.current_sequence === 4
          || order.order.dataValues.current_sequence === 5
          || order.order.dataValues.current_sequence === 6
        ) {
          finalStatus = 'In Progress';
        } else if (order.order.dataValues.current_sequence === 3) {
          finalStatus = 'Waiting';
        }
      }
      StatusValue.push({
        order_id: order.order.dataValues.order_id,
        order_no: order.order.dataValues.order_no,
        currentSequence: order.order.dataValues.current_sequence,
        orderPosition: order.order.dataValues.order_position,
        orderType: order.order.dataValues.order_type,
        created_by:
          order.order.dataValues.businessPartner.dataValues.bpUserName,
        created_date: order.order.dataValues.created_date,
        quote_status: finalStatus,
        quoteId: StatusDetails.dataValues.quoteId,
        assetGradeSubmitted: StatusDetails.dataValues.assetGradeSubmitted,
      });
    } else {
      StatusValue.push({
        order_id: order.order.dataValues.order_id,
        order_no: order.order.dataValues.order_no,
        currentSequence: order.order.dataValues.current_sequence,
        orderPosition: order.order.dataValues.order_position,
        orderType: order.order.dataValues.order_type,
        created_by:
          order.order.dataValues.businessPartner.dataValues.bpUserName,
        created_date: order.order.dataValues.created_date,
        quote_status: 'New',
        quoteId: undefined,
      });
    }
  }
  return StatusValue;
};

exports.getRecycleOrderItems = async (req) => {
  const { orderId } = req.params;
  const { userId } = req.userInfo;
  const orderQuote = await Models.order_quote.findOne({
    where: { order_id: orderId, created_by: userId },
    attributes: [
      ['id', 'orderQuoteId'],
      ['recycle_price_per_kg', 'pricePerKg'],
      ['comments', 'quoteComments'],
      ['quote_status', 'quoteStatus'],
    ],
    include: [
      {
        model: Models.order_quote_item,
        as: 'orderItemQuotes',
        attributes: [
          ['id', 'orderItemQuoteId'],
          ['recycle_item_unit', 'itemUnit'],
        ],
        include: [
          {
            model: Models.order_item,
            as: 'order_item',
            attributes: [['model', 'orderItem']],
          },
        ],
      },
    ],
  });
  let result = {};
  if (orderQuote) {
    const orderQuoteData = orderQuote.dataValues;
    const orderItemsModel = orderQuoteData.orderItemQuotes;
    let orderItems = [];
    orderItemsModel.forEach((orderItem) => {
      orderItems.push({
        orderItemQuoteId: orderItem.dataValues.orderItemQuoteId,
        orderItem: orderItem.dataValues.order_item.dataValues.orderItem,
        itemUnit: orderItem.dataValues.itemUnit,
      });
    });
    result = {
      isInitialQuoteSubmitted: true,
      orderQuoteId: orderQuoteData.orderQuoteId,
      pricePerKg: orderQuoteData.pricePerKg,
      quoteComments: orderQuoteData.quoteComments,
      quoteStatus: orderQuoteData.quoteStatus,
      orderItems,
    };
  } else {
    const orderItems = await Models.order_item.findAll({
      where: { order_id: orderId },
      attributes: [
        ['id', 'orderItemId'],
        ['model', 'orderItem'],
      ],
    });
    result = { orderItems, isInitialQuoteSubmitted: false };
  }
  return result;
};

exports.getLogisticsData = async (orderId) => {
  const order = await Models.order.findOne({
    where: { order_id: orderId },
    attributes: [
      ['order_id', 'orderId'],
      ['vehicle_type', 'vehicleType'],
      ['vehicle_licence_no', 'vehicleLicenceNumber'],
      ['driver_name', 'driverName'],
      ['logistic_provider', 'logisticProvider'],
      ['recycler_contact_name', 'recyclerContactName'],
      ['recycler_contact_number', 'recyclerContactNumber'],
    ],
  });
  if (
    order.dataValues.vehicleType === null
    || order.dataValues.vehicleLicenceNumber === null
    || order.dataValues.driverName === null
  ) {
    order.dataValues.isLogisticDataSubmitted = false;
  } else {
    order.dataValues.isLogisticDataSubmitted = true;
  }
  return order;
};
