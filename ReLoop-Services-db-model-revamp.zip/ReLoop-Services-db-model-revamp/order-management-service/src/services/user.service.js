const Models = require('../models/index');

exports.getUserDatabyCognito = async (cognitoId) => {
  const res = await Models.business_partner.findOne({
    where: {
      bp_userid: cognitoId,
      // Will be used when existing useer archive flag is set to false
      // [Op.not]: [{ archive: true }],
    },
    attributes: ['bp_id', 'bp_username', 'bp_email_id'],
  });
  if (!res) return false;
  const userData = Models.business_partner.attributesMapHelper(res.dataValues, { method: 'out' });
  return userData;
};

exports.getApproverDatabyCognito = async (cognitoId) => {
  const approverData = await Models.approver.findOne({
    where: {
      approver_userid: cognitoId,
    },
    attributes: [['approver_id', 'approverId']],
  });
  return approverData;
};

exports.userPrivateNtwOwner = async (userId) => {
  const pvtNetworks = await Models.bp_private_nwk.findOne({
    where: { nwk_member: userId },
    attributes: ['nwk_owner'],
    include: [{ model: Models.business_partner, attributes: ['bp_username'], as: 'nwkOwner' }],
  });
  let privateNetworkOwner = {};
  if (pvtNetworks) {
    privateNetworkOwner = {
      nwkOwner: pvtNetworks.dataValues.nwk_owner,
      nwkOwnerName: pvtNetworks.dataValues.nwkOwner.dataValues.bp_username,
    };
  }
  return privateNetworkOwner;
};
