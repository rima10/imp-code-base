const Models = require('../models/index');
const kakfaUtil = require('../utils/kafka.util');
const orderWorkflowService = require('./orderWorkflow.service');

/*
  @desc helper function to get order list
  @param String - approverId
  @return Array - orderList
*/
const getOrderList = async (approverId) => {
  const pendingOrderApprovals = await Models.order_workflow_approver.findAll(
    {
      attributes: [['order_workflow_approver_id', 'orderWorkflowApproverId'], 'status'],
      include: [{
        model: Models.workflow_approver,
        attributes: [['workflow_approver_id', 'workflowApproverId']],
        as: 'workflow_approver',
        where: { approver_id: approverId },
      },
      {
        model: Models.order_workflow,
        as: 'orderWorkflow',
        attributes: [['order_id', 'orderId'], ['workflow_id', 'workflowId']],
        include: [{ model: Models.order, as: 'order', attributes: [['order_no', 'orderNo'], ['order_type', 'orderType'], ['total_weight', 'totalWeight']] },
        {
          model: Models.workflow,
          as: 'workflow',
          attributes: [['process_stage_name', 'processStageName'],
          ['process_stage_sequence', 'processStageSequence']],
        }],
      }],
    },
  );
  const orderList = [];
  pendingOrderApprovals.map((orderApproval) => {
    const orderApprovalData = orderApproval.dataValues;
    const orderWorkflowData = orderApprovalData.orderWorkflow.dataValues;
    const workflowData = orderApprovalData.orderWorkflow.dataValues.workflow.dataValues;
    const orderData = orderWorkflowData.order.dataValues;

    return orderList.push({
      orderId: orderWorkflowData.orderId,
      orderNo: orderData.orderNo,
      orderType: orderData.orderType,
      totalWeight: orderData.totalWeight,
      processStageName: workflowData.processStageName,
      processStageSequence: workflowData.processStageSequence,
      orderWorkflowApproverId: orderApprovalData.orderWorkflowApproverId,
      workflowApproverId: orderApprovalData.workflow_approver.dataValues.workflowApproverId,
      status: orderApprovalData.status,
    });
  });
  return orderList;
};

/*
  @desc background function to calculate and update overall workflow status
  @desc iterate over all order workflow approvers
  @desc if status of all is approved set status as accepted else rejected/pending
  @param String - orderWorkflowId
  @return Array - orderList
*/
const calculateWorkflowOverallStatus = async (orderWorkflowId) => {
  const orderWorkflowApporvers = await Models.order_workflow_approver.findAll(
    {
      where: { order_workflow_id: orderWorkflowId },
      attributes: ['status'],
    },
  );
  let overallStatus = 'Pending';
  let isApproved = true;

  for (let i = 0; i < orderWorkflowApporvers.length; i += 1) {
    const { status } = orderWorkflowApporvers[i];
    if (status === 'Pending') {
      isApproved = false;
      break;
    } else if (status === 'Rejected') {
      isApproved = false;
      overallStatus = status;
      break;
    }
  }
  if (isApproved) overallStatus = 'Approved';
  await Models.order_workflow.update(
    { overall_status: overallStatus },
    { where: { order_workflow_id: orderWorkflowId } },
  );
};

const notifyBP = async (type, orderId, comment, approverid) => {
  const order = await Models.order.findOne({
    where: { order_id: orderId },
    attributes: ['order_id', 'order_no'],
    include: [{ model: Models.business_partner, as: 'businessPartner', atrributes: ['bp_email_id'] }],
  });
  const approver = await Models.approver.findOne({ where: { approver_id: approverid }, attributes: [['approver_name', 'apporverName']] });
  const approverName = approver.dataValues.apporverName;
  const receiver = order.businessPartner.bp_email_id;
  const notification = {
    type,
    receivers: [{ receiverType: 'bp', email: receiver }],
    values: {
      orderNo: order.order_no,
      approver: approverName,
      comment,
    },
  };
  kakfaUtil.runProducer('user-notification', notification);
};

exports.notifyApprover = async (type, orderId, receiver) => {
  const order = await Models.order.findOne({
    where: { order_id: orderId },
    attributes: ['order_id', 'order_no'],
  });
  const notification = {
    type,
    receivers: [{ receiverType: 'approver', email: receiver }],
    values: {
      orderNo: order.order_no,
    },
  };
  kakfaUtil.runProducer('user-notification', notification);
};

const requestNextApproverInWorkflow = async (orderWorkflowId, orderId, currentSequence) => {
  const orderWorkflow = await Models.order_workflow.findOne(
    {
      where: { order_workflow_id: orderWorkflowId },
      attributes: [['order_workflow_id', 'orderWorkflowId']],
      include: [{
        model: Models.order_workflow_approver,
        as: 'order_workflow_approvers',
        attributes: [['order_workflow_approver_id', 'orderWorkflowApporverId']],
      },
      {
        model: Models.workflow,
        as: 'workflow',
        attributes: [['workflow_id', 'workflowId']],
        include: [{
          model: Models.workflow_approver,
          as: 'workflow_approvers',
          attributes: [['workflow_approver_id', 'workflowApproverId'], ['approver_sequence', 'approverSequence']],
        }],
      }],
    },
  );
  const { approverSequence } = orderWorkflow.workflow.workflow_approvers[currentSequence - 1].dataValues;
  const nextSequence = (parseInt(approverSequence, 10) + 1).toString();
  const { workflowId } = orderWorkflow.workflow.dataValues;
  const nextWorkflowApprover = await Models.workflow_approver.findOne(
    {
      where: {
        workflow_id: workflowId,
        approver_sequence: nextSequence,
      },
      attributes: [['workflow_approver_id', 'workflowApproverId']],
      include: [{ model: Models.approver, as: 'approver', attributes: [['approver_email_id', 'approverEmailId']] }],
    },
  );
  if (nextWorkflowApprover) {
    await orderWorkflowService.createOrderWfApprover(orderWorkflowId, workflowId, nextSequence, orderId);
  }
};

exports.getPendingApprovals = async (req, res, next) => {
  try {
    const { approverId } = req.params;
    const orderList = await getOrderList(approverId);
    return orderList;
  } catch (error) {
    return next(error);
  }
};

async function updateOrderWorkflowApprover(id, payload) {
  const orderWorkflowApprover = await Models.order_workflow_approver.findOne({
    where: { order_workflow_approver_id: id },
    include: [{
      model: Models.order_workflow,
      as: 'orderWorkflow',
      include: [{
        model: Models.workflow,
        as: 'workflow',
      }],
    }],
  });
  await orderWorkflowApprover.update(payload);
  return orderWorkflowApprover;
}

function formApprovalActivityIdentifier(pss, approverId, orderWorkflowApproverId) {
  return `pss_${pss}|gpapp_${approverId}|wkappid_${orderWorkflowApproverId}`;
}

exports.approve = async (req, res, next) => {
  try {
    const { approverId } = req.params;
    const { comment, orderId, orderWorkflowApproverId } = req.body;

    const orderWorkflowApprover = await updateOrderWorkflowApprover(orderWorkflowApproverId, { status: 'Approved' });

    if (comment) {
      const workflowDoc = orderWorkflowApprover?.dataValues?.orderWorkflow?.dataValues?.workflow;
      await Models.order_notes.create({
        order_id: orderId,
        activity: `Approval of ${workflowDoc.dataValues.process_stage_name}`,
        activity_identifier: formApprovalActivityIdentifier(
          workflowDoc.dataValues.process_stage_sequence,
          approverId,
          orderWorkflowApprover.dataValues.workflow_approver_id),
        activity_comment: comment,
        is_internal: true,
        approver_update_by: approverId,
      });
    }

    const orderList = await getOrderList(approverId);

    // Async tasks will run in the backgorund
    const { order_workflow_id, approver_sequence } = orderWorkflowApprover;
    requestNextApproverInWorkflow(order_workflow_id, orderId, approver_sequence);
    notifyBP('request accepted', orderId, comment, approverId);
    calculateWorkflowOverallStatus(order_workflow_id);

    return orderList;
  } catch (error) {
    return next(error);
  }
};

exports.reject = async (req, res, next) => {
  try {
    const { approverId } = req.params;
    const { comment, orderId, orderWorkflowApproverId } = req.body;
    const orderWorkflowApprover = await updateOrderWorkflowApprover(orderWorkflowApproverId, { status: 'Rejected' });

    if (comment) {
      const workflowDoc = orderWorkflowApprover?.dataValues?.orderWorkflow?.dataValues?.workflow;
      await Models.order_notes.create({
        order_id: orderId,
        activity: `Rejection of ${workflowDoc.dataValues.process_stage_name}`,
        activity_comment: comment,
        activity_identifier: formApprovalActivityIdentifier(
          workflowDoc.dataValues.process_stage_sequence,
          approverId,
          orderWorkflowApprover.dataValues.workflow_approver_id),
        is_internal: true,
        approver_update_by: approverId,
      });
    }

    const orderList = await getOrderList(approverId);
    // Async task will run in the backgorund
    notifyBP('request rejected', orderId, comment, approverId);
    const { order_workflow_id } = orderWorkflowApprover;
    calculateWorkflowOverallStatus(order_workflow_id);

    return orderList;
  } catch (error) {
    return next(error);
  }
};
