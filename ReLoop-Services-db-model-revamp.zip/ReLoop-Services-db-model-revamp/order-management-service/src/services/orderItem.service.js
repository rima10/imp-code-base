const Models = require('../models/index');
const utilFunctions = require('../utils/commonFunctions.util');
const docService = require('./doc.service');
const OrderRepo = require('../repo/order.repo');
const OrderItemRepo = require('../repo/order_item.repo');

// Excel to column mapping for refusrbish order
const getRefurbishOrderMapping = (orderId, userId, currElement) => ({
  order_id: orderId,
  equipment_no: currElement.A,
  asset_no: currElement.B,
  building_loc: currElement.E,
  bond_status: currElement.F,
  item_type: currElement.G,
  make: currElement.H,
  model: currElement.I,
  manufacture_serial: currElement.J,
  age_in_year: currElement.K,
  purchase_year: currElement.L,
  description: currElement.M,
  created_by: userId,
  updated_by: userId,
});

// Excel to column mapping for recycle order
const getRecycleOrderMapping = (orderId, userId, currElement) => ({
  order_id: orderId,
  model: currElement.B,
  item_quantity: currElement.C || null,
  recycle_item_unit: currElement.D || null,
  building_loc: currElement.E,
  description: currElement.F,
  created_by: userId,
  updated_by: userId,
});

const createOrderItem = async (req) => {
  const assetList = utilFunctions.convertExcelToJson(req.file.buffer);
  const { orderType, orderID } = req;
  const inputArr = assetList.slice(1);
  await Promise.all(inputArr.map(async (currElement) => {
    const orderItemData = orderType === '1' ? getRefurbishOrderMapping(orderID, req.userId, currElement)
      : getRecycleOrderMapping(orderID, req.userId, currElement);
    await Models.order_item.create(orderItemData);
  }));
};
exports.createOrderItem = createOrderItem;

const assetExcelHandler = async (userId, orderDetails, excelFile, orderType) => {
  try {
    const { order_no, order_id } = orderDetails;
    const orderItemReq = {
      file: excelFile,
      order_no,
      userId,
      orderID: order_id,
      orderType,
    };

    await createOrderItem(orderItemReq);

    // after creating the order, save the asset file
    const docItemReq = {
      files: { document: [excelFile] },
      params: { orderId: order_id },
      body: { documentName: 'Asset List', orderNo: order_no },
      userInfo: { userId },
    };
    await docService.uploadDocument(docItemReq);

    return Promise.resolve(true);
  } catch (err) {
    return Promise.reject(err);
  }
};
exports.assetExcelHandler = assetExcelHandler;

const readExcel = async (req) => {
  const excelData = utilFunctions.convertExcelToJson(req.file.buffer);
  const header = excelData.shift();
  const assetList = [];
  excelData.forEach((row) => {
    const assetRow = {};
    Object.keys(row).forEach((key) => {
      const value = row[key];
      assetRow[header[key]] = value;
    });
    assetList.push(assetRow);
  });
  return assetList;
};
exports.readExcel = readExcel;

exports.updateAssetExcelOrderItems = async (userId, orderId, assetExcelFile) => {
  const dbOrder = await OrderRepo.getOrder(orderId);
  const orderDetails = dbOrder.dataValues;
  if (orderDetails.order_position !== 'Draft') {
    throw new Error('Cannot update ongoing order data.');
  }

  const input = {
    file: assetExcelFile,
  };
  const rows = await readExcel(input);
  if (!rows || !rows.length) {
    throw new Error('Asset list is empty');
  }

  // delete existing asset rows for an order
  await OrderItemRepo.deleteOrderItemsForOrder(orderId);

  await assetExcelHandler(userId, orderDetails, assetExcelFile, orderDetails.order_type);
  const dbRows = await OrderRepo.getOrderItems(orderId, orderDetails.order_type);
  return Promise.resolve(dbRows);
};
