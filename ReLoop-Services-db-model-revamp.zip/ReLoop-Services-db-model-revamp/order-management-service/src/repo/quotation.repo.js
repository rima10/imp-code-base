const models = require('../models/index');

exports.getRecycleInitialQuote = async (orderId) => {
  const quotes = await models.order_quote
    .findAll({
      where:
        { order_id: orderId },
      attributes: [['id', 'quoteId'], ['quote_status', 'quoteStatus'], ['comments', 'quoteComments'], ['recycle_price_per_kg', 'pricePerKg'], ['comments', 'quoteComments'], ['asset_grading_submitted', 'assetGradeSubmitted']],
      include: [{
        model: models.business_partner,
        as: 'createdByBP',
        attributes: [['bp_id', 'recyclerId'], ['bp_username', 'recyclerName']],
      }, {
        model: models.order_quote_item,
        as: 'orderItemQuotes',
        attributes: [['id', 'quoteItemId'], ['order_item_id', 'orderItemId'], ['recycle_item_unit', 'recycleItemUnit']],
        include: [
          {
            model: models.order_item,
            as: 'order_item',
            attributes: [
              ['id', 'orderItemId'], 'model'],
          },
        ],
      }],
    });
  return quotes;
};

exports.getRefurbishInitialQuote = async (orderId) => {
  const quotes = await models.order_quote.findAll({
    where: { order_id: orderId },
    attributes: [
      ['id', 'quoteId'],
      ['id', 'quoteId'],
      ['quote_status', 'quoteStatus'],
      ['comments', 'quoteComments'],
      ['asset_grading_submitted', 'assetGradeSubmitted']],
    include: [{
      model: models.business_partner,
      as: 'createdByBP',
      attributes: [['bp_id', 'recyclerId'], ['bp_username', 'recyclerName']],
    }, {
      model: models.model_quote,
      as: 'modelQuotes',
      attributes: [['model_quote_id', 'modelQuoteId'], ['item_type', 'itemType'], 'make', 'model', 'price', 'count'],
    }],
  });
  return quotes;
};

exports.updateOrderQuoteItems = async (userId, orderId, orderQuoteId, payload) => {
  const bulkUpdatePayload = payload.map((item) => (
    {
      ...item,
      orderId,
      orderQuoteId,
      createdByUserId: userId,
      updatedByUserId: userId,
    }
  ));
  const dbBulkUpdatePayload = models.order_quote_item.attributesMapHelper(bulkUpdatePayload, { method: 'in', allowNewFields: false });
  const updateOptions = {
    updateOnDuplicate: ['last_modified_date', 'grade', 'data_wipe', 'report_status', 'accessories_status',
      'to_be_invoiced', 'service_cost', 'created_by', 'updated_by'],
  };
  return models.order_quote_item.bulkCreate(dbBulkUpdatePayload, updateOptions);
};

exports.getOrderQuote = async (orderId, quoteId, projection) => {
  let method = 'in';
  if (!projection || !projection) {
    // eslint-disable-next-line no-param-reassign
    projection = [];
    method = 'out';
  }
  const res = await models.order_quote.findOne({
    where: {
      order_id: orderId,
      id: quoteId,
    },
    attributes: models.order_quote.attributesMapHelper(projection, { method }),
  });
  return res;
};

exports.updateOrderQuote = async (userId, orderId, quoteId, updatePayload) => {
  const updatePayloadCopy = { ...updatePayload };
  updatePayloadCopy.updatedByUserId = userId;
  updatePayloadCopy.lastModifiedDate = new Date();

  const dbUpdatePayload = models.order_quote.attributesMapHelper(updatePayloadCopy, {
    allowNewFields: false,
    method: 'in',
  });
  return models.order_quote.update(
    dbUpdatePayload,
    {
      where: {
        order_id: orderId,
        id: quoteId,
      },
    },
  );
};

exports.updateTotalPrice = async (orderId, quoteId) => {
  const quote = await models.order_quote.findOne({
    where: { order_id: orderId, id: quoteId },
    attributes: ['id'],
    include: [{
      model: models.order_quote_item,
      as: 'orderItemQuotes',
      attributes: [['to_be_invoiced', 'toBeInvoiced'], ['service_cost', 'serviceCost']],
    }],
  });
  let totalPrice = quote.dataValues.orderItemQuotes.reduce((acc, itemQuote) => {
    let updatedAcc = acc;
    updatedAcc += Number(itemQuote.dataValues.toBeInvoiced);
    return updatedAcc;
  }, 0);
  totalPrice = Math.round(totalPrice * 100) / 100;
  await quote.update({ total_price: totalPrice });
  return quote;
};

exports.checkQuoteStatus = async (orderId, userId) => {
  const quoteStatus = await models.order_quote.findOne(
    {
      where: { order_id: orderId, created_by: userId },
      attributes: [['id', 'quoteId'], ['quote_status', 'quoteStatus']],
    },
  );
  if (quoteStatus && quoteStatus.dataValues.quoteStatus === 'Accepted') return true;
  return false;
};
