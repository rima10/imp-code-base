const Models = require('../models/index');

exports.getManyByQuery = async (query) => {
  const dbQuery = Models.bp_private_nwk.attributesMapHelper(query);
  const pvtNetworks = await Models.bp_private_nwk.findAll({
    where: dbQuery,
    attributes: Models.bp_private_nwk.attributesMapHelper(['bpNwkId', ['nwk_member', 'recyclerId'],
      ['nwk_owner', 'greenPartnerId']]),
    include: [{
      model: Models.business_partner,
      attributes: Models.business_partner.attributesMapHelper(['emailId', 'username', 'phoneNumber']),
      as: 'rcy',
    }],
  });
  return pvtNetworks;
};
