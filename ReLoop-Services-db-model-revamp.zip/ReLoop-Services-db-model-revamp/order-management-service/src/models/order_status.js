const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('order_status', {
    order_status_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order',
        key: 'order_id',
      },
    },
    status_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'status',
        key: 'status_id',
      },
    },
    completed: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    order_status_sequence: {
      type: DataTypes.DECIMAL,
      allowNull: false,
    },
    order_status_text: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    created_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    updated_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
  }, {
    sequelize,
    tableName: 'order_status',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'order_status_pkey',
        unique: true,
        fields: [
          { name: 'order_status_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.business_partner, { as: 'created_by_business_partner', foreignKey: 'created_by' });
    model.belongsTo(models.business_partner, { as: 'updated_by_business_partner', foreignKey: 'updated_by' });
    model.belongsTo(models.order, { as: 'order', foreignKey: 'order_id' });
    model.belongsTo(models.status, { as: 'status', foreignKey: 'status_id' });
  };

  return model;
};
