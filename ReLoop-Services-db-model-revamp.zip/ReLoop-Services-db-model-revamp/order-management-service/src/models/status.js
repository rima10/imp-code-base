module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('status', {
    status_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    status_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'status',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'status_pkey',
        unique: true,
        fields: [
          { name: 'status_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.hasMany(models.order_status, { as: 'order_statuses', foreignKey: 'status_id' });
  };

  return model;
};
