/**
 * @swagger
 *  components:
 *    schemas:
 *      Category:
 *        type: object
 *        required:
 *        properties:
 *          category_id:
 *            type: string
 *          category_name:
 *            type: string
 *        example:
 *           category_id: 1
 *           category_name: E-waste
 */

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('category', {
    category_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    category_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'category',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'category_pkey',
        unique: true,
        fields: [
          { name: 'category_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.hasMany(models.order, { as: 'orders', foreignKey: 'category' });
    model.hasMany(models.sub_category, { as: 'sub_categories', foreignKey: 'category_id' });
    model.hasMany(models.recycling_category, { as: 'recycling_categories', foreignKey: 'cat_id' });
  };

  return model;
};
