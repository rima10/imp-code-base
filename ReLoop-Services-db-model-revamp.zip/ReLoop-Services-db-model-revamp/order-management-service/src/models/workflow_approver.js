module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('workflow_approver', {
    workflow_approver_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    workflow_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'workflow',
        key: 'workflow_id',
      },
    },
    approver_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'approver',
        key: 'approver_id',
      },
    },
    approver_sequence: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'workflow_approver',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'workflow_approver_pkey',
        unique: true,
        fields: [
          { name: 'workflow_approver_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.hasMany(models.order_workflow_approver, { as: 'order_workflow_approvers', foreignKey: 'workflow_approver_id' });
    model.belongsTo(models.approver, { as: 'approver', foreignKey: 'approver_id' });
    model.belongsTo(models.workflow, { as: 'workflow', foreignKey: 'workflow_id' });
};

  return model;
};
