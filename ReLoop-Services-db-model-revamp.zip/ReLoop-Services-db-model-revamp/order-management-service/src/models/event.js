const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('event', {
    event_id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
    },
    event_type: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    template_content: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
  }, {
    sequelize,
    tableName: 'event',
    schema: 'notification',
    timestamps: false,
    indexes: [
      {
        name: 'event_pkey',
        unique: true,
        fields: [
          { name: 'event_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
  };

  return model;
};
