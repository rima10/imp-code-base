import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Label, Input, Select, Title, Option, TextArea, Button, FlexBox } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import bg from '../../asset/images/background-image.png';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport.js';
import { getBusinessInfo, updateBusinessInfo, getStates, getIndustry, getCities } from '../../store/action/taskAction';
import { GST_MAXLENGTH, PHONE_LENGTH, COMPANYCODE_LENGTH, CIN_NO_LENGTH } from '../../asset/constants/constant';
import validateInput from '../../validation/BusinessProfile';
import { camelCaseToSentence } from '../../utils/formatter';
import { isEmpty } from '../../validation/common';

const BusinessInfoForm = ({
    startUpdateBusinessInfo,
    startGetStates,
    startGetCities,
    startGetIndustry,
    startGetBusinessInfo,
    businessInfo,
    industry,
    states,
    cities,
    onBiSave
}) => {
    const [selectedState, setSelectedState] = useState(businessInfo.location && businessInfo.location.stateId);
    const [inputBox, setInputBox] = useState({
        businessName: {
            value: businessInfo.bpUsername,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        gstin: {
            value: businessInfo.gstNumber,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        cin: {
            value: businessInfo.cin,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        pan: {
            value: businessInfo.pan,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        pincode: {
            value: businessInfo.location && businessInfo.location.pincode,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        companyCode: {
            value: businessInfo.companyCode,
            valueState: 'None',
            valueStateMessage: '',
            required: false
        },
        industryType: {
            value: businessInfo.industryType,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        phoneNumber: {
            value: businessInfo.bpPhoneNumber,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        address: {
            value: businessInfo.location && businessInfo.location.locDetails,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        state: {
            value: businessInfo.location && businessInfo.location.stateId,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        city: {
            value: businessInfo.location && businessInfo.location.cityId,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        }
    });

    useEffect(() => {
        startGetBusinessInfo();
        startGetIndustry();
        startGetStates();
    }, []);

    useEffect(() => {
        if (!isEmpty(selectedState)) {
            startGetCities(selectedState);
        }
    }, [selectedState]);

    const submitBusinessInfoForm = async (event) => {
        event.preventDefault();
        let isValid = true;
        let tempInputBox = { ...inputBox };
        Object.keys(tempInputBox).map((field) => {
            // check to find whether value is empty for required fields
            if (tempInputBox[field]['required'] && tempInputBox[field]['value'] === '') {
                let fieldName = '';
                if (field === 'cin' || field === 'pan' || field === 'gstin') {
                    fieldName = field.toUpperCase();
                } else {
                    fieldName = camelCaseToSentence(field);
                }
                tempInputBox[field]['valueState'] = 'Error';
                tempInputBox[field]['valueStateMessage'] = <span>{fieldName} is required</span>;
                isValid = false;
            }
            // check to find whether any field has error state
            if (tempInputBox[field]['valueState'] === 'Error') {
                isValid = false;
            }
        });
        if (isValid) {
            const payload = {
                bpPhoneNumber: inputBox.phoneNumber.value,
                bpUsername: inputBox.businessName.value,
                cin: inputBox.cin.value,
                gstNumber: inputBox.gstin.value,
                companyCode: inputBox.companyCode.value,
                industryType: inputBox.industryType.value,
                pan: inputBox.pan.value,
                location: {
                    country: '1',
                    stateId: inputBox.state.value,
                    cityId: inputBox.city.value,
                    pincode: inputBox.pincode.value,
                    locDetails: inputBox.address.value
                }
            };
            startUpdateBusinessInfo(payload)
                .then(() => onBiSave())
                .catch(() => console.log('Something went wrong!'));
        } else {
            setInputBox(tempInputBox);
        }
    };

    const onSelectionChange = (event) => {
        let tempInputBox = { ...inputBox };
        let field = event.target.name;
        let value = event.target.selectedOption.value;
        tempInputBox[field]['value'] = value;
        tempInputBox[field]['valueState'] = 'None';
        tempInputBox[field]['valueStateMessage'] = '';
        if (field === 'state') {
            if (!isEmpty(value)) {
                startGetCities(value);
            }
            tempInputBox['city']['value'] = '';
            setSelectedState(value);
        }
        setInputBox(tempInputBox);
    };

    const onInputChange = (event) => {
        let tempInputBox = { ...inputBox };
        let field = event.target.name;
        let { isValid, errorMessage } = validateInput(event.target.value, field, tempInputBox[field]);
        tempInputBox[field]['value'] = event.target.value;
        tempInputBox[field]['valueStateMessage'] = <span>{errorMessage}</span>;
        if (isValid) {
            tempInputBox[field]['valueState'] = 'None';
        } else {
            tempInputBox[field]['valueState'] = 'Error';
        }
        setInputBox(tempInputBox);
    };

    return (
        <FlexBox alignItems="Center" direction="Column" justifyContent="SpaceBetween">
            <div style={{ backgroundImage: `url(${bg})`, width: '100%', height: '270px', textAlign: 'center' }}>
                <Title
                    style={{
                        fontSize: 'x-large',
                        textAlign: 'center',
                        marginTop: '80px',
                        color: '#000000'
                    }}
                >
                    <b>Business Information</b>
                </Title>
                <Label
                    wrap
                    style={{
                        fontSize: 'large',
                        marginTop: '20px',
                        color: '#000000'
                    }}
                >
                    Please add all the business data needed to complete your Business Profile
                </Label>
            </div>
            <FlexBox alignItems="Start" justifyContent="SpaceBetween">
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label required style={{ fontSize: 'large', marginTop: '2rem', display: 'block' }}>
                        Business Name
                    </Label>
                    <Label required style={{ fontSize: 'large', marginTop: '2rem', display: 'block' }}>
                        Industry Type{' '}
                    </Label>
                    <Label required style={{ fontSize: 'large', marginTop: '2.5rem', display: 'block' }}>
                        GSTIN
                    </Label>
                    <Label required style={{ fontSize: 'large', marginTop: '2rem', display: 'block' }}>
                        CIN Number
                    </Label>
                    <Label required style={{ fontSize: 'large', marginTop: '2rem', display: 'block' }}>
                        PAN
                    </Label>
                    <Label required style={{ fontSize: 'large', marginTop: '2rem', display: 'block' }}>
                        Phone Number
                    </Label>
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '3rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2.5rem', display: 'block' }} />
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Input
                        id="businessName"
                        style={{ marginTop: '2rem', display: 'block' }}
                        name="businessName"
                        value={inputBox.businessName.value}
                        valueState={inputBox.businessName.valueState}
                        valueStateMessage={inputBox.businessName.valueStateMessage}
                        readonly
                    >
                        {inputBox.businessName.value}
                    </Input>
                    <Select
                        style={{ marginTop: '1rem', display: 'block', width: '100px' }}
                        name="industryType"
                        id="industryType"
                        valueState={inputBox.industryType.valueState}
                        valueStateMessage={inputBox.industryType.valueStateMessage}
                        onChange={(e) => {
                            onSelectionChange(e);
                        }}
                    >
                        <Option id="-1" name="-" value="">
                            Select Industry Type
                        </Option>
                        {industry?.map((indus) => {
                            return (
                                <Option selected={indus === inputBox.industryType.value} key={indus} value={indus}>
                                    {indus}
                                </Option>
                            );
                        })}
                    </Select>
                    <Input
                        style={{ marginTop: '1.5rem', display: 'block' }}
                        name="gstin"
                        id="gstin"
                        maxlength={GST_MAXLENGTH}
                        value={inputBox.gstin.value}
                        valueState={inputBox.gstin.valueState}
                        valueStateMessage={inputBox.gstin.valueStateMessage}
                        onInput={(e) => {
                            onInputChange(e);
                        }}
                        placeholder="Enter GSTIN"
                    />
                    <Input
                        style={{ marginTop: '1.5rem', display: 'block' }}
                        id="cin"
                        name="cin"
                        maxlength={CIN_NO_LENGTH}
                        value={inputBox.cin.value}
                        valueState={inputBox.cin.valueState}
                        valueStateMessage={inputBox.cin.valueStateMessage}
                        onInput={(e) => {
                            onInputChange(e);
                        }}
                        placeholder="Enter CIN Number"
                    />
                    <Input
                        style={{ marginTop: '1.25rem', display: 'block' }}
                        id="pan"
                        name="pan"
                        placeholder="Enter PAN"
                        value={inputBox.pan.value}
                        valueState={inputBox.pan.valueState}
                        valueStateMessage={inputBox.pan.valueStateMessage}
                        onInput={(e) => {
                            onInputChange(e);
                        }}
                    />
                    <Input
                        style={{ marginTop: '1.25rem', display: 'block' }}
                        id="phoneNumber"
                        name="phoneNumber"
                        placeholder="Enter Business phone number"
                        maxlength={PHONE_LENGTH}
                        value={inputBox.phoneNumber.value}
                        valueState={inputBox.phoneNumber.valueState}
                        valueStateMessage={inputBox.phoneNumber.valueStateMessage}
                        onInput={(e) => {
                            onInputChange(e);
                        }}
                    />
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label
                        required
                        style={{ fontSize: 'large', marginLeft: '7rem', marginTop: '2rem', display: 'block' }}
                    >
                        State
                    </Label>
                    <Label
                        required
                        style={{ fontSize: 'large', marginLeft: '7rem', marginTop: '2rem', display: 'block' }}
                    >
                        City
                    </Label>
                    <Label
                        required
                        style={{ fontSize: 'large', marginLeft: '7rem', marginTop: '2rem', display: 'block' }}
                    >
                        Pincode
                    </Label>
                    <Label style={{ fontSize: 'large', marginLeft: '7rem', marginTop: '2rem', display: 'block' }}>
                        Company Code
                    </Label>
                    <Label
                        required
                        style={{ fontSize: 'large', marginLeft: '7rem', marginTop: '2rem', display: 'block' }}
                    >
                        Address
                    </Label>
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '3rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2.5rem', display: 'block' }} />
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Select
                        style={{ marginTop: '1.5rem', display: 'block' }}
                        id="state"
                        name="state"
                        valueState={inputBox.state.valueState}
                        valueStateMessage={inputBox.state.valueStateMessage}
                        onChange={(e) => {
                            onSelectionChange(e);
                        }}
                    >
                        <Option id="-1" name="-" value="">
                            Select State
                        </Option>
                        {states?.map((stateVal) => (
                            <Option
                                selected={stateVal.state_id === inputBox.state.value}
                                key={stateVal.state_id}
                                value={stateVal.state_id}
                            >
                                {stateVal.state_name}
                            </Option>
                        ))}
                    </Select>
                    <Select
                        style={{ marginTop: '1.5rem', display: 'block' }}
                        id="city"
                        name="city"
                        onChange={(e) => {
                            onSelectionChange(e);
                        }}
                        valueState={inputBox.city.valueState}
                        valueStateMessage={inputBox.city.valueStateMessage}
                        disabled={states.length}
                    >
                        <Option id="-1" name="-" value="">
                            Select City
                        </Option>
                        {cities?.map((cityVal) => (
                            <Option
                                selected={cityVal.city_id === inputBox.city.value}
                                key={cityVal.city_id}
                                value={cityVal.city_id}
                            >
                                {cityVal.city_name}
                            </Option>
                        ))}
                    </Select>
                    <Input
                        style={{ marginTop: '1.5rem', display: 'block' }}
                        id="pincode"
                        name="pincode"
                        value={inputBox.pincode.value}
                        valueState={inputBox.pincode.valueState}
                        valueStateMessage={inputBox.pincode.valueStateMessage}
                        onInput={(e) => {
                            onInputChange(e);
                        }}
                        placeholder="Pincode"
                    />
                    <Input
                        style={{ marginTop: '1.5rem', display: 'block' }}
                        name="companyCode"
                        id="companyCode"
                        placeholder="Enter Company Code"
                        maxlength={COMPANYCODE_LENGTH}
                        value={inputBox.companyCode.value}
                        valueState={inputBox.companyCode.valueState}
                        valueStateMessage={inputBox.companyCode.valueStateMessage}
                        onInput={(e) => {
                            onInputChange(e);
                        }}
                    />
                    <TextArea
                        rows={3}
                        style={{
                            width: '210px',
                            fontSize: 'medium',
                            marginTop: '1.5rem',
                            display: 'block'
                        }}
                        id="address"
                        name="address"
                        value={inputBox.address.value}
                        valueState={inputBox.address.valueState}
                        valueStateMessage={inputBox.address.valueStateMessage}
                        onInput={(e) => {
                            onInputChange(e);
                        }}
                        placeholder="Street and number, Building Name, Landmark etc."
                    />
                </FlexBox>
            </FlexBox>
            <FlexBox>
                <Button
                    design="Emphasized"
                    style={{
                        marginLeft: '45rem',
                        marginTop: '1.5rem',
                        float: 'right'
                    }}
                    onClick={submitBusinessInfoForm}
                >
                    Submit
                </Button>
            </FlexBox>
        </FlexBox>
    );
};

const mapStateToProps = (state) => {
    return {
        businessInfo: state.account.businessInfo,
        industry: state.account.industry,
        states: state.account.states,
        cities: state.account.cities
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetBusinessInfo: () => dispatch(getBusinessInfo()),
        startGetIndustry: () => dispatch(getIndustry()),
        startGetStates: () => dispatch(getStates()),
        startGetCities: (stateId) => dispatch(getCities(stateId)),
        startUpdateBusinessInfo: (payload) => dispatch(updateBusinessInfo(payload))
    };
};

BusinessInfoForm.propTypes = {
    startUpdateBusinessInfo: PropTypes.func,
    startGetStates: PropTypes.func,
    startGetCities: PropTypes.func,
    startGetIndustry: PropTypes.func,
    startGetBusinessInfo: PropTypes.func,
    businessInfo: PropTypes.object,
    industry: PropTypes.array,
    states: PropTypes.array,
    cities: PropTypes.array,
    onBiSave: PropTypes.func
};

BusinessInfoForm.defaultProps = {
    businessInfo: {},
    industry: [],
    states: [],
    cities: []
};

export default connect(mapStateToProps, mapDispatchToProps)(BusinessInfoForm);
