import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Label, Title, Button, FlexBox } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import bg from '../../asset/images/background-image.png';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport.js';
import { getBusinessInfo } from '../../store/action/taskAction';
import LoadingIndicator from '../common/Loading';

const BusinessInfoView = ({ startGetBusinessInfo, businessInfo, onEditClick }) => {
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        startGetBusinessInfo();
    }, []);
    useEffect(() => {
        if (businessInfo && businessInfo.industryType && businessInfo.industryType.length) {
            setLoading(false);
        }
    }, [businessInfo.industryType]);

    const { industryType, gstNumber, cin, pan, bpPhoneNumber, companyCode, bpUsername, location = {} } = businessInfo;
    if (loading) {
        return <LoadingIndicator />;
    }
    return (
        <FlexBox alignItems="Center" direction="Column" justifyContent="SpaceBetween">
            <div style={{ backgroundImage: `url(${bg})`, width: '100%', height: '270px', textAlign: 'center' }}>
                <Title
                    style={{
                        fontSize: 'x-large',
                        textAlign: 'center',
                        marginTop: '80px',
                        color: '#000000'
                    }}
                >
                    <b> Business Information </b>
                </Title>
                <Label
                    wrap
                    style={{
                        fontSize: 'large',
                        textAlign: 'center',
                        marginTop: '20px',
                        color: '#000000'
                    }}
                >
                    {' '}
                    Please add all the business data needed to complete your Business Profile
                </Label>
            </div>
            <FlexBox alignItems="Start" justifyContent="SpaceBetween">
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label className="formLabel">Business Name </Label>
                    <Label className="formLabel">Industry Type </Label>
                    <Label className="formLabel">GSTIN</Label>
                    <Label className="formLabel">CIN Number</Label>
                    <Label className="formLabel">PAN</Label>
                    <Label className="formLabel">Phone Number</Label>
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label className="formLabel">:</Label>
                    <Label className="formLabel">:</Label>
                    <Label className="formLabel">:</Label>
                    <Label className="formLabel">:</Label>
                    <Label className="formLabel">:</Label>
                    <Label className="formLabel">:</Label>
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label className="formLabel txtColor"> {bpUsername} </Label>
                    <Label className="formLabel txtColor"> {industryType} </Label>
                    <Label className="formLabel txtColor"> {gstNumber} </Label>
                    <Label className="formLabel txtColor"> {cin} </Label>
                    <Label className="formLabel txtColor"> {pan} </Label>
                    <Label className="formLabel txtColor"> {bpPhoneNumber} </Label>
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <span style={{ marginLeft: '2rem' }} />
                    <span style={{ marginLeft: '2rem' }} />
                    <span style={{ marginLeft: '2rem' }} />
                    <span style={{ marginLeft: '2rem' }} />
                    <span style={{ marginLeft: '2rem' }} />
                    <span style={{ marginLeft: '2rem' }} />
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label className="formLabel">State</Label>
                    <Label className="formLabel">City</Label>
                    <Label className="formLabel">Pincode</Label>
                    <Label className="formLabel">Company Code</Label>
                    <Label className="formLabel">Address</Label>
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label className="formLabel">:</Label>
                    <Label className="formLabel">:</Label>
                    <Label className="formLabel">:</Label>
                    <Label className="formLabel">:</Label>
                    <Label className="formLabel">:</Label>
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label className="formLabel txtColor"> {location.state}</Label>
                    <Label className="formLabel txtColor"> {location.city} </Label>
                    <Label className="formLabel txtColor"> {location.pincode} </Label>
                    <Label className="formLabel txtColor"> {companyCode}</Label>
                    <Label className="formLabel txtColor" wrap>
                        {' '}
                        {location.locDetails}{' '}
                    </Label>
                </FlexBox>
            </FlexBox>
            <FlexBox>
                <Button
                    design="Emphasized"
                    style={{
                        marginLeft: '45rem',
                        float: 'right'
                    }}
                    onClick={onEditClick}
                >
                    Edit
                </Button>
            </FlexBox>
        </FlexBox>
    );
};

const mapStateToProps = (state) => {
    return {
        businessInfo: state.account.businessInfo
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetBusinessInfo: () => dispatch(getBusinessInfo())
    };
};

BusinessInfoView.propTypes = {
    startGetBusinessInfo: PropTypes.func,
    businessInfo: PropTypes.object,
    onEditClick: PropTypes.func
};

BusinessInfoView.defaultProps = {
    businessInfo: {}
};

export default connect(mapStateToProps, mapDispatchToProps)(BusinessInfoView);
