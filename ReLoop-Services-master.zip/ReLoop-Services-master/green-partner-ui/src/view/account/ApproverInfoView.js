import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Label, Title } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport.js';
import bg from '../../asset/images/background-image.png';
import AccountTable from '../common/ModifiedTable';
import { getApproverInfoState, isApproverInfoLoading } from '../../selectors/common';
import { getApproverInfo, registerBPApproverInfo, deleteBPApproverInfo } from '../../store/action/taskAction';
import validateInput from '../../validation/ApproverData';
import { camelCaseToSentence } from '../../utils/formatter';
import { showMessage } from './../../store/action/type';

const ApproverInfoView = ({
    startGetApproverInfo,
    startRegisterBPApproverInfo,
    approverInfo,
    isLoading,
    startDeleteBPApproverInfo,
    startShowMessage
}) => {
    const [rows, setRows] = useState([]);
    const [isNewRow, setIsNewRow] = useState(false);
    const [rowsToDelete, setRowsToDelete] = useState([]);

    const initializeState = () => {
        setIsNewRow(false);
        setRowsToDelete([]);
    };

    const getRowsFromApproverInfo = () => {
        let existingRows = [...rows];
        existingRows = [];
        if (!approverInfo.length) {
            setRows([]);
        } else {
            approverInfo.map((approver) => {
                existingRows.push({
                    isSelected: {
                        value: false,
                        valueState: 'None',
                        type: 'checkbox',
                        readonly: false,
                        id: approver.approver_id
                    },
                    approverRole: {
                        value: approver.approver_role,
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    },
                    approverName: {
                        value: approver.approver_name,
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    },
                    emailAddress: {
                        value: approver.approver_email_id,
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    }
                });
            });
            setRows(existingRows);
        }
    };

    useEffect(() => {
        startGetApproverInfo();
    }, []);

    useEffect(() => {
        getRowsFromApproverInfo();
        initializeState();
    }, [approverInfo]);

    const getAddedRows = () => {
        const newRows = [];
        rows.forEach((row) => {
            if ('isNewRecord' in row.isSelected) {
                newRows.push(row);
            }
        });
        return newRows;
    };

    const checkIfRoleExists = () => {
        let existingRows = [...rows];
        let existingApproverRoles = [];
        existingRows.forEach((row) => {
            if (!('isNewRecord' in row.isSelected)) {
                existingApproverRoles.push(row.approverRole.value.trim().toLowerCase());
            }
        });
        const addedRows = getAddedRows();
        let isDuplicate = addedRows.some((val) =>
            existingApproverRoles.includes(val.approverRole.value.trim().toLowerCase())
        );
        return isDuplicate;
    };

    const saveApproverInfo = async (event) => {
        event.preventDefault();
        let isValid = true;
        let existingRows = [...rows];
        if (checkIfRoleExists()) {
            isValid = false;
            startShowMessage({
                message: 'Approver Role cannot be repeated',
                status: 'Negative'
            });
        } else if (!existingRows.length) {
            isValid = false;
        } else {
            existingRows.map((input, idx) => {
                Object.keys(input).map((field) => {
                    // check to find whether value is empty for required fields
                    if (existingRows[idx][field]['required'] && existingRows[idx][field]['value'] === '') {
                        let fieldName = camelCaseToSentence(field);
                        existingRows[idx][field]['valueState'] = 'Error';
                        existingRows[idx][field]['valueStateMessage'] = <span>{fieldName} is required</span>;
                        isValid = false;
                    }
                    // check to find whether any field has error state
                    if (existingRows[idx][field]['valueState'] === 'Error') {
                        isValid = false;
                    }
                });
            });
        }
        if (isValid) {
            const addedRows = getAddedRows();
            if (addedRows.length) {
                const payload = { approvers: [] };
                addedRows.map((row) => {
                    payload.approvers.push({
                        approverEmailId: row.emailAddress.value,
                        approverName: row.approverName.value,
                        approverRole: row.approverRole.value
                    });
                });
                startRegisterBPApproverInfo(payload);
            }
        } else {
            setRows(existingRows);
        }
    };

    const getRowsToBeDeleted = () => {
        const selectedRows = [];
        rows.forEach((row) => {
            if (row.isSelected.value === true) {
                selectedRows.push(row.isSelected.id);
            }
        });
        return setRowsToDelete(selectedRows);
    };

    const onInputChange = (rowIndex, field, event) => {
        let tempRows = [...rows];
        let idx = rowIndex;
        if (field === 'isSelected') {
            tempRows[idx][field]['value'] = !tempRows[idx][field]['value'];
            tempRows[idx][field]['valueState'] = 'None';
            getRowsToBeDeleted();
        } else {
            let { isValid, errorMessage } = validateInput(event.target.value, field, tempRows[idx][field]);
            tempRows[idx][field]['value'] = event.target.value;
            tempRows[idx][field]['valueStateMessage'] = <span>{errorMessage}</span>;
            if (isValid) {
                tempRows[idx][field]['valueState'] = 'None';
            } else {
                tempRows[idx][field]['valueState'] = 'Error';
            }
        }
        setRows(tempRows);
    };

    const onAddRowClick = () => {
        setIsNewRow(true);
        const existingRows = [
            ...rows,
            {
                isSelected: {
                    value: false,
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'checkbox',
                    readonly: true,
                    isNewRecord: true
                },
                approverRole: {
                    value: '',
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'input',
                    required: true
                },
                approverName: {
                    value: '',
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'input',
                    required: true
                },
                emailAddress: {
                    value: '',
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'input',
                    required: true
                }
            }
        ];
        setRows(existingRows);
    };

    const onCancel = async (event) => {
        event.preventDefault();
        initializeState();
        getRowsFromApproverInfo();
    };

    const onDeleteClick = async (event) => {
        event.preventDefault();
        if (rowsToDelete.length) {
            const payload = { approvers: [] };
            approverInfo.map((approver) => {
                if (rowsToDelete.includes(approver.approver_id)) {
                    payload.approvers.push({
                        approverId: approver.approver_id
                    });
                }
            });
            startDeleteBPApproverInfo(payload);
        }
    };

    const buttons = [
        {
            name: 'Save',
            icon: 'save',
            onClick: saveApproverInfo,
            disabled: !isNewRow
        },
        {
            name: 'Cancel',
            icon: 'decline',
            onClick: onCancel,
            disabled: !isNewRow
        },
        {
            name: 'Add',
            icon: 'add',
            onClick: onAddRowClick,
            disabled: false
        },
        {
            name: 'Delete',
            icon: 'delete',
            onClick: onDeleteClick,
            disabled: !rowsToDelete.length
        }
    ];

    const columns = ['', 'Approver Role', 'Approver Name', 'Approver Email ID'];

    return (
        <div style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ backgroundImage: `url(${bg})`, width: '100%', height: '270px', textAlign: 'center' }}>
                <Title
                    style={{
                        fontSize: 'x-large',
                        textAlign: 'center',
                        marginTop: '80px',
                        color: '#000000'
                    }}
                >
                    <b>Approver Information</b>
                </Title>
                <Label
                    wrap
                    style={{
                        fontSize: 'large',
                        textAlign: 'center',
                        marginTop: '20px',
                        color: '#000000'
                    }}
                >
                    In case you want to create an Approval Workflow please add data about your approver team
                </Label>
            </div>
            <AccountTable
                isLoading={isLoading}
                buttons={buttons}
                columns={columns}
                rows={rows}
                onInputChange={onInputChange}
            />
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        approverInfo: getApproverInfoState(state),
        isLoading: isApproverInfoLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetApproverInfo: async () => dispatch(getApproverInfo()),
        startRegisterBPApproverInfo: (payload) => dispatch(registerBPApproverInfo(payload)),
        startDeleteBPApproverInfo: (payload) => dispatch(deleteBPApproverInfo(payload)),
        startShowMessage: (payload) => dispatch(showMessage(payload))
    };
};

ApproverInfoView.propTypes = {
    startGetApproverInfo: PropTypes.func,
    startRegisterBPApproverInfo: PropTypes.func,
    approverInfo: PropTypes.array,
    isLoading: PropTypes.bool,
    startDeleteBPApproverInfo: PropTypes.func,
    startShowMessage: PropTypes.func
};

ApproverInfoView.defaultProps = {
    approverInfo: []
};

export default connect(mapStateToProps, mapDispatchToProps)(ApproverInfoView);
