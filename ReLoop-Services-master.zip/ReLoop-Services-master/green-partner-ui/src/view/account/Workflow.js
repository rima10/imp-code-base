import React, { useEffect, useState, useRef } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Button, Toolbar, Label, FlexBox } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from '@ui5/webcomponents-react-base';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport.js';
import AccountTable from '../common/Table';
import {
    getWorkflowsInfo,
    registerBPWorkflowInfo,
    deleteBPWorkflowInfo,
    deleteBPWorkflowApproverInfo
} from '../../store/action/taskAction';
import { getApproverInfoState, isApproverInfoLoading } from '../../selectors/common';
import { showMessage } from './../../store/action/type';
import { isEmpty } from '../../validation/common';

const Workflow = ({
    processStageSequence,
    processStageName,
    processTypeId,
    approvers = [],
    approverInfo = [],
    workflowId,
    startRegisterBPWorkflowInfo,
    startGetWorkflowInfo,
    showTable,
    startDeleteBPWorkflowInfo,
    startDeleteBPWorkflowApproverInfo,
    isLoading,
    startShowMessage
}) => {
    const [rows, setRows] = useState([]);
    const [table, setTable] = useState(showTable);
    const [selectedRow, setSelectedRow] = useState([]);
    const stateRef = useRef();
    stateRef.current = selectedRow;
    const [newApprovers, setNewApprovers] = useState({
        processStageSequence,
        processStageName,
        processTypeId,
        approvers: {}
    });
    const newAppRef = useRef({});
    newAppRef.current = newApprovers.approvers;

    const newRowRef = useRef({});
    newRowRef.current = rows;

    const isRowSelected = (event, rowNumber) => {
        event.preventDefault();
        let row = stateRef.current;
        const index = row.indexOf(rowNumber);
        if (index > -1) {
            row.splice(index, 1);
        } else {
            row.push(rowNumber);
        }
        setSelectedRow(row);
    };
    const getRowsFromApprovers = (approvers) => {
        const newRows = [];
        if (approvers.length !== 0) {
            approvers.map((app) => {
                const { approver } = app;
                const row = [
                    {
                        type: 'checkbox',
                        onInputChange: isRowSelected,
                        disabled: false,
                        value: approver.approver_id
                    }
                ];
                row.push({
                    name: 'approver_sequence',
                    value: app.approver_sequence,
                    type: 'text'
                });
                row.push({
                    name: 'approver_role',
                    value: approver.approver_role,
                    type: 'text'
                });
                row.push({
                    name: 'approver_name',
                    value: approver.approver_name,
                    type: 'text'
                });
                newRows.push(row);
            });
        }
        return newRows;
    };

    useEffect(() => {
        startGetWorkflowInfo();
    }, []);

    useEffect(() => {
        const rows = getRowsFromApprovers(approvers);
        setRows(rows);
    }, [approvers.length]);

    const saveWorkflowInfo = async (event) => {
        event.preventDefault();
        const payload = { ...newApprovers };
        const approvers = newAppRef.current;
        let isEmptyRow = false;
        for (const key in approvers) {
            const approver = approvers[key];
            if (approver.approverId === '-1') {
                isEmptyRow = true;
            }
        }
        if (isEmpty(approvers) || isEmptyRow) {
            startShowMessage({
                message: 'Please select a role.',
                status: 'Negative'
            });
        } else {
            const approversPayload = [];
            let isDuplicateEntry = false;
            let approverIds = [];
            let existingApproverIds = [];
            rows.forEach((row) => {
                if (row[0]?.value) {
                    existingApproverIds.push(row[0].value);
                }
            });
            for (const key in approvers) {
                const approver = approvers[key];
                approversPayload.push(approver);
                approverIds.push(approver.approverId);
            }
            if (new Set(approverIds).size !== approverIds.length) {
                isDuplicateEntry = true;
            } else if (approverIds.some((val) => existingApproverIds.includes(val))) {
                isDuplicateEntry = true;
            }
            if (isDuplicateEntry) {
                startShowMessage({
                    message: 'Approver Role cannot be repeated',
                    status: 'Negative'
                });
            } else {
                payload.approvers = approversPayload;
                startRegisterBPWorkflowInfo(payload);
                setNewApprovers({ processStageSequence, processStageName, processTypeId, approvers: [] });
            }
        }
    };

    const inputChange = (event) => {
        const { slot } = event.currentTarget.parentElement.parentElement;
        let name = '';
        let value = '';
        if (event.detail) {
            name = 'approverId';
            value = event.detail.selectedOption.attributes.id.value;
            const approverName = event.detail.selectedOption.attributes.name.value;
            const { current } = newRowRef;
            const updatedRows = [...current];
            updatedRows[Number(slot.substr(-1)) - 1][3].value = approverName;
            setRows(updatedRows);
        } else {
            name = event.target.name;
            value = event.target.value;
        }
        const { current } = newAppRef;
        const approvers = { ...current };
        if (approvers[slot]) approvers[slot][name] = value;
        else {
            approvers[slot] = {};
            approvers[slot][name] = value;
        }
        setNewApprovers({ ...newApprovers, approvers });
        name = 'approverSequence';
        value = rows.length + 1;
        if (approvers[slot]) approvers[slot][name] = value;
        else {
            approvers[slot] = {};
            approvers[slot][name] = value;
        }
        setNewApprovers({ ...newApprovers, approvers });
    };

    const onAddRowClick = () => {
        const row = [];
        row.push({
            type: 'checkbox',
            onInputChange: isRowSelected,
            disabled: true
        });
        row.push({
            name: 'approverSequence',
            value: `${rows.length + 1}`,
            type: 'text'
        });
        row.push({
            name: 'role',
            value: 'name',
            type: 'select',
            options: approverInfo,
            onInputChange: inputChange
        });
        row.push({ name: 'name', value: '-', type: 'text' });
        const { current } = newRowRef;
        const existingRows = [...current];
        existingRows.push(row);
        setRows(existingRows);
    };

    const onCancel = async (event) => {
        event.preventDefault();
        const newRows = getRowsFromApprovers(approvers);
        setRows(newRows);
    };

    const onAddWorkflow = (stepId) => {
        setTable(true);
        onAddRowClick();
    };

    const onDeleteWorklow = (event) => {
        event.preventDefault();
        setTable(false);
        if (!isEmpty(workflowId)) {
            const payload = { processTypeId: processTypeId, workflowId: workflowId };
            startDeleteBPWorkflowInfo(payload);
        } else {
            setRows([]);
        }
    };

    const onDeleteClick = async (event) => {
        event.preventDefault();
        const rowsToDelete = stateRef.current;
        if (isEmpty(rowsToDelete)) {
            startShowMessage({
                message: 'There are no existing entries to be deleted',
                status: 'Negative'
            });
        } else {
            const payload = { processTypeId: processTypeId, workflowApprovers: [] };
            rowsToDelete.map((row) => {
                payload.workflowApprovers.push({
                    workflowApproverId: approvers[row].workflow_approver_id
                });
            });
            startDeleteBPWorkflowApproverInfo(payload);
            setSelectedRow([]);
        }
    };

    const buttons = [
        {
            name: 'Save',
            icon: 'save',
            onClick: saveWorkflowInfo
        },
        {
            name: 'Cancel',
            icon: 'decline',
            onClick: onCancel
        },
        {
            name: 'Add',
            icon: 'add',
            onClick: onAddRowClick
        },
        {
            name: 'Delete',
            icon: 'delete',
            onClick: onDeleteClick
        }
    ];

    const columns = ['', 'Approver Sequence', 'Approver Role', 'Approver Name'];

    return (
        <div style={{ display: 'flex', ...spacing.sapUiMediumMargin }}>
            <>
                {showTable || table ? (
                    <>
                        <Button
                            design="Negative"
                            icon="delete"
                            style={{ position: 'absolute', right: '4.5%' }}
                            onClick={(e) => onDeleteWorklow(e)}
                        >
                            Delete Workflow
                        </Button>
                        <AccountTable
                            selectedRow={selectedRow}
                            isLoading={isLoading}
                            buttons={buttons}
                            columns={columns}
                            rows={rows}
                            edit={false}
                            text={`Define Approval Workflow for ${processStageName} `}
                        />
                    </>
                ) : (
                    <FlexBox direction="Column" style={{ width: '100%' }}>
                        <Label style={{ fontSize: '1rem', fontWeight: 'bold', ...spacing.sapUiSmallMarginTopBottom }}>
                            Define Approval Workflow for {processStageName}
                        </Label>
                        <Button
                            id="add_workflow"
                            onClick={() => onAddWorkflow()}
                            design="Emphasized"
                            style={{ width: '150px' }}
                        >
                            Add Workflow
                        </Button>
                        <Toolbar />
                    </FlexBox>
                )}
            </>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        approverInfo: getApproverInfoState(state),
        isLoading: isApproverInfoLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetWorkflowInfo: (payload) => dispatch(getWorkflowsInfo(payload)),
        startRegisterBPWorkflowInfo: (payload) => dispatch(registerBPWorkflowInfo(payload)),
        startDeleteBPWorkflowInfo: (payload) => dispatch(deleteBPWorkflowInfo(payload)),
        startDeleteBPWorkflowApproverInfo: (payload) => dispatch(deleteBPWorkflowApproverInfo(payload)),
        startShowMessage: (payload) => dispatch(showMessage(payload))
    };
};

Workflow.propTypes = {
    processStageSequence: PropTypes.string,
    processStageName: PropTypes.string,
    processTypeId: PropTypes.string,
    approvers: PropTypes.array,
    approverInfo: PropTypes.array,
    workflowId: PropTypes.string,
    startRegisterBPWorkflowInfo: PropTypes.func,
    startGetWorkflowInfo: PropTypes.func,
    showTable: PropTypes.bool,
    startDeleteBPWorkflowInfo: PropTypes.func,
    startDeleteBPWorkflowApproverInfo: PropTypes.func,
    isLoading: PropTypes.bool,
    startShowMessage: PropTypes.func
};

Workflow.defaultProps = {
    approvers: [],
    approverInfo: []
};

export default connect(mapStateToProps, mapDispatchToProps)(Workflow);
