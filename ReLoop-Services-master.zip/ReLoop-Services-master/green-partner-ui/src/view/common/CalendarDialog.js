import React, { useState } from 'react';
import PropTypes from 'prop-types';
import {
    Button,
    Dialog,
    FlexBox,
    Calendar,
    Label,
    Input,
    DurationPicker,
    Select,
    Option,
    TextArea
} from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from '@ui5/webcomponents-react-base';
import {
    validateContactNumber
} from '../../validation/common';
import { PHONE_LENGTH } from '../../asset/constants/constant';

const CalendarDialog = React.forwardRef(({ onCancel, onSubmit, headerText, showEstHours, options }, ref) => {
    const [payload, setPayload] = useState({
        dateValidation: {
            valueState: 'None'
        },
        timeValidation: {
            valueState: 'None'
        },
        estimatedTimeValidation: {
            valueState: 'None'
        },
        contactValidation: {
            valueState: 'None'
        }
    });

    const onDateSelect = (event) => {
        const updatedPayload = { ...payload };
        updatedPayload.date = event.detail.values[0];
        updatedPayload.dateValidation = {
            valueState: 'None'
        };
        setPayload(updatedPayload);
    };

    const onTimeSelect = (event) => {
        event.preventDefault();
        const updatedPayload = { ...payload };
        updatedPayload.time = event.detail.value;
        updatedPayload.timeValidation = {
            valueState: 'None'
        };
        setPayload(updatedPayload);
    };

    const onEstimatedHoursSelect = (event) => {
        event.preventDefault();
        const updatedPayload = { ...payload };
        if (event.detail.selectedOption.value.toString() === '-1') {
            return;
        }
        updatedPayload.estimatedTimeValidation = {
            valueState: 'None'
        };
        updatedPayload.estimatedTime = event.detail.selectedOption.textContent;
        setPayload(updatedPayload);
    };

    const onInputChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        const updatedPayload = { ...payload };
        updatedPayload[name] = value;
        setPayload(updatedPayload);
    };

    const onSubmitLocal = (event) => {
        const updatedPayload = { ...payload };
        let isValid = true;
        if (options.dateRequired && !updatedPayload.date) {
            isValid = false;
            updatedPayload.dateValidation = {
                valueState: 'Error',
                valueStateMessage: <span> Date is required</span>
            };
        }
        if (options.timeRequired && !updatedPayload.time) {
            isValid = false;
            updatedPayload.timeValidation = {
                valueState: 'Error',
                valueStateMessage: <span> Time is required</span>
            };
        }
        if (options.estimatedTimeRequired && !updatedPayload.estimatedTime) {
            isValid = false;
            updatedPayload.estimatedTimeValidation = {
                valueState: 'Error',
                valueStateMessage: <span> Estimated Hours is required</span>
            };
        }

        if (updatedPayload.logisticSpocContactNumber) {
            const validResponse = validateContactNumber(updatedPayload.logisticSpocContactNumber);
            isValid = validResponse.isValid;
            if (!isValid) {
                updatedPayload.contactValidation = {
                    valueState: 'Error',
                    valueStateMessage: <span> {validResponse.errorMessage} </span>
                };
            }
        }
        if (!isValid) {
            setPayload(updatedPayload);
            return;
        }

        onSubmit(updatedPayload);
    };

    return (
        <Dialog
            ref={ref}
            footer={
                <div>
                    <Button style={spacing.sapUiTinyMargin} onClick={(e) => onSubmitLocal(e)}>
                        Submit
                    </Button>
                    <Button style={spacing.sapUiTinyMargin} onClick={onCancel}>
                        Close
                    </Button>
                </div>
            }
            headerText={headerText}
        >
            <FlexBox justifyContent="SpaceBetween">
                <Calendar
                    onSelectedDatesChange={onDateSelect}
                    primaryCalendarType="Gregorian"
                    selectionMode="Single"
                    format-pattern="yyyy-MM-dd"
                    minDate={options.minDate}
                />
                <FlexBox style={spacing.sapUiSmallMargin} justifyContent="Center" direction="Column">
                    <Label style={spacing.sapUiSmallMarginTopBottom} required={options.dateRequired}>Date</Label>
                    <Input
                        disabled placeholder="Date"
                        value={payload.date}
                        valueState={payload.dateValidation.valueState}
                        valueStateMessage={payload.dateValidation.valueStateMessage}
                    />
                    <Label style={spacing.sapUiSmallMarginTopBottom} required={options.timeRequired}>Time</Label>
                    <DurationPicker
                        onChange={onTimeSelect}
                        valueState={payload.timeValidation.valueState}
                        valueStateMessage={payload.timeValidation.valueStateMessage}
                    />
                    {showEstHours && (
                        <>
                            <Label required={options.estimatedTimeRequired}
                                style={spacing.sapUiSmallMarginTopBottom}>Estimated Hours</Label>
                            <Select
                                onChange={onEstimatedHoursSelect}
                                valueState={payload.estimatedTimeValidation.valueState}
                                valueStateMessage={payload.estimatedTimeValidation.valueStateMessage}
                            >
                                <Option value="-1">Select</Option>
                                <Option>1 hour</Option>
                                <Option>2 hours</Option>
                                <Option>3 hours</Option>
                                <Option>4 hours</Option>
                                <Option>5 hours</Option>
                                <Option>6 hours</Option>
                            </Select>
                            <Label style={spacing.sapUiSmallMarginTopBottom}>Additional Comment</Label>
                            <TextArea name="comment"
                                onChange={onInputChange} />
                        </>
                    )}
                    {!showEstHours && (
                        <>
                            <Label style={spacing.sapUiSmallMarginTopBottom}>Name (Order Responsible)</Label>
                            <Input name="logisticSpocName"
                                onChange={onInputChange} />
                            <Label style={spacing.sapUiSmallMarginTopBottom}>Contact (Order Responsible)</Label>
                            <Input
                                type="number"
                                name="logisticSpocContactNumber"
                                valueState={payload.contactValidation.valueState}
                                valueStateMessage={payload.contactValidation.valueStateMessage}
                                maxlength={PHONE_LENGTH}
                                onChange={onInputChange} />
                        </>
                    )}

                </FlexBox>
            </FlexBox>
        </Dialog>
    );
});

CalendarDialog.propTypes = {
    onCancel: PropTypes.func,
    onSubmit: PropTypes.func,
    headerText: PropTypes.string,
    showEstHours: PropTypes.bool,
    options: PropTypes.object
};

CalendarDialog.defaultProps = {
    showEstHours: true,
    options: {}
};

export default CalendarDialog;
