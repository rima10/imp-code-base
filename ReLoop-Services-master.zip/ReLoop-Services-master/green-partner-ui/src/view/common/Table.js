import React from 'react';
import {
    Label,
    Button,
    Toolbar,
    Input,
    Table,
    TableColumn,
    ToolbarSpacer,
    TableRow,
    TableCell,
    Text,
    Select,
    Option,
    CheckBox,
    TableGrowingMode
} from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from '@ui5/webcomponents-react-base';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport.js';
import { Loader } from '@ui5/webcomponents-react';

const AccountTable = ({ rows = [], columns = [], buttons = [], edit = false, text, isLoading, isBusy, selectedRow,
    lazyLoading, height }) => {
    const getCell = (cell, rowNumber) => {
        switch (cell.type) {
            case 'text':
                return (<Text className="tableCellText" tooltip={cell.value}
                    wrapping={cell.wrapping} style={cell.style}>{cell.value}</Text>);
                break;
            case 'input':
                return (
                    <Input
                        key={cell.name}
                        name={cell.name}
                        onKeyUp={(e) => {
                            e.preventDefault();
                            //space 32 is for the space key pressed
                            if (e.keyCode === 32) { e.target.value += " "; }
                        }}
                        onInput={(e) => {
                            e.preventDefault();
                            cell.onInputChange(e);
                        }}
                    />
                );
                break;
            case 'select':
                return (
                    <Select
                        onChange={(e) => {
                            cell.onInputChange(e);
                        }}
                    >
                        <Option key="-1" id="-1" name="-" value="-">
                            Select Role
                        </Option>
                        {cell.options.map((item) => (
                            <Option
                                key={item.approver_id}
                                id={item.approver_id}
                                name={item.approver_name}
                                value={item.approver_role}
                            >
                                {item.approver_role}
                            </Option>
                        ))}
                    </Select>
                );
            case 'checkbox':
                let checked = selectedRow.includes(rowNumber);
                return (
                    <CheckBox
                        className=""
                        onChange={(e) => {
                            cell.onInputChange(e, rowNumber);
                        }}
                        slot=""
                        style={{ zoom: '0.7' }}
                        tooltip=""
                        disabled={cell.disabled}
                        checked={checked}
                    />
                );
        }
    };
    const getStyleForTable = () => {
        const style = {
            border: "1px solid #888888",
            overflowX: "auto"
        };
        if (height) {
            style.height = height;
        }
        return style;
    };
    const renderFunction = () => {
        return (
            <div style={{ width: "100%" }}>
                <Toolbar
                    className=""
                    slot=""
                    style={{ ...spacing.sapUiLargeMarginTop, fontSize: "1.1rem" }}
                    tooltip=""
                >
                    <Label style={{ fontSize: '1rem', fontWeight: 'bold' }}>{text}</Label>
                    <ToolbarSpacer />
                    <div>
                        {buttons.map((button) => {
                            return (
                                <span key={button.name}>
                                    {(!button.hide && !button.html) &&
                                        <Button
                                            key={button.name}
                                            onClick={button.onClick}
                                            icon={button.icon}
                                            style={{ marginLeft: "10px" }}
                                            disabled={button.disabled}
                                        >
                                            {button.name}
                                        </Button>
                                    }
                                    {(!button.hide && button.html) &&
                                        button.html
                                    }
                                </span>
                            );
                        })}
                    </div>
                </Toolbar>
                {isLoading && <Loader />}
                <Table
                    busy={isBusy}
                    style={getStyleForTable()}
                    showNoData
                    noDataText={'No data available'}
                    stickyColumnHeader={!!height}
                    onLoadMore={lazyLoading}
                    growing={lazyLoading ? TableGrowingMode.Scroll : TableGrowingMode.None}
                    columns={columns.map((column, index) => {
                        return (
                            <TableColumn style={{ width: '5rem', border: "1px" }}>
                                <Label style={{ fontSize: "var(--sapFontSize)" }}>{column}</Label>
                            </TableColumn>
                        );
                    })}
                >
                    {rows.map((row, idx) => (
                        <TableRow key={idx}>
                            {row.map((cell, id) => {
                                return (<TableCell style={{
                                    verticalAlign: 'middle', width: '5rem'
                                }} key={id}> {getCell(cell, idx)}</TableCell>);
                            })}
                        </TableRow>
                    ))}
                </Table>
            </div>
        );
    };
    return renderFunction();
};

export default AccountTable;
