import React, { useEffect } from 'react';
import { Route, Switch, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import PrivateRoute from '../login/PrivateRoute';
import PreviousOrder from './PreviousOrder';
import OrderCreationForm from './OrderCreationForm';
import OrderInfo from './OrderInfo';
import ErrorComponent from '../common/Error';
import { getOrderInfoState } from '../../selectors/common';
import { getOrderInfo } from '../../store/action/order';

const OrderComponent = ({ orderInfo, startGetOrderInfo }) => {
    useEffect(() => {
        startGetOrderInfo();
    }, []);

    return (
        <Switch>
            <PrivateRoute exact path="/order/newOrder" component={OrderCreationForm} />
            <PrivateRoute
                exact
                path="/order/previousOrder"
                component={PreviousOrder}
            />
            <PrivateRoute
                exact
                path="/order/previousOrder/:orderNumber"
                component={OrderInfo}
            />
            <Route
                exact
                path="/404"
                component={() => <ErrorComponent text="Page Not Found" />}
            />
            <Redirect from="/" to="/404" />
        </Switch>
    );
};

const mapStateToProps = (state) => {
    return {
        orderInfo: getOrderInfoState(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetOrderInfo: () => dispatch(getOrderInfo())
    };
};

OrderComponent.propTypes = {
    orderInfo: PropTypes.array,
    startGetOrderInfo: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderComponent);
