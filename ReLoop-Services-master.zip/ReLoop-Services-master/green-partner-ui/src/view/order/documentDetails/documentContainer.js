import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Grid, Title, Text } from '@ui5/webcomponents-react';
import DocumentCard from './documentCard';
import { spacing } from '@ui5/webcomponents-react-base';
import {
    getOrderDocuments,
    downloadDocument,
    uploadDocument,
    generateDCDocument
} from '../../../store/action/order';
import {
    getOrderDocInfoState, getOrderId, getOrderNo, getRpName, getGpName,
    getUserInfo,
    getOrderType
} from '../../../selectors/common';
import LoadingIndicator from '../../common/Loading';


const DocumentContainer = ({ startGetOrderDocumentsInfo, startUploadOrderDocument,
    startDownloadOrderDocument, RpName, GpName,
    startGenerateDCDocument, orderDocInfo, orderId, orderNo, userInfo, orderType }) => {
    // eslint-disable-next-line no-unused-vars
    const [uploadpayload, setUploadPayload] = useState({});
    const [documents, setDocuments] = useState([]);
    const recyclerDocs = [
        'Data Destruction Certificate',
        'Form 2',
        'Form 6',
        'Service Invoice',
        'Recycling Certificate'
    ];
    const [Generatedocuments, setGenerateDocuments] = useState([]);
    const openDialog = (ref) => {
        ref.current.open();
    };

    const onGenerateDC = (payload) => {
        payload.orderNo = orderNo;
        documents.map((document) => {
            if (document.docName === 'Delivery Challan') {
                document.status = 'Created';
                document.date = new Date();
                document.key = 'document';
            }
        });
        startGenerateDCDocument(orderId, payload);
    };


    const onUpload = (payload) => {
        const formdata = new FormData();
        for (const [key, value] of Object.entries(payload)) {
            if (key === 'document') {
                for (var pair of value.entries()) {
                    formdata.append(pair[0], pair[1]);
                }
            }
            formdata.append(`${key}`, `${value}`);
        }
        formdata.append('orderNo', orderNo);
        startUploadOrderDocument(orderId, formdata);
    };

    // eslint-disable-next-line no-unused-vars
    const dialogRef = useRef(null);

    const onDownload = (key) => {
        startDownloadOrderDocument(orderId, key);
    };
    // eslint-disable-next-line no-unused-vars
    const onGenerate = (ref, payload) => {
        if (ref !== null) {
            ref.current.open();
        }
    };


    const formatDocuments = (orderDocs) => {
        const gpDocs = [];
        const rpDocs = [];
        orderDocs.map((orderDoc) => {
            if (orderDoc.docName === 'other') {
                orderDoc.order_docs.map(otherDoc => {
                    const otherDocument = {
                        title: otherDoc.documentText,
                        status: 'Created',
                        date: otherDoc.lastModifiedDate,
                        key: otherDoc.storageKey,
                        type: 'other',
                        createdBy: otherDoc.createdBy?.bpUserName,
                        openDialog: openDialog,
                        onDownload: onDownload
                    };
                    if (otherDocument.createdBy === userInfo.bp_username) {
                        gpDocs.push(otherDocument);
                    } else rpDocs.push(otherDocument);
                });
            } else {
                const doc = {};
                doc.title = orderDoc.docName;
                if (orderDoc.order_docs && orderDoc.order_docs.length) {
                    doc.status = 'Created';
                    doc.date = orderDoc.order_docs[0].lastModifiedDate;
                    doc.key = orderDoc.order_docs[0].storageKey;
                    doc.createdBy = orderDoc.order_docs[0].createdBy?.bpUserName;
                } else {
                    doc.status = 'Pending';
                    doc.date = null;
                }
                doc.onGenerate = openDialog;
                doc.openDialog = openDialog;
                doc.onDownload = onDownload;
                if (recyclerDocs.includes(orderDoc.docName)) {
                    rpDocs.push(doc);
                } else gpDocs.push(doc);
            }
        });
        setDocuments(rpDocs);
        setGenerateDocuments(gpDocs);
    };
    useEffect(() => {
        startGetOrderDocumentsInfo(orderId);
    }, []);
    useEffect(() => {
        formatDocuments(orderDocInfo.orderDocuments);
    }, [JSON.stringify(orderDocInfo.orderDocuments)]);


    if (orderDocInfo.isLoading) {
        return (<LoadingIndicator />);
    } else {
        return (<>
            <Title level="H3" style={{ ...spacing.sapUiMediumMarginTopBottom }}>
                From {GpName}
            </Title>
            <Text>
                Here you can upload, generate and store the files of the following documents.

            </Text>
            <Grid style={{ marginTop: '20px' }}>
                {Generatedocuments?.map((document, index) => {
                    const { title, status, date, onDownload, onGenerate, openDialog, key, createdBy, type } = document;
                    if (((title !== 'Asset Grading' && title !== 'Delivery Challan') || orderType === '1')) {
                        return (
                            <DocumentCard
                                key={"gpdoc_" + index}
                                title={title}
                                status={status}
                                date={date}
                                createdBy={createdBy}
                                onDownload={onDownload}
                                onUpload={onUpload}
                                openDialog={openDialog}
                                onGenerate={onGenerate}
                                docKey={key}
                                noUpload = {title === 'Asset Grading' || title === 'Asset List'}
                                onGenerateDC={onGenerateDC}
                                type={type}
                            />
                        );
                    }
                })}

                <DocumentCard
                    key={`addDoc`}
                    title="Add Document"
                    openUploadDialog={onUpload}
                    openDialog={openDialog}
                    onUpload={onUpload}
                    newDoc
                />
            </Grid>
            <Title level="H3" style={{ ...spacing.sapUiMediumMarginTopBottom }}>
                From {RpName ? RpName : "Recycler"}
            </Title>
            <Text>
                These are the documents your recycling customer provided for you. You can review and download them.
            </Text>
            <Grid style={{ marginTop: '20px' }}>
                {documents?.map((document, index) => {
                    const { title, status, date, onDownload, onGenerate, openDialog, key, createdBy } = document;
                    return (
                        <DocumentCard
                            key={"rpdoc_" + index}
                            title={title}
                            status={status}
                            date={date}
                            createdBy={createdBy}
                            openDialog={openDialog}
                            onDownload={onDownload}
                            onGenerate={onGenerate}
                            onUpload={onUpload}
                            docKey={key}
                            noUpload = {title === 'Asset Grading'}
                            onGenerateDC={onGenerateDC}
                        />
                    );
                })}
            </Grid>
        </>
        );
    }
};
const mapStateToProps = (state) => {
    return {
        orderDocInfo: getOrderDocInfoState(state),
        orderId: getOrderId(state),
        orderNo: getOrderNo(state),
        RpName: getRpName(state),
        GpName: getGpName(state),
        userInfo: getUserInfo(state),
        orderType: getOrderType(state)
    };
};

DocumentContainer.propTypes = {
    orderHeaderData: PropTypes.object,
    orderId: PropTypes.string,
    startGetOrderDocumentsInfo: PropTypes.func,
    startUploadOrderDocument: PropTypes.func,
    startGenerateDCDocument: PropTypes.func,
    orderDocInfo: PropTypes.object,
    orderNo: PropTypes.string,
    startDownloadOrderDocument: PropTypes.func,
    orderType: PropTypes.string
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetOrderDocumentsInfo: (orderId) => dispatch(getOrderDocuments(orderId)),
        startDownloadOrderDocument: (orderId, key) => dispatch(downloadDocument(orderId, key)),
        startUploadOrderDocument: (orderId, payload) => dispatch(uploadDocument(orderId, payload)),
        startGenerateDCDocument: (orderId, payload) => dispatch(generateDCDocument(orderId, payload))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(DocumentContainer);
