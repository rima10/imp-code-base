import React, { useState } from 'react';
import PropTypes from 'prop-types';
import {
    Form, Button, FormItem, Dialog, Label, FileUploader, Input
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';


const UploadDocDialog = React.forwardRef(({ onCancel, headerText, onSubmit, onDocUpload, newDoc, type }, ref) => {
    const [uploadpayload, setUploadPayload] = useState();
    const onFileSelect = (event) => {
        const fileform = new FormData();
        fileform.append(event.target.name, event.target.files[0]);
        const updatedPayload = { ...uploadpayload };
        updatedPayload[event.target.name] = fileform;
        if (!newDoc && type !== 'other') updatedPayload.documentName = headerText;
        else if (type === 'other') {
            updatedPayload.documentName = 'other';
            updatedPayload.documentText = headerText;
        }
        setUploadPayload(updatedPayload);
    };
    const uploadToS3 = () => {
        onDocUpload(uploadpayload);
    };
    const onInputChange = (event) => {
        const { value } = event.target;
        const payload = { ...uploadpayload };
        payload.documentName = 'other';
        payload.documentText = value;
        setUploadPayload(payload);
    };

    return (<Dialog
        className=""
        ref={ref}
        footer={<div style={spacing.sapUiSmallMargin}>
            <Button style={spacing.sapUiTinyMargin} onClick={onCancel}>Close</Button>
            <Button style={spacing.sapUiTinyMargin} onClick={uploadToS3}>Upload</Button></div>}
        headerText={headerText}
        style={{ width: "20%" }}
    >
        <div style={{ display: "flex", justifyContent: "center" }}>
            <Form >
                {newDoc ? <FormItem label={<Label >Document Name</Label>}>
                    <Input name="document" onChange={onInputChange} />
                </FormItem> : <FormItem label={<Label required>{'Document Type: ' + headerText}</Label>}/>}
                <FormItem label={<Label >Document</Label>}>
                    <FileUploader name="document" onChange={onFileSelect} >
                        <Button design="emphasized" icon="upload" />
                    </FileUploader>
                </FormItem>
            </Form>
        </div>
    </Dialog>);
});

UploadDocDialog.propTypes = {
    onCancel: PropTypes.func,
    onSubmit: PropTypes.func,
    onUpload: PropTypes.func,
    headerText: PropTypes.string,
    onSelectDocChange: PropTypes.func,
    onFileSelect: PropTypes.func,
    onDocUpload: PropTypes.func,
    newDoc: PropTypes.bool,
    type: PropTypes.string
};

export default UploadDocDialog;
