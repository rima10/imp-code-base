import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

import {
    Panel, List, CustomListItem, Label, FlexBox, Text, Bar, Icon
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import { useHistory } from 'react-router-dom';
import { getOrderInfo } from '../../store/action/order';
import { getOrderInfoState, isOrderInfoLoading } from '../../selectors/common';
import LoadingIndicator from '../common/Loading';

const PreviousOrder = ({ isLoading, orderInfo, startGetOrderInfo }) => {
    useEffect(() => {
        startGetOrderInfo();
    }, []);

    let history = useHistory();

    const onSelectionChange = (orderNumber) => {
        history.push({
            pathname: `/order/previousOrder/${orderNumber}`
        });
    };

    const getDataWithSpecificStatus = (status) => {
        return orderInfo.filter((order) => order.orderPosition === status);
    };

    const getStyleForOrderPosition = (orderPosition) => {
        const colorMap = {
            'Draft': '#0A6EDA',
            'In Progress': '#EC890C',
            'Completed': '#107e3e',
            'Cancelled': '#DC143C'
        };
        return {
            color: colorMap[orderPosition]
        };
    };
    const orderTypeFontColor = {
        1: '#0065c5',
        2: '#107e3e'
    };

    const uniqueStatus = [...new Set(orderInfo.map((order) => order.orderPosition))];

    return (
        <>
            {isLoading && <LoadingIndicator/>}
            <Label style={{ fontSize: '1.3rem', fontWeight: 'Bold', marginBottom: '20px' }}>Previous Orders</Label>
            {uniqueStatus.map((status, index) => {
                let data = getDataWithSpecificStatus(status);
                return (
                    <Panel headerText={`${status} Orders (${data.length})`} key={index}>
                        <List
                            busy={isLoading}
                            noDataText="No Previous Orders"
                            mode="SingleSelect"
                            separators="All"
                            growing="Scroll"
                            onSelectionChange={(e) =>
                                onSelectionChange(e.detail.selectedItems[0].dataset.id)
                            }
                        >
                            {data.map((order, idx) => (
                                <CustomListItem
                                    data-id={order.orderNumber}
                                    key={idx}
                                    style={{
                                        height: '5rem'
                                    }}>
                                    <Bar
                                        className="active-hover"
                                        style={{
                                            height: '5rem'
                                        }}
                                        endContent={
                                            <div>
                                                <br />
                                                <span style={getStyleForOrderPosition(order.orderPosition)}>
                                                    {order.orderPosition}
                                                </span>
                                            </div>
                                        }
                                        startContent={
                                            <FlexBox>
                                                <Icon
                                                    name="order-status"
                                                    tooltip="Order"
                                                />
                                                <div style={spacing.sapUiTinyMarginBeginEnd}>
                                                    <div>
                                                        <Text>{order.orderNumber}</Text>
                                                        <div style={spacing.sapUiTinyMarginTop}>
                                                            <span>
                                                                <strong style={{
                                                                    color: orderTypeFontColor[order.orderType]
                                                                }}>
                                                                    {order.orderProcessType.processTypeName}
                                                                </strong>
                                                                &nbsp;|&nbsp;   {order.orderNetwork} Network
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </FlexBox>
                                        }
                                    />
                                </CustomListItem>
                            ))}
                        </List>
                    </Panel>
                );
            })}
        </>
    );
};

const mapStateToProps = (state) => {
    return {
        orderInfo: getOrderInfoState(state),
        isLoading: isOrderInfoLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetOrderInfo: () => dispatch(getOrderInfo())
    };
};


PreviousOrder.propTypes = {
    orderInfo: PropTypes.array,
    isLoading: PropTypes.bool,
    startGetOrderInfo: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(PreviousOrder);
