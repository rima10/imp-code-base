import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from "react-redux";
import {
    Form, FormGroup, FormItem, Select, Option, Toolbar, Label, ToolbarSpacer, Button, Input,
    MultiComboBox, MultiComboBoxItem, DateTimePicker, TextArea, FileUploader, Icon, Link
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import moment from 'moment';
import {
    getOrderType, getCategory, getSubCategory,
    getBusinessInfo, getNetworkInfo, getPrivateNetworkOwner
} from '../../store/action/taskAction';
import { downloadDocument } from '../../store/action/order';

const OrderHeaderFormEdit = ({
    orderId,
    startGetBusinessInfo, startGetOrderType, startGetCategory, startGetSubCategory, startGetPrivateNetworkRecyclers,
    startDownloadPicture,
    businessInfo, orderTypes, categories, subcategories, privateNetworkRecyclers,
    isPartOfPvtNwk, networkRecycler, startGetPrivateNetworkOwner,
    onSubmit, formFields, orderPayloadParent, setFormFieldsState
}) => {
    useEffect(() => {
        startGetBusinessInfo();
        startGetOrderType();
        startGetCategory();
        startGetSubCategory();
    }, []);
    useEffect(() => {
        if (isPartOfPvtNwk) {
            startGetPrivateNetworkOwner();
        } else {
            startGetPrivateNetworkRecyclers();
        }
    }, [isPartOfPvtNwk]);
    const defaultState = {
        orderType: '',
        category: '1',
        subcategory: '1',
        network: 'Private',
        recyclerIds: [],
        recycleAssetType: 'Non-Fixed',
        picture: {
            name: ''
        },
        additionalInfo: '',
        submissionDeadline: '',
        orderLocation: businessInfo?.location?.city
    };
    // orderPayloadParent should not be cloned, as it contains parent state as props
    const [orderPayload, setOrderPayload] = useState({ ...defaultState, ...orderPayloadParent });

    // VIP, incase local orderPayload needs to be in sync with parent props
    useEffect(() => {
        if (orderPayloadParent) {
            setOrderPayload(orderPayloadParent);
        }
    }, [orderPayloadParent]);

    const onInputChangeLocal = (event, fieldName, value) => {
        let orderPayloadCopy = { ...orderPayload };
        orderPayloadCopy[fieldName] = value;
        if (fieldName === 'orderType') {
            orderPayloadCopy = { ...defaultState, ...orderPayloadCopy };
            orderPayloadCopy["recyclerIds"] = [];
            privateNetworkRecyclers.forEach((item) => {
                orderPayloadCopy["recyclerIds"].push(item.nwk_member);
            });
            // reset form validations
            Object.keys(formFields).forEach((field) => {
                formFields[field].valueState = 'None';
            });
            setFormFieldsState(formFields);
        }
        setOrderPayload(orderPayloadCopy);
        if (value) {
            formFields[fieldName].valueState = 'None';
            setFormFieldsState(formFields);
        }
        if (formFields && formFields[fieldName] && formFields[fieldName].onInputChange) {
            formFields[fieldName].onInputChange(event, fieldName, value, orderPayloadCopy);
        }
    };
    const assetTypes = [{
        id: 0,
        value: 'Fixed',
        heading: 'Fixed'
    }, {
        id: 1,
        value: 'Non-Fixed',
        heading: 'Non-Fixed'
    }];

    const downloadPicture = (e) => {
        startDownloadPicture(orderId, orderPayload.picture.location);
    };

    const removeCurrentPicture = (e) => {
        let orderPayloadCopy = { ...orderPayload };
        orderPayloadCopy.picture.location = '';
        setOrderPayload(orderPayloadCopy);
    };

    return (
        <div style={spacing.sapUiMediumMarginTop}>
            {
                onSubmit &&
                <Toolbar style={spacing.sapUiTinyMargin}
                >
                    <Label style={{ fontSize: '1rem', fontWeight: 'bold' }}>
                        Order Details
                    </Label>
                    <ToolbarSpacer />
                    <Button onClick={(e) => { onSubmit(orderPayload); }}>
                        Save
                    </Button>
                </Toolbar>
            }

            <Form columnsL={2}
                columnsM={2}
                columnsS={2}
                labelSpanM={5}

                style={spacing.sapUiLargeMarginBottom}>
                <FormGroup>
                    <FormItem label={<Label required>This request is for</Label>}>
                        <Select style={spacing.sapUiTinyMargin} name="orderType"
                            onChange={(e) => {
                                onInputChangeLocal(e, e.target.name, e.detail.selectedOption.dataset.id);
                            }}>
                            {orderTypes.map((item) => (
                                <Option key={item.processTypeId}
                                    data-id={item.processTypeId}
                                    selected={orderPayload.orderType === item.processTypeId}>
                                    {item.processTypeName}
                                </Option>))}
                        </Select>
                    </FormItem>
                    <FormItem label={<Label required>Category</Label>}>
                        <Select style={spacing.sapUiTinyMargin} name="category"
                            onChange={(e) => {
                                onInputChangeLocal(e, e.target.name, e.detail.selectedOption.dataset.id);
                            }}>
                            {categories.map((item) => (
                                <Option selected={item.categoryId === orderPayload.category}
                                    key={item.categoryId}
                                    disabled={item.categoryId !== '1'}
                                    data-id={item.categoryId}>
                                    {item.categoryName}
                                </Option>))}
                        </Select>
                    </FormItem>
                    <FormItem label={<Label required>Subcategory</Label>}>
                        <Select style={spacing.sapUiTinyMargin} name="subcategory"
                            onChange={(e) => {
                                onInputChangeLocal(e, e.target.name, e.detail.selectedOption.dataset.id);
                            }}>
                            {subcategories.map((item) => (
                                <Option selected={item.subcategoryId === orderPayload.subcategory}
                                    key={item.subcategoryId}
                                    disabled={item.subcategoryId !== '1'}
                                    data-id={item.subcategoryId}>
                                    {item.subcategoryName}
                                </Option>))}
                        </Select>
                    </FormItem>
                    {orderPayload.orderType === "2" &&
                        <FormItem label={<Label required>Asset Type</Label>}>
                            <Select style={spacing.sapUiTinyMargin}
                                name="recycleAssetType"
                                onChange={(e) => {
                                    onInputChangeLocal(e, e.target.name, e.detail.selectedOption.dataset.id);
                                }}>
                                {assetTypes.map((item) => (
                                    <Option
                                        key={item.id}
                                        data-id={item.value}
                                        selected={item.value === orderPayload.recycleAssetType}
                                    >
                                        {item.heading}
                                    </Option>))}
                            </Select>
                        </FormItem>}
                    {orderPayload.orderType === "1" && businessInfo.location &&
                        <FormItem label="City" required>
                            <Select style={spacing.sapUiTinyMargin} name="orderLocCity"
                                onChange={(e) => {
                                    onInputChangeLocal(e, e.target.name, e.detail.selectedOption.dataset.id);
                                }} disabled>
                                <Option selected data-id={businessInfo.location.city}>
                                    {businessInfo.location !== undefined ? businessInfo.location.city : ''}
                                </Option>
                            </Select>
                        </FormItem>}
                    <FormItem label="Company Code">
                        <Input style={spacing.sapUiTinyMargin} name="companyCode" readonly
                            value={businessInfo.companyCode}>
                            {businessInfo.companyCode}
                        </Input>
                    </FormItem>
                    {orderPayload.orderType === "2" &&
                        <FormItem label="Total Weight" required>
                            <Input style={spacing.sapUiTinyMargin} placeholder="Enter weight in kgs"
                                name="totalWeight"
                                value={orderPayload.totalWeight || ''}
                                onInput={(e) => {
                                    onInputChangeLocal(e, e.target.name, e.target.attributes.value.value);
                                }} />
                        </FormItem>}
                </FormGroup>
                <FormGroup>
                    <FormItem label={<Label required>Network</Label>}>
                        <Select disabled style={spacing.sapUiTinyMargin} name="network"
                            onChange={(e) => {
                                onInputChangeLocal(e, e.target.name, e.detail.selectedOption.dataset.id);
                            }}>
                            <Option selected value="Private" data-id="Private">
                                Private
                            </Option>
                            <Option value="Public" data-id="Public" disabled>
                                Public
                            </Option>
                        </Select>
                    </FormItem>
                    <FormItem label={<Label required>Available Recyclers</Label>}>
                        {!isPartOfPvtNwk ? (
                            <MultiComboBox
                                style={{ ...spacing.sapUiTinyMargin, width: '65%' }}
                                name="recyclerIds"
                                valueState={formFields.recyclerIds.valueState}
                                valueStateMessage={formFields.recyclerIds.valueStateMessage}
                                onSelectionChange={(e) => {
                                    let ids = [];
                                    if (e.detail.items && e.detail.items.length) {
                                        e.detail.items.forEach((selectedItem) => {
                                            ids.push(selectedItem.attributes.value.value);
                                        });
                                    }
                                    onInputChangeLocal(e, "recyclerIds", ids);
                                }}
                                tooltip="Available Recyclers"
                            >
                                {privateNetworkRecyclers.map((item) => (
                                    <MultiComboBoxItem
                                        text={item.nwk_member_business_partner.bp_username}
                                        key={item.nwk_member}
                                        value={item.nwk_member}
                                        selected={orderPayload.recyclerIds.includes(item.nwk_member)}
                                    />))}
                            </MultiComboBox>
                        ) : (
                            <Input value={networkRecycler?.nwkOwnerName} disabled style={spacing.sapUiTinyMargin} />
                        )}

                    </FormItem>
                    <FormItem label={<Label required wrap>Quote Submission Deadline</Label>}>
                        <DateTimePicker
                            name="submissionDeadline"
                            placeholder="d-mmm-yy, h:mm:ss a"
                            style={{ ...spacing.sapUiTinyMargin, width: '65%' }}
                            minDate={moment(new Date()).format("MMM D, y, h:mm:ss a")}
                            value={orderPayload.submissionDeadline}
                            valueState={formFields.submissionDeadline.valueState}
                            valueStateMessage={formFields.submissionDeadline.valueStateMessage}
                            onChange={(e) => {
                                onInputChangeLocal(e, e.target.name, e.target.value);
                            }}
                        />
                    </FormItem>
                    <FormItem label={<Label >Additional Information</Label>}>
                        <TextArea
                            rows={3}
                            style={{
                                width: '210px',
                                margin: '0.5rem'
                            }}
                            name="additionalInfo"
                            value={orderPayload.additionalInfo || ''}
                            onInput={(e) => {
                                onInputChangeLocal(e, e.target.name, e.target.attributes.value.value);
                            }}
                        />
                    </FormItem>
                    <FormItem label={<Label >Picture</Label>}>
                        {
                            orderPayload.picture.location &&
                            <span>
                                <Link target="_blank" onClick={downloadPicture}>
                                    {orderPayload.picture.location}
                                </Link>
                                <Icon style={spacing.sapUiTinyMarginBeginEnd} className="pointer"
                                    name="decline" onClick={removeCurrentPicture} />
                            </span>
                        }
                        {
                            !orderPayload.picture.location &&
                            <FileUploader style={spacing.sapUiTinyMargin} name="picture"
                                value={orderPayload.picture.name || ''}
                                onChange={(e) => {
                                    onInputChangeLocal(e, e.target.name, e.target.files[0]);
                                }}>
                                <Button design="emphasized" icon="upload" />
                            </FileUploader>
                        }
                    </FormItem>
                    {orderPayload.orderType === "2" && businessInfo.location && <FormItem label="City" required>
                        <Select style={spacing.sapUiTinyMargin}
                            name="orderLocCity"
                            onChange={(e) => {
                                onInputChangeLocal(e, e.target.name, e.detail.selectedOption.dataset.id);
                            }} disabled>
                            <Option selected data-id={businessInfo.location.city}>
                                {businessInfo.location !== undefined ? businessInfo.location.city : ''}
                            </Option>
                        </Select>
                    </FormItem>}
                </FormGroup>
            </Form >
        </div >
    );
};

const mapStateToProps = state => {
    return {
        businessInfo: state.account.businessInfo,
        orderTypes: state.order.orderType,
        categories: state.order.category,
        subcategories: state.order.subcategory,
        privateNetworkRecyclers: state.account.networkInfo,
        isPartOfPvtNwk: state.userInfo.isPartOfPvtNwk,
        networkRecycler: state.order.privateNetworkOwner
    };
};

OrderHeaderFormEdit.propTypes = {
    orderId: PropTypes.string,
    orderPayloadParent: PropTypes.object,
    businessInfo: PropTypes.object,
    onSubmit: PropTypes.func,
    formFields: PropTypes.object,
    orderTypes: PropTypes.array,
    categories: PropTypes.array,
    subcategories: PropTypes.array,
    privateNetworkRecyclers: PropTypes.array,
    startGetCategory: PropTypes.func,
    startGetOrderType: PropTypes.func,
    startGetSubCategory: PropTypes.func,
    startGetBusinessInfo: PropTypes.func,
    startGetPrivateNetworkRecyclers: PropTypes.func,
    isPartOfPvtNwk: PropTypes.bool,
    networkRecycler: PropTypes.object,
    startGetPrivateNetworkOwner: PropTypes.func,
    setFormFieldsState: PropTypes.func,
    startDownloadPicture: PropTypes.func
};

OrderHeaderFormEdit.defaultProps = {
    orderPayloadParent: undefined,
    businessInfo: {},
    orderTypes: [],
    categories: [],
    subcategories: [],
    privateNetworkRecyclers: []
};


const mapDispatchToProps = dispatch => {
    return {
        startGetOrderType: () => dispatch(getOrderType()),
        startGetCategory: () => dispatch(getCategory()),
        startGetSubCategory: () => dispatch(getSubCategory()),
        startGetBusinessInfo: () => dispatch(getBusinessInfo()),
        startGetPrivateNetworkRecyclers: () => dispatch(getNetworkInfo()),
        startGetPrivateNetworkOwner: () => dispatch(getPrivateNetworkOwner()),
        startDownloadPicture: (orderId, key) => dispatch(downloadDocument(orderId, key))
    };
};
export default connect(mapStateToProps, mapDispatchToProps)(OrderHeaderFormEdit);
