import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import {
    Form,
    FormGroup,
    FormItem,
    Text,
    Button,
    Toolbar,
    ToolbarSpacer
} from '@ui5/webcomponents-react';
import AccountTable from '../../common/Table';
import { spacing } from '@ui5/webcomponents-react-base';
import { useHistory } from 'react-router-dom';
import { showMessage } from '../../../store/action/type';
import { cancelOrder } from '../../../store/action/order';
import { connect } from 'react-redux';
import LoadingIndicator from '../../common/Loading';

const QuoteSubmission = ({
    consolidatedOrderItemInfo,
    onNextStep,
    currentSequence,
    startShowMessage,
    startCancelOrder
}) => {
    const [assetRows, setAssetRows] = useState([]);
    const [showLoader, setShowLoader] = useState(false);

    const history = useHistory();

    const onSubmit = () => {
        startShowMessage({
            // eslint-disable-next-line max-len
            message: `Your order ${consolidatedOrderItemInfo.orderNumber} has been successfully submitted to your ${consolidatedOrderItemInfo.orderNetwork} network`,
            status: 'Positive'
        });
        onNextStep(2, false);
        history.push('/order/previousOrder');
    };

    const assetColumns = ['Item Type', 'Make', 'Model', 'Count'];

    const getOrderItemDetails = (consolidatedOrderItemInfo) => {
        const newRows = [];
        consolidatedOrderItemInfo.map((index) => {
            const row = [];
            row.push({ name: assetColumns[0], value: index.itemType, type: 'text' });
            row.push({ name: assetColumns[1], value: index.make, type: 'text' });
            row.push({ name: assetColumns[2], value: index.model, type: 'text' });
            row.push({ name: assetColumns[3], value: index.count, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };

    useEffect(() => {
        if (consolidatedOrderItemInfo.orderItems) {
            const assetRows = getOrderItemDetails(consolidatedOrderItemInfo.orderItems);
            setAssetRows(assetRows);
        }
    }, [consolidatedOrderItemInfo.orderItems]);

    const onCancelOrder = () => {
        setShowLoader(true);
        const { orderId, orderNumber } = consolidatedOrderItemInfo;
        startCancelOrder(orderId)
            .then((response) => {
                setShowLoader(false);
                startShowMessage({
                    message: `Your Order ${orderNumber} has been cancelled.`,
                    status: 'Positive'
                });
                history.push('/order/previousOrder');
            })
            .catch((err) => {
                setShowLoader(false);
            });
    };

    return (
        <div style={{ height: '100%', margin: '10px' }}>
            {showLoader && <LoadingIndicator />}
            <Form
                columnsL={2}
                columnsM={2}
                columnsS={2}
                labelSpanM={5}
                style={spacing.sapUiLargeMarginBottom}
            >
                <FormGroup>
                    <FormItem label="Order Type">
                        <Text style={spacing.sapUiTinyMargin}>
                            {consolidatedOrderItemInfo.processType}
                        </Text>
                    </FormItem>
                    <FormItem label="Category">
                        <Text style={spacing.sapUiTinyMargin}>
                            {consolidatedOrderItemInfo.categoryName}
                        </Text>
                    </FormItem>
                    <FormItem label="Subcategory">
                        <Text style={spacing.sapUiTinyMargin}>
                            {consolidatedOrderItemInfo.subCategoryName}
                        </Text>
                    </FormItem>
                    <FormItem label="Network">
                        <Text style={spacing.sapUiTinyMargin}>{consolidatedOrderItemInfo.orderNetwork} Network</Text>
                    </FormItem>
                </FormGroup>
                <FormGroup>
                    <FormItem label="Quote Submission Deadline">
                        <Text style={spacing.sapUiTinyMargin}>
                            {new Date(consolidatedOrderItemInfo.submissionDeadline).toDateString()}
                        </Text>
                    </FormItem>
                    <FormItem label="Additional information">
                        <Text style={spacing.sapUiTinyMargin}>
                            {consolidatedOrderItemInfo.orderAdditionalInfo}
                        </Text>
                    </FormItem>
                </FormGroup>
            </Form>
            <AccountTable
                columns={assetColumns}
                edit={false}
                text="Consolidated Asset List"
                rows={assetRows}
            />
            {
                consolidatedOrderItemInfo.orderPosition !== 'Cancelled' &&
                <Toolbar toolbarStyle="Clear">
                    <ToolbarSpacer />
                    {
                        (Number(currentSequence) <= 2) &&
                        <Button onClick={onCancelOrder}>
                            Cancel Order
                        </Button>
                    }
                    <Button design="Emphasized" disabled={Number(currentSequence) > 2} onClick={() => onSubmit()}>
                        Submit Order
                    </Button>
                </Toolbar>
            }
        </div>
    );
};

const mapStateToProps = (state) => {
    return {};
};

const mapDispatchToProps = (dispatch) => {
    return {
        startShowMessage: (payload) => dispatch(showMessage(payload)),
        startCancelOrder: (orderId) => dispatch(cancelOrder(orderId))
    };
};

QuoteSubmission.propTypes = {
    consolidatedOrderItemInfo: PropTypes.object,
    currentSequence: PropTypes.string,
    onNextStep: PropTypes.func,
    startShowMessage: PropTypes.func,
    startCancelOrder: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(QuoteSubmission);
