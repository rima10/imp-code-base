import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import {
    Form,
    FormGroup,
    FormItem,
    Text,
    Button,
    Toolbar,
    ToolbarSpacer,
    Token
} from '@ui5/webcomponents-react';
import AccountTable from '../../common/Table';
import { spacing } from '@ui5/webcomponents-react-base';
import { useHistory } from 'react-router-dom';
import { showMessage } from '../../../store/action/type';
import { cancelOrder } from '../../../store/action/order';
import { connect } from 'react-redux';
import LoadingIndicator from '../../common/Loading';

const RecycleQuoteSubmission = ({
    onNextStep,
    orderItemInfo,
    currentSequence,
    startShowMessage,
    startCancelOrder
}) => {
    const [assetRows, setAssetRows] = useState([]);
    const [showLoader, setShowLoader] = useState(false);

    const history = useHistory();

    const onSubmit = () => {
        startShowMessage({
            // eslint-disable-next-line max-len
            message: `Your order ${orderItemInfo.orderNumber} has been successfully submitted to your ${orderItemInfo.orderNetwork} network`,
            status: 'Positive'
        });
        onNextStep(2, false);
        history.push('/order/previousOrder');
    };

    const assetColumns = [
        'Item',
        'Quantity',
        'Unit',
        'Location',
        'Remarks'
    ];
    const getOrderItemDetails = (orderItemInfo) => {
        const newRows = [];
        orderItemInfo.map((index) => {
            const row = [];
            row.push({ name: assetColumns[0], value: index.model, type: 'text' });
            row.push({ name: assetColumns[1], value: index.itemQuantity || '-', type: 'text' });
            row.push({ name: assetColumns[3], value: index.recycleItemUnit || '-', type: 'text' });
            row.push({ name: assetColumns[2], value: index.buildingLocation, type: 'text' });
            row.push({ name: assetColumns[4], value: index.description, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };

    useEffect(() => {
        if (orderItemInfo.orderItems) {
            let rows = getOrderItemDetails(orderItemInfo.orderItems);
            setAssetRows(rows);
        }
    }, [orderItemInfo.orderItems]);

    const onCancelOrder = () => {
        setShowLoader(true);
        const { orderId, orderNumber } = orderItemInfo;
        startCancelOrder(orderId)
            .then((response) => {
                setShowLoader(false);
                startShowMessage({
                    message: `Your Order ${orderNumber} has been cancelled.`,
                    status: 'Positive'
                });
                history.push('/order/previousOrder');
            })
            .catch((err) => {
                setShowLoader(false);
            });
    };

    return (
        <div style={{ height: '100%', margin: '10px' }}>
            {showLoader && <LoadingIndicator />}
            <Form
                columnsL={2}
                columnsM={2}
                columnsS={2}
                labelSpanM={5}
                style={spacing.sapUiLargeMarginBottom}
            >
                <FormGroup>
                    <FormItem label="Order Type">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.processType}</Text>
                    </FormItem>
                    <FormItem label="Category">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.categoryName}</Text>
                    </FormItem>
                    <FormItem label="Subcategory">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.subCategoryName}</Text>
                    </FormItem>
                    <FormItem label="Asset Type ">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.recycleAssetType || '-'}</Text>
                    </FormItem>
                    <FormItem label="Total Weight ">
                        <Text style={spacing.sapUiTinyMargin}> {orderItemInfo.totalWeight ?
                            `${orderItemInfo.totalWeight} KG` : '-'}</Text>
                    </FormItem>
                </FormGroup>
                <FormGroup>
                    <FormItem label="Network">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.orderNetwork} Network</Text>
                    </FormItem>
                    <FormItem label="Recyclers">
                        <Text style={spacing.sapUiTinyMargin} >
                            {orderItemInfo.recyclers.map((item) => {
                                return <Token style={spacing.sapUiTinyMargin} readonly text={item.bpUsername} />;
                            })}
                        </Text>
                    </FormItem>
                    <FormItem label="Quote Submission Deadline">
                        <Text style={spacing.sapUiTinyMargin}>
                            {new Date(orderItemInfo.submissionDeadline).toDateString()}
                        </Text>
                    </FormItem>
                    <FormItem label="Additional information">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.orderAdditionalInfo}</Text>
                    </FormItem>
                </FormGroup>
            </Form>
            <AccountTable
                columns={assetColumns}
                edit={false}
                text="Asset List"
                rows={assetRows}
            />
            {
                orderItemInfo.orderPosition !== 'Cancelled' &&
                <Toolbar toolbarStyle="Clear">
                    <ToolbarSpacer />
                    {
                        (Number(currentSequence) <= 2) &&
                        <Button onClick={onCancelOrder}>
                            Cancel Order
                        </Button>
                    }
                    <Button design="Emphasized" disabled={Number(currentSequence) > 2} onClick={() => onSubmit()}>
                        Submit Order
                    </Button>
                </Toolbar>
            }
        </div>
    );
};

const mapStateToProps = (state) => {
    return {};
};

const mapDispatchToProps = (dispatch) => {
    return {
        startShowMessage: (payload) => dispatch(showMessage(payload)),
        startCancelOrder: (orderId) => dispatch(cancelOrder(orderId))
    };
};

RecycleQuoteSubmission.propTypes = {
    orderItemInfo: PropTypes.object,
    currentSequence: PropTypes.string,
    onNextStep: PropTypes.func,
    startShowMessage: PropTypes.func,
    startCancelOrder: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(RecycleQuoteSubmission);
