import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { Button, Toolbar, ToolbarSpacer, FileUploader } from '@ui5/webcomponents-react';
import AccountTable from '../../common/Table';
import { connect } from 'react-redux';
import { createOrderWorkflow, cancelOrder, updateAssetListFromExcel } from '../../../store/action/order';
import { showMessage } from '../../../store/action/type';
import LoadingIndicator from '../../common/Loading';
import { useHistory } from 'react-router-dom';
import CommentDialog from '../../common/Dialog';
import OrderHeaderView from './OrderHeaderDetailsView';

const RecycleOrderCreation = ({
    orderItemInfo, onNextStep,
    startCreateOrderWorkflow, startCancelOrder, startShowMessage, startUpdateAssetListFromExcel }) => {
    const [assetRows, setAssetRows] = useState([]);
    const [approverRows, setApproverRows] = useState([]);
    const [showLoader, setShowLoader] = useState(false);
    const [orderEditAllowed, setOrderEditAllowed] = useState(false);
    const history = useHistory();
    const dialogRef = useRef(null);
    const processStageSequence = '1';
    const assetColumns = [
        'Item',
        'Quantity',
        'Unit',
        'Location',
        'Remarks'
    ];

    const approverColumns = ['Approver Sequence', 'Approver Name', 'Approver Role', 'Status', 'Comments'];

    const sendForApproval = (event) => {
        let payload = {
            orderId: orderItemInfo.orderId,
            processStageSequence: processStageSequence,
            processType: orderItemInfo.orderType
        };
        if (event.comments) { // comes from the comment dialog box
            payload.commentsForApprover = event.comments;
        }
        startCreateOrderWorkflow(payload);
        dialogRef.current.close();
    };

    const getOrderItemDetails = (orderItemInfo) => {
        const newRows = [];
        orderItemInfo.map((index) => {
            const row = [];
            row.push({ name: assetColumns[0], value: index.model, type: 'text' });
            row.push({ name: assetColumns[1], value: index.itemQuantity || '-', type: 'text' });
            row.push({ name: assetColumns[3], value: index.recycleItemUnit || '-', type: 'text' });
            row.push({ name: assetColumns[2], value: index.buildingLocation, type: 'text' });
            row.push({ name: assetColumns[4], value: index.description, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };

    useEffect(() => {
        if (orderItemInfo.orderItems) {
            let rows = getOrderItemDetails(orderItemInfo.orderItems);
            setAssetRows(rows);
        }
        if (orderItemInfo.orderPosition === 'Draft') {
            setOrderEditAllowed(true);
        }
    }, [orderItemInfo.orderItems]);

    const getOrderCreationApproverActivityId = (workflowApprover) => {
        // eslint-disable-next-line max-len
        return (`pss_${processStageSequence}|gpapp_${workflowApprover.approverId}|wkappid_${workflowApprover.workflowApproverId}`);
    };
    const getApproverDetails = (workflowApprovers) => {
        const newRows = [];
        workflowApprovers.map((workflowApprover) => {
            const row = [];
            row.push({
                name: approverColumns[0],
                value: workflowApprover.approverSequence,
                type: 'text'
            });
            row.push({
                name: approverColumns[1],
                value: workflowApprover.approverName,
                type: 'text'
            });
            row.push({
                name: approverColumns[2],
                value: workflowApprover.approverRole,
                type: 'text'
            });
            row.push({
                name: approverColumns[3],
                value: workflowApprover.status,
                type: 'text'
            });

            const approverComments = orderItemInfo.orderNotes.find((item) => {
                return (item.activity_identifier === getOrderCreationApproverActivityId(workflowApprover));
            });
            row.push({
                name: approverColumns[4],
                value: approverComments ? approverComments.comment : '-',
                type: 'text'
            });
            newRows.push(row);
        });
        return newRows;
    };

    useEffect(() => {
        if (orderItemInfo.workflow) {
            let rows = getApproverDetails(orderItemInfo.workflow.workflowApprovers);
            setApproverRows(rows);
        }
    }, [orderItemInfo.workflow]);

    const getNextBtnDisabled = (workflow) => {
        if (!workflow) return false;
        const { workflowApprovers } = workflow;
        let isDisabled = false;
        for (let i = 0; i < workflowApprovers.length; i += 1) {
            if (workflowApprovers[i].status !== 'Approved') {
                isDisabled = true;
                break;
            }
        }
        return isDisabled;
    };

    const onCancelOrder = () => {
        setShowLoader(true);
        const { orderId, orderNumber } = orderItemInfo;
        startCancelOrder(orderId)
            .then((response) => {
                setShowLoader(false);
                startShowMessage({
                    message: `Your Order ${orderNumber} has been cancelled.`,
                    status: 'Positive'
                });
                history.push('/order/previousOrder');
            })
            .catch((err) => {
                setShowLoader(false);
            });
    };

    const validateAssetExcelUpload = (file) => {
        const oneMBinBytes = 1 * 1024 * 1024;
        if (file.size > oneMBinBytes) {
            startShowMessage({
                message: 'Cannot upload File of size above 1 MB',
                status: 'Negative'
            });
            return false;
        }
        if (file.type !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
            startShowMessage({
                message: 'Only Excel (.xlsx) files are accepted',
                status: 'Negative'
            });
            return false;
        }
        return true;
    };
    const [isTableOperation, setTableOperation] = useState(false);
    const onFileChangeHandler = (event) => {
        const fileform = new FormData();
        const fileMeta = event.target.files[0];
        fileform.append(event.target.name, fileMeta);
        if (validateAssetExcelUpload(fileMeta)) {
            setTableOperation(true);
            startUpdateAssetListFromExcel(orderItemInfo.orderId, fileform)
                .then((res) => {
                    setTableOperation(false);
                })
                .catch((err) => {
                    setTableOperation(false);
                });
        }
    };
    const assetTableButtons = [{
        name: 'Update Asset List',
        icon: 'down-arrow',
        hide: !orderEditAllowed,
        html: <FileUploader name="assetExcel"
            accept=".xlsx"
            onChange={onFileChangeHandler}
            hideInput>
            <Button>
                Update Asset List
            </Button>
        </FileUploader>
    }];

    const renderButton = () => {
        if (Number(orderItemInfo.currentSequence) === 1 && orderItemInfo.orderPosition !== 'Cancelled') {
            if (orderItemInfo.orderPosition !== 'Draft') {
                return (
                    <>
                        {' '}
                        <Toolbar>
                            <ToolbarSpacer />
                            <Button
                                design="Emphasized"
                                disabled={getNextBtnDisabled(orderItemInfo.workflow)}
                                onClick={() => onNextStep(1)}
                            >
                                Check Order Before Submission
                            </Button>
                        </Toolbar>
                    </>
                );
            } else {
                return (
                    <>
                        {' '}
                        <Toolbar toolbarStyle="Clear">
                            <ToolbarSpacer />
                            <Button onClick={onCancelOrder}>
                                Cancel Order
                            </Button>
                            <Button design="Emphasized" onClick={() => dialogRef.current.open()}>
                                Send Asset List for Internal Approval
                            </Button>
                        </Toolbar>
                    </>
                );
            }
        } else return <></>;
    };

    return (
        <div style={{ height: '100%', margin: '10px' }}>
            {showLoader && <LoadingIndicator />}
            <OrderHeaderView orderItemInfo={orderItemInfo} />
            <AccountTable
                isBusy={isTableOperation}
                columns={assetColumns}
                text="Asset List"
                rows={assetRows}
                buttons={assetTableButtons} />
            <AccountTable
                text="Asset List Approval Workflow"
                columns={approverColumns}
                edit={false}
                rows={approverRows} />
            {renderButton()}
            <CommentDialog ref={dialogRef} onCancel={(e) => dialogRef.current.close()} onSubmit={sendForApproval}
                headerText="Send Asset List for Internal Approval" />
        </div>
    );
};

const mapStateToProps = (state) => {
    return {};
};

const mapDispatchToProps = (dispatch) => {
    return {
        startCreateOrderWorkflow: (payload) => dispatch(createOrderWorkflow(payload)),
        startCancelOrder: (orderId) => dispatch(cancelOrder(orderId)),
        startShowMessage: (payload) => dispatch(showMessage(payload)),
        startUpdateAssetListFromExcel: (orderId, payload) => dispatch(updateAssetListFromExcel(orderId, payload))
    };
};

RecycleOrderCreation.propTypes = {
    orderItemInfo: PropTypes.object,
    onNextStep: PropTypes.func,
    startCreateOrderWorkflow: PropTypes.func,
    startCancelOrder: PropTypes.func,
    startShowMessage: PropTypes.func,
    startUpdateAssetListFromExcel: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(RecycleOrderCreation);
