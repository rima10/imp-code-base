import React, { useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import {
    ShellBar,
    Avatar,
    Popover,
    Button,
    Bar,
    NotificationListItem,
    List,
    Label,
    Text,
    FlexBox
} from '@ui5/webcomponents-react';
import { getNotificationInfo, readNotification, logout, getGPPersonalData } from '../../store/action/taskAction';
import { useHistory } from 'react-router-dom';
import { connect } from 'react-redux';
import logo from '../../../public/favicon.ico';
import { spacing } from '@ui5/webcomponents-react-base';

const Header = ({
    handleSideNavCollapse,
    userName,
    imageSrc,
    notificationList,
    startGetNotificationsInfo,
    startReadNotification,
    startLogout,
    isInitialSetupDone,
    startGetGPPersonalData
}) => {
    const popoverRef = useRef(null);
    const signoutRef = useRef(null);
    const history = useHistory();
    const onNotificationsClick = (e) => {
        popoverRef.current.openBy(e.detail.targetRef);
    };
    const onAvatarClick = (e) => {
        signoutRef.current.openBy(e.detail.targetRef);
    };
    const onPopoverClose = () => {
        popoverRef.current.close();
    };
    const onLogout = () => {
        onPopoverClose();
        startLogout();
        history.push('/logout');
    };
    useEffect(() => {
        startGetNotificationsInfo();
    }, []);
    const handleLogoClick = () => {
        if (isInitialSetupDone) {
            history.push('/');
        } else {
            history.push('/initialSetup');
        }
    };
    const getNotificationAge = (notificationTime) => {
        const startDate = new Date(notificationTime);
        const endDate = new Date();
        let difference = endDate.getTime() - startDate.getTime();
        const daysDifference = Math.floor(difference / 1000 / 60 / 60 / 24);
        if (daysDifference) return `${daysDifference} Days Ago`;

        const hoursDifference = Math.floor(difference / 1000 / 60 / 60);
        if (hoursDifference) return `${hoursDifference} Hours Ago`;

        const minutesDifference = Math.floor(difference / 1000 / 60);
        if (minutesDifference) return `${minutesDifference} Minutes Ago`;
        else return 'Just Now';
    };

    const onNotificationRead = (event) => {
        const bpNotificationId = event.currentTarget.getAttribute('data-id');
        startReadNotification(bpNotificationId);
    };

    const getNotificationStyle = (isRead) => {
        if (!isRead) return { background: 'aliceblue' };
        else return {};
    };
    const renderAvatar = () => {
        if (imageSrc) {
            return <Avatar size="XS" imageFitType="Contain" image={imageSrc} />;
        } else if (userName) {
            let initials = userName
                .split(' ')
                .slice(0, 2)
                .map((word) => word.charAt(0))
                .join('');
            return <Avatar size="XS" initials={initials} />;
        } else {
            return <Avatar icon="employee" size="XS" />;
        }
    };

    return (
        <>
            <ShellBar
                logo={<img alt="EverLoop Logo" src={logo} />}
                primaryTitle="EverLoop by SAP"
                profile={renderAvatar()}
                showNotifications
                notificationCount={notificationList.length}
                onNotificationsClick={onNotificationsClick}
                onProfileClick={onAvatarClick}
                onLogoClick={handleLogoClick}
                style={{ position: 'fixed', top: '0', zIndex: '100' }}
            >
                <Button slot="startButton" disabled={!isInitialSetupDone} onClick={handleSideNavCollapse} icon="menu" />
            </ShellBar>
            <Popover
                headerText="Notifications"
                footer={
                    <Bar
                        style={{ background: 'var(--sapShellColor)' }}
                        endContent={<Button onClick={onPopoverClose}>Close</Button>}
                    />
                }
                placementType="Bottom"
                horizontalAlign="Center"
                ref={popoverRef}
            >
                <>
                    <List noDataText="No new notifications">
                        {notificationList.map((notification, index) => {
                            const notificationItem = notification.notification;
                            return (
                                <NotificationListItem
                                    key={`notification|${index}`}
                                    style={getNotificationStyle(notification.isRead)}
                                    data-id={notification.bpNotificationId}
                                    footnotes={<Label>{getNotificationAge(notificationItem.createdDate)}</Label>}
                                    heading={notificationItem.notificationBody}
                                    showClose={!notification.isRead}
                                    onClose={onNotificationRead}
                                >
                                    {notificationItem.notificationText}
                                </NotificationListItem>
                            );
                        })}
                    </List>
                </>
            </Popover>

            <Popover placementType="Bottom" horizontalAlign="Center" ref={signoutRef}>
                <>
                    <FlexBox
                        style={spacing.sapUiSmallMargin}
                        direction="Column"
                        justifyContent="SpaceBetween"
                        alignItems="Start"
                    >
                        <Text>{userName}</Text>
                        <Button
                            disabled
                            style={{ ...spacing.sapUiTinyMargin, fontSize: '0.8rem', border: 'none' }}
                            icon="action-settings"
                            design="Transparent"
                        >
                            Settings
                        </Button>
                        <Button
                            style={{ ...spacing.sapUiTinyMargin, fontSize: '0.8rem', border: 'none' }}
                            icon="visits"
                            design="Transparent"
                            onClick={() => {startGetGPPersonalData();}}
                        >
                            Export Personal Data
                        </Button>
                        <Button
                            style={{ ...spacing.sapUiTinyMargin, fontSize: '0.8rem', border: 'none' }}
                            icon="log"
                            onClick={onLogout}
                        >
                            Sign Out
                        </Button>
                    </FlexBox>
                </>
            </Popover>
        </>
    );
};

const mapStateToProps = (state) => {
    return {
        notificationList: state.notification
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetNotificationsInfo: async () => dispatch(getNotificationInfo()),
        startReadNotification: async (bpNotificationId) => dispatch(readNotification(bpNotificationId)),
        startLogout: async () => dispatch(logout()),
        startGetGPPersonalData: async () => dispatch(getGPPersonalData())
    };
};

Header.propTypes = {
    handleSideNavCollapse: PropTypes.func,
    userName: PropTypes.string,
    imageSrc: PropTypes.string,
    notificationList: PropTypes.array,
    startGetNotificationsInfo: PropTypes.func,
    startReadNotification: PropTypes.func,
    isInitialSetupDone: PropTypes.bool,
    startLogout: PropTypes.func,
    startGetGPPersonalData: PropTypes.func
};

Header.defaultProps = {
    notificationList: []
};

export default connect(mapStateToProps, mapDispatchToProps)(Header);
