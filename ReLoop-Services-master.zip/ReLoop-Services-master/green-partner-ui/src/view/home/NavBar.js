import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { SideNavigation, SideNavigationItem, SideNavigationSubItem } from '@ui5/webcomponents-react';
import { withRouter } from 'react-router-dom';
import PrivacyStatement from './PrivacyStatement';
import { getUserInfo } from '../../selectors/common';
import { isEmpty } from '../../validation/common';

class NavBar extends Component {
    constructor (props) {
        super(props);
        this.myRef = React.createRef();
        this.state = {
            activePath: '/',
            orderItems: [
                {
                    path: '/order/newOrder' /* path is used as id to check which NavItem is active basically */,
                    name: 'New Order',
                    key: 'key1' /* Key is required, else console throws error. Does this please you Mr. Browser?! */,
                    icon: 'create'
                },
                {
                    path: '/order/previousOrder',
                    name: 'Previous Order',
                    key: 'key2',
                    icon: 'present'
                }
            ],
            accountItems: [
                {
                    path: '/account/businessInfo' /* path is used as id to check which NavItem is active basically */,
                    name: 'Business Information',
                    // eslint-disable-next-line max-len
                    key: 'accountKey1' /* Key is required, else console throws error. Does this please you Mr. Browser?! */,
                    icon: 'business-card'
                },
                {
                    path: '/account/approverInfo',
                    name: 'Approver Information',
                    key: 'accountKey3',
                    icon: 'customer-and-contacts'
                },
                {
                    path: '/account/workflowInfo',
                    name: 'Workflow Information',
                    key: 'accountKey4',
                    icon: 'add-activity'
                }
            ]
        };
    }
    componentDidMount () {
        if (isEmpty(this.props.userInfo.isPartOfPvtNwk) || this.props.userInfo.isPartOfPvtNwk === false) {
            this.setState({
                accountItems: [
                    ...this.state.accountItems,
                    {
                        path: '/account/networkInfo',
                        name: 'Private Network',
                        key: 'accountKey2',
                        icon: 'cancel-share'
                    }
                ]
            });
        }
    }
    onSelectionChange = (event) => {
        this.setState({ activePath: event.detail.item.getAttribute('path') });
        let path = event.detail.item.getAttribute('path');
        this.props.history.push(`${path}`);
    };

    render () {
        const { orderItems, accountItems, activePath } = this.state;
        return (
            <>
                <SideNavigation
                    style={{ position: 'fixed', height: '-webkit-fill-available', marginTop: '44px' }}
                    slot=""
                    onSelectionChange={this.onSelectionChange}
                    fixedItems={
                        <>
                            <SideNavigationItem
                                icon="compare"
                                text="Privacy Statement"
                                onClick={(e) => this.myRef.current.open()}
                                path="#"
                            />
                            <SideNavigationItem
                                icon="chain-link"
                                text="EverLoop Website"
                                onClick={() => window.open('https://everloopbysap.webflow.io/', '_blank')}
                                path="#"
                            />
                        </>
                    }
                    collapsed={this.props.isCollapsed}
                >
                    <SideNavigationItem wholeItemToggleable path="#" text="Order Management" expanded icon="sap-icon://sales-order-item">
                        {orderItems.map((item) => (
                            /* Return however many NavItems in array to be rendered */
                            <SideNavigationSubItem
                                id={item.key}
                                path={item.path}
                                text={item.name}
                                active={item.path === activePath}
                                key={item.key}
                                icon={item.icon}
                            />
                        ))}
                    </SideNavigationItem>
                    <SideNavigationItem wholeItemToggleable path="#" text="Account Management" icon="sap-icon://account">
                        {accountItems.map((item) => (
                            /* Return however many NavItems in array to be rendered */
                            <SideNavigationSubItem
                                id={item.key}
                                path={item.path}
                                text={item.name}
                                active={item.path === activePath}
                                key={item.key}
                                icon={item.icon}
                            />
                        ))}
                    </SideNavigationItem>
                </SideNavigation>
                <PrivacyStatement ref={this.myRef} />
            </>
        );
    }
}

NavBar.propTypes = {
    isCollapsed: PropTypes.bool,
    history: PropTypes.object,
    userInfo: PropTypes.object
};

const mapStateToProps = (state) => {
    return {
        userInfo: getUserInfo(state)
    };
};

export default withRouter(connect(mapStateToProps)(NavBar));
