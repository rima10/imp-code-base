import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { spacing } from '@ui5/webcomponents-react-base';
import { withRouter, useHistory } from 'react-router-dom';
import {
    Grid,
    Icon,
    Button,
    Input,
    Label,
    FlexBox,
    Title,
    Toolbar,
    Select,
    Option,
    Loader
} from '@ui5/webcomponents-react';
import { getApproverInfoState, isApproverInfoLoading } from '../../selectors/common';
import { getApproverInfo, registerBPWorkflowInfo, getUserData } from '../../store/action/taskAction';

const ApprovalWorkflowStep = ({
    startGetApproverInfo,
    startRegisterBPWorkflowInfo,
    approverInfo,
    isLoading,
    startGetUserData
}) => {
    useEffect(() => {
        startGetApproverInfo();
    }, []);
    const history = useHistory();
    const [orderCreationInput, setOrderCreationInput] = useState([
        {
            approvalSequence: {
                value: 1,
                valueState: 'None',
                valueStateMessage: '',
                readonly: true
            },
            approverRole: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                readonly: false
            },
            approverName: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                readonly: true
            },
            emailAddress: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                readonly: true
            }
        }
    ]);

    const onOrderCreationInputChange = (event) => {
        let value = event.detail.selectedOption.attributes.value.value;
        let tempInputBox = [...orderCreationInput];
        let idx = event.detail.selectedOption.attributes.id.value;
        if (value !== 'Select Role') {
            tempInputBox[idx]['approverRole']['value'] = value;
            let filtered = approverInfo.find((element) => element.approver_role === value);
            tempInputBox[idx]['approverName']['value'] = filtered.approver_name;
            tempInputBox[idx]['emailAddress']['value'] = filtered.approver_email_id;
        } else {
            tempInputBox[idx]['approverRole']['value'] = value;
            tempInputBox[idx]['approverName']['value'] = '';
            tempInputBox[idx]['emailAddress']['value'] = '';
        }
        setOrderCreationInput(tempInputBox);
    };

    const onOrderCreationDeleteClick = (index) => {
        let tempInputBox = [...orderCreationInput];
        tempInputBox.forEach((value, idx) => {
            if (idx > index) {
                value['approvalSequence']['value'] = value['approvalSequence']['value'] - 1;
            }
        });
        tempInputBox = tempInputBox.filter((value, idx) => idx !== index);
        setOrderCreationInput(tempInputBox);
    };

    const [quoteInput, setQuoteInput] = useState([
        {
            approvalSequence: {
                value: 1,
                valueState: 'None',
                valueStateMessage: '',
                readonly: true
            },
            approverRole: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                readonly: false
            },
            approverName: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                readonly: true
            },
            emailAddress: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                readonly: true
            }
        }
    ]);

    const onQuoteInputChange = (event) => {
        let value = event.detail.selectedOption.attributes.value.value;
        let tempInputBox = [...quoteInput];
        let idx = event.detail.selectedOption.attributes.id.value;
        if (value !== 'Select Role') {
            tempInputBox[idx]['approverRole']['value'] = value;
            let filtered = approverInfo.find((element) => element.approver_role === value);
            tempInputBox[idx]['approverName']['value'] = filtered.approver_name;
            tempInputBox[idx]['emailAddress']['value'] = filtered.approver_email_id;
        } else {
            tempInputBox[idx]['approverRole']['value'] = value;
            tempInputBox[idx]['approverName']['value'] = '';
            tempInputBox[idx]['emailAddress']['value'] = '';
        }
        setQuoteInput(tempInputBox);
    };

    const onQuoteDeleteClick = (index) => {
        let tempInputBox = [...quoteInput];
        tempInputBox.forEach((value, idx) => {
            if (idx > index) {
                value['approvalSequence']['value'] = value['approvalSequence']['value'] - 1;
            }
        });
        tempInputBox = tempInputBox.filter((value, idx) => idx !== index);
        setQuoteInput(tempInputBox);
    };

    const [itemLevelQuoteInput, setItemLevelQuoteInput] = useState([
        {
            approvalSequence: {
                value: 1,
                valueState: 'None',
                valueStateMessage: '',
                readonly: true
            },
            approverRole: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                readonly: false
            },
            approverName: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                readonly: true
            },
            emailAddress: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                readonly: true
            }
        }
    ]);

    const onItemLevelQuoteInputChange = (event) => {
        let value = event.detail.selectedOption.attributes.value.value;
        let tempInputBox = [...itemLevelQuoteInput];
        let idx = event.detail.selectedOption.attributes.id.value;
        if (value !== 'Select Role') {
            tempInputBox[idx]['approverRole']['value'] = value;
            let filtered = approverInfo.find((element) => element.approver_role === value);
            tempInputBox[idx]['approverName']['value'] = filtered.approver_name;
            tempInputBox[idx]['emailAddress']['value'] = filtered.approver_email_id;
        } else {
            tempInputBox[idx]['approverRole']['value'] = value;
            tempInputBox[idx]['approverName']['value'] = '';
            tempInputBox[idx]['emailAddress']['value'] = '';
        }
        setItemLevelQuoteInput(tempInputBox);
    };

    const onItemLevelQuoteDeleteClick = (index) => {
        let tempInputBox = [...itemLevelQuoteInput];
        tempInputBox.forEach((value, idx) => {
            if (idx > index) {
                value['approvalSequence']['value'] = value['approvalSequence']['value'] - 1;
            }
        });
        tempInputBox = tempInputBox.filter((value, idx) => idx !== index);
        setItemLevelQuoteInput(tempInputBox);
    };

    const onSkip = () => {
        startGetUserData()
            .then(() => history.push('/order/newOrder'))
            .catch(() => console.log('Something went wrong!'));
    };

    const onSave = () => {
        const orderCreationPayload = {
            processStageSequence: '1',
            processStageName: 'Order Creation',
            processTypeId: '1',
            approvers: []
        };
        const recycleOrderCreationPayload = {
            processStageSequence: '1',
            processStageName: 'Order Creation',
            processTypeId: '2',
            approvers: []
        };
        const quotePayload = {
            processStageSequence: '3',
            processStageName: 'Quote Selection',
            processTypeId: '1',
            approvers: []
        };
        const recycleQuotePayload = {
            processStageSequence: '3',
            processStageName: 'Quote Selection',
            processTypeId: '2',
            approvers: []
        };
        const itemLevelQuotePayload = {
            processStageSequence: '5',
            processStageName: 'Approval of Final Quote',
            processTypeId: '1',
            approvers: []
        };
        const recycleItemLevelQuotePayload = {
            processStageSequence: '5',
            processStageName: 'Approval of Final Quote',
            processTypeId: '2',
            approvers: []
        };
        orderCreationInput.map((input) => {
            let approverRole = input.approverRole.value;
            let filtered = approverInfo.find((element) => element.approver_role === approverRole);
            if (filtered) {
                orderCreationPayload.approvers.push({
                    approverId: filtered.approver_id,
                    approverSequence: input.approvalSequence.value
                });
                recycleOrderCreationPayload.approvers.push({
                    approverId: filtered.approver_id,
                    approverSequence: input.approvalSequence.value
                });
            }
        });
        quoteInput.map((input) => {
            let approverRole = input.approverRole.value;
            let filtered = approverInfo.find((element) => element.approver_role === approverRole);
            if (filtered) {
                quotePayload.approvers.push({
                    approverId: filtered.approver_id,
                    approverSequence: input.approvalSequence.value
                });
                recycleQuotePayload.approvers.push({
                    approverId: filtered.approver_id,
                    approverSequence: input.approvalSequence.value
                });
            }
        });
        itemLevelQuoteInput.map((input) => {
            let approverRole = input.approverRole.value;
            let filtered = approverInfo.find((element) => element.approver_role === approverRole);
            if (filtered) {
                itemLevelQuotePayload.approvers.push({
                    approverId: filtered.approver_id,
                    approverSequence: input.approvalSequence.value
                });
                recycleItemLevelQuotePayload.approvers.push({
                    approverId: filtered.approver_id,
                    approverSequence: input.approvalSequence.value
                });
            }
        });
        Promise.all([
            startRegisterBPWorkflowInfo(orderCreationPayload),
            startRegisterBPWorkflowInfo(quotePayload),
            startRegisterBPWorkflowInfo(itemLevelQuotePayload),
            startRegisterBPWorkflowInfo(recycleOrderCreationPayload),
            startRegisterBPWorkflowInfo(recycleQuotePayload),
            startRegisterBPWorkflowInfo(recycleItemLevelQuotePayload)
        ])
            .then(() => {
                startGetUserData()
                    .then(() => history.push('/order/newOrder'))
                    .catch(() => console.log('Something went wrong!'));
            })
            .catch(() => console.log('Something went wrong!'));
    };

    return (
        <>
            <FlexBox alignItems="Center" direction="Column">
                {isLoading && <Loader />}
                <Title style={{ fontSize: 'larger', marginTop: '2rem' }}>
                    <b> Please select the approvers</b> that you created in the previous
                    steps in order <b>to assign them to the approval steps below.</b>
                </Title>
                <Title style={{ fontSize: 'larger', marginTop: '0.5rem' }}>
                    This step could be skipped and set up later under{' '}
                    <b>Menu &gt; Account Management &gt; Approval Workflows.</b>
                </Title>
            </FlexBox>
            <Grid style={{ margin: '20px' }}>
                <div data-layout-span="XL12 L12 M12 S12">
                    <Label style={{ fontSize: 'larger', marginTop: '3rem', color: '#000000' }}>
                        In your Process, who is responsible for the internal approval of the asset list?
                    </Label>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label style={{ fontSize: 'larger', marginTop: '2rem' }}>Approval Sequence</Label>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label required style={{ fontSize: 'larger', marginTop: '2rem' }}>
                        Approver Role
                    </Label>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label style={{ fontSize: 'larger', marginTop: '2rem' }}>Approver Name</Label>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label style={{ fontSize: 'larger', marginTop: '2rem' }}>Email Address</Label>
                </div>
                {orderCreationInput.map((inputElements, index) =>
                    Object.keys(inputElements).map((inputElement, idx) => (
                        <div key={idx} data-layout-span="XL3 L3 M3 S3">
                            {inputElement === 'approverRole' ? (
                                <Select
                                    onChange={(e) => {
                                        onOrderCreationInputChange(e);
                                    }}
                                >
                                    <Option key="-1" id={index} name="" value="Select Role">
                                        Select Role
                                    </Option>
                                    {approverInfo &&
                                        approverInfo.map((item) => (
                                            <Option
                                                key={item.approver_id}
                                                id={index}
                                                name={item.approver_name}
                                                value={item.approver_role}
                                                selected={inputElements[inputElement].value === item.approver_role}
                                            >
                                                {item.approver_role}
                                            </Option>
                                        ))}
                                </Select>
                            ) : (
                                <Input
                                    id={inputElement + index}
                                    value={inputElements[inputElement].value}
                                    valueState={inputElements[inputElement].valueState}
                                    valueStateMessage={inputElements[inputElement].valueStateMessage}
                                    readonly={inputElements[inputElement].readonly}
                                    onInput={onOrderCreationInputChange}
                                />
                            )}
                            {idx === Object.keys(inputElements).length - 1 ? (
                                <Icon
                                    name="delete"
                                    onClick={() => onOrderCreationDeleteClick(index)}
                                    tooltip="Delete Row"
                                    style={{ ...spacing.sapUiTinyMarginBegin, width: '1.5rem', cursor: 'pointer' }}
                                />
                            ) : null}
                        </div>
                    ))
                )}
            </Grid>
            <Button
                design="Transparent"
                style={{ color: 'blue', marginLeft: '15px' }}
                onClick={() => {
                    let tempInputBox = [...orderCreationInput];
                    let sequenceNo = tempInputBox.length + 1;
                    tempInputBox.push({
                        approvalSequence: {
                            value: sequenceNo,
                            valueState: 'None',
                            valueStateMessage: '',
                            readonly: true
                        },
                        approverRole: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            readonly: false
                        },
                        approverName: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            readonly: true
                        },
                        emailAddress: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            readonly: true
                        }
                    });
                    setOrderCreationInput(tempInputBox);
                }}
            >
                + Add Approver
            </Button>
            <Toolbar />
            <Grid style={{ margin: '20px' }}>
                <div data-layout-span="XL12 L12 M12 S12">
                    <Label style={{ fontSize: 'larger', marginTop: '3rem', color: '#000000' }}>
                        In your Process, who is responsible for internally approving higher level quotes from your
                        recycler?
                    </Label>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label style={{ fontSize: 'larger', marginTop: '2rem' }}>Approval Sequence</Label>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label required style={{ fontSize: 'larger', marginTop: '2rem' }}>
                        Approver Role
                    </Label>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label style={{ fontSize: 'larger', marginTop: '2rem' }}>Approver Name</Label>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label style={{ fontSize: 'larger', marginTop: '2rem' }}>Email Address</Label>
                </div>
                {quoteInput.map((inputElements, index) =>
                    Object.keys(inputElements).map((inputElement, idx) => (
                        <div key={idx} data-layout-span="XL3 L3 M3 S3">
                            {inputElement === 'approverRole' ? (
                                <Select
                                    onChange={(e) => {
                                        onQuoteInputChange(e);
                                    }}
                                >
                                    <Option key="-1" id={index} name="" value="Select Role">
                                        Select Role
                                    </Option>
                                    {approverInfo &&
                                        approverInfo.map((item) => (
                                            <Option
                                                key={item.approver_id}
                                                id={index}
                                                name={item.approver_name}
                                                value={item.approver_role}
                                                selected={inputElements[inputElement].value === item.approver_role}
                                            >
                                                {item.approver_role}
                                            </Option>
                                        ))}
                                </Select>
                            ) : (
                                <Input
                                    id={inputElement + index}
                                    value={inputElements[inputElement].value}
                                    valueState={inputElements[inputElement].valueState}
                                    valueStateMessage={inputElements[inputElement].valueStateMessage}
                                    readonly={inputElements[inputElement].readonly}
                                    onInput={onQuoteInputChange}
                                />
                            )}
                            {idx === Object.keys(inputElements).length - 1 ? (
                                <Icon
                                    name="delete"
                                    onClick={() => onQuoteDeleteClick(index)}
                                    tooltip="Delete Row"
                                    style={{ ...spacing.sapUiTinyMarginBegin, width: '1.5rem', cursor: 'pointer' }}
                                />
                            ) : null}
                        </div>
                    ))
                )}
            </Grid>
            <Button
                design="Transparent"
                style={{ color: 'blue', marginLeft: '15px' }}
                onClick={() => {
                    let tempInputBox = [...quoteInput];
                    let sequenceNo = tempInputBox.length + 1;
                    tempInputBox.push({
                        approvalSequence: {
                            value: sequenceNo,
                            valueState: 'None',
                            valueStateMessage: '',
                            readonly: true
                        },
                        approverRole: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            readonly: false
                        },
                        approverName: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            readonly: true
                        },
                        emailAddress: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            readonly: true
                        }
                    });
                    setQuoteInput(tempInputBox);
                }}
            >
                + Add Approver
            </Button>
            <Toolbar />
            <Grid style={{ margin: '20px' }}>
                <div data-layout-span="XL12 L12 M12 S12">
                    <Label style={{ fontSize: 'larger', marginTop: '3rem', color: '#000000' }}>
                        In your Process, who is responsible for internally approving item level quotes from your
                        recycler?
                    </Label>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label style={{ fontSize: 'larger', marginTop: '2rem' }}>Approval Sequence</Label>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label required style={{ fontSize: 'larger', marginTop: '2rem' }}>
                        Approver Role
                    </Label>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label style={{ fontSize: 'larger', marginTop: '2rem' }}>Approver Name</Label>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label style={{ fontSize: 'larger', marginTop: '2rem' }}>Email Address</Label>
                </div>
                {itemLevelQuoteInput.map((inputElements, index) =>
                    Object.keys(inputElements).map((inputElement, idx) => (
                        <div key={idx} data-layout-span="XL3 L3 M3 S3">
                            {inputElement === 'approverRole' ? (
                                <Select
                                    onChange={(e) => {
                                        onItemLevelQuoteInputChange(e);
                                    }}
                                >
                                    <Option key="-1" id={index} name="" value="Select Role">
                                        Select Role
                                    </Option>
                                    {approverInfo &&
                                        approverInfo.map((item) => (
                                            <Option
                                                key={item.approver_id}
                                                id={index}
                                                name={item.approver_name}
                                                value={item.approver_role}
                                                selected={inputElements[inputElement].value === item.approver_role}
                                            >
                                                {item.approver_role}
                                            </Option>
                                        ))}
                                </Select>
                            ) : (
                                <Input
                                    id={inputElement + index}
                                    value={inputElements[inputElement].value}
                                    valueState={inputElements[inputElement].valueState}
                                    valueStateMessage={inputElements[inputElement].valueStateMessage}
                                    readonly={inputElements[inputElement].readonly}
                                    onInput={onItemLevelQuoteInputChange}
                                />
                            )}
                            {idx === Object.keys(inputElements).length - 1 ? (
                                <Icon
                                    name="delete"
                                    onClick={() => onItemLevelQuoteDeleteClick(index)}
                                    tooltip="Delete Row"
                                    style={{ ...spacing.sapUiTinyMarginBegin, width: '1.5rem', cursor: 'pointer' }}
                                />
                            ) : null}
                        </div>
                    ))
                )}
            </Grid>
            <Button
                design="Transparent"
                style={{ color: 'blue', marginLeft: '15px' }}
                onClick={() => {
                    let tempInputBox = [...itemLevelQuoteInput];
                    let sequenceNo = tempInputBox.length + 1;
                    tempInputBox.push({
                        approvalSequence: {
                            value: sequenceNo,
                            valueState: 'None',
                            valueStateMessage: '',
                            readonly: true
                        },
                        approverRole: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            readonly: false
                        },
                        approverName: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            readonly: true
                        },
                        emailAddress: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            readonly: true
                        }
                    });
                    setItemLevelQuoteInput(tempInputBox);
                }}
            >
                + Add Approver
            </Button>
            <Grid style={{ ...spacing.sapUiMediumMarginTop }}>
                <div style={{}} data-layout-indent="XL9 L9 M9 S9" data-layout-span="XL3 L3 M3 S3">
                    <Button style={{ ...spacing.sapUiSmallMarginEnd }} onClick={() => onSkip()}>
                        Skip
                    </Button>
                    <Button onClick={() => onSave()} design="Emphasized">
                        Save &amp; Enter EverLoop
                    </Button>
                </div>
            </Grid>
        </>
    );
};

const mapStateToProps = (state) => {
    return {
        approverInfo: getApproverInfoState(state),
        isLoading: isApproverInfoLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetApproverInfo: () => dispatch(getApproverInfo()),
        startRegisterBPWorkflowInfo: (payload) => dispatch(registerBPWorkflowInfo(payload)),
        startGetUserData: async () => dispatch(getUserData())
    };
};

ApprovalWorkflowStep.propTypes = {
    startGetApproverInfo: PropTypes.func,
    startRegisterBPWorkflowInfo: PropTypes.func,
    approverInfo: PropTypes.array,
    isLoading: PropTypes.bool,
    startGetUserData: PropTypes.func
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(ApprovalWorkflowStep));
