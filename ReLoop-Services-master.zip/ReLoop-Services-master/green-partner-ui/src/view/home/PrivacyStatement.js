import React from 'react';
import { spacing } from '@ui5/webcomponents-react-base';
import { Button, Dialog, Title, Text, Bar } from '@ui5/webcomponents-react';

const PrivacyStatement = React.forwardRef(({}, ref) => {
    const onClosePrivacyStatementDialog = () => {
        ref.current.close();
    };

    return (
        <Dialog
            className=""
            ref={ref}
            footer={
                <Bar style={{ ...spacing.sapUiMediumMargin }}
                    endContent={<Button onClick={onClosePrivacyStatementDialog}>OK</Button>}
                />
            }
            style={{ marginRight: '100px', marginTop: '50px' }}
            headerText="Privacy Statement"
        >
            <Text style={{ fontSize: 'var(--sapFontSize)', ...spacing.sapUiSmallMargin }}>
                <Title>Privacy Information Notice for EverLoop by SAP Cloud Service</Title>

                <p>Last updated on 27th September 2021. </p>
                <p>
                    The SAP Group entity (referenced in this notice as “SAP”, “we”, “us”, or “our”) that your
                    organization contracted with to subscribe to SAP’s cloud services (your organization referenced
                    in this notice as “Customer”) has created this Information Notice (“Notice”) to demonstrate SAP’s
                    commitment to the individual’s right to data protection and privacy. It is meant to help users and
                    Customers understand what data we collect, why we collect it, and what we do with such data.
                </p>

                <Title>OVERVIEW</Title>

                <p>
                    We offer a pre-production version of EverLoop by SAP(the “Cloud Service”) to our Customers and
                    through whom you, the end user of such Cloud Service (“Authorized User”), are provided access to
                    test and evaluate the Cloud Service. This Notice describes solely how SAP processes data that
                    identifies or relates to an identifiable individual (“Personal Data”) that SAP collects on its own
                    behalf from or through the Cloud Service.
                </p>

                <p>
                    This Notice does not apply to the extent we process Personal Data in SAP’s role as a processor or
                    service provider to its Customers. This includes activities where Customers or their affiliates can:
                    (i) create their own websites and applications running on SAP platforms; (ii) sell or offer their
                    own products and services; (iii) send electronic communications to others; or (iv) otherwise process
                    Personal Data via the Cloud Service. This also includes Personal Data that SAP processes on the
                    direction and at the instruction of the Customer. In such cases, SAP processes such data as provided
                    in SAP’s agreements with the Customer (“Customer Data”). Please note that SAP’s agreement with your
                    affiliated Customer may differ from these template agreements and a Customer may configure the Cloud
                    Services as provided to you as the Customer’s end user, and this can affect the data accessed or
                    obtained by the Cloud Services. Please contact your affiliated Customer for more information about
                    how to exercise your legal rights regarding Customer Data and your Customer’s practices to process
                    Customer Data.
                </p>

                <Title>A. GENERAL INFORMATION</Title>

                <p>PROCESSING FOR STATUTORY OBLIGATIONS</p>


                <p>
                    SAP SE processes Personal Data based on statutory obligations (Article 6 para. 1 lit. c Regulation
                    (EU) 2016/679 (General Data Protection Regulation, “GDPR”) or the equivalent articles under other
                    national laws, when applicable) and SAP’s legitimate interest (Article 6 para. 1 lit. f GDPR or the
                    equivalent articles under other national laws, when applicable), as follows:
                </p>

                <ul>
                    <li>
                        SAP requires your first and last name, physical address, IP address and other registration data
                        to ensure SAP’s compliance with export control and sanctions laws.
                    </li>

                </ul>


                <p>PROCESSING FOR SAP’S LEGITIMATE BUSINESS INTEREST</p>

                <p>
                    <b>Product Testing.</b>Your organization or employer has elected to
                    participate in a test and evaluation of the Cloud Service and to invite youto voluntarily
                    participate in the testing and evaluation of the Cloud Service. When using the Cloud Service, you
                    may submit data to simulate transactions in the Cloud Service. When using the Cloud Service, SAP may
                    collect and store the following Personal Data:
                </p>

                <ul>
                    <li>Private NetworkSection</li>

                    <ul>
                        <li>Stakeholder Contact Name</li>
                        <li>Stakeholder E-mail ID</li>
                        <li>Stakeholder Contact Number</li>
                    </ul>

                    <li>Approver Information Section</li>
                    <ul>
                        <li>Approver E-mail ID</li>
                        <li>Approver Name &amp; Role</li>
                    </ul>

                    <li>Onsite Scheduling &amp; Logistics Scheduling Section</li>
                    <ul>
                        <li>Transporting Driver’s Name</li>
                        <li>
                            Contact Name and Contact Number of order responsible person from both sides of the
                            stakeholders
                        </li>
                    </ul>
                </ul>


                <p>
                    SAP processes the Personal Data based on its legitimate interest (Article 6 para. 1 lit. f GDPR or
                    the equivalent articles under other national laws, when applicable) to test and improve the
                    performance of the Cloud Service.
                </p>

                <p>HOW WE MAY SHARE PERSONAL DATA </p>

                <p>
                    As part of a global group of companies operating internationally, SAP has affiliates (the “SAP
                    Group”)and third-party service providers outside of the European Economic Area (the “EEA”) or from a
                    region with a legal restriction on international data transfers and will transfer your Personal Data
                    to countries outside of the EEA. If these transfers are to a country for which the EU Commissionhas
                    not issued an adequacy decision, SAP uses the EU standard contractual clauses to contractually
                    require that your Personal Data receives a level of data protection consistent with the EEA. You can
                    obtain a copy (redacted to remove commercial or irrelevant) of such standard contractual clauses by
                    sending a request to privacy@sap.com. You can also obtain more information from the European
                    Commission the international dimension of data protection here.
                </p>

                <p>DATA RETENTION </p>

                <p>
                    SAP will only store your Personal Data for as long as it is required for SAP to comply with its
                    statutory obligations resulting from applicable export control and sanctions laws.
                </p>

                <p>
                    SAP will only store your Personal Data as long as it is required for the testing and development of
                    the Cloud Service, or until you object against such use by SAP, plus, where applicable, any
                    additional periods under applicable laws during which SAP has to retain your Personal Data.
                </p>

                <p>YOUR DATA PROTECTION RIGHTS AND HOW TO EXERCISE THEM</p>

                <p>
                    You have certain rights related to your Personal Data, subject to local data protection laws.
                    Depending on the applicable laws, these rights include:
                </p>

                <ul>
                    <li>
                        the right to request access at any time to information about what Personal Data is processed
                        about you
                    </li>

                    <li>the correction, restrictionor deletion of such Personal Data</li>

                    <li>
                        to object to processing of your Personal Data carried out on the basis of our legitimate
                        interests.
                    </li>
                </ul>

                <p>
                    To exercise your rights in connection with Personal Data processed by SAP on its own behalf, please
                    contact us at ajit.chandran@sap.com. To exercise your rights with respect to Customer Data processed
                    by the Cloud Services on behalf of your affiliated Customer, please directly contact your affiliated
                    Customer, the data controllerof the Customer Data.
                </p>

                <p>
                    SAP will take steps to ensure that it verifies your identity to a reasonable degree of certainty
                    before it will executethe data protection right you want to exercise. When feasible, SAP will match
                    Personal Data provided by you in submitting a request to exercise your rights with information
                    already maintained by SAP. This could include matching two or more data points you provide when you
                    submit a request with two or more data points that are already maintained by SAP.{' '}
                </p>

                <p>
                    Right to lodge a complaint. If you take the view that SAP is not processing your Personal Data in
                    accordance with the requirements in this Privacy Information Noticeor under applicable data
                    protection laws, you can at any time lodge a complaint with the data protection authority of the EEA
                    country where
                    you live or with the data protection authority of the country or state where SAP has its registered
                    seat.
                </p>

                <p>
                    SAP has appointed a Data Protection Officer for the SAP Group that is reachable via
                    privacy[at]sap.com.
                </p>
            </Text>
        </Dialog>
    );
});

export default PrivacyStatement;
