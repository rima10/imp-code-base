import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { updateBusinessInfo, getStates, getIndustry, getCities } from '../../store/action/taskAction';
import { Select, Grid, Button, Option, Input, Title, FlexBox, Label, TextArea, Loader } from '@ui5/webcomponents-react';
import validateInput from '../../validation/BusinessProfile';
import { camelCaseToSentence } from '../../utils/formatter';
import { isApproverInfoLoading, getUserInfo } from '../../selectors/common';
import { isEmpty } from '../../validation/common';

const BusinessProfile = ({
    onNextClick,
    startUpdateBusinessInfo,
    startGetStates,
    startGetCities,
    startGetIndustry,
    industry,
    states,
    cities,
    isLoading,
    userInfo
}) => {
    const [inputBox, setInputBox] = useState({
        phoneNumber: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        gstin: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        cin: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        pan: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        pincode: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        companyCode: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: false
        },
        address: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        industryType: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        state: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        city: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        }
    });

    useEffect(() => {
        startGetIndustry();
        startGetStates();
    }, []);

    const getCity = (stateId) => {
        startGetCities(stateId);
    };

    const onSelectionChange = (event) => {
        let tempInputBox = { ...inputBox };
        let field = event.target.name;
        let value = event.target.selectedOption.value;
        tempInputBox[field]['value'] = value;
        tempInputBox[field]['valueState'] = 'None';
        tempInputBox[field]['valueStateMessage'] = '';
        setInputBox(tempInputBox);
        if (field === 'state') {
            getCity(value);
        }
    };

    const onInputChange = (event) => {
        let tempInputBox = { ...inputBox };
        let field = event.target.name;
        let { isValid, errorMessage } = validateInput(event.target.value, field, tempInputBox[field]);
        tempInputBox[field]['value'] = event.target.value;
        tempInputBox[field]['valueStateMessage'] = <span>{errorMessage}</span>;
        if (isValid) {
            tempInputBox[field]['valueState'] = 'None';
        } else {
            tempInputBox[field]['valueState'] = 'Error';
        }
        setInputBox(tempInputBox);
    };

    const submitBusinessInfoForm = async (event) => {
        event.preventDefault();
        let isValid = true;
        let tempInputBox = { ...inputBox };
        Object.keys(tempInputBox).map((field) => {
            // check to find whether value is empty for required fields
            if (tempInputBox[field]['required'] && tempInputBox[field]['value'] === '') {
                let fieldName = '';
                if (field === 'cin' || field === 'pan' || field === 'gstin') {
                    fieldName = field.toUpperCase();
                } else {
                    fieldName = camelCaseToSentence(field);
                }
                tempInputBox[field]['valueState'] = 'Error';
                tempInputBox[field]['valueStateMessage'] = <span>{fieldName} is required</span>;
                isValid = false;
            }
            // check to find whether any field has error state
            if (tempInputBox[field]['valueState'] === 'Error') {
                isValid = false;
            }
        });
        if (isValid) {
            const payload = {
                bpPhoneNumber: inputBox.phoneNumber.value,
                cin: inputBox.cin.value,
                companyCode: inputBox.companyCode.value,
                gstNumber: inputBox.gstin.value,
                pan: inputBox.pan.value,
                industryType: inputBox.industryType.value,
                location: {
                    country: '1',
                    stateId: inputBox.state.value,
                    cityId: inputBox.city.value,
                    pincode: inputBox.pincode.value,
                    locDetails: inputBox.address.value
                }
            };
            startUpdateBusinessInfo(payload)
                .then(() => {
                    if (isEmpty(userInfo.isPartOfPvtNwk) || userInfo.isPartOfPvtNwk === false) {
                        onNextClick('2');
                    } else {
                        onNextClick('3');
                    }
                })
                .catch(() => console.log('Something went wrong!'));
        } else {
            setInputBox(tempInputBox);
        }
    };

    return (
        <>
            <FlexBox alignItems="Center" direction="Column">
                {isLoading && <Loader />}
                <Title style={{ fontSize: 'larger', marginTop: '2rem' }}>
                    Please add all the business data needed to complete your <b>Business Profile</b>
                </Title>
            </FlexBox>
            <Grid style={{ margin: '20px' }}>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label required style={{ marginTop: '2rem', display: 'block' }}>
                        Industry Type
                    </Label>
                    <Select
                        name="industryType"
                        id="industryType"
                        valueState={inputBox.industryType.valueState}
                        valueStateMessage={inputBox.industryType.valueStateMessage}
                        style={{ width: '80%' }}
                        onChange={(e) => onSelectionChange(e)}
                    >
                        <Option value={''}>Select Industry Type</Option>
                        {industry?.map((indus) => (
                            <Option key={indus} value={indus}>
                                {indus}
                            </Option>
                        ))}
                    </Select>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label required style={{ display: 'block', marginTop: '2rem' }}>
                        GSTIN
                    </Label>
                    <Input
                        id="gstin"
                        valueState={inputBox.gstin.valueState}
                        valueStateMessage={inputBox.gstin.valueStateMessage}
                        name="gstin"
                        style={{ width: '80%' }}
                        onInput={(e) => onInputChange(e)}
                    />
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label required style={{ display: 'block', marginTop: '2rem' }}>
                        CIN
                    </Label>
                    <Input
                        id="cin"
                        valueState={inputBox.cin.valueState}
                        valueStateMessage={inputBox.cin.valueStateMessage}
                        name="cin"
                        style={{ width: '80%' }}
                        onInput={(e) => onInputChange(e)}
                    />
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label style={{ display: 'block', marginTop: '2rem' }}>Company Code</Label>
                    <Input
                        id="companyCode"
                        valueState={inputBox.companyCode.valueState}
                        valueStateMessage={inputBox.companyCode.valueStateMessage}
                        name="companyCode"
                        style={{ width: '80%' }}
                        onInput={(e) => onInputChange(e)}
                    />
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label required style={{ display: 'block', marginTop: '2rem' }}>
                        State
                    </Label>
                    <Select
                        id="state"
                        style={{ width: '80%' }}
                        name="state"
                        valueState={inputBox.state.valueState}
                        valueStateMessage={inputBox.state.valueStateMessage}
                        onChange={(e) => onSelectionChange(e)}
                    >
                        <Option value={''}>Select State</Option>
                        {states?.map((stateVal) => (
                            <Option key={stateVal.state_id} value={stateVal.state_id}>
                                {stateVal.state_name}
                            </Option>
                        ))}
                    </Select>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label required style={{ display: 'block', marginTop: '2rem' }}>
                        City
                    </Label>
                    <Select
                        name="city"
                        id="city"
                        style={{ width: '80%' }}
                        valueState={inputBox.city.valueState}
                        valueStateMessage={inputBox.city.valueStateMessage}
                        onChange={(e) => onSelectionChange(e)}
                        disabled={states.length}
                    >
                        <Option value={''}>Select City</Option>
                        {cities?.map((cityVal) => (
                            <Option key={cityVal.city_id} value={cityVal.city_id}>
                                {cityVal.city_name}
                            </Option>
                        ))}
                    </Select>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label required style={{ display: 'block', marginTop: '2rem' }}>
                        Pincode
                    </Label>
                    <Input
                        id="pincode"
                        valueState={inputBox.pincode.valueState}
                        valueStateMessage={inputBox.pincode.valueStateMessage}
                        name="pincode"
                        onInput={(e) => onInputChange(e)}
                        style={{ width: '80%' }}
                    />
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label required style={{ display: 'block', marginTop: '2rem' }}>
                        Address
                    </Label>
                    <TextArea
                        valueState={inputBox.address.valueState}
                        valueStateMessage={inputBox.address.valueStateMessage}
                        id="address"
                        name="address"
                        onInput={(e) => onInputChange(e)}
                        style={{ width: '80%', height: '200%' }}
                    />
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label required style={{ display: 'block', marginTop: '2rem' }}>
                        PAN
                    </Label>
                    <Input
                        id="pan"
                        valueState={inputBox.pan.valueState}
                        valueStateMessage={inputBox.pan.valueStateMessage}
                        name="pan"
                        style={{ width: '80%' }}
                        onInput={(e) => onInputChange(e)}
                    />
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label required style={{ display: 'block', marginTop: '2rem' }}>
                        Phone Number
                    </Label>
                    <Input
                        id="phoneNumber"
                        valueState={inputBox.phoneNumber.valueState}
                        valueStateMessage={inputBox.phoneNumber.valueStateMessage}
                        name="phoneNumber"
                        style={{ width: '80%' }}
                        onInput={(e) => onInputChange(e)}
                    />
                </div>
                <FlexBox data-layout-span="XL12 L12 M12 S12" justifyContent="End">
                    <Button
                        style={{
                            marginTop: '12px',
                            marginRight: '5%'
                        }}
                        design="Emphasized"
                        onClick={submitBusinessInfoForm}
                    >
                        Save
                    </Button>
                </FlexBox>
            </Grid>
        </>
    );
};

const mapStateToProps = (state) => {
    return {
        industry: state.account.industry,
        states: state.account.states,
        cities: state.account.cities,
        isLoading: isApproverInfoLoading(state),
        userInfo: getUserInfo(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetIndustry: () => dispatch(getIndustry()),
        startGetStates: () => dispatch(getStates()),
        startGetCities: (stateId) => dispatch(getCities(stateId)),
        startUpdateBusinessInfo: (payload) => dispatch(updateBusinessInfo(payload))
    };
};

BusinessProfile.propTypes = {
    onNextClick: PropTypes.func,
    startUpdateBusinessInfo: PropTypes.func,
    startGetStates: PropTypes.func,
    startGetCities: PropTypes.func,
    startGetIndustry: PropTypes.func,
    cities: PropTypes.array,
    states: PropTypes.array,
    industry: PropTypes.array,
    isLoading: PropTypes.bool,
    userInfo: PropTypes.object
};

BusinessProfile.defaultProps = {
    industry: [],
    states: [],
    cities: []
};

export default connect(mapStateToProps, mapDispatchToProps)(BusinessProfile);
