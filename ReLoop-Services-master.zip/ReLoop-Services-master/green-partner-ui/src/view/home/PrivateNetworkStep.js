import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Button, Grid, Input, Title, Label, FlexBox, Icon, Loader } from '@ui5/webcomponents-react';
import { registerBPNetworkInfo } from '../../store/action/taskAction';
import { spacing } from '@ui5/webcomponents-react-base';
import validateInput from '../../validation/PrivateNetworkData';
import { isApproverInfoLoading } from '../../selectors/common';
import { camelCaseToSentence } from '../../utils/formatter';
import { showMessage } from './../../store/action/type';

const PrivateNetworkStep = ({ onNextClick, startRegisterBPNetworkInfo, isLoading, startShowMessage }) => {
    const [inputBox, setInputBox] = useState([
        {
            companyName: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                required: true
            },
            contactName: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                required: false
            },
            emailAddress: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                required: true
            }
        }
    ]);

    const onSave = () => {
        let isValid = true;
        let tempInputBox = [...inputBox];
        if (!tempInputBox.length) {
            isValid = false;
            startShowMessage({
                message: 'Add Private Network to continue.',
                status: 'Negative'
            });
        } else {
            tempInputBox.map((input, idx) => {
                Object.keys(input).map((field) => {
                    // check to find whether value is empty for required fields
                    if (tempInputBox[idx][field]['required'] && tempInputBox[idx][field]['value'] === '') {
                        let fieldName = camelCaseToSentence(field);
                        tempInputBox[idx][field]['valueState'] = 'Error';
                        tempInputBox[idx][field]['valueStateMessage'] = <span>{fieldName} is required</span>;
                        isValid = false;
                    }
                    // check to find whether any field has error state
                    if (tempInputBox[idx][field]['valueState'] === 'Error') {
                        isValid = false;
                    }
                });
            });
        }
        if (isValid) {
            const payload = { pvtNwkMembers: [] };
            inputBox.map((input) => {
                payload.pvtNwkMembers.push({
                    emailId: input.emailAddress.value,
                    username: input.companyName.value,
                    contactName: input.contactName.value
                });
            });
            startRegisterBPNetworkInfo(payload)
                .then(() => onNextClick('3'))
                .catch(() => console.log('Something went wrong!'));
        } else {
            setInputBox(tempInputBox);
        }
    };

    const onInputChange = (event) => {
        let tempInputBox = [...inputBox];
        let id = event.target.id;
        let split = id.split('-');
        let field = split[0];
        let idx = split[1];
        let { isValid, errorMessage } = validateInput(event.target.value, field, tempInputBox[idx][field]);
        tempInputBox[idx][field]['value'] = event.target.value;
        tempInputBox[idx][field]['valueStateMessage'] = <span>{errorMessage}</span>;
        if (isValid) {
            tempInputBox[idx][field]['valueState'] = 'None';
        } else {
            tempInputBox[idx][field]['valueState'] = 'Error';
        }
        setInputBox(tempInputBox);
    };

    const onDeleteClick = (index) => {
        let tempInputBox = [...inputBox];
        tempInputBox = tempInputBox.filter((value, idx) => idx !== index);
        setInputBox(tempInputBox);
    };

    return (
        <>
            <FlexBox alignItems="Center" direction="Column">
                {isLoading && <Loader />}
                <Title style={{ fontSize: 'larger', marginTop: '2rem' }}>
                    Set your Private Network by adding all the vendors you are currently working with.
                </Title>
                <Title style={{ fontSize: 'larger', marginTop: '0.5rem' }}>
                    This step could be skipped and set up later under{' '}
                    <b>Menu &gt; Account Management &gt; Private Network.</b>
                </Title>
            </FlexBox>
            <Grid style={{ margin: '20px' }}>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label required style={{ fontSize: 'larger', marginTop: '2rem' }}>
                        Company Name
                    </Label>
                </div>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label style={{ fontSize: 'larger', marginTop: '2rem' }}>Contact Name</Label>
                </div>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label required style={{ fontSize: 'larger', marginTop: '2rem' }}>
                        Email Address
                    </Label>
                </div>
                {inputBox.map((inputElements, index) =>
                    Object.keys(inputElements).map((inputElement, idx) => (
                        <div key={idx} data-layout-span="XL4 L4 M4 S4">
                            <Input
                                id={inputElement + '-' + index}
                                value={inputElements[inputElement].value}
                                valueState={inputElements[inputElement].valueState}
                                valueStateMessage={inputElements[inputElement].valueStateMessage}
                                onInput={onInputChange}
                            />
                            {idx === Object.keys(inputElements).length - 1 ? (
                                <Icon
                                    id={'delete-' + index}
                                    name="delete"
                                    onClick={() => onDeleteClick(index)}
                                    tooltip="Delete Row"
                                    style={{ ...spacing.sapUiTinyMarginBegin, width: '1.5rem', cursor: 'pointer' }}
                                />
                            ) : null}
                        </div>
                    ))
                )}
            </Grid>
            <Button
                design="Transparent"
                style={{ color: 'blue', marginLeft: '15px' }}
                onClick={() => {
                    let tempInputBox = [...inputBox];
                    tempInputBox.push({
                        companyName: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            required: true
                        },
                        contactName: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            required: false
                        },
                        emailAddress: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            required: true
                        }
                    });
                    setInputBox(tempInputBox);
                }}
            >
                + Add Vendor
            </Button>
            <Grid style={{ ...spacing.sapUiMediumMarginTop }}>
                <div data-layout-indent="XL8 L8 M8 S8" data-layout-span="XL4 L4 M4 S4">
                    <Button style={{ ...spacing.sapUiSmallMarginEnd }} onClick={() => onNextClick('3')}>
                        Skip
                    </Button>
                    <Button onClick={() => onSave()} design="Emphasized">
                        Save &amp; Go Next
                    </Button>
                </div>
            </Grid>
        </>
    );
};

const mapStateToProps = (state) => {
    return {
        isLoading: isApproverInfoLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startRegisterBPNetworkInfo: (payload) => dispatch(registerBPNetworkInfo(payload)),
        startShowMessage: (payload) => dispatch(showMessage(payload))
    };
};

PrivateNetworkStep.propTypes = {
    onNextClick: PropTypes.func,
    startRegisterBPNetworkInfo: PropTypes.func,
    isLoading: PropTypes.bool,
    startShowMessage: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(PrivateNetworkStep);
