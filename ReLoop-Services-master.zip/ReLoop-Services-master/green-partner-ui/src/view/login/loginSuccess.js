import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import { getAccessToken } from '../../store/action/taskAction';
import LoadingIndicator from '../common/Loading';
import ErrorComponent from '../common/Error';

const LoginSuccess = ({ userInfo, isLoading = true, startGetAccessToken }) => {
    useEffect(() => {
        startGetAccessToken();
    }, []);

    const redirect = (isInitialSetupDone) => {
        return isInitialSetupDone ? <Redirect to="/order/newOrder" /> : <Redirect to="/initialSetup" />;
    };

    if (isLoading) {
        return <LoadingIndicator />;
    } else {
        const isInitialSetupDone = userInfo.isBusinessDataPresent;
        return userInfo.isLoggedIn ? redirect(isInitialSetupDone) : <ErrorComponent text="Login Failed" redirect />;
    }
};

const mapStateToProps = (state) => {
    return {
        isLoading: state.isLoading,
        userInfo: state.userInfo
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetAccessToken: () => dispatch(getAccessToken())
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(LoginSuccess);
