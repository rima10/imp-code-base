const GST_REGEX = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
const GST_MAXLENGTH = 15;
const PAN_REGEX = /(^([a-zA-Z]{5})([0-9]{4})([a-zA-Z]{1})$)/;
const EMAIL_REGEX = /^\S+@\S+\.\S+$/;
const PHONE_LENGTH = 10;
const PHONE_REGEX = /^(\+91[\-\s]?)?[0]?(91)?[6789]\d{9}$/;
const COMPANYCODE_LENGTH = 10;
const CIN_NO_LENGTH = 21;
const PINCODE_REGEX = /^[1-9][0-9]{5}$/;
const COMPANYCODE_REGEX = /^[0-9]{4}$/;
const CIN_REGEX = /^[a-zA-Z0-9]{21}$/;

export {
    GST_REGEX,
    GST_MAXLENGTH,
    PAN_REGEX,
    EMAIL_REGEX,
    PHONE_LENGTH,
    PHONE_REGEX,
    COMPANYCODE_LENGTH,
    PINCODE_REGEX,
    COMPANYCODE_REGEX,
    CIN_NO_LENGTH,
    CIN_REGEX
};
