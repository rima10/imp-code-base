import {
    ORDER_INFO_LOADING,
    SET_ORDER_INFO,
    ORDER_INFO_FAILED,
    ORDER_ITEM_INFO_LOADING,
    SET_ORDER_ITEM_INFO,
    ORDER_ITEM_INFO_FAILED,
    SET_PREVIEW_ORDER_ITEM_INFO,
    CLEAR_PREVIEW_ORDER_ITEMS,
    CONSOLIDATED_ORDER_ITEM_INFO_LOADING,
    SET_CONSOLIDATED_ORDER_ITEM_INFO,
    CONSOLIDATED_ORDER_ITEM_INFO_FAILED,
    ORDER_QUOTATION_LOADING,
    SET_ORDER_QUOTATION,
    ORDER_QUOTATION_FAILED,
    SET_ORDERTYPE_INFO,
    SET_CATEGORY_INFO,
    SET_SUBCATEGORY_INFO,
    SET_APPROVER,
    ONSITE_VISIT_LOADING,
    SET_ONSITE_VISIT_DETAILS,
    ONSITE_VISIT_FAILED,
    SET_ORDER_ITEM_QUOTATION,
    PRIVATE_NETWORK_OWNER_LOADING,
    SET_PRIVATE_NETWORK_OWNER,
    PRIVATE_NETWORK_OWNER_FAILED,
    SET_UPDATED_ORDER_ITEMS,
    SET_UPDATED_ORDER_HEADER_DATA
} from '../action/type';

const initialState = {
    isLoading: true,
    isOnsiteLoading: true,
    onsiteErrMsg: null,
    errMsg: null,
    orderInfo: [],
    orderItemInfo: {},
    isOrderItemInfoLoading: true,
    orderItemInfoErrMsg: null,
    consolidatedOrderItemInfo: {},
    isConsolidatedOrderItemInfoLoading: true,
    consolidatedOrderItemInfoErrMsg: null,
    previewOrderItemInfo: [],
    orderQuotation: {},
    isOrderQuotationLoading: true,
    orderQuotationErrMsg: null,
    approver: { 1: [], 3: [], 5: [] },
    onSiteVisitDetails: {},
    orderItemQuotation: []
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case ORDER_INFO_LOADING:
            return { ...state, isLoading: true, errMsg: null, orderInfo: [] };

        case SET_ORDER_INFO:
            return { ...state, isLoading: false, errMsg: null, orderInfo: payload };

        case ORDER_INFO_FAILED:
            return { ...state, isLoading: false, errMsg: payload, orderInfo: [] };

        case ORDER_ITEM_INFO_LOADING:
            return { ...state, isOrderItemInfoLoading: true, orderItemInfoErrMsg: null, orderItemInfo: {} };

        case SET_ORDER_ITEM_INFO:
            return { ...state, isOrderItemInfoLoading: false, orderItemInfoErrMsg: null, orderItemInfo: payload };

        case ORDER_ITEM_INFO_FAILED:
            return { ...state, isOrderItemInfoLoading: false, orderItemInfoErrMsg: payload, orderItemInfo: {} };

        case SET_PREVIEW_ORDER_ITEM_INFO:
            return { ...state, previewOrderItemInfo: payload };

        case CLEAR_PREVIEW_ORDER_ITEMS:
            return { ...state, previewOrderItemInfo: [] };

        case CONSOLIDATED_ORDER_ITEM_INFO_LOADING:
            return {
                ...state,
                isConsolidatedOrderItemInfoLoading: true,
                consolidatedOrderItemInfoErrMsg: null,
                consolidatedOrderItemInfo: {}
            };

        case SET_CONSOLIDATED_ORDER_ITEM_INFO:
            return {
                ...state,
                isConsolidatedOrderItemInfoLoading: false,
                consolidatedOrderItemInfoErrMsg: null,
                consolidatedOrderItemInfo: payload
            };

        case CONSOLIDATED_ORDER_ITEM_INFO_FAILED:
            return {
                ...state,
                isConsolidatedOrderItemInfoLoading: false,
                consolidatedOrderItemInfoErrMsg: payload,
                consolidatedOrderItemInfo: {}
            };

        case ORDER_QUOTATION_LOADING:
            return { ...state, isOrderQuotationLoading: true, orderQuotationErrMsg: null, orderQuotation: {} };

        case SET_ORDER_QUOTATION:
            return { ...state, isOrderQuotationLoading: false, orderQuotationErrMsg: null, orderQuotation: payload };

        case ORDER_QUOTATION_FAILED:
            return { ...state, isOrderQuotationLoading: false, orderQuotationErrMsg: payload, orderQuotation: {} };

        case SET_ORDERTYPE_INFO:
            return { ...state, orderType: payload };

        case SET_CATEGORY_INFO:
            return { ...state, category: payload };

        case SET_SUBCATEGORY_INFO:
            return { ...state, subcategory: payload };

        case SET_APPROVER:
            const approvers = payload.workflowApprovers || [];
            const { processStageSequence } = payload;
            const approverObj = { ...state.approver };
            approverObj[processStageSequence] = approvers;
            return { ...state, approver: approverObj };

        case ONSITE_VISIT_LOADING:
            return { ...state, isOnsiteLoading: true, onsiteErrMsg: null, onSiteVisitDetails: {} };

        case SET_ONSITE_VISIT_DETAILS:
            return {
                ...state,
                isOnsiteLoading: false,
                onsiteErrMsg: null,
                onSiteVisitDetails: payload || {}
            };

        case ONSITE_VISIT_FAILED:
            return { ...state, isOnsiteLoading: false, onsiteErrMsg: payload, onSiteVisitDetails: {} };

        case SET_ORDER_ITEM_QUOTATION:
            return { ...state, orderItemQuotation: payload };

        case PRIVATE_NETWORK_OWNER_LOADING:
            return { ...state, isPrivateNetworkLoading: true, privateNetworkErrMsg: null, privateNetworkOwner: {} };

        case SET_PRIVATE_NETWORK_OWNER:
            return { ...state, privateNetworkOwner: payload };

        case PRIVATE_NETWORK_OWNER_FAILED:
            return { ...state, isPrivateNetworkLoading: false, privateNetworkErrMsg: payload, privateNetworkOwner: {} };

        case SET_UPDATED_ORDER_ITEMS:
            if (state.orderItemInfo) {
                state.orderItemInfo.orderItems = payload;
            }
            return { ...state };

        case SET_UPDATED_ORDER_HEADER_DATA:
            const index = state.orderInfo.findIndex((order) => order.orderId === payload.orderId);
            if (index !== -1) {
                Object.keys(state.orderInfo[index]).forEach((field) => {
                    state.orderInfo[index][field] = payload[field];
                });
            }

            return { ...state, orderItemInfo: payload };
        default:
            return state;
    }
};
