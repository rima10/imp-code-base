import {
    setUserInfo,
    loadInProgress,
    loadCompleted,
    setBusinessInfo,
    accountInfoLoading,
    accountInfoFailed,
    setNetworkInfo,
    setApproverInfo,
    setCitiesInfo,
    setStatesInfo,
    setIndustryInfo,
    setWorkflowInfo,
    showMessage,
    setNotificationsInfo,
    setOrderTypeInfo,
    setCategoryInfo,
    setSubCategoryInfo,
    setPreviewOrderItemInfo,
    orderInfoLoading,
    privateNetworkOwnerLoading,
    setPrivateNetworkOwner,
    privateNetworkOwnerFailed
} from './type';
import { getToken } from '../../utils/authUtils';
import http from '../../utils/httpService';
import { getErrorMessage } from '../../utils/errorMessage';
import { getOrderInfo } from './order';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

export const validateUser = (tokenObj) => async (dispatch, getState) => {
    try {
        const isLoggedIn = getState().userInfo.isLoggedIn;
        if (!isLoggedIn) {
            dispatch(loadInProgress());
            let params = {
                withCredentials: true
            };
            if (tokenObj) {
                params.headers = {
                    authorization: 'Bearer ' + tokenObj.idToken,
                    refresh: tokenObj.refreshToken
                };
            }
            const response = await http.axiosPost(API_BASE_URL + 'auth/validate?app=gp', null, params);
            const cognitoId = response.data.cognitoId;
            // eslint-disable-next-line max-len
            const userData = await http.get(API_BASE_URL + `user/getUserData/${cognitoId}?bp=gp`, { withCredentials: true });
            userData.data['cognitoId'] = cognitoId;
            const csrfData = await http.head(API_BASE_URL + 'getCsrf', { withCredentials: true });
            const csrf = csrfData.headers['csrf-token'];
            dispatch(setUserInfo(userData.data, true, csrf));
            dispatch(loadCompleted());
        }
    } catch (error) {
        dispatch(setUserInfo(null, false));
        dispatch(loadCompleted());
    }
};

export const getAccessToken = () => async (dispatch, getState) => {
    const tokenObj = await getToken();
    await validateUser(tokenObj)(dispatch, getState);
};

export const logout = () => async () => {
    await http.post(`${API_BASE_URL}auth/logout`, null, {
        withCredentials: true
    });
};

export const getBusinessInfo = () => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const response = await http.get(`${API_BASE_URL}user/getBusinessInfo`, {
            withCredentials: true
        });
        dispatch(setBusinessInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const getNetworkInfo = () => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const response = await http.get(`${API_BASE_URL}user/getprivatenetwork`, {
            withCredentials: true
        });
        dispatch(setNetworkInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const getApproverInfo = () => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const response = await http.get(`${API_BASE_URL}user/approver/getApprovers`, {
            withCredentials: true
        });
        dispatch(setApproverInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const getStates = () => async (dispatch, getState) => {
    const response = await http.get(`${API_BASE_URL}user/loc/getStatesbyCountry/1`, {
        withCredentials: true
    });
    dispatch(setStatesInfo(response.data));
};

export const getCities = (stateId) => async (dispatch, getState) => {
    const response = await http.get(`${API_BASE_URL}user/loc/getCitiesbyState/${stateId}`, {
        withCredentials: true
    });
    dispatch(setCitiesInfo(response.data));
};

export const getIndustry = () => async (dispatch, getState) => {
    dispatch(
        setIndustryInfo([
            'IT & Telecommunications',
            'Oil & Gas',
            'Retail',
            'Mining',
            'Public Sector',
            'High Tech',
            'Banking',
            'Higher Education'
        ])
    );
};

export const updateBusinessInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        await http.patch(`${API_BASE_URL}user/update`, payload, {
            withCredentials: true
        });
        dispatch(showMessage({ message: 'Successfully added business information!', status: 'Positive' }));
        await getBusinessInfo()(dispatch, getState);
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
        console.log(error);
        throw new Error(error);
    }
};

export const registerBPApproverInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        await http.post(`${API_BASE_URL}user/approver/addApprovers`, payload, {
            withCredentials: true
        });
        await getApproverInfo()(dispatch, getState);
        dispatch(showMessage({ message: 'Approver Added', status: 'Positive' }));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
        throw new Error(error);
    }
};

export const registerBPNetworkInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        await http.post(`${API_BASE_URL}user/createPrivateNetwork?bp=gp`, payload, {
            withCredentials: true
        });
        await getNetworkInfo()(dispatch, getState);
        dispatch(showMessage({ message: 'Private Network Added', status: 'Positive' }));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
        throw new Error(error);
    }
};

export const getWorkflowsInfo = () => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const response = await http.get(`${API_BASE_URL}user/workflow/getWorkflows`, {
            withCredentials: true
        });
        dispatch(setWorkflowInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const registerBPWorkflowInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        await http.post(`${API_BASE_URL}user/workflow/addWorkflow`, payload, {
            withCredentials: true
        });
        await getWorkflowsInfo()(dispatch, getState);
        dispatch(showMessage({ message: 'Workflow Added', status: 'Positive' }));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
        throw new Error(error);
    }
};

export const updateOrderInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(orderInfoLoading());
        await http.post(`${API_BASE_URL}order/createOrder`, payload, {
            withCredentials: true
        });
        dispatch(getOrderInfo()(dispatch, getState));
    } catch (error) {
        console.log(error);
    }
};

export const deleteBPNetworkInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        await http.delete(`${API_BASE_URL}user/deleteprivatenetwork`, {
            data: payload,
            withCredentials: true
        });
        await getNetworkInfo()(dispatch, getState);
        dispatch(showMessage({ message: 'Private Network Deleted', status: 'Positive' }));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const deleteBPApproverInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const response = await http.delete(`${API_BASE_URL}user/approver/deleteApprovers`, {
            data: payload,
            withCredentials: true
        });
        dispatch(setApproverInfo(response.data));
        dispatch(showMessage({ message: 'Approver Deleted', status: 'Positive' }));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const readExcelInfo = (payload) => async (dispatch, getState) => {
    try {
        const response = await http.post(`${API_BASE_URL}order/orderItem/readExcel`, payload, {
            withCredentials: true
        });
        if (response.data.length === 0) {
            dispatch(showMessage({ message: 'No asset data present in excel', status: 'Negative' }));
        } else dispatch(setPreviewOrderItemInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(showMessage({ message: errorMessage, status: 'Negative' }));
        return Promise.reject(error);
    }
};

export const deleteBPWorkflowInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const workflowId = payload.workflowId;
        const processTypeId = payload.processTypeId;
        // eslint-disable-next-line max-len
        const response = await http.delete(`${API_BASE_URL}user/workflow/deleteWorkflow/${workflowId}/${processTypeId}`, {
            withCredentials: true
        });
        dispatch(setWorkflowInfo(response.data));
        dispatch(showMessage({ message: 'Workflow Deleted', status: 'Positive' }));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const deleteBPWorkflowApproverInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const userId = getState().userInfo.bp_id;
        await http.delete(`${API_BASE_URL}user/workflow/deleteWorkflowApprover/${userId}`, {
            data: payload,
            withCredentials: true
        });
        await getWorkflowsInfo()(dispatch, getState);
        dispatch(showMessage({ message: 'Workflow Approver Deleted', status: 'Positive' }));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const getNotificationInfo = () => async (dispatch, getState) => {
    try {
        const notifications = await http.get(`${API_BASE_URL}notification/getNotifications?$skip=0&top=5`, {
            withCredentials: true
        });
        dispatch(setNotificationsInfo(notifications.data));
    } catch (error) {
        console.log(error);
    }
};

export const readNotification = (bpNotificationId) => async (dispatch, getState) => {
    try {
        await http.post(`${API_BASE_URL}notification/readNotification/${bpNotificationId}`, null, {
            withCredentials: true
        });
        dispatch(getNotificationInfo()(dispatch, getState));
    } catch (error) {
        console.log(error);
    }
};

export const updateDraftOrderInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(orderInfoLoading());
        await http.post(`${API_BASE_URL}order/createOrderAsDraft`, payload, {
            withCredentials: true
        });
        dispatch(getOrderInfo()(dispatch, getState));
    } catch (error) {
        console.log(error);
    }
};

export const getOrderType = () => async (dispatch, getState) => {
    const response = await http.get(`${API_BASE_URL}order/getOrderType`, {
        withCredentials: true
    });
    dispatch(setOrderTypeInfo(response.data));
};

export const getCategory = () => async (dispatch, getState) => {
    const response = await http.get(`${API_BASE_URL}wasteCategory/getCategory`, {
        withCredentials: true
    });
    dispatch(setCategoryInfo(response.data));
};

export const getSubCategory = () => async (dispatch, getState) => {
    const response = await http.get(`${API_BASE_URL}wasteCategory/getsubCategory/1`, {
        withCredentials: true
    });
    dispatch(setSubCategoryInfo(response.data));
};

export const getPrivateNetworkRecyclers = () => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const response = await http.get(`${API_BASE_URL}order/privatenetwork`, {
            withCredentials: true
        });
        dispatch(setNetworkInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const downloadFile = async (orderId, key) => {
    try {
        const response = await http.get(`${API_BASE_URL}order/document/downloadDocument/${orderId}/${key}`, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([response.data]);
        const url = window.URL.createObjectURL(responseBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = key;
        a.click();
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        console.log(errorMessage);
    }
};

export const getUserData = () => async (dispatch, getState) => {
    try {
        const cognitoId = getState().userInfo.cognitoId;
        const userData = await http.get(API_BASE_URL + `user/getUserData/${cognitoId}?bp=gp`, {
            withCredentials: true
        });
        dispatch(setUserInfo(userData.data, true));
    } catch (error) {
        console.log(error);
    }
};

export const getPrivateNetworkOwner = () => async (dispatch, getState) => {
    try {
        dispatch(privateNetworkOwnerLoading(true));
        const response = await http.get(`${API_BASE_URL}order/getNetworkOwner`, {
            withCredentials: true
        });
        dispatch(setPrivateNetworkOwner(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(privateNetworkOwnerFailed(errorMessage));
    }
};
export const downloadPrivacyStatement = (key) => async (dispatch, getState) => {
    try {
        const downloadPromise = await http.get(`${API_BASE_URL}user/privacyStatement/${key}`, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([downloadPromise.data], { type: downloadPromise.headers['content-type'] });
        const url = window.URL.createObjectURL(responseBlob);
        window.open(url, '_blank');
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        console.log(errorMessage);
    }
};

export const getGPPersonalData = () => async (dispatch) => {
    try {
        const response = await http.get(API_BASE_URL + `user/getGPPersonalData`, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([response.data]);
        const url = window.URL.createObjectURL(responseBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `EverLoop_Personal_Data_${new Date().toLocaleString()}.xlsx`;
        a.click();
    } catch (error) {
        console.log(error);
    }
};
