import {
    orderInfoLoading,
    setOrderInfo,
    orderInfoFailed,
    orderItemInfoLoading,
    setOrderItemInfo,
    orderItemInfoFailed,
    consolidatedOrderItemInfoLoading,
    setConsolidatedOrderItemInfo,
    consolidatedOrderItemInfoFailed,
    orderQuotationLoading,
    setOrderQuotation,
    orderQuotationFailed,
    setOnsiteVisitDetails,
    onsiteVisitDetailsLoading,
    onsiteVisitDetailsFailed,
    // setTemporaryAcceptQuote,
    setOrderApprover,
    setOrderItemQuotation,
    setOrderDocuments,
    orderDocumentsLoading,
    orderDocumentsFailed,
    orderDocumentsLoaded,
    showMessage,
    setOrderItems,
    setOrderHeaderData
} from './type';
import http from '../../utils/httpService';
import { getErrorMessage } from '../../utils/errorMessage';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

export const getOrderInfo = () => async (dispatch, getState) => {
    try {
        dispatch(orderInfoLoading());
        const response = await http.get(`${API_BASE_URL}order/getOrders`, {
            withCredentials: true
        });
        dispatch(setOrderInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderInfoFailed(errorMessage));
    }
};

export const getRefurbishOrderItemInfo = (orderId) => async (dispatch) => {
    try {
        dispatch(orderItemInfoLoading());
        const response = await http.get(`${API_BASE_URL}order/getRefurbishOrderByOrderId/${orderId}`, {
            withCredentials: true
        });
        dispatch(setOrderItemInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderItemInfoFailed(errorMessage));
    }
};

export const getRecycleOrderItemInfo = (orderId) => async (dispatch) => {
    try {
        dispatch(orderItemInfoLoading());
        const response = await http.get(`${API_BASE_URL}order/getRecycleOrderByOrderId/${orderId}`, {
            withCredentials: true
        });
        dispatch(setOrderItemInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderItemInfoFailed(errorMessage));
    }
};

export const getConsolidatedOrderItemInfo = (orderId) => async (dispatch) => {
    try {
        dispatch(consolidatedOrderItemInfoLoading());
        const response = await http.get(`${API_BASE_URL}order/getConsolidatedOrderData/${orderId}`, {
            withCredentials: true
        });
        dispatch(setConsolidatedOrderItemInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(consolidatedOrderItemInfoFailed(errorMessage));
    }
};


export const getRecycleOrderQuotation = (orderId) => async (dispatch) => {
    try {
        dispatch(orderQuotationLoading());
        const response = await http.get(`${API_BASE_URL}order/quotation/getRecycleOrderInitialQuotes/${orderId}`, {
            withCredentials: true
        });
        dispatch(setOrderQuotation(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderQuotationFailed(errorMessage));
    }
};

export const getRefurbishOrderQuotation = (orderId) => async (dispatch) => {
    try {
        dispatch(orderQuotationLoading());
        const response = await http.get(`${API_BASE_URL}order/quotation/getRefurbishOrderInitialQuotes/${orderId}`, {
            withCredentials: true
        });
        dispatch(setOrderQuotation(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderQuotationFailed(errorMessage));
    }
};

export const temporaryAcceptQuote = (orderId, quoteId, orderType) => async (dispatch, getState) => {
    try {
        await http.post(`${API_BASE_URL}order/quotation/temporaryAcceptQuote/${orderId}/${quoteId}`, null, {
            withCredentials: true
        });
        if (orderType === '1') await getRefurbishOrderQuotation(orderId)(dispatch, getState);
        else await getRecycleOrderQuotation(orderId)(dispatch, getState);
    } catch (error) {
        getErrorMessage(error);
    }
};

export const rejectQuote = (orderId, quoteId, orderType) => async (dispatch, getState) => {
    try {
        await http.post(`${API_BASE_URL}order/quotation/rejectQuote/${orderId}/${quoteId}`, null, {
            withCredentials: true
        });
        if (orderType === '1') await getRefurbishOrderQuotation(orderId)(dispatch, getState);
        else await getRecycleOrderQuotation(orderId)(dispatch, getState);
    } catch (error) {
        getErrorMessage(error);
    }
};

export const setMoveToNextStep = (orderId, nextStage, orderType, addApprovers) => async (dispatch, getState) => {
    try {
        let url = `${API_BASE_URL}order/moveOrderToNextStep/${orderId}/${nextStage}`;
        if (addApprovers === false) url = url + '?addApprovers=false';
        await http.post(url, null, {
            withCredentials: true
        });
        if (orderType === '1') await getRefurbishOrderItemInfo(orderId)(dispatch, getState);
        else await getRecycleOrderItemInfo(orderId)(dispatch, getState);
    } catch (error) {
        getErrorMessage(error);
    }
};

export const acceptQuote = (orderId, payload, orderType) => async (dispatch, getState) => {
    try {
        await http.post(`${API_BASE_URL}order/quotation/acceptQuote/${orderId}`, payload, {
            withCredentials: true
        });
        if (orderType === '1') await getRefurbishOrderQuotation(orderId)(dispatch, getState);
        else await getRecycleOrderQuotation(orderId)(dispatch, getState);
        await setMoveToNextStep(orderId, '4')(dispatch, getState);
    } catch (error) {
        getErrorMessage(error);
    }
};

export const getApprover = (orderId, processType, sequenceNo) => async (dispatch) => {
    try {
        // eslint-disable-next-line max-len
        const response = await http.get(`${API_BASE_URL}order/getStageApprovalStatus/${orderId}?processType=${processType}&processStageSequence=${sequenceNo}`, {
            withCredentials: true
        });
        dispatch(setOrderApprover(response.data));
    } catch (error) {
        getErrorMessage(error);
    }
};

export const getOnsiteVisitDetails = (orderId) => async (dispatch) => {
    try {
        dispatch(onsiteVisitDetailsLoading());
        const response = await http.get(`${API_BASE_URL}order/quotation/getScheduledOnsiteVisitDetails/${orderId}`, {
            withCredentials: true
        });
        dispatch(setOnsiteVisitDetails(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(onsiteVisitDetailsFailed(errorMessage));
    }
};

export const getRefurbishOrderItemLevelQuote = (orderId, quoteId) => async (dispatch, getState) => {
    try {
        const response = await http.get(`${API_BASE_URL}order/quotation/refurbish/grading/${orderId}/${quoteId}`, {
            withCredentials: true
        });
        dispatch(setOrderItemQuotation(response.data));
    } catch (error) {
        getErrorMessage(error);
    }
};

export const getRecycleOrderItemLevelQuote = (orderId, processType, sequenceNo) => async (dispatch, getState) => {
    try {
        const response = await http.get(`${API_BASE_URL}order/quotation/getRecycleOrderFinalQuote/${orderId}`, {
            withCredentials: true
        });
        dispatch(setOrderItemQuotation(response.data));
    } catch (error) {
        getErrorMessage(error);
    }
};

export const getOrderDocuments = (orderId) => async (dispatch) => {
    try {
        dispatch(orderDocumentsLoading());
        const response = await http.get(`${API_BASE_URL}order/document/getOrderDocuments/${orderId}`, {
            withCredentials: true
        });
        dispatch(setOrderDocuments(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderDocumentsFailed(errorMessage));
    }
};

export const downloadDocument = (orderId, key) => async (dispatch) => {
    try {
        dispatch(orderDocumentsLoading());
        const response = await http.get(`${API_BASE_URL}order/document/downloadDocument/${orderId}/${key}`, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([response.data]);
        const url = window.URL.createObjectURL(responseBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = key;
        a.click();
        dispatch(orderDocumentsLoaded());
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderDocumentsFailed(errorMessage));
    }
};

export const uploadDocument = (orderId, payload) => async (dispatch) => {
    try {
        dispatch(orderDocumentsLoading());
        await http.post(`${API_BASE_URL}order/document/uploadDocument/${orderId}`, payload, {
            withCredentials: true
        });
        dispatch(getOrderDocuments(orderId)(dispatch));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderDocumentsFailed(errorMessage));
    }
};

export const generateDCDocument = (orderId, payload) => async (dispatch) => {
    try {
        dispatch(orderDocumentsLoading());
        const response = await http.post(`${API_BASE_URL}order/document/generateDC/${orderId}`, payload, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([response.data]);
        const url = window.URL.createObjectURL(responseBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Delivery_Challan_${payload.orderNo}.pdf`;
        a.click();
        dispatch(getOrderDocuments(orderId)(dispatch));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderDocumentsFailed(errorMessage));
    }
};

export const scheduleLogistics = (orderId, payload) => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.bp_id;
        payload.userId = userId;
        await http.post(`${API_BASE_URL}order/scheduleLogistics/${orderId}`, payload, {
            withCredentials: true
        });
        await setMoveToNextStep(orderId, '6')(dispatch, getState);
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderQuotationFailed(errorMessage));
    }
};

export const createOrderWorkflow = (payload) => async (dispatch, getState) => {
    try {
        await http.post(`${API_BASE_URL}order/workflow/createOrderWorkflow/${payload.orderId}`, payload, {
            withCredentials: true
        });
        if (payload.processType === '1') await getRefurbishOrderItemInfo(payload.orderId)(dispatch);
        else await getRecycleOrderItemInfo(payload.orderId)(dispatch);
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderQuotationFailed(errorMessage));
    }
};

export const downloadAssetGradeList = (orderId, quoteId) => async (dispatch, getState) => {
    const downloadPromise = http.get(`${API_BASE_URL}order/quotation/refurbish/grading/${orderId}/${quoteId}/excel`, {
        responseType: 'arraybuffer',
        withCredentials: true
    });
    return downloadPromise;
};

export const cancelOrder = (orderId) => async (dispatch, getState) => {
    try {
        const res = await http.patch(`${API_BASE_URL}order/${orderId}/cancel`, {}, {
            withCredentials: true
        });
        dispatch(getOrderInfo());
        return Promise.resolve(res);
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(showMessage({ message: errorMessage, status: 'Negative' }));
        return Promise.reject(error);
    }
};

export const updateAssetListFromExcel = (orderId, payload) => async (dispatch, getState) => {
    try {
        const response = await http.put(`${API_BASE_URL}order/orderItem/excel/${orderId}`, payload, {
            withCredentials: true
        });
        dispatch(setOrderItems(response.data));
        return response;
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(showMessage({ message: errorMessage, status: 'Negative' }));
        return Promise.reject(error);
    }
};

export const updateOrderHeaderData = (orderId, payload) => async (dispatch, getState) => {
    try {
        const response = await http.patch(`${API_BASE_URL}order/headerData/${orderId}`, payload, {
            withCredentials: true
        });
        dispatch(setOrderHeaderData(response.data));
        return Promise.resolve(response);
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(showMessage({ message: errorMessage, status: 'Negative' }));
        return Promise.reject(error);
    }
};

export const completeOrder = (orderId) => async (dispatch, getState) => {
    try {
        const res = await http.patch(`${API_BASE_URL}order/${orderId}/complete`, {}, {
            withCredentials: true
        });
        dispatch(getOrderInfo());
        return Promise.resolve(res);
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(showMessage({ message: errorMessage, status: 'Negative' }));
        return Promise.reject(error);
    }
};
