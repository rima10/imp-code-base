import { hot } from 'react-hot-loader';
import React, { Component } from "react";
import { ThemeProvider } from '@ui5/webcomponents-react';
import { BrowserRouter, Route, Switch } from "react-router-dom";
import { Provider } from "react-redux";
import { store } from "./store/store";
import LoginSuccess from './view/login/loginSuccess';
import '@ui5/webcomponents/dist/Assets.js';
import Main from './view/Main';
import PrivateRoute from './view/login/PrivateRoute';
import ErrorComponent from './view/common/Error';
import CognitoRedirect from './view/login/CognitoRedirect';

class App extends Component {
    constructor (props) {
        super(props);
    }

    render () {
        return (
            <Provider store = {store}>
                <ThemeProvider>
                    <BrowserRouter>
                        <Switch>
                            <Route path="/loginSuccessful">
                                <LoginSuccess/>
                            </Route>

                            <Route exact path="/logout"
                                component={() => <ErrorComponent text="User signed out" redirect/>} />
                            <Route exact path="/login" component={CognitoRedirect} />
                            <PrivateRoute path="/" component= {Main}/>
                        </Switch>
                    </BrowserRouter>
                </ThemeProvider>
            </Provider>
        );
    }
}
export default hot(module)(App);
