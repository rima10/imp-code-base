import { validateEmail, validateContactNumber, validateIsEmpty } from './common';

const validateInput = (value, field, fieldConfig) => {
    if (field === 'emailAddress') {
        return validateEmail(value);
    } else if (field === 'phoneNumber') {
        return validateContactNumber(value, fieldConfig.required);
    } else if (field === 'companyName') {
        return validateIsEmpty(value, field);
    } else {
        return { isValid: true, errorMessage: '' };
    }
};

export default validateInput;
