const quoteRepo = require('../../repo/quotation.repo');

exports.isQuoteAccepted = async (req, res, next) => {
  const { orderId } = req.params;
  const { userId } = req.userInfo;
  const { bp } = req.query;
  if (bp === 'rp') {
    const isAccepted = await quoteRepo.checkQuoteStatus(orderId, userId);
    if (!isAccepted) {
      res.status(403).json({
        error: {
          message: 'Unauthorized to access the data',
        },
      });
      next(new Error('Unauthorized to access the data'));
    } else next();
  } else next();
};
