const {
  check, param, query, validationResult,
} = require('express-validator');

exports.createUserValidations = [
  check('bp_userid').exists(),
  check('bp_username').exists(),
];
exports.scheduleLogisticsValidations = [
  param('orderId').isNumeric(),
  check('scheduledLogisticDate').exists(),
];
exports.getStageApprovalStatusValidations = [
  param('orderId').isNumeric(),
  query('processType').isNumeric(),
  query('processStageSequence').isNumeric(),
];

exports.orderIdValidations = [
  param('orderId').isNumeric(),
];
exports.userIdValidations = [
  param('userId').isNumeric(),
];
exports.createOrderValidations = [
  check('orderType').exists(),
  check('category').exists(),
  check('subcategory').exists(),
  check('network').exists(),
  check('submissionDeadline').exists(),
  check('recyclerIds').exists(),
  check('processStageSequence').exists(),
  check('assetExcel').custom((value, { req }) => {
    if (req.files.assetExcel[0].mimetype === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
      return true;
    }
    return false;
  }).withMessage('Please only submit excel documents.'),
];

exports.orderHeaderDataValidations = [
  check('orderType').exists(),
  check('category').exists(),
  check('subcategory').exists(),
  check('network').exists(),
  check('submissionDeadline').exists(),
  check('recyclerIds').exists(),
];

exports.categoryIdValidations = [
  param('categoryID').isNumeric(),
];
exports.createCategoryValidations = [
  check('categories').exists(),
  check('categories').isArray(),
  check('categories.*.categoryName').exists(),
];
exports.createSubCategoryValidations = [
  param('categoryID').isNumeric(),
  check('subcategories').exists(),
  check('subcategories').isArray(),
  check('subcategories.*.subcategoryName').exists(),
];
exports.createOrderWorkflowValidations = [
  check('orderId').isNumeric(),
  check('processType').isNumeric(),
  check('processStageSequence').isNumeric(),
];

exports.approverIdValidations = [
  param('approverId').isNumeric(),
];
exports.genearteDCValidations = [
  param('orderId').isNumeric(),
  check('orderNo').isAlphanumeric(),
  check('dcNo').exists(),
  check('dcNo').notEmpty(),
  check('gst').isNumeric(),
  check('hsnCode').isNumeric(),
];
exports.inviteRecyclersValidations = [
  param('userId').isNumeric(),
  check('orderId').isNumeric(),
  check('recyclers').exists(),
  check('recyclers').isArray(),
];
exports.acceptQuoteValidations = [
  param('orderId').isNumeric(),
  check('scheduledOnsiteDate').exists(),
  check('estimatedTime').exists(),
];
exports.acceptTemporaryQuoteValidations = [
  param('orderId').isNumeric(),
  param('quoteId').isNumeric(),
];
exports.submitRefurbishFinalQuoteValidations = [
  param('userId').isNumeric(),
  param('orderId').isNumeric(),
  check('orderItemQuotes').exists(),
  check('orderItemQuotes').isArray(),
  check('orderItemQuotes.*.orderItemId').isNumeric(),
  check('orderItemQuotes.*.grade').isLength({
    max: 1,
  }),
  check('orderItemQuotes.*.listPrice').isDecimal(),
  check('orderItemQuotes.*.serviceCost').isDecimal(),
  check('orderItemQuotes.*.toBeInvoiced').isDecimal(),
];

exports.submitRecycleFinalQuoteValidations = [
  param('orderId').isNumeric(),
  check('orderItemQuotes').exists(),
  check('orderItemQuotes').isArray(),
  check('orderItemQuotes.*.finalQty').isNumeric(),
  check('orderItemQuotes.*.pricePerUnit').isNumeric(),
];
exports.submitRefurbishInitialQuoteValidations = [
  check('orderId').isNumeric(),
  check('orderItems').exists(),
  check('orderItems').isArray(),
  check('orderItems.*.price').isDecimal(),
  check('orderItems.*.count').isInt(),
];

exports.submitRecycleInitialQuoteValidations = [
  check('orderId').isNumeric(),
  check('orderItems').exists(),
  check('orderItems').isArray(),
  check('orderItems.*.itemUnit').isString(),
];

exports.validate = async function (req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.status(400).json({ errors: errors.array() });
    next(errors);
  } else next();
};

exports.readExcelFileValidations = [
  check('assetExcel').custom((value, { req }) => {
    if (req.file.mimetype === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
      return true;
    }
    return false;
  }).withMessage('Please only submit excel documents.'),
];

exports.generateForm6Validations = [
  param('orderId').isNumeric(),
  check('orderNo').isAlphanumeric(),
  check('invoiceNo').exists(),
  check('weight').isInt(),
];

exports.generateForm2Validations = [
  param('orderId').isNumeric(),
  check('orderNo').isAlphanumeric(),
  check('weight').isInt(),
];

exports.quoteValidations = [
  param('orderId').isNumeric(),
  param('quoteId').isNumeric(),
];

exports.orderItemGradingValidation = [
  check('orderItemId').exists(),
];
