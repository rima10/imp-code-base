const orderService = require('../services/order.service');

/*
  @desc controller function for create order
*/
exports.createOrder = async function (req, res, next) {
  try {
    const order = await orderService.createOrder(req, res, next);
    res.status(201).json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for create order as draft
*/
exports.createOrderAsDraft = async function (req, res, next) {
  try {
    const order = await orderService.saveOrderAsDraft(req, res, next);
    res.status(201).json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get orders based on business partner id
*/
exports.getOrders = async function (req, res, next) {
  try {
    const order = await orderService.getOrders(req, res, next);
    res.json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to cancel an order
*/
exports.cancelOrder = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const response = await orderService.cancelOrder(orderId);
    res.status(200).send(response);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to complete an order
*/
exports.completeOrder = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const response = await orderService.completeOrder(orderId);
    res.status(200).send(response);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get orders based on order id
*/
exports.getRecycleOrderByOrderId = async function (req, res, next) {
  try {
    const order = await orderService.getRecycleOrderByOrderId(req, res, next);
    res.json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get orders based on order id
*/
exports.getRefurbishOrderByOrderId = async function (req, res, next) {
  try {
    const order = await orderService.getRefurbishOrderByOrderId(req, res, next);
    res.json(order);
  } catch (error) {
    next(error);
  }
};
/*
@desc controller function to get orders based on order id
*/
exports.getFileURL = async function (req, res, next) {
  try {
    const fileURL = await orderService.getFileURL(req, res, next);
    res.json(fileURL);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get orders based on order id for approvers
*/
exports.getOrderForApprover = async function (req, res, next) {
  try {
    const order = await orderService.getOrderForApprover(req, res, next);
    res.json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get order type
*/
exports.getOrderType = async function (req, res, next) {
  try {
    const orderType = await orderService.getOrderType(req, res, next);
    res.json(orderType);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get consolidated order based on order id for approvers
*/
exports.getConsolidatedOrderData = async function (req, res, next) {
  try {
    const order = await orderService.getConsolidatedOrderData(req, res, next);
    res.json(order);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get consolidated order based on order id for recycler
*/
exports.getRecyclerConsolidatedOrderData = async function (req, res, next) {
  try {
    const order = await orderService.getRecyclerConsolidatedOrderData(req, res, next);
    res.json(order);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function for creating order type
*/
exports.createOrderType = async function (req, res, next) {
  try {
    const orderType = await orderService.createOrderType(req, res, next);
    res.json(orderType);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to approval stats for order for a stage
*/
exports.getStageApprovalStatus = async (req, res, next) => {
  try {
    const approvals = await orderService.getStageApprovalStatus(req, res, next);
    res.json(approvals);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to move order to next step
*/
exports.moveOrderToNextStep = async (req, res, next) => {
  try {
    const order = await orderService.moveOrderToNextStep(req, res, next);
    res.json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to schedule logistics
*/
exports.scheduleLogistics = async function (req, res, next) {
  try {
    const order = await orderService.scheduleLogistics(req, res, next);
    res.json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to accept logistics by recycler
*/
exports.acceptLogistics = async function (req, res, next) {
  try {
    const order = await orderService.acceptLogistics(req, res, next);
    res.json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for user pvt ntw update
*/
exports.getUserPrivateNtw = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const userPrivateNtws = await orderService.getUserPrivateNtw(userId);
    res.json(userPrivateNtws);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get the header data of the order
*/
exports.getOrderHeaderData = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const { userId } = req.userInfo;
    const order = await orderService.getOrderHeaderData(orderId, userId);
    res.status(200).json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to update order header data of the order
*/
exports.updateOrderHeaderData = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const { userId } = req.userInfo;

    const updatePayload = req.body;
    const { files } = req;
    if (files && files.picture !== undefined) {
      [updatePayload.picture] = files.picture;
    }
    const updatedOrder = await orderService.updateOrderHeaderData(userId, orderId, updatePayload);
    res.status(200).json(updatedOrder);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get the order details for recycler in order list page
*/
exports.getOrdersForRP = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;
    const order = await orderService.getOrdersForRP(userId);
    res.status(200).json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get the order items for a particular recycling order
*/
exports.getRecycleOrderItems = async function (req, res, next) {
  try {
    const order = await orderService.getRecycleOrderItems(req, res, next);
    res.status(200).json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get Logistics Data based order id
*/
exports.getLogisticsData = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const order = await orderService.getLogisticsData(orderId);
    res.json(order);
  } catch (error) {
    next(error);
  }
};
