const userService = require('../services/user.service');
/*
  @desc service function to get private network
*/
exports.userPrivateNtwOwner = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const userPrivateNtws = await userService.userPrivateNtwOwner(userId);
    res.status(200).json(userPrivateNtws);
  } catch (error) {
    return next(error);
  }
};
