const { order_item, order_quote_item, model_quote } = require('../models/index');

function getModelMapKey(orderItem) {
  // delimiter used here is ||
  return `${orderItem.model}||${orderItem.make}||${orderItem.itemType}`;
}
exports.getOrderItemsWithOrderQuoteItems = async (orderId, orderQuoteId) => {
  const dbres = await order_item.findAll({
    where: { order_id: orderId },
    attributes: [
      ['id', 'orderItemId'],
      ['equipment_no', 'equipmentNumber'],
      ['asset_no', 'assetNumber'],
      ['building_loc', 'buildingLocation'],
      ['bond_status', 'bondStatus'],
      ['age_in_year', 'ageInYear'],
      ['description', 'description'],
      ['model', 'model'],
      ['make', 'make'],
      ['item_type', 'itemType'],
    ],
    include: [{
      model: order_quote_item,
      as: 'order_quote_items',
      where: { order_quote_id: orderQuoteId },
      attributes: order_quote_item.attributesMapHelper([], { method: 'out' }),
      required: false,
    }],
  });
  // unwind the exact quote item data from array structure, if available
  const orderItemsWithQuotes = dbres.map((element) => {
    let item = { ...element.dataValues };
    if (element.dataValues.order_quote_items && element.dataValues.order_quote_items.length) {
      item = { ...item, ...element.dataValues.order_quote_items[0].dataValues };
    }
    delete item.order_quote_items;
    return item;
  });

  const modelQuoteDbRes = await model_quote.findAll({
    where: {
      order_quote_id: orderQuoteId,
    },
    attributes: model_quote.attributesMapHelper([], { method: 'out' }),
  });

  const modelQuotesMap = new Map();
  modelQuoteDbRes.forEach((item) => {
    const modelKey = getModelMapKey(item.dataValues);
    modelQuotesMap.set(modelKey, item);
  });

  orderItemsWithQuotes.forEach((item) => {
    const modelKey = getModelMapKey(item);
    if (modelQuotesMap.has(modelKey)) {
      item.listPrice = modelQuotesMap.get(modelKey).price;
    }
  });

  return orderItemsWithQuotes;
};

exports.deleteOrderItemsForOrder = async (orderId) => {
  const promise = order_item.destroy({
    where: {
      order_id: orderId,
    },
  });
  return promise;
};
