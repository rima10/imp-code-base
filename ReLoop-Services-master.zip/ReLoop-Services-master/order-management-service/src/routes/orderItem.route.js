const router = require('express').Router();
const multer = require('multer');
const authUtil = require('../utils/auth.util');
const validator = require('../utils/validate.util');

const upload = multer();

const orderItemController = require('../controllers/orderItem.controller');

module.exports = (app) => {
  /**
 * @swagger
 * /api/order/orderItem/readExcel:
 *   post:
 *    description:  Endpoint to post excel data
 *    tags:
 *      - OrderItem Details
 *    requestBody:
 *      content:
 *        multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *              assetExcel:
 *                type: string
 *                format: binary
 *      responses:
 *       200:
 *         description: A list of asset.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                type: object
 *                properties:
 *                  Equipment No:
 *                    type: string
 *                    description: Equipment Number
 *                    example: 5X86XXXX
 *                  Asset No:
 *                    type: string
 *                    description: Asset No
 *                    example: 5X86XXXX
 */
  router.post('/readExcel', upload.single('assetExcel'), [authUtil.validateMiddleware, authUtil.isGpUser],
    validator.readExcelFileValidations, validator.validate, orderItemController.readExcel);

  /**
* @swagger
* /api/order/orderItem/excel/{orderId}:
*   put:
*    description:  Endpoint to update excel asset list for an order
*    tags:
*      - OrderItem Details
*    parameters:
*      - name: orderId
*        description: id of the draft order
*        in: path
*        required: true
*        type: number
*    requestBody:
*      content:
*        multipart/form-data:
*          schema:
*            type: object
*            properties:
*              assetExcel:
*                type: string
*                format: binary
*      responses:
*       200:
*         description: A list of asset.
*         content:
*           application/json:
*             schema:
*              type: array
*              items:
*                $ref: '#/components/schemas/OrderItem'
*/
  router.put('/excel/:orderId',
    upload.single('assetExcel'),
    [authUtil.validateMiddleware, authUtil.isGpUser],
    validator.readExcelFileValidations, validator.validate,
    orderItemController.updateAssetExcelOrderItems);

  app.use('/api/order/orderItem', router);
};
