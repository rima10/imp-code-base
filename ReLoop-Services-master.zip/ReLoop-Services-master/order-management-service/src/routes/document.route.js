const router = require('express').Router();
const multer = require('multer');
const docController = require('../controllers/document.controller');
const authUtil = require('../utils/auth.util');
const validator = require('../utils/validate.util');

const upload = multer();

module.exports = (app) => {
  /**
 * @swagger
 * /api/order/document/generateDC/{orderId}:
 *   post:
 *    description:  Endpoint to download document
 *    tags:
 *      - Document
 *    parameters:
 *       - name: orderId
 *         description: id of the order
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              orderNo:
 *                type: string
 *                description: order number.
 *                example: 1
 *              dcNo:
 *                type: string
 *                description: delivery challan number
 *                example: 121
 *              gst:
 *                type: string
 *                description: gst value
 *                example: 18
 *              hsnCode:
 *                type: string
 *                description: hsn code for asset
 *                example: 8471
 *    responses:
 *       200:
 *         description: document downloaded.
 */
  router.post('/generateDC/:orderId', [authUtil.validateMiddleware, authUtil.isGpOrRp, authUtil.isGPorRPAsset], validator.genearteDCValidations, validator.validate,
    docController.generateDC);

  /**
 * @swagger
 * /api/order/document/generateForm6/{orderId}:
 *   post:
 *    description:  Endpoint to download document
 *    tags:
 *      - Document
 *    parameters:
 *       - name: orderId
 *         description: id of the order
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              orderNo:
 *                type: string
 *                description: order number.
 *                example: 1
 *              invoiceNo:
 *                type: string
 *                description: invoice number
 *                example: 121
 *              weight:
 *                type: number
 *                description: weight
 *                example: 350
 *    responses:
 *       200:
 *         description: document downloaded.
 */
  router.post('/generateForm6/:orderId', [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isRPAsset], validator.generateForm6Validations, validator.validate, docController.generateForm6);

  /**
 * @swagger
 * /api/order/document/generateForm2/{orderId}:
 *   post:
 *    description:  Endpoint to download document
 *    tags:
 *      - Document
 *    parameters:
 *       - name: orderId
 *         description: id of the order
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              orderNo:
 *                type: string
 *                description: order number.
 *                example: 1
 *              weight:
 *                type: number
 *                description: weight
 *                example: 350
 *    responses:
 *       200:
 *         description: document downloaded.
 */
  router.post('/generateForm2/:orderId', [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isRPAsset], validator.generateForm2Validations, validator.validate, docController.generateForm2);

  /**
 * @swagger
 * /api/order/document/downloadDocument/{orderId}/{key}:
 *   get:
 *    description:  Endpoint to download document
 *    tags:
 *      - Document
 *    parameters:
 *       - name: key
 *         description: key of the file
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: document downloaded.
 */
  router.get('/downloadDocument/:orderId/:key',
    [authUtil.validateMiddleware, authUtil.isGpOrRPorApprover, authUtil.isGPorRPorApproverAsset],
    docController.downloadDocument);
  /**
 * @swagger
 * /api/order/document/uploadDocument/{orderId}:
 *   post:
 *    description:  Endpoint to download document
 *    tags:
 *      - Document
 *    parameters:
 *       - name: orderId
 *         description: order Id
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *              orderNo:
 *                type: string
 *              documentId:
 *                type: string
 *              document:
 *                type: string
 *                format: binary
 *    responses:
 *       200:
 *         description: document downloaded.
 */
  router.post('/uploadDocument/:orderId', upload.fields([{
    name: 'document', maxCount: 1,
  }]), [authUtil.validateMiddleware, authUtil.isGpOrRp, authUtil.isGPorRPAsset],
    docController.uploadDocument);
  /**
 * @swagger
 * /api/order/document/getOrderDocuments/{orderId}:
 *   get:
 *    description:  Endpoint to download document
 *    tags:
 *      - Document
 *    parameters:
 *       - name: orderId
 *         description: order id
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: order documents.
 */
  router.get('/getOrderDocuments/:orderId', [authUtil.validateMiddleware, authUtil.isGpOrRp, authUtil.isGPorRPAsset], validator.orderIdValidations, validator.validate, docController.getOrderDocuments);

  app.use('/api/order/document', router);
};
