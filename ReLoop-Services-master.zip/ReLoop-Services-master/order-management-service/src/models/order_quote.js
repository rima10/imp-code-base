const Sequelize = require('sequelize');

const attributesMap = [
  ['quoteId', 'id'],
  ['orderId', 'order_id'],
  ['totalPrice', 'total_price'],
  ['currency', 'currency'],
  ['quoteStatus', 'quote_status'],
  ['onsiteScheduledTime', 'onsite_scheduled_time'],
  ['quoteComments', 'comments'],
  ['assetGradeComments', 'asset_grading_comments'],
  ['assetGradeSubmitted', 'asset_grading_submitted'],
  ['createdByUserId', 'created_by'],
  ['updatedByUserId', 'updated_by'],
  ['recyclePricePerKg', 'recycle_price_per_kg'],
  ['createdDate', 'created_date'],
  ['lastModifiedDate', 'last_modified_date'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

/**
 * @swagger
 *  components:
 *    schemas:
 *      OrderQuote:
 *        type: object
 *        required:
 *        properties:
 *          id:
 *            type: string
 *          order_id:
 *            type: string
 *          model_quotes:
 *            type: array
 *            items:
 *              $ref: '#/components/schemas/ModelQuote'
 *        example:
 *           quoteId: 1
 *           orderId: 2
 *           totalPrice: aaa123
 *           currency: INR
 *           quoteStatus: Accepted
 *           onsiteScheduledTime: 2021-08-28 14:29:45.78015+05:30
 *           quoteComments: new comments
 *           assetGradeComments: asset new comments
 *           assetGradeSubmitted: true/false
 */
module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('order_quote', {
    id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order',
        key: 'order_id',
      },
    },
    total_price: {
      type: DataTypes.DECIMAL,
      allowNull: true,
    },
    currency: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    quote_status: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    onsite_scheduled_time: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    comments: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    asset_grading_comments: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    asset_grading_submitted: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    created_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    updated_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    recycle_price_per_kg: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    schedule_onsite_visit_comment: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    duration_time: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'order_quote',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'order_quote_pkey',
        unique: true,
        fields: [
          { name: 'id' },
        ],
      },
    ],
  });

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
