const attributesMap = [
  ['id', 'order_invited_bp_id'],
  ['orderId', 'order_id'],
  ['bpId', 'invited_bp_id'],
  ['bpUsername', 'invited_bp_username'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('order_invited_business_partner', {
    order_invited_bp_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order',
        key: 'order_id',
      },
    },
    invited_bp_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    invited_bp_username: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'order_invited_business_partner',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'order_invited_business_partner_pkey',
        unique: true,
        fields: [
          { name: 'order_invited_bp_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.business_partner, { as: 'invited_bp', foreignKey: 'invited_bp_id' });
    model.belongsTo(models.order, { as: 'order', foreignKey: 'order_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;
  return model;
};
