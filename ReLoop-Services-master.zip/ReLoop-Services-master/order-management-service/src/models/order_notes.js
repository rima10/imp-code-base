const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('order_notes', {
    order_note_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order',
        key: 'order_id',
      },
    },
    activity: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    activity_time: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    activity_comment: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    activity_identifier: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    is_internal: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    updated_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    approver_update_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'approver',
        key: 'approver_id',
      },
    },
  }, {
    sequelize,
    tableName: 'order_notes',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'order_notes_pkey',
        unique: true,
        fields: [
          { name: 'order_note_id' },
        ],
      },
    ],
  });
};
