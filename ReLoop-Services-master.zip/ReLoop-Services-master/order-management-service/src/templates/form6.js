const dotenv = require('dotenv');

dotenv.config();
const env = process.env.NODE_ENV;
exports.getForm6Temp = (data) => {
  const {
    senderName, senderAddress, recyclerName, recyclerAddress, weight, qty,
    recyclerAuthNo, vehicleNumber, vehicleType, day = [], mon = [], year = [], invoiceNo,

  } = data;
  return `<html style="${env === 'production' ? 'zoom: 0.60;' : ''}">

    <head>
    <meta http-equiv=Content-Type content="text/html; charset=windows-1252">
    <meta name=Generator content="Microsoft Word 15 (filtered)">
    <style>
    <!--
     /* Font Definitions */
     @font-face
        {font-family:"Cambria Math";
        panose-1:2 4 5 3 5 4 6 3 2 4;}
    @font-face
        {font-family:Calibri;
        panose-1:2 15 5 2 2 2 4 3 2 4;}
     /* Style Definitions */
     p.MsoNormal, li.MsoNormal, div.MsoNormal
        {margin-top:0cm;
        margin-right:0cm;
        margin-bottom:8.0pt;
        margin-left:0cm;
        line-height:107%;
        font-size:11.0pt;
        font-family:"Calibri",sans-serif;
        color:black;}
    .MsoPapDefault
        {margin-bottom:8.0pt;
        line-height:107%;}
     /* Page Definitions */
     @page WordSection1
        {size:595.0pt 842.0pt;
        margin:72.0pt 54.3pt 72.0pt 85.2pt;}
    div.WordSection1
        {page:WordSection1;}
    -->
    </style>
    
    </head>
    
    <body lang=EN-IN style='word-wrap:break-word'>
    
    <div class=WordSection1>
    
    <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
    margin-bottom:0cm;margin-left:4.3pt;text-align:center;text-indent:-.5pt'><b><span
    style='font-size:12.0pt;line-height:107%;font-family:"Arial",sans-serif'>Form-6
    </span></b></p>
    
    <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
    margin-bottom:0cm;margin-left:3.85pt;text-align:center'><i><span
    style='font-size:12.0pt;line-height:107%;font-family:"Arial",sans-serif'> [See
    rule 19] </span></i></p>
    
    <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
    margin-bottom:0cm;margin-left:6.45pt;text-align:center'><i><span
    style='font-family:"Arial",sans-serif'> </span></i></p>
    
    <p class=MsoNormal align=center style='margin-top:0cm;margin-right:.5pt;
    margin-bottom:0cm;margin-left:4.3pt;text-align:center;text-indent:-.5pt'><b><span
    style='font-size:12.0pt;line-height:107%;font-family:"Arial",sans-serif'>E-WASTE
    MANIFEST  </span></b></p>
    
    <div align=center>
    
    <table class=TableGrid border=0 cellspacing=0 cellpadding=0 width=618
     style='width:550.45pt;border-collapse:collapse'>
     <tr style='height:42.0pt'>
      <td width=250pt valign=top style='width:35.6pt;border:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:42.0pt'>
      <p class=MsoNormal align=right style='margin:5pt;text-align:right'><span style='font-size:
      12.0pt;line-height:107%;font-family:"Arial",sans-serif'>1.  </span></p>
      </td>
      <td width=322 valign=top style='width:241.4pt;border:solid black 1.0pt;
      border-left:none;padding:1.2pt 0cm 0cm 0cm;height:42.0pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:
      12.0pt;line-height:107%;font-family:"Arial",sans-serif'>Sender’s name and
      mailing address:  </span></p>
      <p class=MsoNormal style='margin-left:20pt'>(including Phone No.)<span style='font-size:12.0pt;
      line-height:107%;font-family:"Arial",sans-serif'> </span></p>
      </td>
      <td width=249 colspan=13 valign=top style='width:186.45pt;border:solid black 1.0pt;
      border-left:none;padding:1.2pt 0cm 0cm 0cm;height:42.0pt'>
      <p class=MsoNormal style='margin:10pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'> </span><b><span style='font-size:12.0pt;line-height:
      107%;font-family:"Times New Roman",serif'>${senderName}</span></b></p>
      <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10pt;
      margin-left:10pt'>${senderAddress}</p>
      </td>
     </tr>
     <tr style='height:28.1pt'>
      <td width=47 valign=top style='width:35.6pt;border:solid black 1.0pt;
      border-top:none;padding:1.2pt 0cm 0cm 0cm;height:28.1pt'>
      <p class=MsoNormal align=right style='margin:5pt;text-align:right'><span style='font-size:
      12.0pt;line-height:107%;font-family:"Arial",sans-serif'>2.  </span></p>
      </td>
      <td width=322 valign=top style='width:241.4pt;border-top:none;border-left:
      none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:28.1pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;
      font-family:"Arial",sans-serif'> Sender’s authorisation No, if applicable:  </span></p>
      </td>
      <td width=249 colspan=13 valign=top style='width:186.45pt;border-top:none;
      border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:28.1pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'> </span></p>
      </td>
     </tr>
     <tr style='height:28.1pt'>
      <td width=47 valign=top style='width:35.6pt;border:solid black 1.0pt;
      border-top:none;padding:1.2pt 0cm 0cm 0cm;height:28.1pt'>
      <p class=MsoNormal align=right style='margin:5pt;text-align:right'><span style='font-size:
      12.0pt;line-height:107%;font-family:"Arial",sans-serif'>3.  </span></p>
      </td>
      <td width=322 valign=top style='width:241.4pt;border-top:none;border-left:
      none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:28.1pt'>
      <p class=MsoNormal style='margin:5pt'><b><span style='font-size:12.0pt;
      line-height:107%;font-family:"Arial",sans-serif'> Manifest Document No.</span></b></p>
      </td>
      <td width=249 colspan=13 valign=top style='width:186.45pt;border-top:none;
      border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:28.1pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'> Invoice No. ${invoiceNo}</span></p>
      </td>
     </tr>
     <tr style='height:41.75pt'>
      <td width=47 valign=top style='width:35.6pt;border:solid black 1.0pt;
      border-top:none;padding:1.2pt 0cm 0cm 0cm;height:41.75pt'>
      <p class=MsoNormal align=right style='margin:5pt;text-align:right'><span style='font-size:
      12.0pt;line-height:107%;font-family:"Arial",sans-serif'>4.  </span></p>
      </td>
      <td width=322 valign=bottom style='width:241.4pt;border-top:none;border-left:
      none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:41.75pt'>
      <p class=MsoNormal style='margin:5pt'><b><span style='font-size:12.0pt;
      line-height:107%;font-family:"Arial",sans-serif'>Transporter’s: name and
      address</span></b></p>
      <p class=MsoNormal style='margin:5pt'><b><span style='font-size:12.0pt;
      line-height:107%;font-family:"Arial",sans-serif'>(including Phone no.)</span></b></p>
      </td>
      <td width=249 colspan=13 valign=top style='width:186.45pt;border-top:none;
      border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:41.75pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'>${recyclerName}</span></p>
      <p class=MsoNormal style='margin:5pt'>${recyclerAddress}</p>
      </td>
     </tr>
     <tr style='height:28.3pt'>
      <td width=47 valign=top style='width:35.6pt;border:solid black 1.0pt;
      border-top:none;padding:1.2pt 0cm 0cm 0cm;height:28.3pt'>
      <p class=MsoNormal align=right style='margin:5pt;text-align:right'><span style='font-size:
      12.0pt;line-height:107%;font-family:"Arial",sans-serif'>5.  </span></p>
      </td>
      <td width=322 valign=top style='width:241.4pt;border-top:none;border-left:
      none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:28.3pt'>
      <p class=MsoNormal style='margin:5pt'><b><span style='font-size:12.0pt;
      line-height:107%;font-family:"Arial",sans-serif'>Type of vehicle:</span></b></p>
      <p class=MsoNormal style='margin:5pt'><b>&nbsp;</b></p>
      </td>
      <td width=249 colspan=13 valign=top style='width:186.45pt;border-top:none;
      border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:28.3pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'> ${vehicleType}</span></p>
      </td>
     </tr>
     <tr style='height:28.1pt'>
      <td width=47 valign=top style='width:35.6pt;border:solid black 1.0pt;
      border-top:none;padding:1.2pt 0cm 0cm 0cm;height:28.1pt'>
      <p class=MsoNormal align=right style='margin:5pt;text-align:right'><span style='font-size:
      12.0pt;line-height:107%;font-family:"Arial",sans-serif'>6.  </span></p>
      </td>
      <td width=322 valign=top style='width:241.4pt;border-top:none;border-left:
      none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:28.1pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;
      line-height:107%;font-family:"Arial",sans-serif'>Transporter/s registration No.:</span></p>
      </td>
      <td width=249 colspan=13 valign=top style='width:186.45pt;border-top:none;
      border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:28.1pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'> </span></p>
      </td>
     </tr>
     <tr style='height:14.15pt'>
      <td width=47 valign=top style='width:35.6pt;border:solid black 1.0pt;
      border-top:none;padding:1.2pt 0cm 0cm 0cm;height:14.15pt'>
      <p class=MsoNormal align=right style='margin:5pt;text-align:right'><span style='font-size:
      12.0pt;line-height:107%;font-family:"Arial",sans-serif'>7.  </span></p>
      </td>
      <td width=322 valign=top style='width:241.4pt;border-top:none;border-left:
      none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.15pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'>Vehicle registration No.: </span></p>
      </td>
      <td width=249 colspan=13 valign=top style='width:186.45pt;border-top:none;
      border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.15pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'>  ${vehicleNumber}</span></p>
      </td>
     </tr>
     <tr style='height:14.4pt'>
      <td width=47 valign=top style='width:35.6pt;border:solid black 1.0pt;
      border-top:none;padding:1.2pt 0cm 0cm 0cm;height:14.4pt'>
      <p class=MsoNormal align=right style='margin:5pt;text-align:right'><span style='font-size:
      12.0pt;line-height:107%;font-family:"Arial",sans-serif'>8.  </span></p>
      </td>
      <td width=322 valign=top style='width:241.4pt;border-top:none;border-left:
      none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.4pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;
      font-family:"Arial",sans-serif'>  Receiver’s name &amp; address: </span></p>
      </td>
      <td width=249 colspan=13 valign=top style='width:186.45pt;border-top:none;
      border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.4pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'>${recyclerName}</span></p>
      <p class=MsoNormal style='margin:5pt'> ${recyclerAddress}</p>
      </td>
     </tr>
     <tr style='height:28.1pt'>
      <td width=47 valign=top style='width:35.6pt;border:solid black 1.0pt;
      border-top:none;padding:1.2pt 0cm 0cm 0cm;height:28.1pt'>
      <p class=MsoNormal align=right style='margin:5pt;text-align:right'><span style='font-size:
      12.0pt;line-height:107%;font-family:"Arial",sans-serif'>9.  </span></p>
      </td>
      <td width=322 valign=top style='width:241.4pt;border-top:none;border-left:
      none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:28.1pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;
      font-family:"Arial",sans-serif'>  Receiver’s authorisation No, if applicable.</span></p>
      </td>
      <td width=249 colspan=13 valign=top style='width:186.45pt;border-top:none;
      border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:28.1pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'>${recyclerAuthNo}</span></p>
      </td>
     </tr>
     <tr style='height:28.3pt'>
      <td width=47 valign=top style='width:35.6pt;border-top:none;border-left:solid black 1.0pt;
      border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;padding:1.2pt 0cm 0cm 0cm;
      height:28.3pt'>
      <p class=MsoNormal align=right style='margin:5pt;text-align:right'><span style='font-size:
      12.0pt;line-height:107%;font-family:"Arial",sans-serif'>10.  </span></p>
      </td>
      <td width=322 valign=top style='width:241.4pt;border-top:none;border-left:
      none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:28.3pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'>Description of E-Waste (Weight/ Numbers): </span></p>
      </td>
      <td width=249 colspan=13 valign=top style='width:186.45pt;border-top:none;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:28.3pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'> E-Waste: ${weight}Kgs. (${qty} No’s)</span></p>
      </td>
     </tr>     
     <tr style='height:28.3pt'>
     <td width=47 rowspan=3 valign=top style='width:35.6pt;border-top:none;
     border-left:solid black 1.0pt;border-bottom:solid black 1.5pt;border-right:
     solid black 1.0pt;padding:1.2pt 0cm 0cm 0cm;height:28.3pt'>
     <p class=MsoNormal align=right style='margin:5pt;text-align:right'><span style='font-size:
     12.0pt;line-height:107%;font-family:"Arial",sans-serif'>11.  </span></p>
     </td>
     <td width=322 valign=top style='width:241.4pt;border-top:none;border-left:
     none;
     padding:1.2pt 0cm 0cm 0cm;height:28.3pt'>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'>Name and stamp of Sender* (Manufacturer/ Producer/ Bulk Consumer/ Collection Centre/ Refurbisher/ Dismantler):</span></p>
     </td>
     <td width=249 colspan=13 valign=top style='width:186.45pt;border-top:none;
     border-left:none;border-right:solid black 1.0pt;
     padding:1.2pt 0cm 0cm 0cm;height:28.3pt'>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'> </span></p>
     </td>
    </tr>
    <tr style='height:28.1pt'>
    <td width=322 rowspan=2 valign=top style='width:241.4pt;
     border-bottom:solid black 1.5pt;padding:1.2pt 0cm 0cm 0cm;height:13.05pt' border-left:solid black 1.0pt;>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'>Signature:</span></p>
     </td>
     <td width=322 rowspan=2 valign=top style='width:241.4pt;
     border-bottom:solid black 1.5pt;padding:1.2pt 0cm 0cm 0cm;height:13.05pt' border-left:solid black 1.0pt;>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'></span></p>
     </td>
     <td width=249 colspan=13 valign=top style='width:186.45pt;border:none;border-bottom:solid black 1.0pt;
     border-right:solid black 1.0pt;padding:1.2pt 0cm 0cm 0cm;height:13.05pt'>
     <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
     margin-left:-1.0pt'><span style='font-size:12.0pt;line-height:107%;
     font-family:"Arial",sans-serif'>Day               Month                       Year  </span></p>
     </td>
    </tr>
    <tr style='height:14.65pt'>
     <td width=347 colspan=2 valign=bottom style='width:259.95pt;border-top:none;
     border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
     padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:1.0pt;line-height:107%;font-family:
     "Arial",sans-serif'> </span></p>
     </td>
     <td width=19 valign=top style='width:13.9pt;border-top:solid black 1.0pt;
     border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
     padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'>${day[0]}</span></p>
     </td>
     <td width=19 valign=top style='width:13.9pt;border-top:solid black 1.0pt;
     border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
     padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'>${day[1]}</span></p>
     </td>
     
     <td width=17 valign=top style='width:12.95pt;border-top:solid black 1.0pt;
     border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
     padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'>${mon[0]}</span></p>
     </td>
     <td width=17 valign=top style='width:12.85pt;border-top:solid black 1.0pt;
     border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
     padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'>${mon[1]}</span></p>
     </td>
     <td width=19 valign=top style='width:14.4pt;border-top:solid black 1.0pt;
     border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
     padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'>${year[0]}</span></p>
     </td>
     <td width=19 valign=top style='width:14.4pt;border-top:solid black 1.0pt;
     border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
     padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'>${year[1]}</span></p>
     </td>
     <td width=19 valign=top style='width:14.4pt;border-top:solid black 1.0pt;
     border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
     padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'>${year[2]}</span></p>
     </td>
     <td width=19 valign=top style='width:14.4pt;border-top:solid black 1.0pt;
     border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
     padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'>${year[3]}</span></p>
     </td>
         </tr>
     <tr style='height:28.3pt'>
      <td width=47 rowspan=3 valign=top style='width:35.6pt;border-top:none;
      border-left:solid black 1.0pt;border-bottom:solid black 1.5pt;border-right:
      solid black 1.0pt;padding:1.2pt 0cm 0cm 0cm;height:28.3pt'>
      <p class=MsoNormal align=right style='margin:5pt;text-align:right'><span style='font-size:
      12.0pt;line-height:107%;font-family:"Arial",sans-serif'>12.  </span></p>
      </td>
      <td width=322 valign=top style='width:241.4pt;border-top:none;border-left:
      none;
      padding:1.2pt 0cm 0cm 0cm;height:28.3pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'>Transporter acknowledgement of receipt of E-Wastes  </span></p>
      </td>
      <td width=249 colspan=13 valign=top style='width:186.45pt;border-top:none;
      border-left:none;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:28.3pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'> </span></p>
      </td>
     </tr>
     <tr style='height:28.1pt'>
    <td width=322 rowspan=2 valign=top style='width:241.4pt;
     border-bottom:solid black 1.5pt;padding:1.2pt 0cm 0cm 0cm;height:13.05pt' border-left:solid black 1.0pt;>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'>Name and stamp:</span></p>
     </td>
     <td width=322 rowspan=2 valign=top style='width:241.4pt;
     border-bottom:solid black 1.5pt;padding:1.2pt 0cm 0cm 0cm;height:13.05pt' border-left:solid black 1.0pt;>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'></span></p>
     </td>
     <td width=249 colspan=13 valign=top style='width:186.45pt;border:none;border-bottom:solid black 1.0pt;
     border-right:solid black 1.0pt;padding:1.2pt 0cm 0cm 0cm;height:13.05pt'>
     <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
     margin-left:-1.0pt'><span style='font-size:12.0pt;line-height:107%;
     font-family:"Arial",sans-serif'>                                        Day            Month       Year  </span></p>
     </td>
    </tr>
     <tr style='height:14.65pt'>
      <td width=347 colspan=2 valign=bottom style='width:259.95pt;border-top:none;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:1.0pt;line-height:107%;font-family:
      "Arial",sans-serif'> </span></p>
      </td>
      <td width=19 valign=top style='width:13.9pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'>${day[0]}</span></p>
      </td>
      <td width=19 valign=top style='width:13.9pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'>${day[1]}</span></p>
      </td>
      
      <td width=17 valign=top style='width:12.95pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'>${mon[0]}</span></p>
      </td>
      <td width=17 valign=top style='width:12.85pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'>${mon[1]}</span></p>
      </td>
      <td width=19 valign=top style='width:14.4pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'>${year[0]}</span></p>
      </td>
      <td width=19 valign=top style='width:14.4pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'>${year[1]}</span></p>
      </td>
      <td width=19 valign=top style='width:14.4pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'>${year[2]}</span></p>
      </td>
      <td width=19 valign=top style='width:14.4pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'>${year[3]}</span></p>
      </td>
          </tr>
     <tr style='height:28.3pt'>
      <td width=47 rowspan=3 valign=top style='width:35.6pt;border-top:none;
      border-left:solid black 1.0pt;border-bottom:solid black 1.5pt;border-right:
      solid black 1.0pt;padding:1.2pt 0cm 0cm 0cm;height:28.3pt'>
      <p class=MsoNormal align=right style='margin:5pt;text-align:right'><span style='font-size:
      12.0pt;line-height:107%;font-family:"Arial",sans-serif'>13.  </span></p>
      </td>
      <td width=570 colspan=14 valign=top style='width:427.85pt;border-top:none;
      border-left:none;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:28.3pt'>
      <p class=MsoNormal style='margin:5pt;text-align:justify;text-justify:inter-ideograph'><span
      style='font-size:12.0pt;line-height:107%;font-family:"Arial",sans-serif'>Receiver*
      (Collection Centre or Refurbisher or Dismantler or Recycler) certification of
      receipt of E-waste </span></p>
      </td>
     </tr>
     <tr style='height:28.1pt'>
    <td width=322 rowspan=2 valign=top style='width:241.4pt;
     border-bottom:solid black 1.5pt;padding:1.2pt 0cm 0cm 0cm;height:13.05pt' border-left:solid black 1.0pt;>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'>Name and stamp:</span></p>
     </td>
     <td width=322 rowspan=2 valign=top style='width:241.4pt;
     border-bottom:solid black 1.5pt;padding:1.2pt 0cm 0cm 0cm;height:13.05pt' border-left:solid black 1.0pt;>
     <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
     "Arial",sans-serif'></span></p>
     </td>
     <td width=249 colspan=13 valign=top style='width:186.45pt;border:none;
     border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;padding:1.2pt 0cm 0cm 0cm;height:13.05pt'>
     <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
     margin-left:-1.0pt'><span style='font-size:12.0pt;line-height:107%;
     font-family:"Arial",sans-serif'>                                                                              Day               Month           Year  </span></p>
     </td>
    </tr>
     <tr style='height:14.65pt'>
      <td width=347 colspan=2 valign=bottom style='width:259.95pt;border-top:none;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:1.0pt;line-height:107%;font-family:
      "Arial",sans-serif'> </span></p>
      </td>
      <td width=19 valign=top style='width:13.9pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'> </span></p>
      </td>
      <td width=19 valign=top style='width:14.15pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin-top:0cm;margin-right:-1.3pt;margin-bottom:
      0cm;margin-left:5.4pt'><span style='font-size:12.0pt;line-height:107%;
      font-family:"Arial",sans-serif'>   </span></p>
      </td>
      <td width=17 valign=top style='width:12.95pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'> </span></p>
      </td>
      <td width=17 valign=top style='width:12.95pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'> </span></p>
      </td>
      <td width=17 valign=top style='width:12.85pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'> </span></p>
      </td>
      <td width=19 valign=top style='width:14.4pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'> </span></p>
      </td>
      <td width=19 valign=top style='width:13.9pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
      margin-left:5.15pt'><span style='font-size:12.0pt;line-height:107%;
      font-family:"Arial",sans-serif'> </span></p>
      </td>
      <td width=19 valign=top style='width:14.15pt;border-top:solid black 1.0pt;
      border-left:none;border-bottom:solid black 1.5pt;border-right:solid black 1.0pt;
      padding:1.2pt 0cm 0cm 0cm;height:14.65pt'>
      <p class=MsoNormal style='margin:5pt'><span style='font-size:12.0pt;line-height:107%;font-family:
      "Arial",sans-serif'> </span></p>
      </td>      
     </tr>
    </table>
    
    </div>
    
    <p class=MsoNormal style='margin-bottom:0cm'><span style='font-size:12.0pt;
    line-height:107%;font-family:"Arial",sans-serif'>                               
    * As applicable </span></p>
    
    <p class=MsoNormal style='margin-bottom:0cm'><span style='font-family:"Arial",sans-serif'> </span></p>
    
    <p class=MsoNormal style='margin-bottom:0cm'><b><span style='font-size:12.0pt;
    line-height:107%;font-family:"Arial",sans-serif'>                                
    Note: - </span></b></p>
    
    <div align=center>
    
    <table class=TableGrid border=0 cellspacing=0 cellpadding=0 width=624
     style='width:550.75pt;border-collapse:collapse'>
     <tr style='height:40.3pt'>
      <td width=138 valign=top style='width:103.45pt;border:solid black 1.0pt;
      padding:2.3pt 2.2pt 0cm 5.15pt;height:40.3pt'>
      <p class=MsoNormal style='margin-bottom:0cm'><b><span style='font-size:11.5pt;
      line-height:107%;font-family:"Arial",sans-serif'>Copy        number </span></b></p>
      <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
      margin-left:.25pt;text-align:justify;text-justify:inter-ideograph'><b><span
      style='font-size:11.5pt;line-height:107%;font-family:"Arial",sans-serif'>with
      colour code </span></b></p>
      <p class=MsoNormal align=center style='margin-top:0cm;margin-right:3.45pt;
      margin-bottom:0cm;margin-left:0cm;text-align:center'><b><span
      style='font-size:11.5pt;line-height:107%;font-family:"Arial",sans-serif'>(1) </span></b></p>
      </td>
      <td width=486 valign=top style='width:364.3pt;border:solid black 1.0pt;
      border-left:none;padding:2.3pt 2.2pt 0cm 5.15pt;height:40.3pt'>
      <p class=MsoNormal align=center style='margin-top:0cm;margin-right:2.8pt;
      margin-bottom:0cm;margin-left:0cm;text-align:center'><b><span
      style='font-size:11.5pt;line-height:107%;font-family:"Arial",sans-serif'>Purpose
      </span></b></p>
      <p class=MsoNormal align=center style='margin-top:0cm;margin-right:3.2pt;
      margin-bottom:0cm;margin-left:0cm;text-align:center'><b><span
      style='font-size:11.5pt;line-height:107%;font-family:"Arial",sans-serif'>(2) </span></b></p>
      </td>
     </tr>
     <tr style='height:26.9pt'>
      <td width=138 valign=top style='width:103.45pt;border:solid black 1.0pt;
      border-top:none;padding:2.3pt 2.2pt 0cm 5.15pt;height:26.9pt'>
      <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
      margin-left:.25pt'><b><span style='font-size:11.5pt;line-height:107%;
      font-family:"Arial",sans-serif'>Copy 1 (Yellow) </span></b></p>
      </td>
      <td width=486 valign=top style='width:364.3pt;border-top:none;border-left:
      none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:2.3pt 2.2pt 0cm 5.15pt;height:26.9pt'>
      <p class=MsoNormal style='margin-bottom:0cm;text-align:justify;text-justify:
      inter-ideograph'><span style='font-size:11.5pt;line-height:107%;font-family:
      "Arial",sans-serif'>To be retained by the sender after taking signature on it
      from the transporter and other three copies will be carried by transporter. </span></p>
      </td>
     </tr>
     <tr style='height:13.5pt'>
      <td width=138 valign=top style='width:103.45pt;border:solid black 1.0pt;
      border-top:none;padding:2.3pt 2.2pt 0cm 5.15pt;height:13.5pt'>
      <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
      margin-left:.25pt'><b><span style='font-size:11.5pt;line-height:107%;
      font-family:"Arial",sans-serif'>Copy 2 (Pink) </span></b></p>
      </td>
      <td width=486 valign=top style='width:364.3pt;border-top:none;border-left:
      none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:2.3pt 2.2pt 0cm 5.15pt;height:13.5pt'>
      <p class=MsoNormal style='margin-bottom:0cm'><span style='font-size:11.5pt;
      line-height:107%;font-family:"Arial",sans-serif'>To be retained by the
      receiver after signature of the transporter. </span></p>
      </td>
     </tr>
     <tr style='height:26.9pt'>
      <td width=138 valign=top style='width:103.45pt;border:solid black 1.0pt;
      border-top:none;padding:2.3pt 2.2pt 0cm 5.15pt;height:26.9pt'>
      <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
      margin-left:.25pt;text-align:justify;text-justify:inter-ideograph'><b><span
      style='font-size:11.5pt;line-height:107%;font-family:"Arial",sans-serif'>Copy
      3 (Orange) </span></b></p>
      </td>
      <td width=486 valign=top style='width:364.3pt;border-top:none;border-left:
      none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:2.3pt 2.2pt 0cm 5.15pt;height:26.9pt'>
      <p class=MsoNormal style='margin-bottom:0cm'><span style='font-size:11.5pt;
      line-height:107%;font-family:"Arial",sans-serif'>To be retained by the
      transporter after taking signature of the receiver. </span></p>
      </td>
     </tr>
     <tr style='height:13.9pt'>
      <td width=138 valign=top style='width:103.45pt;border:solid black 1.0pt;
      border-top:none;padding:2.3pt 2.2pt 0cm 5.15pt;height:13.9pt'>
      <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
      margin-left:.25pt'><b><span style='font-size:11.5pt;line-height:107%;
      font-family:"Arial",sans-serif'>Copy 4 (Green) </span></b></p>
      </td>
      <td width=486 valign=top style='width:364.3pt;border-top:none;border-left:
      none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
      padding:2.3pt 2.2pt 0cm 5.15pt;height:13.9pt'>
      <p class=MsoNormal style='margin-bottom:0cm'><span style='font-size:11.5pt;
      line-height:107%;font-family:"Arial",sans-serif'>To be returned by the
      receiver with his/her signature to the sender  </span></p>
      </td>
     </tr>
    </table>
    
    </div>
   
    </div>
    
    </body>
    
    </html>
    `;
};
