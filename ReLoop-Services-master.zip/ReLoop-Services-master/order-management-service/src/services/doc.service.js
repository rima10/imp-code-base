const mime = require('mime');
const dataTypes = require('sequelize').DataTypes;
const { sequelize } = require('../models/index');
const Models = require('../models/init-models')(sequelize, dataTypes);
const form6 = require('../templates/form6');
const form2 = require('../templates/form2');
const dc = require('../templates/dc');
const docUtil = require('../utils/docs.util');
const s3UtilFunctions = require('../utils/s3.util');
const dataFormatUtil = require('../utils/order/dataFormat.util');

const uploadDocToS3 = async (orderId, documentName, file, fileName, userId, documentText) => {
  let document = null;
  const s3FileKey = await s3UtilFunctions.pushFileToS3(file, fileName);
  const doc = await Models.doc.findOne({ where: { doc_name: documentName } });
  const docQuery = { where: { order_id: orderId, doc_id: doc.doc_id } };
  if (documentName === 'other') {
    docQuery.where.document_text = documentText;
  }
  const existingDocument = await Models.order_doc.findOne(docQuery);
  if (existingDocument) {
    document = await existingDocument.update({
      storage_metadata: s3FileKey,
      last_modified_date: new Date(),
      updated_by: userId,
    });
  } else {
    document = await Models.order_doc.create({
      order_id: orderId,
      doc_id: doc.doc_id,
      storage_metadata: s3FileKey,
      created_by: userId,
      document_text: documentText,
    });
  }
  return document;
};
exports.uploadDocToS3 = uploadDocToS3;

const getDCData = async (orderId, dcNo, gst, hsnCode) => {
  const orderData = await Models.order.findOne({
    where: { order_id: orderId },
    attributes: [['order_id', 'orderId']],
    include: [{
      model: Models.business_partner,
      as: 'businessPartner',
      attributes: [['bp_username', 'bpUsername'], ['gst_number', 'gstNumber'], 'cin', 'pan'],
      include: [{
        model: Models.location,
        as: 'loc',
        attributes: ['pincode', ['loc_details', 'locDetails']],
        include: [{ model: Models.city, as: 'city' }, { model: Models.state, as: 'state' }],
      }],
    },
    {
      model: Models.order_quote,
      as: 'order_quotes',
      where: { quote_status: 'Accepted' },
      attributes: ['id'],
      include: [{
        model: Models.business_partner,
        as: 'createdByBP',
        attributes: [['bp_username', 'bpUsername'], ['gst_number', 'gstNumber'], 'cin', 'pan'],
        include: [{
          model: Models.location,
          as: 'loc',
          attributes: ['pincode', ['loc_details', 'locDetails']],
          include: [{ model: Models.city, as: 'city' }, { model: Models.state, as: 'state' }],
        }],
      }, {
        model: Models.model_quote,
        as: 'modelQuotes',
        attributes: ['model', 'price', 'count'],
      }],
    }],
  });
  if (!orderData || !orderData.dataValues.order_quotes.length) throw new Error('No quotations has been accepted for the order');
  const dcData = dataFormatUtil.formatDcData(orderData, dcNo, gst, hsnCode);
  return dcData;
};

const generateForm6Data = async (orderId, weight, invoiceNo) => {
  const orderData = await Models.order.findOne({
    where: { order_id: orderId },
    attributes: [['order_id', 'orderId'], ['vehicle_type', 'vehicleType'], ['vehicle_licence_no', 'vehicleLicenseNo'],
      [sequelize.fn('COUNT', sequelize.col('orderItems.id')), 'itemsCount']],
    group: ['order.order_id', 'businessPartner.bp_id', 'businessPartner.loc.loc_id', 'businessPartner.loc.city.city_id',
      'businessPartner.loc.state.state_id', 'order_quotes.id', 'order_quotes.createdByBP.bp_id', 'order_quotes.createdByBP.loc.loc_id', 'order_quotes.createdByBP.loc.city.city_id',
      'order_quotes.createdByBP.loc.state.state_id'],
    include: [{
      model: Models.business_partner,
      as: 'businessPartner',
      attributes: [['bp_username', 'bpUsername']],
      include: [{
        model: Models.location,
        as: 'loc',
        attributes: ['pincode', ['loc_details', 'locDetails']],
        include: [{ model: Models.city, as: 'city' }, { model: Models.state, as: 'state' }],
      }],
    },
    {
      model: Models.order_item,
      as: 'orderItems',
      attributes: [],
    },
    {
      model: Models.order_quote,
      as: 'order_quotes',
      where: { quote_status: 'Accepted' },
      attributes: ['id'],
      include: [{
        model: Models.business_partner,
        as: 'createdByBP',
        attributes: [['bp_username', 'bpUsername'], ['auth_number', 'authNumber']],
        include: [{
          model: Models.location,
          as: 'loc',
          attributes: ['pincode', ['loc_details', 'locDetails']],
          include: [{ model: Models.city, as: 'city' }, { model: Models.state, as: 'state' }],
        }],
      }],
    }],
  });
  if (!orderData.dataValues.order_quotes.length) throw new Error('No quotations has been accepted for the order');
  const f6Data = dataFormatUtil.formatF6Data(orderData, weight, invoiceNo);
  return f6Data;
};

const generateForm2Data = async (orderId, weight) => {
  const orderData = await Models.order.findOne({
    where: { order_id: orderId },
    attributes: [['order_id', 'orderId']],
    include: [{
      model: Models.business_partner,
      as: 'businessPartner',
      attributes: [['bp_username', 'bpUsername']],
      include: [{
        model: Models.location,
        as: 'loc',
        attributes: ['pincode', ['loc_details', 'locDetails']],
        include: [{ model: Models.city, as: 'city' }, { model: Models.state, as: 'state' }],
      }],
    },
    {
      model: Models.order_quote,
      as: 'order_quotes',
      where: { quote_status: 'Accepted' },
      attributes: ['id'],
      include: [{
        model: Models.business_partner,
        as: 'createdByBP',
        attributes: [['bp_username', 'bpUsername'], ['auth_number', 'authNumber']],
        include: [{
          model: Models.location,
          as: 'loc',
          attributes: ['pincode', ['loc_details', 'locDetails']],
          include: [{ model: Models.city, as: 'city' }, { model: Models.state, as: 'state' }],
        }],
      }],
    }],
  });
  if (!orderData.dataValues.order_quotes.length) throw new Error('No quotations has been accepted for the order');
  const f6Data = dataFormatUtil.formatF2Data(orderData, weight);
  return f6Data;
};

const uploadGeneratedDocToS3 = async (temp, formOptions, orderId, fileName, docName, userId) => {
  const s3Stream = await docUtil.generateDocument(temp, formOptions);
  const file = { buffer: s3Stream, mimeType: 'application/pdf' };
  uploadDocToS3(orderId, docName, file, fileName, userId);
};
exports.generateForm6 = async (req, res) => {
  const { orderId } = req.params;
  const { userId } = req.userInfo;
  const {
    weight, invoiceNo, orderNo,
  } = req.body;
  const form6Data = await generateForm6Data(orderId, weight, invoiceNo);
  const temp = form6.getForm6Temp(form6Data);
  const formOptions = {
    type: 'pdf',
    format: 'A4',
    orientation: 'portrait',
  };
  const fileName = `Form 6_${orderNo}.pdf`;
  const stream = await docUtil.generateDocument(temp, formOptions);
  res.attachment(fileName);
  await uploadGeneratedDocToS3(temp, formOptions, orderId, fileName, 'Form 6', userId);
  return stream;
};

exports.generateDC = async (req, res) => {
  const { orderId } = req.params;
  const { userId } = req.userInfo;
  const {
    dcNo, gst, hsnCode, orderNo,
  } = req.body;
  const dcData = await getDCData(orderId, dcNo, gst, hsnCode);
  const temp = dc.getDCTemp(dcData);
  const formOptions = {
    type: 'pdf',
    format: 'A4',
    orientation: 'landscape',
  };
  const fileName = `Delivery Challan_${orderNo}.pdf`;
  const stream = await docUtil.generateDocument(temp, formOptions);
  res.attachment(fileName);
  await uploadGeneratedDocToS3(temp, formOptions, orderId, fileName, 'Delivery Challan', userId);
  return stream;
};

exports.generateForm2 = async (req, res) => {
  const { orderId } = req.params;
  const { userId } = req.userInfo;
  const {
    weight, orderNo,
  } = req.body;
  const form2Data = await generateForm2Data(orderId, weight);
  const temp = form2.getForm2Temp(form2Data);
  const formOptions = {
    type: 'pdf',
    format: 'A4',
    orientation: 'portrait',
  };
  const fileName = `Form 2_${orderNo}.pdf`;
  const stream = await docUtil.generateDocument(temp, formOptions);
  res.attachment(fileName);
  await uploadGeneratedDocToS3(temp, formOptions, orderId, fileName, 'Form 2', userId);
  return stream;
};

exports.downloadFile = async (req, res) => {
  const { key } = req.params;
  const result = await s3UtilFunctions.downloadFile(key, res);
  const { stream, data } = result;
  res.set('Content-Type', mime.getType(key));
  res.set('Content-Length', data.ContentLength);
  res.attachment(key);
  return stream;
};

exports.getOrderDocuments = async (req) => {
  const { orderId } = req.params;
  const documents = await Models.doc.findAll({
    attributes: [['doc_id', 'docId'], ['doc_name', 'docName']],
    include: [{
      model: Models.order_doc,
      as: 'order_docs',
      where: { order_id: orderId },
      required: false,
      attributes: [['order_doc_id', 'orderDocId'], ['storage_metadata', 'storageKey'], ['last_modified_date', 'lastModifiedDate'], ['document_text', 'documentText']],
      include: [{
        model: Models.business_partner,
        as: 'createdBy',
        attributes: [['bp_username', 'bpUserName']],
      }],
    }],
  });
  return documents;
};

exports.uploadDocument = async (req) => {
  const { orderId } = req.params;
  const { userId } = req.userInfo;
  const { files } = req;
  const { documentName, orderNo, documentText } = req.body;
  const doc = await Models.doc.findOne({ where: { doc_name: documentName } });
  const documentType = doc.doc_name;
  const file = files.document[0];
  const fileNamewithExt = file.originalname;
  const fileExt = fileNamewithExt.substr(fileNamewithExt.lastIndexOf('.') + 1);
  let key;
  if (documentName === 'other') {
    key = `${documentText}_${orderNo}.${fileExt}`;
  } else key = `${documentType}_${orderNo}.${fileExt}`;
  const document = await uploadDocToS3(orderId, documentName, file, key, userId, documentText);
  return document;
};
