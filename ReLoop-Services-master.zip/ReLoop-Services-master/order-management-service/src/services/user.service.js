const dataTypes = require('sequelize').DataTypes;
const { sequelize } = require('../models/index');
const { business_partner } = require('../models/index');
const { approver } = require('../models/index');
const Models = require('../models/init-models')(sequelize, dataTypes);

exports.getUserDatabyCognito = async (cognitoId) => {
  const res = await business_partner.findOne({
    where: {
      bp_userid: cognitoId,
      // Will be used when existing useer archive flag is set to false
      // [Op.not]: [{ archive: true }],
    },
    attributes: ['bp_id', 'bp_username', 'bp_email_id'],
  });
  if (!res) return false;
  const userData = business_partner.attributesMapHelper(res.dataValues, { method: 'out' });
  return userData;
};

exports.getApproverDatabyCognito = async (cognitoId) => {
  const approverData = await approver.findOne({
    where: {
      approver_userid: cognitoId,
    },
    attributes: [['approver_id', 'approverId']],
  });
  return approverData;
};

exports.userPrivateNtwOwner = async (userId) => {
  const pvtNetworks = await Models.bp_private_nwk.findOne({
    where: { nwk_member: userId },
    attributes: ['nwk_owner'],
    include: [{ model: Models.business_partner, attributes: ['bp_username'], as: 'nwkOwner' }],
  });
  let privateNetworkOwner = {};
  if (pvtNetworks) {
    privateNetworkOwner = {
      nwkOwner: pvtNetworks.dataValues.nwk_owner,
      nwkOwnerName: pvtNetworks.dataValues.nwkOwner.dataValues.bp_username,
    };
  }
  return privateNetworkOwner;
};
