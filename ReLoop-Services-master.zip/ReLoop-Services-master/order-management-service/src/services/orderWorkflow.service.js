const dataTypes = require('sequelize').DataTypes;
const { sequelize, order_notes } = require('../models/index');
const Workflow = require('../models/workflow')(sequelize, dataTypes);
const OrderWorkflow = require('../models/order_workflow')(sequelize, dataTypes);
const orderWorkflowApprover = require('../models/order_workflow_approver')(sequelize, dataTypes);
const approvalService = require('./approval.service');
const Models = require('../models/init-models')(sequelize, dataTypes);

const createOrderWorkflowSkeleton = async (orderId, workflowId) => {
  const existingOrderWorklow = await OrderWorkflow.findOne(
    { where: { order_id: orderId, workflow_id: workflowId } },
  );
  if (existingOrderWorklow) {
    return existingOrderWorklow;
  }
  const OrderWorkflowDetail = await OrderWorkflow.create({
    order_id: orderId,
    workflow_id: workflowId,
  });
  return OrderWorkflowDetail;
};

// get the workflow id from the account management of a particular business user
// for a specific process type(refurbish,recycle) and
// process sequence(order creation,order submission)

const getWorkflow = async (userId, processStageSequence, ProcessType) => {
  const workflowDetail = await Workflow
    .findOne({
      where:
      {
        bp_id: userId,
        process_type_id: ProcessType,
        process_stage_sequence: processStageSequence,
      },

    });
  return workflowDetail;
};

exports.createOrderWfApprover = async (order_workflow_id, workflow_id, sequence, orderId) => {
  const workflow = await Models.workflow_approver.findOne({
    where:
      { workflow_id, approver_sequence: sequence },
    include: [{ model: Models.approver, as: 'approver', attributes: [['approver_email_id', 'approverEmailId']] }],
  });
  if (workflow) {
    await orderWorkflowApprover.create({
      order_workflow_id,
      workflow_approver_id: workflow.workflow_approver_id,
      approver_sequence: sequence,
    });
    approvalService.notifyApprover('approval requested', orderId, workflow.approver.dataValues.approverEmailId);
  }
};

exports.createOrderWorkflow = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { orderId } = req.params;
    const order = await Models.order.findOne({ where: { order_id: orderId }, attributes: ['order_id'] });
    if (order) await order.update({ order_position: 'In Progress' });
    else throw new Error('Invalid Order Id');
    const orderWorkflow = await exports.createOrderWorkflowData(userId, req.body);
    return orderWorkflow;
  } catch (error) {
    return next(error);
  }
};

exports.createOrderWorkflowData = async (userId, body) => {
  const {
    orderId, processStageSequence, processType, addApprovers, commentsForApprover,
  } = body;
  const workflow = await getWorkflow(userId, processStageSequence, processType);
  if (workflow) {
    const orderWorkflow = await createOrderWorkflowSkeleton(orderId, workflow.workflow_id);
    if (addApprovers !== 'false') {
      const { order_workflow_id, workflow_id } = orderWorkflow;
      await exports.createOrderWfApprover(order_workflow_id, workflow_id, '1', orderId);
    }

    if (commentsForApprover) {
      await order_notes.create({
        order_id: orderId,
        activity: `${workflow.process_stage_name} comments from GP`,
        activity_identifier: `pss_${processStageSequence}|gp_${userId}`,
        activity_comment: commentsForApprover,
        is_internal: true,
        updated_by: userId,
      });
    }

    return orderWorkflow;
  }
};
