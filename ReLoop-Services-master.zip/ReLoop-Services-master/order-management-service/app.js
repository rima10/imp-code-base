const express = require('express');

const cors = require('cors');

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json({ limit: '50mb' }));

app.use(cors({
  origin: ['http://localhost:3001', 'http://localhost:3002'],
  optionsSuccessStatus: 200,
  methods: ['POST', 'PUT', 'GET', 'OPTIONS', 'HEAD'],
  credentials: true,
}));
module.exports = app;

// Add routes to the application
require('./src/routes/order.route')(app);
require('./src/routes/wasteCategory.route')(app);
require('./src/routes/orderItem.route')(app);
require('./src/routes/swagger.route')(app);
require('./src/routes/approval.route')(app);
require('./src/routes/orderWorkflow.route')(app);
require('./src/routes/quotation.route')(app);
require('./src/routes/document.route')(app);

app.use((req, res, next) => {
  const error = new Error('method not found');
  res.status(404).json({
    error: {
      message: 'method not found',
    },
  });
  next(error);
});

// centralized error handler middleware for the app
// eslint-disable-next-line no-unused-vars
app.use((error, req, res, next) => {
  if (!res.headersSent) {
    res.status(500).json({
      error: {
        message: error.message,
      },
    });
  }
});
