const dataTypes = require('sequelize').DataTypes;
const ses = require('../utils/ses.util');
const { sequelize } = require('../models/index');
const Models = require('../models/init-models')(sequelize, dataTypes);

const storeNotification = async (type, message, comment, receivers) => {
  const event = await Models.event.findOne({ where: { event_type: type } });
  const notification = await Models.notification.create({
    event_id: event.event_id,
    notification_text: comment,
    notification_body: message,
  });
  receivers.map(async (receiver) => {
    const { receiverType, email } = receiver;
    let receiverId = '';
    if (receiverType === 'bp') {
      const receiverUser = await Models.business_partner.findOne({ where: { bp_email_id: email } });
      receiverId = receiverUser.bp_id;
    } else {
      const receiverUser = await Models.approver.findOne({ where: { approver_email_id: email } });
      receiverId = receiverUser.approver_id;
    }
    await Models.bp_notification.create({
      notification_id: notification.notification_id,
      bp_id: receiverType === 'bp' ? receiverId : null,
      approver_id: receiverType === 'bp' ? null : receiverId,
    });
  });
};

const getMessage = (type, values) => {
  const { orderNo, approver, recycler, greenPartnerName } = values;
  switch (type) {
    case 'new order':
      return 'A new order is added and waiting for your approval';
    case 'waiting approval':
      return `Order No: ${orderNo} is awaiting for your approval`;
    case 'request accepted':
      return `Approval request accepted for Order No: ${orderNo} by approver : ${approver}`;
    case 'request rejected':
      return `Approval request rejected for Order No: ${orderNo} by approver : ${approver}`;
    case 'approval requested':
      return `Requested Approval for Order No: ${orderNo}`;
    case 'quote submitted':
      return `New quote has been submitted for Order No:${orderNo} by recycler : ${recycler}`;
    case 'asset grading completed':
      return `Asset grading completed for Order No:${orderNo} by recycler : ${recycler}`;
    case 'invite recyclers':
      return `Hello recycler!! You are invited by Green Partner : ${greenPartnerName} to submit quotation for: ${orderNo}`;
    case 'accept schedule':
      return `Hello Green Partner! Schedule for onsite visit for OrderNo:${orderNo} is accepted by the recycler: ${recycler} `;
    default:
      return false;
  }
};

exports.notify = async (notification) => {
  const messageJson = JSON.parse(notification.value.toString());
  const { type, receivers, values } = messageJson;
  const messageText = getMessage(type, values);
  await storeNotification(type, messageText, values.comment, receivers);
};
