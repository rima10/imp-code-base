const dataTypes = require('sequelize').DataTypes;
const { sequelize } = require('../models/index');
const businessPartner = require('../models/business_partner')(sequelize, dataTypes);
const approver = require('../models/approver')(sequelize, dataTypes);

exports.getUserDatabyCognito = async (cognitoId) => {
  const bpData = await businessPartner.findOne({
    where: {
      bp_userid: cognitoId,
      // Will be used when existing useer archive flag is set to false
      // [Op.not]: [{ archive: true }],
    },
    attributes: [['bp_id', 'bpId']],
  });
  if (!bpData) return false;
  return bpData;
};

exports.getApproverDatabyCognito = async (cognitoId) => {
  const approverData = await approver.findOne({
    where: {
      approver_userid: cognitoId,
    },
    attributes: [['approver_id', 'approverId']],
  });
  return approverData;
};
