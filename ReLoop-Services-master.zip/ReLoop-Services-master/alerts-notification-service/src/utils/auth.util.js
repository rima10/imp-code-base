const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
const got = require('got');
const jwkToPem = require('jwk-to-pem');
const userService = require('../services/user.service');

exports.ROLES = {
  GP_USER: 'ReLoopGreenPartner',
  RP_USER: 'ReLoopRecyclerPartner',
  GP_APPROVER: 'ReLoopGPApprover',
  ADMIN: 'ReLoopAdmin',
};

dotenv.config();

const { COGNITO_USER_POOL_ID, POOL_REGION } = process.env;

/*
  @desc Fetch JSONWebKeys from cognito to validate the JWT token
  @desc JWKs is fetched dynamically everytime for security resons as well as it can change in future
  @return Object - pems
*/
async function fetchJwks() {
  const url = `https://cognito-idp.${POOL_REGION}.amazonaws.com/${COGNITO_USER_POOL_ID}/.well-known/jwks.json`;
  const jwks = await got(url, { responseType: 'json' });
  const pems = {};
  const { keys } = jwks.body;
  for (let i = 0; i < keys.length; i += 1) {
    const keyId = keys[i].kid;
    const jwk = { kty: keys[i].kty, n: keys[i].n, e: keys[i].e };
    const pem = jwkToPem(jwk);
    pems[keyId] = pem;
  }
  return pems;
}

/*
  @desc validates JWT token with pems
  @param Object pems
  @param String token
  @return Object - pems
*/

const validateJWT = async (pems, token) => {
  try {
    const decodedJwt = jwt.decode(token, { complete: true });
    if (!decodedJwt) {
      throw new Error('not a valid JWT token');
    }
    const { kid } = decodedJwt.header;
    const pem = pems[kid];
    if (!pem) {
      throw new Error('not a valid JWT token');
    }
    const result = jwt.verify(token, pem);
    return result;
  } catch (error) {
    throw new Error('not a valid JWT token');
  }
};

// returns an object with the cookies' name as keys
const getCookies = (req) => {
  // We extract the raw cookies from the request headers
  if (!req.headers.cookie) return req.headers.cookie;
  const rawCookies = req.headers.cookie.split('; ');
  const parsedCookies = {};
  rawCookies.forEach((rawCookie) => {
    const parsedCookie = rawCookie.split('=');
    const [key, val] = parsedCookie;
    parsedCookies[key] = val;
  });
  return parsedCookies;
};

/*
  @desc controller function to validate JWT token
  @desc JWKs is fetched dynamically everytime for security resons as well as it can change in future
  @return Object - pems
*/

exports.validateMiddleware = async (req, res, next) => {
  try {
    const pems = await fetchJwks();
    let { authorization } = req.headers;
    if (!authorization) authorization = getCookies(req).authorization;
    else {
      const [, token] = authorization.split(' ');
      authorization = token;
    }
    const decodedJWT = await validateJWT(pems, authorization);
    req.userInfo = decodedJWT;
    next();
  } catch (error) {
    res.status(401).json({
      error: {
        message: 'Unauthorized',
      },
    });
    next(error);
  }
};

exports.isGpOrRp = async (req, res, next) => {
  try {
    const groups = req.userInfo['cognito:groups'];
    const cognitoId = req.userInfo['cognito:username'];
    if (!(groups.includes(exports.ROLES.RP_USER) || groups.includes(exports.ROLES.GP_USER))) {
      res.status(403).json({
        error: {
          message: 'Unauthorized',
        },
      });
    } else {
      const user = await userService.getUserDatabyCognito(cognitoId);
      req.userInfo.userId = user.dataValues.bpId;
      next();
    }
  } catch (error) {
    next(error);
  }
};

exports.isGPApproverUser = async (req, res, next) => {
  try {
    const groups = req.userInfo['cognito:groups'];
    const cognitoId = req.userInfo['cognito:username'];
    if (!groups.includes(exports.ROLES.GP_APPROVER)) {
      res.status(403).json({
        error: {
          message: 'Unauthorized',
        },
      });
    } else {
      const user = await userService.getApproverDatabyCognito(cognitoId);
      req.userInfo.userId = user.dataValues.approverId;
      next();
    }
  } catch (error) {
    next(error);
  }
};

exports.isGpOrRPorApprover = async (req, res, next) => {
  try {
    const groups = req.userInfo['cognito:groups'];
    const cognitoId = req.userInfo['cognito:username'];
    if (!(groups.includes(exports.ROLES.GP_APPROVER) || groups.includes(exports.ROLES.GP_USER)
    || groups.includes(exports.ROLES.RP_USER))) {
      res.status(403).json({
        error: {
          message: 'Unauthorized',
        },
      });
    } else {
      let user = await userService.getUserDatabyCognito(cognitoId);
      if (!user) {
        user = await userService.getApproverDatabyCognito(cognitoId);
        req.userInfo.isApprover = true;
        req.userInfo.userId = user.dataValues.approverId;
      } else req.userInfo.userId = user.userId;
      next();
    }
  } catch (error) {
    next(error);
  }
};
