const router = require('express').Router();
const notificationController = require('../controllers/notification.controller');
const authUtil = require('../utils/auth.util');

module.exports = (app) => {
  router.get('/getNotifications', [authUtil.validateMiddleware, authUtil.isGpOrRp], notificationController.getNotifications);
  router.get('/getApproverNotifications', [authUtil.validateMiddleware, authUtil.isGPApproverUser], notificationController.getApproverNotifications);
  router.post('/readNotification/:bpNotificationId',
    [authUtil.validateMiddleware, authUtil.isGpOrRPorApprover],
    notificationController.readNotification);
  app.use('/api/notification', router);
};
