import {
    SET_ORDER_LIST_INFO,
    SET_ORDER_INFO,
    SET_ORDER_QUOTATION,
    SET_REFURBISH_ORDER_ITEM_QUOTATION,
    SET_RECYCLE_ORDER_ITEM_QUOTATION

} from "../action/type";

export default (state = {}, action) => {
    const { type, payload } = action;
    switch (type) {
        case SET_ORDER_LIST_INFO:
            return {
                ...state,
                orderList: payload
            };
        case SET_ORDER_INFO:
            return {
                ...state,
                order: payload
            };
        case SET_ORDER_QUOTATION:
            return { ...state, orderQuotation: payload };

        case SET_REFURBISH_ORDER_ITEM_QUOTATION:
            return { ...state, orderItemQuotation: { orderQuoteItems: payload } };

        case SET_RECYCLE_ORDER_ITEM_QUOTATION:
            return { ...state, orderItemQuotation: payload };

        default:
            return state;
    }
};


