import { setUserInfo, loadInProgress, loadCompleted,
    setOrderListInfo, setNotificationsInfo, setOrderInfo,
    setOrderQuotation, orderQuotationFailed,
    setRefurbishOrderItemQuotation, setRecycleOrderItemQuotation }
    from "./type";
import { getToken } from '../../utils/authUtils';
import http from '../../utils/httpService';
import { getErrorMessage } from '../../utils/errorMessage';


const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

export const getUserData = (cognitoId) => async (dispatch, getState) => {
    try {
        const response = await http.get(API_BASE_URL + `user/getUserData/${cognitoId}?approver=true`,
            { withCredentials: true });
        dispatch(setUserInfo(response.data, true));
        dispatch(loadCompleted());
    } catch (error) {
        dispatch(setUserInfo(null, false));
        dispatch(loadCompleted());
    }
};

export const validateUser = (tokenObj) => async (dispatch, getState) => {
    try {
        const isLoggedIn = getState().userInfo.isLoggedIn;
        if (!isLoggedIn) {
            dispatch(loadInProgress());
            let params = {
                withCredentials: true
            };
            if (tokenObj) {
                params.headers = {
                    authorization: 'Bearer ' + tokenObj.idToken,
                    refresh: tokenObj.refreshToken
                };
            }
            const response = await http.axiosPost(API_BASE_URL + 'auth/validate?app=approver', null, params);
            const userData = await http.get(API_BASE_URL + `user/getUserData/${response.data.cognitoId}?approver=true`,
                { withCredentials: true });
            const csrfData = await http.head(API_BASE_URL + 'getCsrf',
                { withCredentials: true });
            const csrf = csrfData.headers['csrf-token'];
            dispatch(setUserInfo(userData.data, true, csrf));
            dispatch(loadCompleted());
        }
    } catch (error) {
        dispatch(setUserInfo(null, false));
        dispatch(loadCompleted());
    }
};


export const getAccessToken = () => async (dispatch, getState) => {
    const tokenObj = await getToken();
    await validateUser(tokenObj)(dispatch, getState);
};

export const logout = () => async () => {
    await http.post(`${API_BASE_URL}auth/logout`, null, {
        withCredentials: true
    });
};

export const getOrdersInfo = (payload) => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.approverId;
        const orders = await http.get(`${API_BASE_URL}order/approval/getPendingApprovals/${userId}`,
            { withCredentials: true });
        dispatch(setOrderListInfo(orders.data));
    } catch (error) {
        console.log(error);
    }
};

export const getOrderInfo = (orderId) => async (dispatch, getState) => {
    try {
        const orders = await http.get(`${API_BASE_URL}order/getOrderForApprover/${orderId}`,
            { withCredentials: true });
        dispatch(setOrderInfo(orders.data));
    } catch (error) {
        console.log(error);
    }
};

export const approveRequest = (payload) => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.approverId;
        const orders = await http.post(`${API_BASE_URL}order/approval/approve/${userId}`, payload,
            { withCredentials: true });
        dispatch(setOrderListInfo(orders.data));
    } catch (error) {
        console.log(error);
    }
};

export const rejectRequest = (payload) => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.approverId;
        const orders = await http.post(`${API_BASE_URL}order/approval/reject/${userId}`, payload,
            { withCredentials: true });
        dispatch(setOrderListInfo(orders.data));
    } catch (error) {
        console.log(error);
    }
};

export const getNotificationInfo = () => async (dispatch, getState) => {
    try {
        const notifications = await
        http.get(`${API_BASE_URL}notification/getApproverNotifications?$skip=0&top=5`,
            { withCredentials: true });
        dispatch(setNotificationsInfo(notifications.data));
    } catch (error) {
        console.log(error);
    }
};

export const readNotification = (bpNotificationId) => async (dispatch, getState) => {
    try {
        await http.post(`${API_BASE_URL}notification/readNotification/${bpNotificationId}`, null,
            { withCredentials: true });
        dispatch(getNotificationInfo()(dispatch, getState));
    } catch (error) {
        console.log(error);
    }
};


export const downloadFile = async (orderId, key) => {
    try {
        const response = await http.get(`${API_BASE_URL}order/document/downloadDocument/${orderId}/${key}`, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([response.data]);
        const url = window.URL.createObjectURL(responseBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = key;
        a.click();
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        console.log(errorMessage);
    }
};

export const getOrderQuotation = (orderId, orderType) => async (dispatch) => {
    try {
        const endpointName = orderType === '1' ? 'getRefurbishOrderInitialQuotes' : 'getRecycleOrderInitialQuotes';
        const response = await http.get(`${API_BASE_URL}order/quotation/${endpointName}/${orderId}`, {
            withCredentials: true
        });
        dispatch(setOrderQuotation(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderQuotationFailed(errorMessage));
    }
};

export const getOrderItemLevelQuote = (orderId, quoteId, orderType,) => async (dispatch) => {
    try {
        let url;
        if (orderType === '1') {
            url = `${API_BASE_URL}order/quotation/refurbish/grading/${orderId}/${quoteId}`;
        } else if (orderType === '2') {
            url = `${API_BASE_URL}order/quotation/getRecycleOrderFinalQuote/${orderId}`;
        }
        const response = await http.get(url, {
            withCredentials: true
        });
        if (orderType === '1') {
            dispatch(setRefurbishOrderItemQuotation(response.data));
        } else if (orderType === '2') {
            dispatch(setRecycleOrderItemQuotation(response.data));
        }
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderQuotationFailed(errorMessage));
    }
};


export const temporaryAcceptQuote = (orderId, quoteId, orderType) => async (dispatch, getState) => {
    try {
        await http.post(`${API_BASE_URL}order/quotation/temporaryAcceptQuote/${orderId}/${quoteId}`, null, {
            withCredentials: true
        });
        await getOrderQuotation(orderId, orderType)(dispatch, getState);
    } catch (error) {
        getErrorMessage(error);
    }
};

export const rejectQuote = (orderId, quoteId, orderType) => async (dispatch, getState) => {
    try {
        await http.post(`${API_BASE_URL}order/quotation/rejectQuote/${orderId}/${quoteId}`, {
            withCredentials: true
        });
        await getOrderQuotation(orderId, orderType)(dispatch, getState);
    } catch (error) {
        getErrorMessage(error);
    }
};
