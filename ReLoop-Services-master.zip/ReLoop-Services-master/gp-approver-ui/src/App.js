import React, { Component } from "react";
import { ThemeProvider } from '@ui5/webcomponents-react';
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Home from "./view/home/Home";
import '@ui5/webcomponents/dist/Assets.js';
import PrivateRoute from "./view/login/PrivateRoute";
import LoginSuccess from './view/login/loginSuccess';
import { Provider } from "react-redux";
import { store } from "./store/store";
import ErrorComponent from './view/common/Error';
import CognitoRedirect from './view/login/CognitoRedirect';

class App extends Component {
    constructor (props) {
        super(props);
    }

    render () {
        return (
            <Provider store = {store}>
                <ThemeProvider>
                    <BrowserRouter>
                        <Switch>
                            <Route path="/loginSuccessful">
                                <LoginSuccess/>
                            </Route>
                            <PrivateRoute exact path="/" component={Home}/>
                            <Route exact path="/logout"
                                component={() => <ErrorComponent text="User signed out" redirect/>} />
                            <Route exact path="/login" component={CognitoRedirect} />
                        </Switch>
                    </BrowserRouter>
                </ThemeProvider>
            </Provider>
        );
    }
}
export default App;
