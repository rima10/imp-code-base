import React from 'react';
import { Label, Button, Toolbar, Input, Table,
    TableColumn, ToolbarSpacer, TableRow, TableCell, Text, Select, Option, Title } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from "@ui5/webcomponents-react-base";
import "@ui5/webcomponents/dist/features/InputElementsFormSupport.js";

const AccountTable = ({ rows = [], columns = [], buttons = [], edit = false, text }) => {
    const getCell = (cell) => {
        switch (cell.type) {
            case 'text':
                return (<Text className="tableCellText" tooltip={cell.value}
                    style={spacing.sapUiTinyMarginBeginEnd}>{cell.value}</Text>);
                break;
            case 'input':
                return (<Input key={cell.name} name ={cell.name}
                    onChange={(e) => { cell.onInputChange(e);}}/>);
                break;
            case 'select':
                return (<Select onChange={(e) => { cell.onInputChange(e); }}>
                    {cell.options.map((item) => (
                        <Option key={item.approver_id} id={item.approver_id}
                            name={item.approver_name} value={item.approver_role}>
                            {item.approver_role}
                        </Option>
                    ))}
                </Select>);
        }
    };
    const renderFunction = () => {
        return (<div>
            <Toolbar className="" slot="" style={{ ...spacing.sapUiMediumMarginTop }} tooltip="">
                <Title>{text}</Title>
                <ToolbarSpacer />
                <div>
                    {buttons.map((button) => {
                        return (
                            <Button
                                key={button.name}
                                onClick={button.onClick}
                                icon={button.icon}
                            >
                                {button.name}
                            </Button>
                        );
                    })}
                </div>
            </Toolbar>
            <Table showNoData noDataText={'No data available'} columns={columns.map(column => {
                return <TableColumn style={{ width: '33rem' }}><Label>{column}</Label></TableColumn>;
            })
            }>
                {rows.map((row, idx) => (
                    <TableRow key = {idx}>
                        {row.map((cell, id) => {
                            return (<TableCell key={id} > {getCell(cell)}</TableCell>);
                        })}
                    </TableRow>
                ))}
            </Table>
        </div>);
    };
    return (renderFunction());
};

export default AccountTable;
