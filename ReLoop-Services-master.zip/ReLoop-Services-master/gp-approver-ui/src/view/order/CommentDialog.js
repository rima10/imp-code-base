import React from 'react';
import { spacing } from "@ui5/webcomponents-react-base";
import PropTypes from 'prop-types';
import { Button, Form,
    FormItem, TextArea, Dialog } from '@ui5/webcomponents-react';
const CommentDialog = React.forwardRef(({ onSubmit, onCancel, onCommentChange, btnText }, ref) => {
    return (<Dialog
        className=""
        ref={ref}
        footer={<div style={spacing.sapUiSmallMargin}>
            <Button style={spacing.sapUiTinyMargin} onClick={onCancel}>Close</Button>
            <Button style={spacing.sapUiTinyMargin} onClick={onSubmit}>{btnText}</Button></div>}
        headerText="Add Comments"
    >
        <Form>
            <FormItem label="Comments">
                <TextArea onChange={onCommentChange}/>
            </FormItem>
        </Form>
    </Dialog>);
});
CommentDialog.propTypes = {
    onSubmit: PropTypes.func,
    onCancel: PropTypes.func,
    onCommentChange: PropTypes.func,
    btnText: PropTypes.string
};
export default CommentDialog;
