import React, { useState, useEffect } from 'react';
import AccountTable from '../common/Table';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import {
    getOrderItemLevelQuote, getOrderInfo
} from '../../store/action/taskAction';

const ApproveFinalQuote = ({ orderWorkflow, startGetItemQuote, orderItemQuotation,
    startGetOrderInfo, orderType, orderInfo }) => {
    const [assetRows, setAssetRows] = useState([]);
    const assetColumns = [
        'Equipment No.',
        'Asset No.',
        'Grade',
        'Blancco',
        'Report status',
        'List price',
        'To be invoiced',
        'service cost'

    ];

    const recycleAssetColumns = [
        'Item',
        'Final Quantity',
        'Unit',
        'Price per Unit (INR)',
        'Total Price (INR)'
    ];

    const getOrderItemQuoteDetails = (orderItemQuotation) => {
        const newRows = [];
        if (orderType === '1') {
            orderItemQuotation.orderQuoteItems.map((orderItem) => {
                const row = [];
                row.push({ name: assetColumns[0], value: orderItem.equipmentNumber, type: 'text' });
                row.push({ name: assetColumns[1], value: orderItem.assetNumber, type: 'text' });
                row.push({ name: assetColumns[2], value: orderItem.grade, type: 'text' });
                row.push({ name: assetColumns[3], value: orderItem.dataWipeStatus, type: 'text' });
                row.push({ name: assetColumns[4], value: orderItem.reportStatus, type: 'text' });
                row.push({ name: assetColumns[5], value: orderItem.listPrice, type: 'text' });
                row.push({ name: assetColumns[6], value: orderItem.serviceCost, type: 'text' });
                row.push({ name: assetColumns[7], value: orderItem.invoiceAmount, type: 'text' });
                newRows.push(row);
            });
        } else {
            orderItemQuotation.orderQuoteItems.map((orderItem) => {
                const row = [];
                row.push({ name: assetColumns[0], value: orderItem.item, type: 'text' });
                row.push({ name: assetColumns[1], value: orderItem.finalQty, type: 'text' });
                row.push({ name: assetColumns[2], value: orderItem.unit, type: 'text' });
                row.push({ name: assetColumns[3], value: orderItem.pricePerUnit, type: 'text' });
                row.push({ name: assetColumns[4], value: orderItem.totalPrice, type: 'text' });
                newRows.push(row);
            });
        }
        return newRows;
    };

    const getColumns = () => {
        return orderType === '1' ? assetColumns : recycleAssetColumns;
    };
    useEffect(() => {
        startGetOrderInfo(orderWorkflow.orderId);
    }, []);

    useEffect(() => {
        if (orderItemQuotation) {
            const assetRows = getOrderItemQuoteDetails(orderItemQuotation);
            setAssetRows(assetRows);
        }
    }, [orderItemQuotation]);

    useEffect(() => {
        if (orderInfo) {
            startGetItemQuote(orderInfo.orderId, orderInfo.acceptedOrderQuote.quoteId, orderType);
        }
    }, [orderInfo]);
    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <AccountTable columns={getColumns()} edit={false} text="Asset List" rows={assetRows} />
        </div>
    );
};


const mapStateToProps = (state) => {
    return {
        orderItemQuotation: state.order.orderItemQuotation,
        orderInfo: state.order.order
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetItemQuote: (orderId, quoteId, orderType) =>
            dispatch(getOrderItemLevelQuote(orderId, quoteId, orderType)),
        startGetOrderInfo: (orderId) => dispatch(getOrderInfo(orderId))
    };
};
ApproveFinalQuote.propTypes = {
    orderWorkflow: PropTypes.object,
    startGetItemQuote: PropTypes.func,
    orderItemQuotation: PropTypes.object,
    startGetOrderInfo: PropTypes.func,
    orderType: PropTypes.string,
    orderInfo: PropTypes.object
};
export default connect(mapStateToProps, mapDispatchToProps)(ApproveFinalQuote);
