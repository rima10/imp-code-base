import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import CognitoRedirect from './CognitoRedirect';
import { validateUser } from '../../store/action/taskAction';
import { Route } from "react-router-dom";
import LoadingIndicator from '../common/Loading';
import PropTypes from 'prop-types';


const PrivateRoute = ({ component: Component, path, isLoading, startValidateUser, userInfo = {}, ...rest }) => {
    useEffect(() => {
        startValidateUser();
    }, []);
    const redirect = <CognitoRedirect/>;
    const routeComponent = () => {
        if (isLoading) return <LoadingIndicator/>;
        else {
            return (userInfo.isLoggedIn ? <Component userInfo={userInfo}/> : redirect);
        }
    };
    return <Route path={path} {...rest} render={routeComponent}/>;
};


const mapStateToProps = state => {
    return {
        isLoading: state.isLoading,
        userInfo: state.userInfo
    };
};

const mapDispatchToProps = dispatch => {
    return {
        startValidateUser: () => dispatch(validateUser())
    };
};
PrivateRoute.propTypes = {
    component: PropTypes.elementType,
    path: PropTypes.string,
    startValidateUser: PropTypes.func,
    isLoading: PropTypes.bool,
    userInfo: PropTypes.object
};
export default connect(mapStateToProps, mapDispatchToProps)(PrivateRoute);
