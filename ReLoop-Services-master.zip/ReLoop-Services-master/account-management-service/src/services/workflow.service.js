const dataTypes = require('sequelize').DataTypes;
const { Op } = require('sequelize');
const { sequelize } = require('../models/index');
const Workflow = require('../models/workflow')(sequelize, dataTypes);
const WorkflowApprover = require('../models/workflow_approver')(sequelize, dataTypes);
const models = require('../models/init-models')(sequelize, dataTypes);

async function getWorkflows(userId) {
  const workflows = await models.workflow
    .findAll({
      where:
      { bp_id: userId },
      attributes: ['workflow_id', 'process_stage_name', 'process_stage_sequence', 'process_type_id'],
      include: [{
        model: models.workflow_approver, attributes: ['approver_sequence', 'workflow_approver_id'], include: { model: models.approver, as: 'approver', attributes: ['approver_id', 'approver_email_id', 'approver_name', 'approver_role'] }, as: 'workflow_approvers',
      }],
    });
  return workflows;
}
/*
  @desc helper function to create workflow
  @param Object - workflowData
  @param Array - approvers
  @return Oject - newWorkflow
*/
async function createWorkflow(workflowData, approvers) {
  let workflow;
  const {
    process_stage_sequence, process_stage_name, process_type_id, bp_id,
  } = workflowData;
  const existingWorkflow = await Workflow.findOne(
    {
      where: { process_type_id, process_stage_sequence, bp_id },
      attributes: ['workflow_id'],
    },
  );
  if (existingWorkflow) {
    workflow = existingWorkflow;
  } else {
    workflow = await Workflow.create(workflowData);
  }
  await Promise.all(approvers.map(async (approver) => {
    const { approverId, approverSequence } = approver;
    await WorkflowApprover.create({
      approver_id: approverId,
      approver_sequence: approverSequence,
      workflow_id: workflow.workflow_id,
    });
  }));
  return workflow;
}

/*
  @desc service function to add workflows
*/
exports.addWorkflows = async function (req, res, next) {
  const { workflows } = req.body;
  const { userId } = req.userInfo;
  await Promise.all(workflows.map(async (workflow) => {
    const {
      processStageSequence, processStageName, processTypeId, approvers,
    } = workflow;
    await createWorkflow({
      process_stage_name: processStageName,
      process_stage_sequence: processStageSequence,
      bp_id: userId,
      process_type_id: processTypeId,
    }, approvers);
  }));
};

/*
  @desc service function to add workflow
*/
exports.addWorkflow = async (req, res, next) => {
  try {
    const workflow = req.body;
    const { userId } = req.userInfo;
    const {
      processStageSequence, processStageName, processTypeId, approvers,
    } = workflow;
    const existingOrderStatus = await models.order.findAll({ where: { created_by: userId, order_position: 'In Progress', order_type: processTypeId }, attributes: [['order_position', 'orderPosition']] });
    if (existingOrderStatus.length !== 0) {
      throw new Error('Workflow cannot be added as being used in ongoing orders');
    } else {
      await createWorkflow({
        process_stage_name: processStageName,
        process_stage_sequence: processStageSequence,
        bp_id: userId,
        process_type_id: processTypeId,
      }, approvers);
      const workflows = await getWorkflows(userId);
      return workflows;
    }
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to get workflows
*/
exports.getWorkflows = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const workflows = await getWorkflows(userId);
    return workflows;
  } catch (error) {
    return next(error);
  }
};

exports.deleteWorkflow = async (req, res, next) => {
  const { userId } = req.userInfo;
  const { workflowId, processTypeId} = req.params;
  const existingOrderStatus = await models.order.findAll({ where: { created_by: userId, order_position: 'In Progress', order_type: processTypeId }, attributes: [['order_position', 'orderPosition']] });
  if (existingOrderStatus.length !== 0) {
    throw new Error('Workflow cannot be deleted as being used in ongoing orders');
  } else {
    await models.workflow.destroy({ where: { bp_id: userId, workflow_id: workflowId } });
    const workflows = await getWorkflows(userId);
    return workflows;
  }
};

exports.deleteWorkflowApprovers = async (req, res, next) => {
  const { userId } = req.userInfo;
  const { workflowApprovers, processTypeId } = req.body;
  const existingOrderStatus = await models.order.findAll({ where: { created_by: userId, order_position: 'In Progress', order_type: processTypeId }, attributes: [['order_position', 'orderPosition']] });
  if (existingOrderStatus.length !== 0) {
    throw new Error('Approver cannot be deleted as being used in ongoing orders');
  } else {
    await Promise.all(workflowApprovers.map(async (approver) => {
      const { workflowApproverId } = approver;
      // eslint-disable-next-line max-len
      const workflowApprover = await models.workflow_approver.findOne({ where: { workflow_approver_id: workflowApproverId } });
      await workflowApprover.destroy();
      await models.workflow_approver.update({ approver_sequence: sequelize.literal(('cast(approver_sequence as integer) - 1')) },
        {
          where: {
            workflow_id: workflowApprover.dataValues.workflow_id,
            approver_sequence: { [Op.gte]: workflowApprover.dataValues.approver_sequence },
          },
        });
    }));
    const workflows = await getWorkflows(userId);
    return workflows;
  }
};
