const { DataTypes } = require('sequelize');
const _approver = require('./approver');
const _bp_notification = require('./bp_notification');
const _bp_private_nwk = require('./bp_private_nwk');
const _business_partner = require('./business_partner');
const _category = require('./category');
const _certificate = require('./certificate');
const _city = require('./city');
const _country = require('./country');
const _doc = require('./doc');
const _event = require('./event');
const _location = require('./location');
const _notification = require('./notification');
const _process_type = require('./process_type');
const _role = require('./role');
const _role_bp_mapping = require('./role_bp_mapping');
const _serviceable_city = require('./serviceable_city');
const _serviceable_location = require('./serviceable_location');
const _serviceable_state = require('./serviceable_state');
const _state = require('./state');
const _workflow = require('./workflow');
const _workflow_approver = require('./workflow_approver');
const _order = require('./order');
const _order_invited_business_partner = require('./order_invited_business_partner');

function initModels(sequelize) {
  const approver = _approver(sequelize, DataTypes);
  const bp_notification = _bp_notification(sequelize, DataTypes);
  const bp_private_nwk = _bp_private_nwk(sequelize, DataTypes);
  const business_partner = _business_partner(sequelize, DataTypes);
  const category = _category(sequelize, DataTypes);
  const certificate = _certificate(sequelize, DataTypes);
  const city = _city(sequelize, DataTypes);
  const country = _country(sequelize, DataTypes);
  const doc = _doc(sequelize, DataTypes);
  const event = _event(sequelize, DataTypes);
  const location = _location(sequelize, DataTypes);
  const notification = _notification(sequelize, DataTypes);
  const process_type = _process_type(sequelize, DataTypes);
  const role = _role(sequelize, DataTypes);
  const role_bp_mapping = _role_bp_mapping(sequelize, DataTypes);
  const serviceable_city = _serviceable_city(sequelize, DataTypes);
  const serviceable_location = _serviceable_location(sequelize, DataTypes);
  const serviceable_state = _serviceable_state(sequelize, DataTypes);
  const state = _state(sequelize, DataTypes);
  const workflow = _workflow(sequelize, DataTypes);
  const workflow_approver = _workflow_approver(sequelize, DataTypes);
  const order_invited_business_partner = _order_invited_business_partner(sequelize, DataTypes);
  const order = _order(sequelize, DataTypes);
  serviceable_location.belongsTo(business_partner, { as: 'rcy', foreignKey: 'rcy_id' });
  business_partner.hasMany(serviceable_location, { as: 'serviceable_locations', foreignKey: 'rcy_id' });
  location.belongsTo(city, { as: 'city', foreignKey: 'city_id' });
  city.hasMany(location, { as: 'locations', foreignKey: 'city_id' });
  serviceable_city.belongsTo(city, { as: 'city', foreignKey: 'city_id' });
  city.hasMany(serviceable_city, { as: 'serviceable_cities', foreignKey: 'city_id' });
  location.belongsTo(country, { as: 'country', foreignKey: 'country_id' });
  country.hasMany(location, { as: 'locations', foreignKey: 'country_id' });
  serviceable_location.belongsTo(country, { as: 'country', foreignKey: 'country_id' });
  country.hasMany(serviceable_location, { as: 'serviceable_locations', foreignKey: 'country_id' });
  state.belongsTo(country, { as: 'country', foreignKey: 'country_id' });
  country.hasMany(state, { as: 'states', foreignKey: 'country_id' });
  serviceable_state.belongsTo(serviceable_location, { as: 'serv_loc', foreignKey: 'serv_loc_id' });
  serviceable_location.hasMany(serviceable_state, { as: 'serviceable_states', foreignKey: 'serv_loc_id' });
  serviceable_city.belongsTo(serviceable_state, { as: 'serv_loc_state', foreignKey: 'serv_loc_state_id' });
  serviceable_state.hasMany(serviceable_city, { as: 'serviceable_cities', foreignKey: 'serv_loc_state_id' });
  city.belongsTo(state, { as: 'state', foreignKey: 'state_id' });
  state.hasMany(city, { as: 'cities', foreignKey: 'state_id' });
  location.belongsTo(state, { as: 'state', foreignKey: 'state_id' });
  state.hasMany(location, { as: 'locations', foreignKey: 'state_id' });
  serviceable_state.belongsTo(state, { as: 'state', foreignKey: 'state_id' });
  state.hasMany(serviceable_state, { as: 'serviceable_states', foreignKey: 'state_id' });
  bp_notification.belongsTo(approver, { as: 'approver', foreignKey: 'approver_id' });
  approver.hasMany(bp_notification, { as: 'bp_notifications', foreignKey: 'approver_id' });
  bp_notification.belongsTo(business_partner, { as: 'bp', foreignKey: 'bp_id' });
  business_partner.hasMany(bp_notification, { as: 'bp_notifications', foreignKey: 'bp_id' });
  notification.belongsTo(event, { as: 'event', foreignKey: 'event_id' });
  event.hasMany(notification, { as: 'notifications', foreignKey: 'event_id' });
  bp_notification.belongsTo(notification, { as: 'notification', foreignKey: 'notification_id' });
  notification.hasMany(bp_notification, { as: 'bp_notifications', foreignKey: 'notification_id' });
  workflow_approver.belongsTo(approver, { as: 'approver', foreignKey: 'approver_id' });
  approver.hasMany(workflow_approver, { as: 'workflow_approvers', foreignKey: 'approver_id' });
  approver.belongsTo(business_partner, { as: 'bp', foreignKey: 'bp_id' });
  business_partner.hasMany(approver, { as: 'approvers', foreignKey: 'bp_id' });
  bp_private_nwk.belongsTo(business_partner, { as: 'nwk_owner_business_partner', foreignKey: 'nwk_owner' });
  business_partner.hasMany(bp_private_nwk, { as: 'bp_private_nwks', foreignKey: 'nwk_owner' });
  bp_private_nwk.belongsTo(business_partner, { as: 'nwk_member_business_partner', foreignKey: 'nwk_member' });
  business_partner.hasMany(bp_private_nwk, { as: 'nwk_member_bp_private_nwks', foreignKey: 'nwk_member' });
  certificate.belongsTo(business_partner, { as: 'bp', foreignKey: 'bp_id' });
  business_partner.hasMany(certificate, { as: 'certificates', foreignKey: 'bp_id' });
  role_bp_mapping.belongsTo(business_partner, { as: 'bp', foreignKey: 'bp_id' });
  business_partner.hasMany(role_bp_mapping, { as: 'role_bp_mappings', foreignKey: 'bp_id' });
  workflow.belongsTo(business_partner, { as: 'bp', foreignKey: 'bp_id' });
  business_partner.hasMany(workflow, { as: 'workflows', foreignKey: 'bp_id' });
  business_partner.belongsTo(location, { as: 'loc', foreignKey: 'loc_id' });
  location.hasMany(business_partner, { as: 'business_partners', foreignKey: 'loc_id' });
  workflow.belongsTo(process_type, { as: 'process_type', foreignKey: 'process_type_id' });
  process_type.hasMany(workflow, { as: 'workflows', foreignKey: 'process_type_id' });
  role_bp_mapping.belongsTo(role, { as: 'role', foreignKey: 'role_id' });
  role.hasMany(role_bp_mapping, { as: 'role_bp_mappings', foreignKey: 'role_id' });
  workflow_approver.belongsTo(workflow, { as: 'workflow', foreignKey: 'workflow_id' });
  workflow.hasMany(workflow_approver, { as: 'workflow_approvers', foreignKey: 'workflow_id' });
  order.belongsTo(business_partner, { as: 'businessPartner', foreignKey: 'created_by' });
  business_partner.hasMany(order, { as: 'orders', foreignKey: 'created_by' });
  order.belongsTo(business_partner, { as: 'updated_by_business_partner', foreignKey: 'updated_by' });
  business_partner.hasMany(order, { as: 'updated_by_orders', foreignKey: 'updated_by' });
  order.hasMany(order_invited_business_partner, { as: 'order_invited_business_partners', foreignKey: 'order_id' });
  order_invited_business_partner.belongsTo(order, { as: 'order', foreignKey: 'order_id' });
  business_partner.hasMany(order_invited_business_partner, { as: 'invitedOrders', foreignKey: 'invited_bp_id' });
  order_invited_business_partner.belongsTo(business_partner, { as: 'invited_bp', foreignKey: 'invited_bp_id' });
  return {
    approver,
    bp_notification,
    bp_private_nwk,
    business_partner,
    category,
    certificate,
    city,
    country,
    doc,
    event,
    location,
    notification,
    process_type,
    role,
    role_bp_mapping,
    serviceable_city,
    serviceable_location,
    serviceable_state,
    state,
    workflow,
    workflow_approver,
    order,
    order_invited_business_partner,
  };
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;
