const router = require('express').Router();
const approverController = require('../controllers/approver.controller');
const authUtil = require('../utils/auth.util');

module.exports = (app) => {
  /**
 * @swagger
 * /api/user/approver/addApprovers:
 *   post:
 *    description:  Endpoint to create approver data
 *    tags:
 *      - Approver
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              approvers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    approverEmailId:
 *                      type: string
 *                      description: approver email id
 *                      example: fake@email.com
 *                    approverName:
 *                      type: string
 *                      description: approver name.
 *                      example: Raj
 *                    approverRole:
 *                      type: string
 *                      description: approver role.
 *                      example: admin
 */
  router.post('/addApprovers', [authUtil.validateMiddleware, authUtil.isGpUser], approverController.addApprovers);

  /**
 * @swagger
 * /api/user/approver/getApprovers:
 *   get:
 *    description:  Endpoint to get list of GP approvers
 *    tags:
 *      - Approver
 *    responses:
 *       200:
 *         description: List of approvers.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Approver'
 */
  router.get('/getApprovers', [authUtil.validateMiddleware, authUtil.isGpUser], approverController.getApprovers);

  /**
 * @swagger
 * /api/user/approver/deleteApprovers/{approverId}:
 *   delete:
 *    description:  Endpoint to delete GP approver
 *    tags:
 *      - Approver
 *    parameters:
 *       - name: approverId
 *         description: id of the approver
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       201:
 *         description: List of approvers.
 *         content:
 *           application/json:
 */
  router.delete('/deleteApprovers/:approverId', [authUtil.validateMiddleware, authUtil.isGpUser], approverController.deleteApprover);
  /**
 * @swagger
 * /api/user/approver/deleteApprovers:
 *   delete:
 *    description:  Endpoint to delete GP approver
 *    tags:
 *      - Approver
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              approvers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    approverId:
 *                      type: string
 *                      description: approver user id
 *                      example: 1
 *    responses:
 *       201:
 *         description: List of approvers.
 *         content:
 *           application/json:
 */
  router.delete('/deleteApprovers', [authUtil.validateMiddleware, authUtil.isGpUser], approverController.deleteApprovers);

  /**
 * @swagger
 * /api/user/approver/updateApprovers:
 *   patch:
 *    description:  Endpoint to update approver data
 *    tags:
 *      - Approver
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              approvers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    approverEmailId:
 *                      type: string
 *                      description: approver email id
 *                      example: fake@email.com
 *                    approverName:
 *                      type: string
 *                      description: approver name.
 *                      example: Raj
 *                    approverRole:
 *                      type: string
 *                      description: approver role.
 *                      example: admin
 */
  router.patch('/updateApprovers', [authUtil.validateMiddleware, authUtil.isGpUser], approverController.updateApprovers);
  app.use('/api/user/approver', router);
};
