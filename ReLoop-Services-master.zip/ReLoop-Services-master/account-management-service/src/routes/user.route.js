const router = require('express').Router();
const multer = require('multer');

const upload = multer();

const userController = require('../controllers/user.controller');
const validator = require('../utils/validate.util');
const authUtil = require('../utils/auth.util');

/*
  @desc router configuartion for /api/user endpoint
*/

module.exports = (app) => {
  /**
 * @swagger
 * /api/user/register:
 *   post:
 *    description:  Endpoint to register business partner
 *    tags:
 *      - Business Partner
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/User'
 *    responses:
 *      200:
 *        description: Successfully Registered Business Partner.
 */
  router.post('/register', validator.createUserValidations, validator.validate, userController.register);

  /**
 * @swagger
 * /api/user/update:
 *   patch:
 *    description:  Endpoint to update business partner
 *    tags:
 *      - Business Partner
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/User'
 */
  router.patch('/update', [authUtil.validateMiddleware, authUtil.isGpOrRp], userController.updateUserBusinessData);

  /**
 * @swagger
 * /api/user/getBusinessInfo:
 *   get:
 *    description:  Endpoint to update business partner
 *    tags:
 *      - Business Partner
 *    responses:
 *       200:
 *         description: A list of user's private networks.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/User'
 */
  router.get('/getBusinessInfo', [authUtil.validateMiddleware, authUtil.isGpOrRp], userController.getUserBusinessData);
  /**
 * @swagger
 * /api/user/createprivatenetwork:
 *   post:
 *    description:  Endpoint to create business partner private network
 *    tags:
 *      - Private Network
 *    parameters:
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              pvtNwkMembers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    emailId:
 *                      type: string
 *                      format: email
 *                      description: Email for the user, needs to be unique.
 *                      example: 0
 *                    username:
 *                      type: string
 *                      description: The Recycling partner user's name.
 *                      example: Cerebra
 */
  router.post('/createprivatenetwork', [authUtil.validateMiddleware, authUtil.isGpOrRp], userController.createUserPrivateNtw);
  /**
 * @swagger
 * /api/user/getprivatenetwork:
 *   get:
 *    description:  Endpoint to get business partner private networks
 *    tags:
 *      - Private Network
 *    responses:
 *       200:
 *         description: A list of user's private networks.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/PrivateNetwork'
 */
  router.get('/getprivatenetwork', [authUtil.validateMiddleware, authUtil.isGpOrRp], userController.getUserPrivateNtw);

  /**
 * @swagger
 * /api/user/deleteprivatenetwork:
 *   delete:
 *    description:  Endpoint to delete business partner private networks
 *    tags:
 *      - Private Network
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              pvtNetworks:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    recyclerId:
 *                      type: string
 *                      description: private recycler user id
 *                      example: 1
 *                    networkId:
 *                      type: string
 *                      description: private network id
 *                      example: 1
 *    responses:
 *       200:
 *         description: A list of user's private networks.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/PrivateNetwork'
 */
  router.delete('/deleteprivatenetwork', [authUtil.validateMiddleware, authUtil.isGpOrRp], userController.deleteUserPrivateNtw);

  /**
 * @swagger
 * /api/user/updateUserPrivateNetwork:
 *   patch:
 *    description:  Endpoint to update business partner
 *    tags:
 *      - Private Network
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              pvtNwkMembers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    emailId:
 *                      type: string
 *                      format: email
 *                      description: Email for the user, needs to be unique.
 *                      example: rpuser@domain.com
 *                    username:
 *                      type: string
 *                      description: The Recycling partner user's name.
 *                      example: Cerebra
 */
  router.patch('/updateUserPrivateNetwork', [authUtil.validateMiddleware, authUtil.isGpOrRp], userController.updateUserPrivateNtw);

  /**
 * @swagger
 * /api/user/certificates:
 *   post:
 *    description:  Upload recycling partner's certificates to verify their business account
 *    tags:
 *      - RP Certificates
 *    requestBody:
 *      required: true
 *      content:
 *        multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *              certificateFile:
 *                type: array of files
 *                format: binary
 *              certificateDetails:
 *                type: array of object (json stringified)
 *                required: true
 *                properties:
 *                  certificateType:
 *                    type: string
 *                    description: Type of certificate
 *                  validPeriod:
 *                    type: date string
 *                    description: Effective valid period of the certificate
 *                    example: 2027-01-31 (YYYY-MM-DD)
 *                  authorizationNumber:
 *                    type: string
 *                    description: An unique certificate auth number
 *                    mandatory: false
 *                  issuedDate:
 *                    type: date string
 *                    description: Date of issue of Certificate
 *                    mandatory: false
 *                  recyclingCapacity:
 *                    type: integer
 *                    description: Units of recycling capacity
 *                    mandatory: false
 *                    example: 100
 *    responses:
 *       201:
 *         description: A list of RP user's newly created certificate details.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Certificate'
 */
  router.post('/certificates',
    upload.array('certificateFile'),
    [authUtil.validateMiddleware, authUtil.isRpUser],
    userController.saveCertificates);

  /**
 * @swagger
 * /api/user/certificates:
 *   get:
 *    description: to retrieve RP user's all certificate details
 *    tags:
 *      - RP Certificates
 *    responses:
 *       200:
 *         description: A list of RP user's certificate details uploaded.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                type: object
 *                $ref: '#/components/schemas/Certificate'
 */
  router.get('/certificates',
    [authUtil.validateMiddleware, authUtil.isRpUser],
    userController.getAllCertificates);

  /**
 * @swagger
 * /api/user/certificates/{certId}:
 *   get:
 *    description: to download certificate document by cert_id
 *    tags:
 *      - RP Certificates
 *    parameters:
 *       - name: certId
 *         description: id of the certificate row in db
 *         in: path
 *         required: true
 *         type: number
 *    responses:
 *       200:
 *         description: document downloaded.
 */
  router.get('/certificates/:certId',
    [authUtil.validateMiddleware, authUtil.isRpUser],
    userController.downloadCertificate);

  /**
 * @swagger
 * /api/user/getUserData/{cognitoId}:
 *   get:
 *    description:  Endpoint to get user data with cognito id
 *    tags:
 *      - Business Partner
 *    parameters:
 *       - name: cognitoId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: string
 *
 */
  router.get('/getUserData/:cognitoId', userController.getUserData);

  /**
 * @swagger
 * /api/user/addServicableLocation:
 *   post:
 *    description:  Endpoint to add service location for a recycler partner
 *    tags:
 *      - Serviceable Location
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              countryId:
 *                type: string
 *                description: Country Id
 *                example: 1
 *              isAllStateSelected:
 *                type: boolean
 *                description: flag to show if the service location is in all the states
 *                example: false
 *              serviceLocations:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    state:
 *                      type: string
 *                      description: state Id of the state
 *                      example: 2
 *                    stateName:
 *                      type: string
 *                      description: state Name of that state Id
 *                      example: Kashmir
 *                    isAllCitySelected:
 *                      type: boolean
 *                      description: flag to show if the service location is in all the cities
 *                      example: false
 *                    city:
 *                      type: array
 *                      items:
 *                        type: object
 *                        properties:
 *                          cityId:
 *                            type: string
 *                            description: city Id of the state
 *                            example: 2
 *                          cityName:
 *                            type: string
 *                            description: state Name of that state Id
 *                            example: Punch
 *    responses:
 *      200:
 *        description: Successfully added service location.
 */

  router.post('/addServicableLocation', [authUtil.validateMiddleware, authUtil.isRpUser], userController.addServicableLocation);

  /**
 * @swagger
 * /api/user/getServicableLocation:
 *   get:
 *    description:  Endpoint to get service location for a recycler partner
 *    tags:
 *      - Serviceable Location
 *    responses:
 *       200:
 *         description: A list of service location.
 *         content:
 *           application/json:
 *            schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/ServiceableLocation'
 */
  router.get('/getServicableLocation', [authUtil.validateMiddleware, authUtil.isRpUser], userController.getRecyclerServicableLocation);

  /**
 * @swagger
 * /api/user/deleteServicableLocation:
 *   delete:
 *    description:  Endpoint to delete recycler partner's ServiceableLocation
 *    tags:
 *      -  Serviceable Location
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              statesDetail:
 *                type: array
 *                items:
 *                  type: string
 *                  description: private recycler's state id
 *                  example: 1
 *    responses:
 *       200:
 *         description: A list of recycler's serviceable location.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/ServiceableLocation'
 */
  router.delete('/deleteServicableLocation', [authUtil.validateMiddleware, authUtil.isRpUser], userController.deleteServiceableLocation);

  /**
 * @swagger
 * /api/user/privacyStatement/{key}:
 *   get:
 *    description: to view privacy statement
 *    tags:
 *      - Privacy Statement
 *    parameters:
 *       - name: key
 *         description: name of the privacy statement file
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: document downloaded.
 */
  router.get('/privacyStatement/:key',
    [authUtil.validateMiddleware, authUtil.isGpOrRp],
    userController.downloadPrivacyStatement);

  /**
 * @swagger
 * /api/user/getGPPersonalData:
 *   get:
 *    description:  Endpoint to get personal data for a green partner
 *    tags:
 *      - Serviceable Location
 *    responses:
 *       200:
 *         description: A list of service location.
 *         content:
 *           application/json:
 *            schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/ServiceableLocation'
 */
  router.get('/getGPPersonalData', [authUtil.validateMiddleware, authUtil.isGpUser], userController.getGPPersonalData);

  /**
 * @swagger
 * /api/user/getRPPersonalData:
 *   get:
 *    description:  Endpoint to get personal data for a green partner
 *    tags:
 *      - Serviceable Location
 *    responses:
 *       200:
 *         description: A list of service location.
 *         content:
 *           application/json:
 *            schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/ServiceableLocation'
 */
  router.get('/getRPPersonalData', [authUtil.validateMiddleware, authUtil.isRpUser], userController.getRPPersonalData);
  app.use('/api/user', router);
};
