const workflowService = require('../services/workflow.service');

/*
  @desc controller function to add workflows
*/
exports.addWorkflows = async (req, res, next) => {
  try {
    const workflows = await workflowService.addWorkflows(req, res, next);
    res.status(201).json(workflows);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to add workflow
*/
exports.addWorkflow = async (req, res, next) => {
  try {
    const workflows = await workflowService.addWorkflow(req, res, next);
    res.status(201).json(workflows);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get workflows
*/
exports.getWorkflows = async (req, res, next) => {
  try {
    const workflows = await workflowService.getWorkflows(req, res, next);
    res.status(201).json(workflows);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to delete workflow
*/
exports.deleteWorkflow = async (req, res, next) => {
  try {
    const workflows = await workflowService.deleteWorkflow(req, res, next);
    res.status(201).json(workflows);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to delete workflow approvers
*/
exports.deleteWorkflowApprovers = async (req, res, next) => {
  try {
    const workflows = await workflowService.deleteWorkflowApprovers(req, res, next);
    res.status(201).json(workflows);
  } catch (error) {
    // To be Updated
    next(error);
  }
};
