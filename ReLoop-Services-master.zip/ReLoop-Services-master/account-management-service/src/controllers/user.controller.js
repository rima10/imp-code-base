/* eslint-disable max-len */
/* eslint-disable no-param-reassign */
const mime = require('mime');
const { Readable } = require('stream');
const moment = require('moment');

const userService = require('../services/user.service');
const businessDataService = require('../services/businessData.service');
const privateNtwService = require('../services/privateNtw.service');
const certificateService = require('../services/certificate.service');
const serviceLocationService = require('../services/serviceLocation.service');

/*
  @desc controller function for user registeration
*/
exports.register = async (req, res, next) => {
  try {
    await userService.register(req);
    res.send(200);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for get user data
*/
exports.getUserBusinessData = async (req, res, next) => {
  try {
    const userData = await businessDataService.getUserBusinessData(req, res, next);
    res.json(userData);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for user business data update
*/
exports.updateUserBusinessData = async (req, res, next) => {
  try {
    const userData = await businessDataService.updateUserBusinessData(req, res, next);
    res.status(201).json(userData);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for user pvt ntw update
*/
exports.createUserPrivateNtw = async (req, res, next) => {
  try {
    const privateNetworks = await privateNtwService.createUserPrivateNtw(req, res, next);
    res.status(201).json(privateNetworks);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for user pvt ntw update
*/
exports.getUserPrivateNtw = async (req, res, next) => {
  try {
    const userPrivateNtws = await privateNtwService.getUserPrivateNtw(req, res, next);
    res.json(userPrivateNtws);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for user pvt ntw update
*/
exports.updateUserPrivateNtw = async (req, res, next) => {
  try {
    const privateNetworks = await privateNtwService.updateUserPrivateNtw(req, res, next);
    res.status(201).json(privateNetworks);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for user pvt ntw update
*/
exports.deleteUserPrivateNtw = async (req, res, next) => {
  try {
    const privateNetworks = await privateNtwService.deleteUserPrivateNtw(req, res, next);
    res.status(201).json(privateNetworks);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for get user data
*/
exports.getUserData = async (req, res, next) => {
  try {
    const userData = await userService.getUserData(req, res, next);
    res.status(200).json(userData);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for adding service location for a recycler
*/
exports.addServicableLocation = async (req, res, next) => {
  try {
    const serviceLocations = await serviceLocationService.addServicableLocation(req, res, next);
    res.status(201).json(serviceLocations);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for adding service location for a recycler
*/
exports.getRecyclerServicableLocation = async (req, res, next) => {
  try {
    const serviceLocations = await
    serviceLocationService.getRecyclerServicableLocation(req, res, next);
    res.status(200).json(serviceLocations);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for recycler's serviceable location update
*/
exports.deleteServiceableLocation = async (req, res, next) => {
  try {
    const serviceableLocation = await
    serviceLocationService.deleteServiceableLocation(req, res, next);
    res.status(201).json(serviceableLocation);
  } catch (error) {
    next(error);
  }
};

/*
@desc controller function to save RPs certificate details
*/
exports.saveCertificates = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { certificateDetails } = req.body;
    // this api is called using multi-part form-data model, so certificateDetails field is a stringified array
    const userCertificates = JSON.parse(certificateDetails);

    userCertificates.forEach((certItem, index) => {
      certItem.businessPartnerId = userId;
      if (!certItem.certificateName) {
        certItem.certificateName = certItem.certificateType;
      }
      certItem.certificateFile = req.files[index];
    });
    const savedData = await certificateService.saveUserCertificates(userId, userCertificates);
    res.status(201).json(savedData);
  } catch (error) {
    next(error);
  }
};

/*
@desc controller function to get all user certificates
*/
exports.getAllCertificates = async (req, res, next) => {
  try {
    const response = await certificateService.getAllCertificatesForUser(req.userInfo.userId);
    res.status(200).json(response);
  } catch (error) {
    next(error);
  }
};

/*
@desc controller function to download certificate file from s3
*/
exports.downloadCertificate = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { certId } = req.params;
    const { stream, filename, data } = await certificateService.downloadUserCertificateById(userId, certId);

    res.set('Content-Type', mime.getType(filename));
    res.set('Content-Length', data.ContentLength);
    res.attachment(filename);

    stream.pipe(res);
  } catch (error) {
    next(error);
  }
};

/*
@desc controller function to download certificate file from s3
*/
exports.downloadPrivacyStatement = async (req, res, next) => {
  try {
    const stream = await userService.downloadPrivacyStatement(req, res, next);
    stream.pipe(res);
  } catch (error) {
    next(error);
  }
};

function bufferToStream(buffer) {
  const stream = new Readable();
  stream.push(buffer);
  stream.push(null);

  return stream;
}

/*
@desc controller function to get gp user personal data
*/
exports.getGPPersonalData = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const buffer = await userService.getGPPersonalDetails(userId);
    const wbStream = bufferToStream(buffer);
    const filename = `EverLoop_Personal_Data__${moment().format('DD-MMM-YYYY hh:mm')}.xlsx`;
    res.set('Content-Type', mime.getType(filename));
    res.attachment(filename);
    wbStream.pipe(res);
  } catch (error) {
    next(error);
  }
};

/*
@desc controller function to get rp user personal data
*/
exports.getRPPersonalData = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const buffer = await userService.getRPPersonalDetails(userId);
    const wbStream = bufferToStream(buffer);
    const filename = `EverLoop_Personal_Data__${moment().format('DD-MMM-YYYY hh:mm')}.xlsx`;
    res.set('Content-Type', mime.getType(filename));
    res.attachment(filename);
    wbStream.pipe(res);
  } catch (error) {
    next(error);
  }
};
