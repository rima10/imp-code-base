const xlsx = require('xlsx');

exports.createExcelFromJSON = (data, sheetName) => {
  const wb = xlsx.utils.book_new();
  const ws = xlsx.utils.json_to_sheet(data);
  xlsx.utils.book_append_sheet(wb, ws, sheetName);
  const wbOpts = { bookType: 'xlsx', type: 'buffer' };
  const bufferData = xlsx.write(wb, wbOpts);
  return bufferData;
};
