aws ecr get-login-password --region ap-south-1 | docker login --username AWS --password-stdin 104844411277.dkr.ecr.ap-south-1.amazonaws.com
::cd .\api-gateway\
::docker build . -t api-gateway-qa
::docker tag api-gateway-qa 104844411277.dkr.ecr.ap-south-1.amazonaws.com/reloopecr:api-gateway-qa
::docker push 104844411277.dkr.ecr.ap-south-1.amazonaws.com/reloopecr:api-gateway-qa
cd .\alerts-notification-service\
docker build . -t ans-qa
docker tag ans-qa 104844411277.dkr.ecr.ap-south-1.amazonaws.com/reloopecr:ans-qa
docker push 104844411277.dkr.ecr.ap-south-1.amazonaws.com/reloopecr:ans-qa
cd ..\order-management-service\
docker build . -t oms-qa
docker tag oms-qa 104844411277.dkr.ecr.ap-south-1.amazonaws.com/reloopecr:oms-qa
docker push 104844411277.dkr.ecr.ap-south-1.amazonaws.com/reloopecr:oms-qa
cd ..\account-management-service\
docker build . -t ams-qa
docker tag ams-qa 104844411277.dkr.ecr.ap-south-1.amazonaws.com/reloopecr:ams-qa
docker push 104844411277.dkr.ecr.ap-south-1.amazonaws.com/reloopecr:ams-qa