import React, { useRef, useEffect } from 'react';
import {
    ShellBar,
    Avatar,
    Popover,
    Button,
    Bar,
    NotificationListItem,
    List,
    Label,
    Text,
    FlexBox
} from '@ui5/webcomponents-react';
import { getNotificationInfo, readNotification, logout, getRPPersonalData } from '../../store/action/taskAction';
import { useHistory } from 'react-router-dom';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import logo from '../../../public/favicon.ico';
import { spacing } from '@ui5/webcomponents-react-base';

const Header = ({
    handleSideNavCollapse,
    userName,
    imageSrc,
    notificationList,
    startGetNotificationsInfo,
    startReadNotification,
    isInitialSetupDone,
    startLogout,
    startGetRPPersonalData
}) => {
    const popoverRef = useRef(null);
    const signoutRef = useRef(null);
    const onNotificationsClick = (e) => {
        popoverRef.current.showAt(e.detail.targetRef);
    };
    useEffect(() => {
        startGetNotificationsInfo();
    }, []);
    const history = useHistory();

    const handleLogoClick = () => {
        if (isInitialSetupDone) {
            history.push('/order');
        } else {
            history.push('/initialSetup');
        }
    };
    const onAvatarClick = (e) => {
        signoutRef.current.showAt(e.detail.targetRef);
    };
    const onPopoverClose = () => {
        popoverRef.current.close();
    };
    const onLogout = () => {
        onPopoverClose();
        startLogout();
        history.push('/logout');
    };
    const getNotificationAge = (notificationTime) => {
        const startDate = new Date(notificationTime);
        const endDate = new Date();
        let difference = endDate.getTime() - startDate.getTime();
        const daysDifference = Math.floor(difference / 1000 / 60 / 60 / 24);
        if (daysDifference) return `${daysDifference} Days Ago`;

        const hoursDifference = Math.floor(difference / 1000 / 60 / 60);
        if (hoursDifference) return `${hoursDifference} Hours Ago`;

        const minutesDifference = Math.floor(difference / 1000 / 60);
        if (minutesDifference) return `${minutesDifference} Minutes Ago`;
        else return 'Just Now';
    };

    const onNotificationRead = (event) => {
        const bpNotificationId = event.currentTarget.getAttribute('data-id');
        startReadNotification(bpNotificationId);
    };

    const getNotificationStyle = (isRead) => {
        if (!isRead) return { background: 'aliceblue' };
        else return {};
    };

    const renderAvatar = () => {
        if (imageSrc) {
            return <Avatar size="XS" imageFitType="Contain" image={imageSrc} />;
        } else if (userName) {
            let initial = userName
                .split(' ')
                .slice(0, 2)
                .map((word) => word.charAt(0))
                .join('').substring(0, 2);
            return <Avatar size="XS" initials={initial} />;
        } else {
            return <Avatar icon="employee" size="XS" />;
        }
    };

    return (
        <>
            <ShellBar
                logo={<img alt="EverLoop Logo" src={logo} />}
                primaryTitle="EverLoop by SAP"
                profile={renderAvatar()}
                showNotifications
                notificationsCount={notificationList.length}
                onNotificationsClick={onNotificationsClick}
                onProfileClick={onAvatarClick}
                onLogoClick={handleLogoClick}
                style={{ position: 'fixed', top: '0', zIndex: '100' }}
            >
                <Button slot="startButton" disabled={!isInitialSetupDone} onClick={handleSideNavCollapse} icon="menu" />
            </ShellBar>
            <Popover
                headerText="Notifications"
                footer={
                    <Bar
                        style={{ background: 'var(--sapShellColor)' }}
                        endContent={<Button onClick={onPopoverClose}>Close</Button>}
                    />
                }
                placementType="Bottom"
                horizontalAlign="Center"
                ref={popoverRef}
            >
                <>
                    <List noDataText="No new notifications">
                        {notificationList.map((notification, index) => {
                            const notificationItem = notification.notification;
                            return (
                                <NotificationListItem
                                    key={`notification|${index}`}
                                    style={getNotificationStyle(notification.isRead)}
                                    data-id={notification.bpNotificationId}
                                    footnotes={<Label>{getNotificationAge(notificationItem.createdDate)}</Label>}
                                    titleText={notificationItem.notificationBody}
                                    showClose={!notification.isRead}
                                    onClose={onNotificationRead}
                                >
                                    {notificationItem.notificationText}
                                </NotificationListItem>
                            );
                        })}
                    </List>
                </>
            </Popover>
            <Popover placementType="Bottom" horizontalAlign="Center" ref={signoutRef}>
                <>
                    <FlexBox
                        style={spacing.sapUiSmallMargin}
                        direction="Column"
                        justifyContent="SpaceBetween"
                        alignItems="Start"
                    >
                        <Text>{userName}</Text>
                        <Button
                            disabled
                            style={{ ...spacing.sapUiTinyMargin, fontSize: '0.8rem', border: 'none' }}
                            icon="action-settings"
                            design="Transparent"
                        >
                            Settings
                        </Button>
                        <Button
                            style={{ ...spacing.sapUiTinyMargin, fontSize: '0.8rem', border: 'none' }}
                            icon="visits"
                            design="Transparent"
                            onClick={() => { startGetRPPersonalData(); }}
                        >
                            Export Personal Data
                        </Button>
                        <Button
                            style={{ ...spacing.sapUiTinyMargin, fontSize: '0.8rem', border: 'none' }}
                            icon="log"
                            onClick={onLogout}
                        >
                            Sign Out
                        </Button>
                    </FlexBox>
                </>
            </Popover>
        </>
    );
};

const mapStateToProps = (state) => {
    return {
        notificationList: state.notification
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetNotificationsInfo: async () => dispatch(getNotificationInfo()),
        startReadNotification: async (bpNotificationId) => dispatch(readNotification(bpNotificationId)),
        startLogout: async () => dispatch(logout()),
        startGetRPPersonalData: async () => dispatch(getRPPersonalData())
    };
};

Header.propTypes = {
    handleSideNavCollapse: PropTypes.func,
    userName: PropTypes.string,
    imageSrc: PropTypes.string,
    notificationList: PropTypes.array,
    startGetNotificationsInfo: PropTypes.func,
    startReadNotification: PropTypes.func,
    isInitialSetupDone: PropTypes.bool,
    startLogout: PropTypes.func,
    startGetRPPersonalData: PropTypes.func
};

Header.defaultProps = {
    notificationList: []
};

export default connect(mapStateToProps, mapDispatchToProps)(Header);
