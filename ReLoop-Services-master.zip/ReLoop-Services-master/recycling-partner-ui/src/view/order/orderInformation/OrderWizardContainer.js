import React, { useState, useEffect } from 'react';
import OrderWizard from './OrderWizard';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { useParams } from 'react-router-dom';
import { getConsolidatedOrderItemInfo, getRecycleOrderItemInfo } from '../../../store/action/order';
import { getOrderList, getConsolidatedOrderItemsState, getRecycleOrderItemsState } from '../../../selectors/common';

const OrderWizardContainer = ({
    orderHeaderData,
    consolidatedOrderItems,
    startGetConsolidatedOrderItemInfo,
    startGetRecycleOrderItemInfo,
    recycleOrderData,
    orderList
}) => {
    const [steps, setSteps] = useState({});
    const { orderNumber } = useParams();
    const [quoteStatus, setQuoteStatus] = useState('');

    useEffect(() => {
        if (orderList && orderList.length > 0) {
            // eslint-disable-next-line eqeqeq
            let order = orderList.find((order) => order.order_no == orderNumber);
            let id = order.order_id;
            if (orderHeaderData.processType === 'Recycle') {
                startGetRecycleOrderItemInfo(id);
            } else {
                startGetConsolidatedOrderItemInfo(id);
            }
        }
    }, [orderList]);

    useEffect(() => {
        let status = '';
        if (orderHeaderData.processType === 'Recycle') {
            status = recycleOrderData.quoteStatus;
        } else {
            status = consolidatedOrderItems.quoteStatus;
        }
        setQuoteStatus(status);
    }, [recycleOrderData, consolidatedOrderItems]);

    useEffect(() => {
        const defaultSteps = {
            1: {
                name: 'Order Detail',
                selected: true,
                disabled: false
            },
            2: {
                name: 'Onsite Visit',
                selected: false,
                disabled: parseInt(orderHeaderData.currentSequence, 10) < 4 || quoteStatus !== 'Accepted'
            },
            3: {
                name: 'Asset Verification',
                selected: false,
                disabled: parseInt(orderHeaderData.currentSequence, 10) < 5 || quoteStatus !== 'Accepted'
            },
            4: {
                name: 'Logistics',
                selected: false,
                disabled: parseInt(orderHeaderData.currentSequence, 10) < 6 || quoteStatus !== 'Accepted'
            }
        };
        setSteps(defaultSteps);
    }, [quoteStatus]);

    return <OrderWizard steps={steps} />;
};

const mapStateToProps = (state) => {
    return {
        recycleOrderData: getRecycleOrderItemsState(state),
        consolidatedOrderItems: getConsolidatedOrderItemsState(state),
        orderList: getOrderList(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetConsolidatedOrderItemInfo: (orderId) => dispatch(getConsolidatedOrderItemInfo(orderId)),
        startGetRecycleOrderItemInfo: (orderId) => dispatch(getRecycleOrderItemInfo(orderId))
    };
};

OrderWizardContainer.propTypes = {
    orderHeaderData: PropTypes.object,
    startGetConsolidatedOrderItemInfo: PropTypes.func,
    startGetRecycleOrderItemInfo: PropTypes.func,
    consolidatedOrderItems: PropTypes.object,
    recycleOrderData: PropTypes.object,
    orderList: PropTypes.array
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderWizardContainer);
