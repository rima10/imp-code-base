/* eslint-disable no-use-before-define */
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import {
    Button,
    Toolbar,
    ToolbarSpacer,
    Bar,
    TextArea,
    Label,
    MessageBox
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import { connect } from 'react-redux';
import { useParams, useHistory } from 'react-router-dom';
import LoadingIndicator from '../../common/Loading';
import MessageBar from '../../common/MessageBar';
import AccountTable from '../../common/Table';
import { getOrderHeaderDataState } from '../../../selectors/common';
import {
    getOrderItemsGradeList,
    saveAssetGradeList,
    getOrderQuoteDetails,
    updateOrderQuote,
    submitAssetGrading
} from '../../../store/action/order';
import RecycleAssetGradingComponent from './recycle/AssetGradingComponent';

export const AssetGrading = ({
    startGetOrderItemsGradeList,
    startSaveAssetGradeList,
    startGetOrderQuoteDetails,
    startUpdateAssetGradeComments,
    startSubmitAssetGrading,
    orderList,
    orderHeaderData
}) => {
    const { orderNumber } = useParams();
    const [order, setorder] = useState(null);
    const [assetGradeComments, setAssetGradeComments] = useState('');
    const [assetGradeStepMode, setAssetGradeStepMode] = useState('NA');

    useEffect(() => {
        if (orderList && orderList.length) {
            let order = orderList.find((order) => order.order_no === orderNumber);
            if (order.quoteId && order.quote_status) {
                setorder(order);
                if (order.quote_status === 'Accepted' && order.currentSequence <= 5) {
                    setAssetGradeStepMode(!order.assetGradeSubmitted ? 'edit' : 'view');
                } else if (order.quote_status === 'Accepted' && order.currentSequence > 5) {
                    setAssetGradeStepMode('view');
                }
                startGetOrderItemsGradeList(order.order_id, order.quoteId)
                    .then((response) => {
                        initializeAssetRows(response);
                    });
                const projection = 'assetGradeComments';
                startGetOrderQuoteDetails(order.order_id, order.quoteId, projection)
                    .then((response) => {
                        if (response && response.assetGradeComments) {
                            setAssetGradeComments(response.assetGradeComments);
                        }
                    });
            }
        }
    }, []);

    const onInputChange = (rowIndex, field, value) => {
        const assetGradeListRowsCopy = [...assetGradeListRows];
        assetGradeListRowsCopy[rowIndex][field].value = value;
        setAssetGradeListRows(assetGradeListRowsCopy);
    };

    const columns = [{
        heading: 'Equipment No.',
        key: 'equipmentNumber',
        style: {
            padding: '10px'
        }
    }, {
        heading: 'Asset No.',
        key: 'assetNumber'
    }, {
        heading: 'Grade',
        key: 'grade',
        edit: {
            required: true,
            type: 'select'
        },
        onInputChange: onInputChange,
        options: [{
            value: 'A',
            text: 'A'
        }, {
            value: 'B',
            text: 'B'
        }, {
            value: 'C',
            text: 'C'
        }, {
            value: 'D',
            text: 'D'
        }],
        style: {
            width: '5rem',
            minWidth: '0rem'
        }
    }, {
        heading: 'Data Wipe',
        key: 'dataWipeStatus',
        edit: {
            required: true,
            type: 'select'
        },
        onInputChange: onInputChange,
        options: [{
            value: 'Erased',
            text: 'Erased',
            style: {
                color: 'green'
            }
        }, {
            value: 'In Progress',
            text: 'In Progress',
            style: {
                color: 'orange'
            }
        }, {
            value: 'Not Erased',
            text: 'Not Erased',
            style: {
                color: 'red'
            }
        }],
        style: {
            width: '7rem',
            minWidth: '0rem'
        },
        cellStyle: (columnDef, value) => {
            let optionItem = columnDef.options.find(i => i.value === value);
            return optionItem ? optionItem.style : {};
        }
    }, {
        heading: 'Report Status',
        key: 'reportStatus',
        onInputChange: onInputChange,
        edit: {
            required: true,
            type: 'textarea'
        },
        viewFieldClassNames: 'viewReportStatus',
        style: {
            width: '12rem'
        }
    }, {
        heading: 'Accessories',
        key: 'accessoriesStatus',
        edit: {
            required: true,
            type: 'select'
        },
        onInputChange: onInputChange,
        options: [{
            value: 'Working',
            text: 'Working'
        }, {
            value: 'Not Working',
            text: 'Not Working'
        }, {
            value: 'Not Submitted',
            text: 'Not Submitted'
        }, {
            value: 'NA',
            text: 'NA'
        }],
        style: {
            width: '10rem',
            minWidth: '0rem'
        }
    }, {
        heading: 'List Price',
        key: 'listPrice',
        style: {
            textAlign: 'right',
            width: '6rem',
            minWidth: '0rem'
        }
    }, {
        heading: 'To be Inv.',
        key: 'invoiceAmount',
        edit: {
            required: true,
            type: 'input',
            dataType: 'Number'
        },
        style: {
            textAlign: 'right',
            width: '6rem',
            minWidth: '0rem'
        },
        onInputChange: (rowIndex, field, value) => {
            onInputChange(rowIndex, field, value);
            // calculate total invoice amount
            calculateTotalAmount(assetGradeListRows, 'invoiceAmount');
        }
    }, {
        heading: 'Service Cost',
        key: 'serviceCost',
        edit: {
            required: true,
            type: 'input',
            dataType: 'Number'
        },
        style: {
            textAlign: 'right',
            width: '5rem',
            minWidth: '0rem'
        },
        onInputChange: (rowIndex, field, value) => {
            onInputChange(rowIndex, field, value);
            // calculate service cost amount
            calculateTotalAmount(assetGradeListRows, 'serviceCost');
        }
    }];

    const [totalRow, setTotalRows] = useState({ invoiceAmount: 0, serviceCost: 0 });
    const calculateTotalAmount = (assetGradeListRows, field1, field2) => {
        const totalRowCopy = { ...totalRow };
        totalRowCopy[field1] = 0;
        if (field2) {
            totalRowCopy[field2] = 0;
        }
        assetGradeListRows.forEach((item) => {
            totalRowCopy[field1] += item[field1].value ? Number(item[field1].value) : 0;
            if (field2) {
                totalRowCopy[field2] += item[field2].value ? Number(item[field2].value) : 0;
            }
        });
        if (field1) {
            totalRowCopy[field1] = Math.round(totalRowCopy[field1] * 100) / 100;
        }
        if (field2) {
            totalRowCopy[field2] = Math.round(totalRowCopy[field2] * 100) / 100;
        }
        setTotalRows(totalRowCopy);
    };

    const [assetGradeListRows, setAssetGradeListRows] = useState([]);
    const [isAssetGradeListLoading, setAssetGradeListLoading] = useState(false);
    const initializeAssetRows = (dbAssetRows) => {
        const assetGradeListRowsCopy = [];
        dbAssetRows.forEach((assetItem) => {
            const newAssetRow = {};
            columns.forEach((colItem) => {
                newAssetRow[colItem.key] = {
                    value: assetItem[colItem.key],
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'text',
                    style: colItem.cellStyle ? colItem.cellStyle(colItem, assetItem[colItem.key]) : {}
                };
            });
            newAssetRow.orderItemId = assetItem.orderItemId;
            newAssetRow.orderItemQuoteId = assetItem.orderItemQuoteId;
            assetGradeListRowsCopy.push(newAssetRow);
        });
        setAssetGradeListRows(assetGradeListRowsCopy);

        calculateTotalAmount(assetGradeListRowsCopy, 'serviceCost', 'invoiceAmount');
    };

    const validateAssetGradeList = (assetGradeListRows) => {
        for (let i = 0; i < assetGradeListRows.length; i++) {
            let valid = true;
            let item = assetGradeListRows[i];
            columns.forEach((colItem) => {
                if (colItem.edit) {
                    if (colItem.edit.required &&
                        (item[colItem.key].value === null ||
                            item[colItem.key].value === undefined ||
                            item[colItem.key].value === '')) {
                        valid = false;
                    }
                }
            });
            if (!valid) return false;
        }

        return true;
    };

    const [isToastMessage, setToastMessage] = useState('');
    const showToastMessage = (message, type) => {
        setToastMessage({ message, type });
    };

    const getAssetGradeListUpdatePayload = (assetGradeListRows) => {
        return assetGradeListRows.map((row) => {
            const item = {};
            item.orderItemId = row.orderItemId;
            columns.forEach((colItem) => {
                if (colItem.edit) {
                    item[colItem.key] = row[colItem.key].value;
                }
            });
            return item;
        });
    };
    const getBackTableToViewMode = () => {
        const assetGradeListRowsCopy = [...assetGradeListRows];
        assetGradeListRowsCopy.forEach((row) => {
            columns.forEach((colItem) => {
                row[colItem.key].type = 'text';
                row[colItem.key].style = colItem.cellStyle ? colItem.cellStyle(colItem, row[colItem.key].value) : {};
            });
        });
        setAssetGradeListRows(assetGradeListRowsCopy);
        setTableEditMode(false);
    };
    const saveAssetGradeData = (e) => {
        setAssetGradeListLoading(true);

        const updatePayload = getAssetGradeListUpdatePayload(assetGradeListRows);

        startSaveAssetGradeList(order.order_id, order.quoteId, updatePayload)
            .then((response) => {
                setAssetGradeListLoading(false);
                getBackTableToViewMode();
            })
            .catch((e) => {
                setAssetGradeListLoading(false);
            });
    };
    const enableEditMode = (e) => {
        e.preventDefault();
        setTableEditMode(true);
        const assetGradeListRowsCopy = [...assetGradeListRows];
        assetGradeListRowsCopy.forEach((row) => {
            columns.forEach((colItem) => {
                row[colItem.key] = { ...row[colItem.key], ...colItem.edit };
            });
        });
        setAssetGradeListRows(assetGradeListRowsCopy);
    };
    const [isOpenCancelDialog, setOpenCancelConfirmation] = useState(false);
    const cancelAssetGradeEdit = (promptUser, e) => {
        if (promptUser) {
            return setOpenCancelConfirmation(true);
        }
        if (e.detail.action === 'Yes') {
            startGetOrderItemsGradeList(order.order_id, order.quoteId)
                .then((response) => {
                    initializeAssetRows(response);
                    setTableEditMode(false);
                });
        }

        return setOpenCancelConfirmation(false);
    };
    const [isAssetGradeListEditMode, setTableEditMode] = useState(false);

    var buttons = [];
    if (assetGradeStepMode === 'edit') {
        buttons = [{
            name: 'Edit',
            icon: 'edit',
            hide: isAssetGradeListEditMode,
            onClick: enableEditMode,
            disabled: orderHeaderData.currentSequence !== '5'
        }, {
            name: 'Cancel',
            icon: 'cancel',
            hide: true,
            onClick: (e) => {
                cancelAssetGradeEdit(true);
            }
        }, {
            name: 'Save',
            icon: 'save',
            design: 'Emphasized',
            hide: !isAssetGradeListEditMode,
            onClick: saveAssetGradeData
        }];
    }

    const onCommentsChange = (value) => {
        setAssetGradeComments(value);
    };

    const saveAssetGradeComments = () => {
        startUpdateAssetGradeComments(order.order_id, order.quoteId, { assetGradeComments });
    };

    const submitAssetGrading = async () => {
        try {
            setToastMessage(false);
            if (!validateAssetGradeList(assetGradeListRows)) {
                showToastMessage('Please fill all the columns before submission.', 'Warning');
                return;
            }

            // save edited table entries, if it is in edit mode (unsaved)
            if (isAssetGradeListEditMode) {
                setAssetGradeListLoading(true);
                const updatePayload = getAssetGradeListUpdatePayload(assetGradeListRows);
                await startSaveAssetGradeList(order.order_id, order.quoteId, updatePayload);
                setAssetGradeListLoading(false);
                getBackTableToViewMode();
            }
            await startUpdateAssetGradeComments(order.order_id, order.quoteId, { assetGradeComments });
            await startSubmitAssetGrading(order.order_id, order.quoteId);
            history.push(`/order`);
        } catch (e) {
            setAssetGradeListLoading(false);
        }
    };
    const history = useHistory();
    if (orderHeaderData.processType === 'Recycle') {
        return <RecycleAssetGradingComponent />;
    }
    if (assetGradeStepMode === 'NA') return null;
    return (
        <>
            {isToastMessage &&
                <MessageBar
                    message={isToastMessage.message}
                    type={isToastMessage.type}
                    onClose={() => setToastMessage(false)} />}
            {!order && <LoadingIndicator />}
            {order && (
                <div style={spacing.sapUiMediumMarginTop}>
                    <MessageBox open={isOpenCancelDialog}
                        actions={['Yes', 'No']}
                        onClose={(e) => cancelAssetGradeEdit(false, e)}>
                        Are you sure to cancel the changes ?
                    </MessageBox>
                    <AccountTable
                        text={`List of Verified Assets (${orderHeaderData.itemsCount})`}
                        height="400px"
                        isLoading={isAssetGradeListLoading}
                        columns={columns}
                        columnOrder
                        rows={assetGradeListRows}
                        onInputChange={onInputChange}
                        buttons={buttons}
                    />
                    <Bar
                        startContent={
                            <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                                Total value to be Invoiced (exclude tax)</Label>
                        }
                        endContent={
                            <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                                {totalRow && totalRow.invoiceAmount} INR
                            </Label>
                        }
                        style={{ background: '#f2f2f2' }}
                    />
                    <Bar
                        startContent={
                            <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                                Total service costs (exclude tax) </Label>
                        }
                        endContent={
                            <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                                {totalRow && totalRow.serviceCost} INR
                            </Label>
                        }
                        style={{ background: '#f2f2f2' }}
                    />
                    <div style={{ width: '100%', marginTop: '2rem' }}>
                        <Toolbar>
                            <Label style={{ fontSize: '1rem', fontWeight: 'bold' }}>Additional Comments</Label>
                            {
                                assetGradeStepMode === 'edit' &&
                                <>
                                    <ToolbarSpacer />
                                    <div>
                                        <Button id="SaveCommentsBtn"
                                            icon="save" design="Emphasized" onClick={saveAssetGradeComments}>
                                            Save
                                        </Button>
                                    </div>
                                </>
                            }
                        </Toolbar>
                        <TextArea
                            readonly={assetGradeStepMode !== 'edit'}
                            value={assetGradeComments}
                            onChange={(e) => onCommentsChange(e.target.attributes.value.value)}
                        />
                    </div>
                    {
                        assetGradeStepMode === 'edit' &&
                        <Bar
                            design="FloatingFooter"
                            style={{ marginTop: '30px', width: '100%', boxShadow: 'none' }}
                            endContent={
                                <>
                                    <Button design="None" onClick={() => history.push(`/order`)}>Cancel</Button>
                                    <Button id="SubmitBtn" design="Emphasized" onClick={submitAssetGrading}>
                                        Submit Asset Verification
                                    </Button>
                                </>
                            }
                        />
                    }
                </div>
            )}
        </>
    );
};
AssetGrading.propTypes = {
    startGetOrderItemsGradeList: PropTypes.func,
    startSaveAssetGradeList: PropTypes.func,
    startGetOrderQuoteDetails: PropTypes.func,
    startUpdateAssetGradeComments: PropTypes.func,
    startSubmitAssetGrading: PropTypes.func,
    orderList: PropTypes.array,
    orderHeaderData: PropTypes.object
};
const mapStateToProps = (state) => {
    return {
        orderList: state.order.orderList.data,
        orderHeaderData: getOrderHeaderDataState(state)
    };
};
const mapDispatchToProps = (dispatch) => {
    return {
        startGetOrderItemsGradeList: (orderId, quoteId) => dispatch(getOrderItemsGradeList(orderId, quoteId)),
        startSaveAssetGradeList: (orderId, quoteId, payload) => dispatch(saveAssetGradeList(orderId, quoteId, payload)),
        startGetOrderQuoteDetails: function (orderId, quoteId, projection) {
            return dispatch(getOrderQuoteDetails(orderId, quoteId, projection));
        },
        startUpdateAssetGradeComments: function (orderId, quoteId, payload) {
            return dispatch(updateOrderQuote(orderId, quoteId, payload));
        },
        startSubmitAssetGrading: (orderId, quoteId) => dispatch(submitAssetGrading(orderId, quoteId))
    };
};
export default connect(mapStateToProps, mapDispatchToProps)(AssetGrading);
