import React, { useEffect } from 'react';
import {
    Title,
    TableColumn,
    Label,
    Table,
    TableRow,
    TableCell,
    Text,
    Button,
    Bar
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import { useParams } from 'react-router-dom';
import PropTypes from 'prop-types';
import moment from 'moment';
import { connect } from 'react-redux';
import { getOnsiteVisitDetails, acceptSchedule } from '../../../store/action/order';
import {
    getOrderList, getOnsiteVisitDetailsState,
    getOrderCurrentSequenceState
} from '../../../selectors/common';

const OnSiteVisitStep = ({
    orderList,
    startGetOnsiteVisitDetails,
    onsiteVisitData,
    startAcceptSchedule,
    orderCurrentSequence
}) => {
    const { orderNumber } = useParams();
    useEffect(() => {
        if (orderList && orderList.length > 0) {
            // eslint-disable-next-line eqeqeq
            let order = orderList.find((order) => order.order_no == orderNumber);
            let id = order.order_id;
            startGetOnsiteVisitDetails(id);
        }
    }, []);

    const getTime = (date) => {
        if (date) {
            return moment(date).format('h:mm a');
        }
    };
    const getDate = (date) => {
        if (date) {
            return moment(date).format('MMMM Do YYYY');
        }
    };
    const acceptschedule = () => {
        // eslint-disable-next-line eqeqeq
        let order = orderList.find((order) => order.order_no == orderNumber);
        let id = order.order_id;
        startAcceptSchedule(id);
    };
    return (
        <>
            <Title style={spacing.sapUiTinyMarginTopBottom}>Onsite Visit</Title>
            <div>
                <Table
                    columns={
                        <>
                            <TableColumn style={{ width: '10rem' }}>
                                <Label>Date</Label>
                            </TableColumn>
                            <TableColumn style={{ width: '10rem' }}>
                                <Label>Time</Label>
                            </TableColumn>
                            <TableColumn style={{ width: '10rem' }}>
                                <Label>Estimated Duration</Label>
                            </TableColumn>
                            <TableColumn style={{ width: '10rem' }}>
                                <Label>Comment</Label>
                            </TableColumn>
                        </>
                    }
                >
                    {onsiteVisitData && (
                        <TableRow key={1}>
                            <TableCell>
                                <Text>
                                    {getDate(onsiteVisitData.onsiteScheduledTime) &&
                                        getDate(onsiteVisitData.onsiteScheduledTime)}
                                </Text>
                            </TableCell>
                            <TableCell>
                                <Text>
                                    {getTime(onsiteVisitData.onsiteScheduledTime) &&
                                        getTime(onsiteVisitData.onsiteScheduledTime)}
                                </Text>
                            </TableCell>
                            <TableCell>
                                <Text>{onsiteVisitData.durationTime}</Text>
                            </TableCell>
                            <TableCell>
                                <Text>{onsiteVisitData.comments}</Text>
                            </TableCell>
                        </TableRow>
                    )}
                </Table>
            </div>
            {
                orderCurrentSequence <= 4 &&
                <Bar
                    design="FloatingFooter"
                    style={{ marginTop: '30px', width: '100%', boxShadow: 'none' }}
                    endContent={
                        <>
                            <Button design="Emphasized" onClick={acceptschedule}>
                                Accept Schedule
                            </Button>
                            <Button design="None">Cancel</Button>
                        </>
                    }
                />
            }
        </>
    );
};

OnSiteVisitStep.propTypes = {
    orderList: PropTypes.array,
    startGetOnsiteVisitDetails: PropTypes.func,
    onsiteVisitData: PropTypes.object,
    startAcceptSchedule: PropTypes.func,
    orderCurrentSequence: PropTypes.string
};

const mapStateToProps = (state) => {
    return {
        orderList: getOrderList(state),
        onsiteVisitData: getOnsiteVisitDetailsState(state),
        orderCurrentSequence: getOrderCurrentSequenceState(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetOnsiteVisitDetails: (orderId) => dispatch(getOnsiteVisitDetails(orderId)),
        startAcceptSchedule: (orderId) => dispatch(acceptSchedule(orderId))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(OnSiteVisitStep);
