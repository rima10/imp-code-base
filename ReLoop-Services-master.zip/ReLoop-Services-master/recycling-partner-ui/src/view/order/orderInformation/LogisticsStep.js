import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Grid, Label, Input, Text, Panel, Toolbar, Bar, Button } from '@ui5/webcomponents-react';
import moment from 'moment';
import AccountTable from '../../common/Table';
import { spacing } from '@ui5/webcomponents-react-base';
import { useHistory } from 'react-router-dom';
import { camelCaseToSentence } from '../../../utils/formatter';
import { acceptLogisticSchedule, getLogisticsData } from '../../../store/action/order';
import OrderHeader from './OrderHeader';
import LoadingIndicator from '../../common/Loading';
import {
    getOrderHeaderDataState,
    isAcceptLogisticsScheduleLoading,
    getLogisticsDataState,
    isLogisticsDataLoading
} from '../../../selectors/common';
import validateInput from '../../../validation/LogisticsData';
import AssetGradingComponent from './AssetGradingComponent';

const Logistics = ({
    isLoading,
    orderHeaderData,
    startAcceptLogisticSchedule,
    startGetLogisticsData,
    isLogisticsDataLoading,
    logisticsData
}) => {
    const history = useHistory();
    const columns = ['Suggested Date', 'Time', 'Customer Contact', 'Phone Number'];
    const [inputBox, setInputBox] = useState({
        vehicleType: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        vehicleNumber: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        driverName: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        logisticProvider: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: false
        },
        recyclerContactName: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: false
        },
        recyclerContactNumber: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: false
        }
    });

    useEffect(() => {
        if (orderHeaderData?.orderId) {
            startGetLogisticsData(orderHeaderData.orderId);
        }
    }, []);

    const getTime = (date) => {
        if (date) {
            return moment(date).format('h:mm a');
        }
    };

    const getDate = (date) => {
        if (date) {
            return moment(date).format('MMMM Do YYYY');
        }
    };

    let tempRows = [];
    tempRows.push({
        suggestedDate: {
            value: getDate(orderHeaderData.logisticsScheduledTime),
            type: 'text'
        },
        time: {
            value: getTime(orderHeaderData.logisticsScheduledTime),
            type: 'text'
        },
        customerContact: {
            value: orderHeaderData.logisticSpocName,
            type: 'text'
        },
        phoneNumber: {
            value: orderHeaderData.logisticSpocContactNumber,
            type: 'text'
        }
    });

    const onInputChange = (event) => {
        let tempInputBox = { ...inputBox };
        let field = event.target.name;
        let { isValid, errorMessage } = validateInput(event.target.value, field, tempInputBox[field]);
        tempInputBox[field]['value'] = event.target.value;
        tempInputBox[field]['valueStateMessage'] = <span>{errorMessage}</span>;
        if (isValid) {
            tempInputBox[field]['valueState'] = 'None';
        } else {
            tempInputBox[field]['valueState'] = 'Error';
        }
        setInputBox(tempInputBox);
    };

    const onAcceptScheduleClick = () => {
        let isValid = true;
        let tempInputBox = { ...inputBox };
        Object.keys(tempInputBox).map((field) => {
            // check to find whether value is empty for required fields
            if (tempInputBox[field]['required'] && tempInputBox[field]['value'] === '') {
                let fieldName = '';
                fieldName = camelCaseToSentence(field);
                tempInputBox[field]['valueState'] = 'Error';
                tempInputBox[field]['valueStateMessage'] = <span>{fieldName} is required</span>;
                isValid = false;
            }
            // check to find whether any field has error state
            if (tempInputBox[field]['valueState'] === 'Error') {
                isValid = false;
            }
        });
        if (isValid) {
            const payload = {
                vehicleType: inputBox.vehicleType.value,
                vehicleNumber: inputBox.vehicleNumber.value,
                driverName: inputBox.driverName.value,
                logisticProvider: inputBox.logisticProvider.value,
                recyclerContactName: inputBox.recyclerContactName.value,
                recyclerContactNumber: inputBox.recyclerContactNumber.value
            };
            startAcceptLogisticSchedule(orderHeaderData.orderId, payload)
                .then(() => history.push('/order'))
                .catch(() => console.log('Something went wrong!'));
        } else {
            setInputBox(tempInputBox);
        }
    };

    if (isLoading || isLogisticsDataLoading) {
        return <LoadingIndicator />;
    }
    return (
        <>
            <Panel headerText="Order Details" collapsed>
                <OrderHeader />
            </Panel>
            <Panel headerText="List of Verified Assets" collapsed>
                <AssetGradingComponent />
            </Panel>
            <Panel headerText="Logistic Details">
                <AccountTable columns={columns} rows={tempRows} />
                <Toolbar style={{ ...spacing.sapUiSmallMarginTop }}>
                    <Text>Additional Logistics Information</Text>
                </Toolbar>
                <Text style={{ ...spacing.sapUiTinyMarginTop }}>
                    In order to create additional documents (i.e. e-way bill etc.) please provide the mandatory
                    information below.
                </Text>
                <Grid style={spacing.sapUiLargeMarginTop}>
                    <div data-layout-span="XL4 L4 M4 S4">
                        <Label required style={{ display: 'block', marginTop: '1rem' }}>
                            Vehicle Type
                        </Label>
                        <Input
                            id="vehicleType"
                            name="vehicleType"
                            value={logisticsData?.vehicleType ?? inputBox.vehicleType.value}
                            valueState={inputBox.vehicleType.valueState}
                            valueStateMessage={inputBox.vehicleType.valueStateMessage}
                            onInput={(e) => onInputChange(e)}
                            style={{ width: '80%' }}
                            disabled={logisticsData.isLogisticDataSubmitted}
                        />
                        <Label required style={{ display: 'block', marginTop: '1rem' }}>
                            Vehicle Number
                        </Label>
                        <Input
                            id="vehicleNumber"
                            name="vehicleNumber"
                            value={logisticsData?.vehicleLicenceNumber ?? inputBox.vehicleNumber.value}
                            valueState={inputBox.vehicleNumber.valueState}
                            valueStateMessage={inputBox.vehicleNumber.valueStateMessage}
                            onInput={(e) => onInputChange(e)}
                            style={{ width: '80%' }}
                            disabled={logisticsData.isLogisticDataSubmitted}
                        />
                    </div>
                    <div data-layout-span="XL4 L4 M4 S4">
                        <Label required style={{ display: 'block', marginTop: '1rem' }}>
                            Driver Name
                        </Label>
                        <Input
                            id="driverName"
                            name="driverName"
                            value={logisticsData?.driverName ?? inputBox.driverName.value}
                            valueState={inputBox.driverName.valueState}
                            valueStateMessage={inputBox.driverName.valueStateMessage}
                            onInput={(e) => onInputChange(e)}
                            style={{ width: '80%' }}
                            disabled={logisticsData.isLogisticDataSubmitted}
                        />
                        <Label style={{ display: 'block', marginTop: '1rem' }}>Logistic Provider</Label>
                        <Input
                            id="logisticProvider"
                            name="logisticProvider"
                            value={logisticsData?.logisticProvider ?? inputBox.logisticProvider.value}
                            valueState={inputBox.logisticProvider.valueState}
                            valueStateMessage={inputBox.logisticProvider.valueStateMessage}
                            onInput={(e) => onInputChange(e)}
                            style={{ width: '80%' }}
                            disabled={logisticsData.isLogisticDataSubmitted}
                        />
                    </div>
                    <div data-layout-span="XL4 L4 M4 S4">
                        <Label style={{ display: 'block', marginTop: '1rem' }}>Recycler Contact Name</Label>
                        <Input
                            id="recyclerContactName"
                            name="recyclerContactName"
                            value={logisticsData?.recyclerContactName ?? inputBox.recyclerContactName.value}
                            valueState={inputBox.recyclerContactName.valueState}
                            valueStateMessage={inputBox.recyclerContactName.valueStateMessage}
                            onInput={(e) => onInputChange(e)}
                            style={{ width: '80%' }}
                            disabled={logisticsData.isLogisticDataSubmitted}
                        />
                        <Label style={{ display: 'block', marginTop: '1rem' }}>Recycler Contact Number</Label>
                        <Input
                            id="recyclerContactNumber"
                            name="recyclerContactNumber"
                            value={logisticsData?.recyclerContactNumber ?? inputBox.recyclerContactNumber.value}
                            valueState={inputBox.recyclerContactNumber.valueState}
                            valueStateMessage={inputBox.recyclerContactNumber.valueStateMessage}
                            onInput={(e) => onInputChange(e)}
                            style={{ width: '80%' }}
                            disabled={logisticsData.isLogisticDataSubmitted}
                        />
                    </div>
                </Grid>
                <Bar
                    style={{ ...spacing.sapUiLargeMarginTop }}
                    design="FloatingFooter"
                    endContent={
                        <Button
                            disabled={logisticsData.isLogisticDataSubmitted}
                            design="Emphasized"
                            onClick={onAcceptScheduleClick}
                        >
                            Accept Schedule
                        </Button>
                    }
                />
            </Panel>
        </>
    );
};

const mapStateToProps = (state) => {
    return {
        isLoading: isAcceptLogisticsScheduleLoading(state),
        orderHeaderData: getOrderHeaderDataState(state),
        logisticsData: getLogisticsDataState(state),
        isLogisticsDataLoading: isLogisticsDataLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startAcceptLogisticSchedule: async (orderId, payload) => dispatch(acceptLogisticSchedule(orderId, payload)),
        startGetLogisticsData: (orderId) => dispatch(getLogisticsData(orderId))
    };
};

Logistics.propTypes = {
    startAcceptLogisticSchedule: PropTypes.func,
    isLoading: PropTypes.bool,
    isLogisticsDataLoading: PropTypes.bool,
    logisticsData: PropTypes.object,
    orderHeaderData: PropTypes.object,
    startGetLogisticsData: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(Logistics);
