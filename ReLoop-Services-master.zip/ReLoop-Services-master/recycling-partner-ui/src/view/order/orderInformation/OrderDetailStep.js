import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import {
    Button,
    FlexBox,
    Text,
    Input,
    Bar,
    Title,
    TextArea,
    Table,
    TableColumn,
    TableCell,
    TableRow,
    Label,
    Select,
    Option
} from '@ui5/webcomponents-react';
import { useParams, useHistory } from 'react-router-dom';
import { spacing } from '@ui5/webcomponents-react-base';
import OrderHeader from './OrderHeader';
import {
    getConsolidatedOrderItemInfo,
    submitFirstLevelQuote,
    getRecycleOrderItemInfo,
    submitRecycleInitialQuote
} from '../../../store/action/order';
import {
    getOrderList,
    getOrderHeaderDataState,
    getConsolidatedOrderItemsState,
    isSubmitFirstLevelQuoteLoading,
    getRecycleOrderItemsState,
    isRecycleOrderItemsLoading
} from '../../../selectors/common';
import LoadingIndicator from '../../common/Loading';
import MessageBar from '../../common/MessageBar';

const OrderDetailStep = ({
    orderList,
    orderHeaderData,
    consolidatedOrderItems,
    startGetConsolidatedOrderItemInfo,
    startSubmitFirstLevelQuote,
    isLoading,
    startGetRecycleOrderItemInfo,
    recycleOrderData,
    isRecycleOrderItemsLoading,
    startSubmitRecycleInitialQuote
}) => {
    const history = useHistory();
    const { orderNumber } = useParams();
    const [isEditMode, setEditMode] = useState(0);
    const [order, setOrder] = useState([]);
    const [orderItems, setOrderItems] = useState([]);
    const [pricePerKg, setPricePerKg] = useState('');
    const [isToastMessage, setToastMessage] = useState('');
    const showToastMessage = (message, type) => {
        setToastMessage({ message, type });
    };

    const [isEditQuoteAllowed, setEditQuoteAllowed] = useState(false);
    useEffect(() => {
        if (orderList && orderList.length > 0) {
            // eslint-disable-next-line eqeqeq
            let order = orderList.find((order) => order.order_no == orderNumber);
            let id = order.order_id;
            if (orderHeaderData.processType === 'Recycle') {
                startGetRecycleOrderItemInfo(id);
            } else {
                startGetConsolidatedOrderItemInfo(id);
            }
        }
    }, [orderList]);

    useEffect(() => {
        if (orderHeaderData && orderHeaderData.currentSequence <= 3) {
            setEditQuoteAllowed(true);
        }
    }, [orderHeaderData]);

    const [totalPrice, setTotalPrice] = useState(0);
    useEffect(() => {
        setEditQuoteAllowed(true);
        setOrder(consolidatedOrderItems);
        let totalPriceNew = 0;
        if (consolidatedOrderItems.orderItems) {
            consolidatedOrderItems.orderItems.forEach((item) => {
                if (item.price !== undefined && item.price !== null && item.price !== '') {
                    setEditQuoteAllowed(false);
                    totalPriceNew += (item.price) ? (item.price * item.count) : 0;
                }
            });
            totalPriceNew = Math.round(totalPriceNew * 100) / 100;
            setTotalPrice(totalPriceNew);
        }
    }, [consolidatedOrderItems]);

    useEffect(() => {
        setEditQuoteAllowed(false);
        setOrderItems(recycleOrderData.orderItems);
        if (recycleOrderData?.pricePerKg) {
            setPricePerKg(recycleOrderData.pricePerKg);
        } else {
            setPricePerKg('');
        }

        if (!recycleOrderData.isInitialQuoteSubmitted) {
            setEditQuoteAllowed(true);
        }
    }, [recycleOrderData]);

    const isValidRefurbishQuote = (order) => {
        for (let i = 0; i < order.orderItems.length; i++) {
            let valid = true;
            let item = order.orderItems[i];
            if (item.price === null ||
                item.price === undefined ||
                item.price === '') {
                valid = false;
            }
            if (!valid) return false;
        }

        return true;
    };

    const isValidRecycleQuote = (orderItems) => {
        let isValid = true;
        if (!pricePerKg) {
            isValid = false;
        }
        orderItems.forEach((item) => {
            if (!isValid) return;
            if (!item.itemUnit) {
                isValid = false;
            }
        });

        return isValid;
    };

    const submitQuote = () => {
        if (orderHeaderData.processType === 'Refurbish') {
            setToastMessage(false);
            if (!isValidRefurbishQuote(order)) {
                showToastMessage('Please fill all Asset List pricing before submission.', 'Warning');
                return;
            }
            let payload = {
                orderId: order.orderId,
                orderItems: order.orderItems,
                quoteComments: order.comment
            };
            startSubmitFirstLevelQuote(payload)
                .then((response) => {
                    setEditQuoteAllowed(false);
                });
        } else {
            if (!isValidRecycleQuote(orderItems)) {
                showToastMessage('Please fill all Asset List pricing before submission.', 'Warning');
                return;
            }
            let payload = {
                orderId: orderHeaderData.orderId,
                pricePerKg: parseInt(pricePerKg, 10),
                quoteComments: order.comment,
                orderItems: []
            };
            orderItems?.map((item) => {
                payload.orderItems.push({
                    orderItemId: item.orderItemId,
                    itemUnit: item.itemUnit
                });
            });
            startSubmitRecycleInitialQuote(orderHeaderData.orderId, payload).then(() => history.push('/order'));
        }
    };

    const onPriceChange = (event, index) => {
        let newOrder = { ...order };
        newOrder.orderItems[index].price = Number(event.target.value);
        let totalPriceNew = 0;
        newOrder.orderItems.forEach((item) => {
            totalPriceNew += item.price ? item.price * item.count : 0;
        });
        totalPriceNew = Math.round(totalPriceNew * 100) / 100;
        setTotalPrice(totalPriceNew);
        setOrder(newOrder);
    };

    const onItemUnitChange = (event, rowNumber) => {
        let tempOrderItems = [...orderItems];
        tempOrderItems[rowNumber]['itemUnit'] = event.detail.selectedOption.attributes.value.value;
        setOrderItems(tempOrderItems);
    };

    const onSubmitComment = (event) => {
        let newOrder = { ...order };
        newOrder.comment = event.target.value;
        setOrder(newOrder);
    };

    const units = ['pc', 'kg'];

    const renderUnit = (index) => {
        if (orderItems && orderItems.length) {
            if (orderItems[index].itemUnit === '-1') {
                return '';
            } else {
                return orderItems[index].itemUnit;
            }
        }
    };

    const renderAssetListForRecycleOrder = () => {
        return (
            <>
                <Label
                    style={{
                        ...spacing.sapUiMediumMarginTopBottom,
                        ...spacing.sapUiMediumMarginEnd
                    }}
                    required
                    showColon
                >
                    Price / kg (INR)
                </Label>
                <Input
                    value={pricePerKg}
                    type="Number"
                    disabled={recycleOrderData.isInitialQuoteSubmitted}
                    onInput={(e) => setPricePerKg(e.target.value)}
                />
                <Table
                    columns={
                        <>
                            <TableColumn>
                                <Label>Order Item</Label>
                            </TableColumn>
                            <TableColumn popinText="Item Unit">
                                <Label>Item Unit</Label>
                            </TableColumn>
                        </>
                    }
                >
                    {recycleOrderData?.orderItems?.map((item, index) => (
                        <TableRow key={index}>
                            <TableCell>
                                <Text>{item.orderItem}</Text>
                            </TableCell>
                            <TableCell>
                                {isEditMode && isEditQuoteAllowed ? (
                                    <Select
                                        style={{ height: '20%' }}
                                        id={'itemUnit-' + index}
                                        value={orderItems[index].itemUnit}
                                        onChange={(e) => onItemUnitChange(e, index)}
                                    >
                                        <Option id="-1" value="-1">
                                            Select a Unit
                                        </Option>
                                        {units?.map((unit, idx) => (
                                            <Option
                                                key={idx}
                                                id={idx}
                                                value={unit}
                                                selected={unit === orderItems[index].itemUnit}
                                            >
                                                {unit}
                                            </Option>
                                        ))}
                                    </Select>
                                ) : (
                                    <Text id={'itemUnit-' + index}> {renderUnit(index)}</Text>
                                )}
                            </TableCell>
                        </TableRow>
                    ))}
                </Table>
            </>
        );
    };

    if (isLoading || isRecycleOrderItemsLoading) {
        return <LoadingIndicator />;
    }
    return (
        <>
            <OrderHeader />
            {isToastMessage &&
                <MessageBar
                    message={isToastMessage.message}
                    type={isToastMessage.type}
                    onClose={() => setToastMessage(false)} />
            }
            <FlexBox direction="Row" alignItems="Center" style={{
                ...spacing.sapUiTinyMarginTopBottom
            }}>
                <Title>{'Asset List (' + orderHeaderData.itemsCount + ')'}</Title>
                {
                    isEditQuoteAllowed &&
                    <Button
                        style={{ position: 'absolute', right: '0' }}
                        design="Transparent"
                        onClick={() => {
                            if (isEditMode === 0) {
                                setEditMode(1);
                            } else {
                                setEditMode(0);
                            }
                        }}
                    >
                        {isEditMode ? 'Save' : 'Edit'}
                    </Button>
                }

            </FlexBox>
            {orderHeaderData.processType === 'Refurbish' ? (
                <>
                    <Table
                        columns={
                            <>
                                <TableColumn style={{ width: '12rem' }}>
                                    <Label>Category</Label>
                                </TableColumn>
                                <TableColumn minWidth={800} popinText="Make">
                                    <Label>Make</Label>
                                </TableColumn>
                                <TableColumn demandPopin minWidth={600} popinText="Model">
                                    <Label>Model</Label>
                                </TableColumn>
                                <TableColumn demandPopin minWidth={600} popinText="Quantity">
                                    <Label>Quantity</Label>
                                </TableColumn>
                                <TableColumn>
                                    <Label>Initial Price per Item (INR)</Label>
                                </TableColumn>
                                <TableColumn>
                                    <Label>Total Price (INR)</Label>
                                </TableColumn>
                            </>
                        }
                    >
                        {order.orderItems &&
                            order.orderItems.map((order, index) => (
                                <TableRow key={index}>
                                    <TableCell>
                                        <Text>{order.itemType}</Text>
                                    </TableCell>
                                    <TableCell>
                                        <Text>{order.make}</Text>
                                    </TableCell>
                                    <TableCell>
                                        <Text>{order.model}</Text>
                                    </TableCell>
                                    <TableCell>
                                        <Text id={'countLabel' + index}>{order.count}</Text>
                                    </TableCell>
                                    <TableCell>
                                        {isEditMode && isEditQuoteAllowed ? (
                                            <Input
                                                type="Number"
                                                id={'initialPrice' + index}
                                                value={order.price}
                                                onInput={(e) => onPriceChange(e, index)}
                                            />
                                        ) : (
                                            <Text id={'initialPriceLabel' + index}>{order.price}</Text>
                                        )}
                                    </TableCell>
                                    <TableCell>
                                        <Text id={'totalAmountLabel' + index}>
                                            {order && order.price ? order.price * order.count : ' '}
                                        </Text>
                                    </TableCell>
                                </TableRow>
                            ))}
                    </Table>
                    <Bar
                        endContent={<Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>{totalPrice}</Label>}
                        startContent={<Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>Total Price </Label>}
                        style={{ background: '#f2f2f2' }}
                    />
                </>
            ) : (
                renderAssetListForRecycleOrder()
            )}
            <div style={{
                ...spacing.sapUiMediumMarginTop
            }}>
                <FlexBox direction="Row" alignItems="Center" style={{
                    ...spacing.sapUiTinyMarginTopBottom
                }}>
                    <Title>Additional Comment</Title>
                </FlexBox>
                <TextArea
                    readonly={!isEditQuoteAllowed}
                    value={recycleOrderData?.quoteComments || order.comment}
                    onInput={(e) => onSubmitComment(e)}
                    disabled={false} />
            </div>
            {
                isEditQuoteAllowed &&
                <Bar
                    design="FloatingFooter"
                    style={{ marginTop: '30px', width: '100%', boxShadow: 'none' }}
                    endContent={

                        <>
                            <Button design="Emphasized" onClick={submitQuote}>
                                Submit Quote
                            </Button>
                            <Button design="None">Cancel</Button>
                        </>
                    }
                />
            }
        </>
    );
};

const mapStateToProps = (state) => {
    return {
        orderList: getOrderList(state),
        orderHeaderData: getOrderHeaderDataState(state),
        consolidatedOrderItems: getConsolidatedOrderItemsState(state),
        isLoading: isSubmitFirstLevelQuoteLoading(state),
        recycleOrderData: getRecycleOrderItemsState(state),
        isRecycleOrderItemsLoading: isRecycleOrderItemsLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetConsolidatedOrderItemInfo: (orderId) => dispatch(getConsolidatedOrderItemInfo(orderId)),
        startSubmitFirstLevelQuote: (payload) => dispatch(submitFirstLevelQuote(payload)),
        startGetRecycleOrderItemInfo: (orderId) => dispatch(getRecycleOrderItemInfo(orderId)),
        startSubmitRecycleInitialQuote: (orderId, payload) => dispatch(submitRecycleInitialQuote(orderId, payload))
    };
};

OrderDetailStep.propTypes = {
    startGetConsolidatedOrderItemInfo: PropTypes.func,
    startSubmitFirstLevelQuote: PropTypes.func,
    orderList: PropTypes.array,
    orderHeaderData: PropTypes.object,
    consolidatedOrderItems: PropTypes.object,
    isLoading: PropTypes.bool,
    startGetRecycleOrderItemInfo: PropTypes.func,
    recycleOrderData: PropTypes.object,
    isRecycleOrderItemsLoading: PropTypes.bool,
    startSubmitRecycleInitialQuote: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderDetailStep);
