import React from 'react';
import PropTypes from 'prop-types';
import { Panel, Label, List, CustomListItem, FlexBox, Bar, Text, Icon } from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { getOrderList } from '../../selectors/common';
import { isOrderListLoading } from '../../selectors/common';
import LoadingIndicator from '../common/Loading';
import { spacing } from '@ui5/webcomponents-react-base';

const OrderList = ({ orderList, isLoading }) => {
    const history = useHistory();
    const onSelectionChange = (orderNumber) => {
        history.push(`/order/${orderNumber}`);
    };
    const uniqueStatus = [
        {
            status: ['New']
        },
        {
            status: ['In Progress', 'Accepted', 'Waiting', 'In Review', 'Temporarily Accepted']
        },
        {
            status: ['Completed', 'Rejected']
        }
    ];
    const getDataWithSpecificStatus = (status) => {
        let list = orderList.filter((order) => status.includes(order.quote_status));
        return list.sort((a, b) => b.order_no.localeCompare(a.order_no));
    };

    const getOrderTypeName = (orderType) => {
        if (orderType === '1') {
            return 'Refurbish';
        } else {
            return 'Recycle';
        }
    };

    const orderTypeFontColor = {
        1: '#0065c5',
        2: '#107e3e'
    };

    if (isLoading) {
        return <LoadingIndicator />;
    }
    return (
        <>
            <Label style={{ fontSize: '1.3rem', fontWeight: 'Bold', marginTop: '15px', marginBottom: '20px' }}>
                Order List
            </Label>
            {uniqueStatus.map((item, index) => {
                let data = getDataWithSpecificStatus(item.status);
                return (
                    <Panel
                        headerText={`${item.status[0]} Orders (${data.length})`}
                        key={index}
                        style={{ overflow: 'hidden' }}
                    >
                        <List
                            noDataText="No New Orders"
                            mode="SingleSelect"
                            separators="None"
                            growing="Scroll"
                            onSelectionChange={(e) => onSelectionChange(e.detail.selectedItems[0].dataset.id)}
                        >
                            {data.map((order, idx) => (
                                <CustomListItem
                                    data-id={order.order_no}
                                    key={'List' + idx}
                                    style={{
                                        height: '5rem'
                                    }}
                                >
                                    <Bar
                                        className="active-hover"
                                        style={{
                                            height: '5rem'
                                        }}
                                        endContent={
                                            <div>
                                                <br />
                                                <Icon name="slim-arrow-right" />
                                            </div>
                                        }
                                        startContent={
                                            <FlexBox>
                                                <Icon name="order-status" tooltip="Order" />
                                                <div style={spacing.sapUiTinyMarginBeginEnd}>
                                                    <div>
                                                        <Text>{order.order_no}</Text>
                                                        <div style={spacing.sapUiTinyMarginTop}>
                                                            <span>
                                                                <strong
                                                                    style={{
                                                                        color: orderTypeFontColor[order?.orderType]
                                                                    }}
                                                                >
                                                                    {getOrderTypeName(order?.orderType)}
                                                                </strong>
                                                                &nbsp;|&nbsp;
                                                                <strong>{order.created_by}</strong>
                                                                &nbsp;|&nbsp;Received Date:{' '}
                                                                {order.created_date.substring(0, 10)}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </FlexBox>
                                        }
                                    />
                                </CustomListItem>
                            ))}
                        </List>
                    </Panel>
                );
            })}
        </>
    );
};
OrderList.propTypes = {
    orderList: PropTypes.array,
    isLoading: PropTypes.bool
};
OrderList.defaultProps = {
    orderList: []
};
const mapStateToProps = (state) => {
    return {
        orderList: getOrderList(state),
        isLoading: isOrderListLoading(state)
    };
};
export default connect(mapStateToProps)(OrderList);
