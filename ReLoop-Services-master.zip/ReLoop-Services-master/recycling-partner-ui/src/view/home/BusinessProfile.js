import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport.js';
import { Select, Option, Grid, Button, Input, Title, FlexBox, Label, TextArea, Loader } from '@ui5/webcomponents-react';
import validateInput from '../../validation/BusinessProfile';
import { updateBusinessInfo } from '../../store/action/account';
import { getStates, getCities } from '../../store/action/location';
import { getStatesInfo, getCitiesInfo } from '../../selectors/common';
import { isBusinessInfoLoading } from '../../selectors/common';
import { camelCaseToSentence } from '../../utils/formatter';

const BusinessProfile = ({
    onNextClick,
    startUpdateBusinessInfo,
    startGetStates,
    startGetCities,
    states,
    cities,
    isLoading
}) => {
    // Selected State from the dropdown
    const [selectedState, setSelectedState] = useState('');
    const [inputBox, setInputBox] = useState({
        gstin: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        cin: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        pan: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        pincode: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        phoneNumber: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        address: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        state: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        city: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        }
    });

    useEffect(() => {
        startGetStates();
    }, []);

    const onSelectionChange = (event) => {
        let tempInputBox = { ...inputBox };
        let field = event.target.name;
        let value = event.target.selectedOption.value;
        tempInputBox[field]['value'] = value;
        tempInputBox[field]['valueState'] = 'None';
        tempInputBox[field]['valueStateMessage'] = '';
        setInputBox(tempInputBox);
        // Call getCities and setState when input field is State
        if (field === 'state') {
            startGetCities(value);
            setSelectedState(value);
        }
    };

    const onInputChange = (event) => {
        let tempInputBox = { ...inputBox };
        let field = event.target.name;
        let { isValid, errorMessage } = validateInput(event.target.value, field, tempInputBox[field]);
        tempInputBox[field]['value'] = event.target.value;
        tempInputBox[field]['valueStateMessage'] = <span>{errorMessage}</span>;
        if (isValid) {
            tempInputBox[field]['valueState'] = 'None';
        } else {
            tempInputBox[field]['valueState'] = 'Error';
        }
        setInputBox(tempInputBox);
    };

    const submitBusinessInfoForm = async (event) => {
        event.preventDefault();
        let isValid = true;
        let tempInputBox = { ...inputBox };
        Object.keys(tempInputBox).map((field) => {
            // check to find whether value is empty for required fields
            if (tempInputBox[field]['required'] && tempInputBox[field]['value'] === '') {
                let fieldName = '';
                if (field === 'cin' || field === 'pan' || field === 'gstin') {
                    fieldName = field.toUpperCase();
                } else {
                    fieldName = camelCaseToSentence(field);
                }
                tempInputBox[field]['valueState'] = 'Error';
                tempInputBox[field]['valueStateMessage'] = <span>{fieldName} is required</span>;
                isValid = false;
            }
            // check to find whether any field has error state
            if (tempInputBox[field]['valueState'] === 'Error') {
                isValid = false;
            }
        });
        if (isValid) {
            const payload = {
                bpPhoneNumber: inputBox.phoneNumber.value,
                cin: inputBox.cin.value,
                gstNumber: inputBox.gstin.value,
                pan: inputBox.pan.value,
                location: {
                    country: '1',
                    stateId: inputBox.state.value,
                    cityId: inputBox.city.value,
                    pincode: inputBox.pincode.value,
                    locDetails: inputBox.address.value
                }
            };
            startUpdateBusinessInfo(payload)
                .then(() => onNextClick('2'))
                .catch(() => console.log('Something went wrong!'));
        } else {
            setInputBox(tempInputBox);
        }
    };

    return (
        <>
            <FlexBox alignItems="Center" direction="Column">
                {isLoading && <Loader />}
                <Title style={{ fontSize: 'larger', marginTop: '2rem' }}>
                    Please add all the business data needed to complete your <b>Business Profile</b>
                </Title>
            </FlexBox>
            <Grid style={{ margin: '20px' }}>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label required showColon style={{ display: 'block', marginTop: '2rem' }}>
                        GSTIN
                    </Label>
                    <Input
                        id="gstin"
                        value={inputBox.gstin.value}
                        valueState={inputBox.gstin.valueState}
                        valueStateMessage={inputBox.gstin.valueStateMessage}
                        name="gstin"
                        onInput={(e) => onInputChange(e)}
                        style={{ width: '80%' }}
                    />
                </div>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label required showColon style={{ display: 'block', marginTop: '2rem' }}>
                        CIN
                    </Label>
                    <Input
                        id="cin"
                        name="cin"
                        value={inputBox.cin.value}
                        valueState={inputBox.cin.valueState}
                        valueStateMessage={inputBox.cin.valueStateMessage}
                        onInput={(e) => onInputChange(e)}
                        style={{ width: '80%' }}
                    />
                </div>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label required showColon style={{ display: 'block', marginTop: '2rem' }}>
                        PAN
                    </Label>
                    <Input
                        id="pan"
                        name="pan"
                        value={inputBox.pan.value}
                        valueState={inputBox.pan.valueState}
                        valueStateMessage={inputBox.pan.valueStateMessage}
                        onInput={(e) => onInputChange(e)}
                        style={{ width: '80%' }}
                    />
                </div>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label required showColon style={{ display: 'block', marginTop: '2rem' }}>
                        State
                    </Label>
                    <Select
                        id="state"
                        style={{ width: '80%' }}
                        name="state"
                        valueState={inputBox.state.valueState}
                        valueStateMessage={inputBox.state.valueStateMessage}
                        onChange={(e) => onSelectionChange(e)}
                    >
                        <Option value={''}>Select State</Option>
                        {states?.map((stateVal) => (
                            <Option key={stateVal.state_id} value={stateVal.state_id}>
                                {stateVal.state_name}
                            </Option>
                        ))}
                    </Select>
                </div>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label required showColon style={{ display: 'block', marginTop: '2rem' }}>
                        City
                    </Label>
                    <Select
                        name="city"
                        id="city"
                        style={{ width: '80%' }}
                        valueState={inputBox.city.valueState}
                        valueStateMessage={inputBox.city.valueStateMessage}
                        onChange={(e) => onSelectionChange(e)}
                        disabled={states.length}
                    >
                        <Option value={''}>Select City</Option>
                        {cities[selectedState]?.map((cityVal) => (
                            <Option key={cityVal.city_id} value={cityVal.city_id}>
                                {cityVal.city_name}
                            </Option>
                        ))}
                    </Select>
                </div>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label required showColon style={{ display: 'block', marginTop: '2rem' }}>
                        Pincode
                    </Label>
                    <Input
                        id="pincode"
                        name="pincode"
                        value={inputBox.pincode.value}
                        valueState={inputBox.pincode.valueState}
                        valueStateMessage={inputBox.pincode.valueStateMessage}
                        onInput={(e) => onInputChange(e)}
                        style={{ width: '80%' }}
                    />
                </div>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label required showColon style={{ display: 'block', marginTop: '2rem' }}>
                        Phone Number
                    </Label>
                    <Input
                        id="phoneNumber"
                        value={inputBox.phoneNumber.value}
                        valueState={inputBox.phoneNumber.valueState}
                        valueStateMessage={inputBox.phoneNumber.valueStateMessage}
                        onInput={(e) => onInputChange(e)}
                        style={{ width: '80%' }}
                        name="phoneNumber"
                    />
                </div>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label required showColon style={{ display: 'block', marginTop: '2rem' }}>
                        Address
                    </Label>
                    <TextArea
                        id="address"
                        name="address"
                        value={inputBox.address.value}
                        valueState={inputBox.address.valueState}
                        valueStateMessage={inputBox.address.valueStateMessage}
                        onInput={(e) => onInputChange(e)}
                        style={{ width: '80%', height: '200%' }}
                    />
                </div>
                <FlexBox data-layout-span="XL12 L12 M12 S12" justifyContent="End">
                    <Button
                        style={{
                            marginTop: '12px',
                            marginRight: '6%'
                        }}
                        design="Emphasized"
                        onClick={submitBusinessInfoForm}
                    >
                        Save &amp; Go Next
                    </Button>
                </FlexBox>
            </Grid>
        </>
    );
};

const mapStateToProps = (state) => {
    return {
        states: getStatesInfo(state),
        cities: getCitiesInfo(state),
        isLoading: isBusinessInfoLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetStates: () => dispatch(getStates()),
        startGetCities: (stateId) => dispatch(getCities(stateId)),
        startUpdateBusinessInfo: async (payload) => dispatch(updateBusinessInfo(payload))
    };
};

BusinessProfile.propTypes = {
    startUpdateBusinessInfo: PropTypes.func,
    startGetStates: PropTypes.func,
    startGetCities: PropTypes.func,
    states: PropTypes.array,
    cities: PropTypes.object,
    onNextClick: PropTypes.func,
    isLoading: PropTypes.bool
};

BusinessProfile.defaultProps = {
    states: [],
    cities: {}
};

export default connect(mapStateToProps, mapDispatchToProps)(BusinessProfile);
