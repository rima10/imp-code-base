import axios from "axios";
import { setUserInfo } from "../store/actionType";
import { store } from "../store/store";

const getCSRF = async (param) => {
    param.headers = param.headers || {};
    param.headers['Content-Type'] = 'application/json';
    const csrf = store.getState().userInfo.csrf;
    if (csrf) {
        param.headers['CSRF-Token'] = csrf;
    }
    return param;
};

const postAPIWrapper = async (url, payload, param) => {
    param = await getCSRF(param);
    const response = await axios.post(url, payload, param);
    return response;
};

const patchAPIWrapper = async (url, payload, param) => {
    param = await getCSRF(param);
    const response = await axios.patch(url, payload, param);
    return response;
};

const deleteAPIWrapper = async (url, param) => {
    param = await getCSRF(param);
    const response = await axios.delete(url, param);
    return response;
};

const putAPIWrapper = async (url, payload, param) => {
    param = await getCSRF(param);
    axios.put(url, payload, param);
};

export default {
    get: axios.get,
    post: postAPIWrapper,
    axiosPost: axios.post,
    put: putAPIWrapper,
    delete: deleteAPIWrapper,
    patch: patchAPIWrapper,
    head: axios.head
};


axios.interceptors.response.use(undefined, function (error) {
    if (error.response.status === 401 || error.response.status === 403) {
        store.dispatch(setUserInfo(null, false));
    }
    return Promise.reject(error);
});
