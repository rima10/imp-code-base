import {
    FETCH_BP_BUSINESS_INFO,
    UPDATE_BP_BUSINESS_INFO,
    FETCH_BP_NETWORK_INFO,
    CREATE_BP_NETWORK_INFO,
    DELETE_BP_NETWORK_INFO,
    FETCH_SERVICE_LOCATION,
    CREATE_SERVICE_LOCATION,
    DELETE_SERVICE_LOCATION,
    POST_CERTIFICATES,
    GET_CERTIFICATES,
    DOWNLOAD_CERTIFICATE
} from '../actionType';
import { showMessage } from './toast';
import http from '../../utils/httpService';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

// Business Info Action Creators
export const getBusinessInfo = () => async (dispatch, getState) => {
    dispatch({
        type: FETCH_BP_BUSINESS_INFO,
        payload: http.get(`${API_BASE_URL}user/getBusinessInfo`, {
            withCredentials: true
        })
    });
};

export const updateBusinessInfo = (payload) => async (dispatch, getState) => {
    await dispatch({
        type: UPDATE_BP_BUSINESS_INFO,
        payload: http.patch(`${API_BASE_URL}user/update`, payload, {
            withCredentials: true
        })
    });
    dispatch(getBusinessInfo());
    dispatch(showMessage({ message: 'Updated Business Information', status: 'Positive' }));
};

// Private Network Action Creators
export const getNetworkInfo = () => async (dispatch, getState) => {
    dispatch({
        type: FETCH_BP_NETWORK_INFO,
        payload: http.get(`${API_BASE_URL}user/getprivatenetwork`, {
            withCredentials: true
        })
    });
};

export const registerBPNetworkInfo = (payload) => async (dispatch, getState) => {
    await dispatch({
        type: CREATE_BP_NETWORK_INFO,
        payload: http.post(`${API_BASE_URL}user/createPrivateNetwork?bp=rp`, payload, {
            withCredentials: true
        })
    });
    dispatch(getNetworkInfo());
    dispatch(showMessage({ message: 'Private Network Added', status: 'Positive' }));
};

export const deleteBPNetworkInfo = (payload) => async (dispatch, getState) => {
    await dispatch({
        type: DELETE_BP_NETWORK_INFO,
        payload: http.delete(`${API_BASE_URL}user/deleteprivatenetwork`, {
            data: payload,
            withCredentials: true
        })
    });
    dispatch(getNetworkInfo());
    dispatch(showMessage({ message: 'Private Network Deleted', status: 'Positive' }));
};

// Service Location Action Creators
export const getServiceLocation = () => async (dispatch, getState) => {
    dispatch({
        type: FETCH_SERVICE_LOCATION,
        payload: http.get(`${API_BASE_URL}user/getServicableLocation`, {
            withCredentials: true
        })
    });
};

export const createServiceLocation = (payload) => async (dispatch, getState) => {
    await dispatch({
        type: CREATE_SERVICE_LOCATION,
        payload: http.post(`${API_BASE_URL}user/addServicableLocation`, payload, {
            withCredentials: true
        })
    });
    dispatch(getServiceLocation());
    dispatch(showMessage({ message: 'Service Location Added', status: 'Positive' }));
};

export const deleteServiceLocation = (payload) => async (dispatch, getState) => {
    await dispatch({
        type: DELETE_SERVICE_LOCATION,
        payload: http.delete(`${API_BASE_URL}user/deleteServicableLocation`, {
            data: payload,
            withCredentials: true
        })
    });
    dispatch(getServiceLocation());
    dispatch(showMessage({ message: 'Service Location Deleted', status: 'Positive' }));
};

export const saveCertificates = (fileForms) => async (dispatch, getState) => {
    try {
        await Promise.all(fileForms.map(async (form) => {
            await dispatch({
                type: POST_CERTIFICATES,
                payload: http.post(`${API_BASE_URL}user/certificates`, form, {
                    withCredentials: true
                })
            });
        }));

        dispatch(showMessage({ message: `Successfully saved the certificates`, status: 'Positive' }));
    } catch (error) {
        return Promise.reject(error);
    }
};

export const getCertificates = () => async (dispatch, getState) => {
    dispatch({
        type: GET_CERTIFICATES,
        payload: http.get(`${API_BASE_URL}user/certificates`, {
            withCredentials: true
        })
    });
};

export const downloadCertificate = (certificateId) => async (dispatch, getState) => {
    const downloadPromise = http.get(`${API_BASE_URL}user/certificates/${certificateId}`, {
        responseType: 'arraybuffer',
        withCredentials: true
    });
    return dispatch({
        type: DOWNLOAD_CERTIFICATE,
        payload: downloadPromise
    });
};

