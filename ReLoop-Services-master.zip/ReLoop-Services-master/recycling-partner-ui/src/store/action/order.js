import {
    SUBMIT_FIRST_LEVEL_QUOTE,
    ACCEPT_LOGISTIC_SCHEDULE,
    FETCH_ORDER_LIST,
    FETCH_ORDER_HEADER_DATA,
    SET_ONSITE_VISIT_SCHEDULE,
    FETCH_CONSOLIDATED_ORDER_ITEMS_INFO,
    SET_ONSITE_VISIT_DETAILS,
    SET_ORDER_DOCUMENTS,
    FETCH_RECYCLE_ORDER_ITEMS,
    SUBMIT_RECYCLE_FIRST_LEVEL_QUOTE,
    FETCH_RECYCLE_CONSOLIDATED_ORDER_ITEMS,
    SUBMIT_RECYCLE_FINAL_QUOTE,
    FETCH_LOGISTICS_DATA
} from '../actionType';
import http from '../../utils/httpService';
import { getErrorMessage } from '../../utils/errorMessage';
import { showErrorMessage, showMessage } from './toast';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

export const getConsolidatedOrderItemInfo = (orderId) => async (dispatch, getState) => {
    dispatch({
        type: FETCH_CONSOLIDATED_ORDER_ITEMS_INFO,
        payload: http.get(`${API_BASE_URL}order/getRecyclerConsolidatedOrderData/${orderId}`, {
            withCredentials: true
        })
    });
};

export const submitFirstLevelQuote = (payload) => async (dispatch, getState) => {
    await dispatch({
        type: SUBMIT_FIRST_LEVEL_QUOTE,
        payload: http.post(`${API_BASE_URL}order/quotation/submitRefurbishInitialQuote`, payload, {
            withCredentials: true
        })
    });
    dispatch(showMessage({ message: 'Successfully Submitted Quote', status: 'Positive' }));
    return Promise.resolve(true);
};

export const acceptLogisticSchedule = (orderId, payload) => async (dispatch, getState) => {
    await dispatch({
        type: ACCEPT_LOGISTIC_SCHEDULE,
        payload: http.post(`${API_BASE_URL}order/acceptLogistics/${orderId}`, payload, {
            withCredentials: true
        })
    });
    dispatch(showMessage({ message: 'You successfully accepted the logistics schedule.', status: 'Positive' }));
};

export const downloadDocument = (orderId, key) => async (dispatch) => {
    const response = await http.get(`${API_BASE_URL}order/document/downloadDocument/${orderId}/${key}`, {
        responseType: 'arraybuffer',
        withCredentials: true
    });
    return Promise.resolve(response);
};

export const getOrderList = () => async (dispatch, getState) => {
    dispatch({
        type: FETCH_ORDER_LIST,
        payload: http.get(API_BASE_URL + `order/getRequestedOrder`, {
            withCredentials: true
        })
    });
};

export const getOrderHeaderData = (orderId) => async (dispatch) => {
    dispatch({
        type: FETCH_ORDER_HEADER_DATA,
        payload: http.get(`${API_BASE_URL}order/getOrderHeaderData/${orderId}`, {
            withCredentials: true
        })
    });
};

export const getOnsiteVisitDetails = (orderId) => async (dispatch) => {
    dispatch({
        type: SET_ONSITE_VISIT_DETAILS,
        payload: http.get(`${API_BASE_URL}order/quotation/getScheduledOnsiteVisitDetails/${orderId}?bp=rp`, {
            withCredentials: true
        })
    });
};
export const getOrderDocuments = (orderId) => async (dispatch) => {
    dispatch({
        type: SET_ORDER_DOCUMENTS,
        payload: http.get(`${API_BASE_URL}order/document/getOrderDocuments/${orderId}`, {
            withCredentials: true
        })
    });
};

export const acceptSchedule = (orderId) => async (dispatch, getState) => {
    const userId = getState().userInfo.bp_id;
    await dispatch({
        type: SET_ONSITE_VISIT_SCHEDULE,
        payload: http.get(`${API_BASE_URL}order/quotation/acceptSchedule/${orderId}/${userId}`, {
            withCredentials: true
        })
    });
    dispatch(getOrderHeaderData(orderId));
    dispatch(showMessage({ message: 'Accepted the Onsite Asset Visit Schedule', status: 'Positive' }));
};
export const generateForm6Document = (orderId, payload) => async (dispatch) => {
    try {
        const response = await http.post(`${API_BASE_URL}order/document/generateForm6/${orderId}`, payload, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        getOrderDocuments(orderId)(dispatch);
        return Promise.resolve(response);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showErrorMessage(errorMessage));
        return Promise.reject(error);
    }
};

export const generateForm2Document = (orderId, payload) => async (dispatch) => {
    try {
        const response = await http.post(`${API_BASE_URL}order/document/generateForm2/${orderId}`, payload, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        getOrderDocuments(orderId)(dispatch);
        return Promise.resolve(response);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showErrorMessage(errorMessage));
        return Promise.reject(error);
    }
};

export const uploadDocument = (orderId, payload) => async (dispatch) => {
    try {
        const response = await http.post(`${API_BASE_URL}order/document/uploadDocument/${orderId}`, payload, {
            withCredentials: true
        });
        getOrderDocuments(orderId)(dispatch);
        dispatch(showMessage({ message: 'Successfully uploaded the document', status: 'Positive' }));
        return Promise.resolve(response);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showErrorMessage(errorMessage));
        return Promise.reject(error);
    }
};

export const getOrderItemsGradeList = (orderId, quoteId) => async (dispatch, getState) => {
    try {
        // eslint-disable-next-line max-len
        const response = await http.get(`${API_BASE_URL}order/quotation/refurbish/grading/${orderId}/${quoteId}?bp=rp`, {
            withCredentials: true
        });
        return Promise.resolve(response.data);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showErrorMessage(errorMessage));
        return Promise.reject(error);
    }
};

export const saveAssetGradeList = (orderId, quoteId, payload) => async (dispatch, getState) => {
    try {
        const url = `${API_BASE_URL}order/quotation/refurbish/grading/${orderId}/${quoteId}`;
        const response = await http.post(url, payload, {
            withCredentials: true
        });
        dispatch(showMessage({ message: `Successfully saved Asset grading changes`, status: 'Positive' }));
        return Promise.resolve(response.data);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showErrorMessage(errorMessage));
        return Promise.reject(error);
    }
};

export const getOrderQuoteDetails = (orderId, quoteId, projection) => async (dispatch, getState) => {
    try {
        const response = await http.get(`${API_BASE_URL}order/quotation/${orderId}/${quoteId}`, {
            params: { projection },
            withCredentials: true
        });
        return Promise.resolve(response.data);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showErrorMessage(errorMessage));
        return Promise.reject(error);
    }
};

export const updateOrderQuote = (orderId, quoteId, payload) => async (dispatch, getState) => {
    try {
        const response = await http.post(`${API_BASE_URL}order/quotation/${orderId}/${quoteId}`, payload, {
            withCredentials: true
        });
        dispatch(showMessage({ message: `Successfully saved Asset grading comments`, status: 'Positive' }));
        return Promise.resolve(response.data);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showErrorMessage(errorMessage));
        return Promise.reject(error);
    }
};

export const submitAssetGrading = (orderId, quoteId) => async (dispatch, getState) => {
    try {
        const url = `${API_BASE_URL}order/quotation/refurbish/grading/${orderId}/${quoteId}/submit`;
        const response = await http.post(url, {}, { withCredentials: true });
        dispatch(
            showMessage({
                message: `Asset verification and grading was successfuly submited to the customer. Next process
             steps will be enabled when they reply.`,
                status: 'Positive'
            })
        );
        return Promise.resolve(response.data);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showErrorMessage(errorMessage));
        return Promise.reject(error);
    }
};

export const getRecycleOrderItemInfo = (orderId) => async (dispatch) => {
    dispatch({
        type: FETCH_RECYCLE_ORDER_ITEMS,
        payload: http.get(`${API_BASE_URL}order/getRecycleOrderItems/${orderId}?bp=rp`, {
            withCredentials: true
        })
    });
};

export const submitRecycleInitialQuote = (orderId, payload) => async (dispatch) => {
    await dispatch({
        type: SUBMIT_RECYCLE_FIRST_LEVEL_QUOTE,
        payload: http.post(`${API_BASE_URL}order/quotation/submitRecycleInitialQuote/${orderId}`, payload, {
            withCredentials: true
        })
    });
    dispatch(showMessage({ message: 'You successfully submitted the quote', status: 'Positive' }));
    return Promise.resolve(true);
};

export const getRecycleConsolidatedOrderItemsInfo = (orderId) => async (dispatch) => {
    dispatch({
        type: FETCH_RECYCLE_CONSOLIDATED_ORDER_ITEMS,
        payload: http.get(`${API_BASE_URL}order/quotation/getRecycleConsolidatedOrderItems/${orderId}`, {
            withCredentials: true
        })
    });
};

export const submitRecycleFinalQuote = (orderId, payload) => async (dispatch) => {
    await dispatch({
        type: SUBMIT_RECYCLE_FINAL_QUOTE,
        payload: http.post(`${API_BASE_URL}order/quotation/submitRecycleFinalQuote/${orderId}`, payload, {
            withCredentials: true
        })
    });
    dispatch(showMessage({ message: 'You successfully submitted the final quote', status: 'Positive' }));
};

export const getLogisticsData = (orderId) => async (dispatch) => {
    dispatch({
        type: FETCH_LOGISTICS_DATA,
        payload: http.get(`${API_BASE_URL}order/getLogisticsData/${orderId}?bp=rp`, {
            withCredentials: true
        })
    });
};
