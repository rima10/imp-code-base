import { ActionType } from 'redux-promise-middleware';
import {
    SHOW_MSG_TOASTER,
    HIDE_MSG_TOASTER,
    FETCH_BP_BUSINESS_INFO,
    UPDATE_BP_BUSINESS_INFO,
    FETCH_BP_NETWORK_INFO,
    CREATE_BP_NETWORK_INFO,
    DELETE_BP_NETWORK_INFO,
    FETCH_SERVICE_LOCATION,
    CREATE_SERVICE_LOCATION,
    DELETE_SERVICE_LOCATION,
    FETCH_ORDER_HEADER_DATA,
    FETCH_ORDER_LIST,
    FETCH_CONSOLIDATED_ORDER_ITEMS_INFO,
    SUBMIT_FIRST_LEVEL_QUOTE,
    ACCEPT_LOGISTIC_SCHEDULE,
    SET_ORDER_DOCUMENTS,
    POST_CERTIFICATES,
    GET_CERTIFICATES,
    DOWNLOAD_CERTIFICATE,
    FETCH_RECYCLE_ORDER_ITEMS,
    SUBMIT_RECYCLE_FIRST_LEVEL_QUOTE,
    FETCH_RECYCLE_CONSOLIDATED_ORDER_ITEMS,
    SUBMIT_RECYCLE_FINAL_QUOTE,
    FETCH_LOGISTICS_DATA
} from '../actionType';
import StatusColor from '../../asset/constants/statusColor';

const initialState = {
    show: false,
    status: StatusColor.Information,
    message: ''
};

const messageToaster = (state = initialState, action) => {
    const { type, payload } = action;

    switch (type) {
        case SHOW_MSG_TOASTER: {
            return {
                ...state,
                message: payload.message,
                status: payload.status,
                show: true
            };
        }

        case HIDE_MSG_TOASTER: {
            return {
                ...initialState
            };
        }

        case `${POST_CERTIFICATES}_${ActionType.Rejected}`:
        case `${GET_CERTIFICATES}_${ActionType.Rejected}`:
        case `${DOWNLOAD_CERTIFICATE}_${ActionType.Rejected}`:
        case `${FETCH_BP_BUSINESS_INFO}_${ActionType.Rejected}`:
        case `${UPDATE_BP_BUSINESS_INFO}_${ActionType.Rejected}`:
        case `${FETCH_BP_NETWORK_INFO}_${ActionType.Rejected}`:
        case `${CREATE_BP_NETWORK_INFO}_${ActionType.Rejected}`:
        case `${DELETE_BP_NETWORK_INFO}_${ActionType.Rejected}`:
        case `${FETCH_SERVICE_LOCATION}_${ActionType.Rejected}`:
        case `${CREATE_SERVICE_LOCATION}_${ActionType.Rejected}`:
        case `${DELETE_SERVICE_LOCATION}_${ActionType.Rejected}`:
        case `${FETCH_CONSOLIDATED_ORDER_ITEMS_INFO}_${ActionType.Rejected}`:
        case `${FETCH_ORDER_HEADER_DATA}_${ActionType.Rejected}`:
        case `${SET_ORDER_DOCUMENTS}_${ActionType.Rejected}`:
        case `${FETCH_ORDER_LIST}_${ActionType.Rejected}`:
        case `${SUBMIT_FIRST_LEVEL_QUOTE}_${ActionType.Rejected}`:
        case `${ACCEPT_LOGISTIC_SCHEDULE}_${ActionType.Rejected}`:
        case `${FETCH_RECYCLE_ORDER_ITEMS}_${ActionType.Rejected}`:
        case `${SUBMIT_RECYCLE_FIRST_LEVEL_QUOTE}_${ActionType.Rejected}`:
        case `${FETCH_RECYCLE_CONSOLIDATED_ORDER_ITEMS}_${ActionType.Rejected}`:
        case `${SUBMIT_RECYCLE_FINAL_QUOTE}_${ActionType.Rejected}`:
        case `${FETCH_LOGISTICS_DATA}_${ActionType.Rejected}`: {
            return {
                ...state,
                // optional chaining checks
                message: payload?.response?.data?.error?.message ?? 'Something went wrong',
                status: StatusColor.Negative,
                show: true
            };
        }

        default: {
            return state;
        }
    }
};

export default messageToaster;
