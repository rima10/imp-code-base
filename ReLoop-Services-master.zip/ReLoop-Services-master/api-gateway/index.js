const express = require('express');
const dotenv = require('dotenv');
const app = require('./app');

dotenv.config();

const { PORT } = process.env;
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.listen(PORT, () => {
  console.log(`App running on port ${PORT}.`);
});
