const router = require('express').Router();
const dotenv = require('dotenv');
const csurf = require('csurf');
const proxy = require('../utils/proxy.util');
const authUtil = require('../utils/auth.util');

const csrfProtection = csurf({ cookie: true });

dotenv.config();

const { ACCOUNT_MGT_URL } = process.env;

/*
  @desc router for /api/user endpoint
*/
module.exports = (app) => {
  router.all('/user*', authUtil.validateMiddleware, csrfProtection, proxy.getCustomProxy(ACCOUNT_MGT_URL));
  app.use('/api', router);
};
