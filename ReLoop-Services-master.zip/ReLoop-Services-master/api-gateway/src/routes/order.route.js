const router = require('express').Router();
const dotenv = require('dotenv');
const csurf = require('csurf');
const proxy = require('../utils/proxy.util');

const csrfProtection = csurf({ cookie: true });

dotenv.config();

const { ORDER_MGT_URL } = process.env;

/*
  @desc router for /api/user endpoint
*/
module.exports = (app) => {
  router.all('/order*', csrfProtection, proxy.getCustomProxy(ORDER_MGT_URL));
  router.all('/wasteCategory*', proxy.getCustomProxy(ORDER_MGT_URL));
  app.use('/api', router);
};
