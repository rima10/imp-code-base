import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { spacing } from '@ui5/webcomponents-react-base';
import { connect } from 'react-redux';
import { Title, Toolbar, Text } from '@ui5/webcomponents-react';
import moment from 'moment';

import AccountTable from '../common/Table';
import { downloadFile } from '../../store/action/taskAction';
import { getOrderInfoState } from '../../selectors/common';

const OrderCreationApproval = ({ orderInfo = {} }) => {
    const [assetRows, setAssetRows] = useState([]);
    const assetColumns = [
        'Equipment No.',
        'Asset No.',
        'Location',
        'Bond Status',
        'Item Type',
        'Make',
        'Model',
        'Manuf. Serial No.',
        'Age in Years',
        'Purchase Year',
        'Description'
    ];
    const recycleAssetColumns = ['Item', 'Quantity', 'Unit', 'Location', 'Remarks'];
    const onDownloadBtnClick = () => {
        downloadFile(orderInfo.orderId, `Asset List_${orderInfo.orderNumber}.xlsx`);
    };

    const buttons = [
        {
            name: 'Download Excel',
            icon: 'download',
            onClick: onDownloadBtnClick
        }
    ];

    const getOrderItemsAsTableRows = (orderItems, limit) => {
        if (!orderItems) return [];
        const newRows = [];
        const limitedRows = orderItems.slice(0, limit);

        if (orderInfo.orderType === '1') {
            limitedRows.forEach((index) => {
                const row = [];
                row.push({ name: assetColumns[0], value: index.equipmentNumber, type: 'text' });
                row.push({ name: assetColumns[1], value: index.assetNumber, type: 'text' });
                row.push({ name: assetColumns[2], value: index.buildingLocation, type: 'text' });
                row.push({ name: assetColumns[3], value: index.bondStatus, type: 'text' });
                row.push({ name: assetColumns[4], value: index.itemType, type: 'text' });
                row.push({ name: assetColumns[5], value: index.make, type: 'text' });
                row.push({ name: assetColumns[6], value: index.model, type: 'text' });
                row.push({ name: assetColumns[7], value: index.manufactureSerial, type: 'text' });
                row.push({ name: assetColumns[8], value: index.ageInYear, type: 'text' });
                row.push({ name: assetColumns[9], value: index.purchaseYear, type: 'text' });
                row.push({ name: assetColumns[10], value: index.description, type: 'text' });
                newRows.push(row);
            });
        } else {
            limitedRows.forEach((index) => {
                const row = [];
                row.push({ name: 'Item', value: index.model, type: 'text' });
                row.push({ name: 'Quantity', value: index.itemQuantity || '-', type: 'text' });
                row.push({ name: 'Unit', value: index.recycleItemUnit || '-', type: 'text' });
                row.push({ name: 'Location', value: index.buildingLocation, type: 'text' });
                row.push({ name: 'Remarks', value: index.description, type: 'text' });
                newRows.push(row);
            });
        }
        return newRows;
    };
    const getColumns = () => (orderInfo.orderType === '1' ? assetColumns : recycleAssetColumns);

    const getOrderCreationActivityId = () => `pss_1|gp_${orderInfo.createdBy}`;
    const [assetListCommentsFromGP, setAssetListCommentsFromGP] = useState([]);

    const minDisplayRows = 10;
    const [minTableHeight, setMinTableHeight] = useState(undefined);

    const loadMoreAssetRows = () => {
        setAssetRows((previousRows) => [
            ...getOrderItemsAsTableRows(orderInfo.orderItems, previousRows.length + minDisplayRows)
        ]);
    };

    useEffect(() => {
        if (orderInfo.orderItems) {
            if (orderInfo.orderItems.length >= minDisplayRows) {
                setMinTableHeight('600px');
            }
            const rows = getOrderItemsAsTableRows(orderInfo.orderItems, minDisplayRows);
            setAssetRows(rows);
        }
        if (orderInfo.orderNotes) {
            const currentActivity = orderInfo.orderNotes.filter(
                (item) => item.activity_identifier === getOrderCreationActivityId()
            );
            setAssetListCommentsFromGP(currentActivity);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [orderInfo.orderItems]);

    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <AccountTable
                text="Asset List"
                edit={false}
                columns={getColumns()}
                rows={assetRows}
                buttons={buttons}
                lazyLoading={loadMoreAssetRows}
                height={minTableHeight}
            />
            <div style={spacing.sapUiLargeMarginTop}>
                <Toolbar>
                    <Title>Additional Comments</Title>
                </Toolbar>
                {
                    assetListCommentsFromGP.map((item, idx) => (
                        <p className="comment-line" key={idx} style={spacing.sapUiTinyMargin}>
                            <Text>{item.comment}</Text>
                            <Text className="inline-text-align-right">
                                {moment(item.timestamp).format('DD-MMM-YYYY hh:mm')}
                            </Text>
                        </p>
                    ))
                }
            </div>
        </div>
    );
};

OrderCreationApproval.propTypes = {
    orderInfo: PropTypes.object
};

const mapStateToProps = (state) => ({
    orderInfo: getOrderInfoState(state)
});

export default connect(mapStateToProps)(OrderCreationApproval);
