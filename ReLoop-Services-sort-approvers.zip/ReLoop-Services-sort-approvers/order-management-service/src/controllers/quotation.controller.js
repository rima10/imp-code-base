const mime = require('mime');
const moment = require('moment');
const { Readable } = require('stream');

const quotationService = require('../services/quotation.service');
const userService = require('../services/user.service');

/*
  @desc controller function to invite recyclers
*/
exports.inviteRecyclers = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;
    const { orderId, recyclers } = req.body;
    await quotationService.inviteRecyclers(userId, orderId, recyclers);
    res.send(201);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to submit first level quotes
*/
exports.submitRecycleInitialQuote = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;
    const { orderId } = req.params;
    const quoteData = req.body;
    const quote = await quotationService.submitRecycleInitialQuote(userId, orderId, quoteData);
    res.status(201).send(quote);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to submit first level quotes
*/
exports.submitRefurbishInitialQuote = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;
    const { orderId } = req.params;
    const quoteData = req.body;
    const quote = await quotationService.submitRefurbishInitialQuote(userId, orderId, quoteData);
    res.status(201).send(quote);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get first level quotes
*/
exports.getRecycleOrderFirstLevelQuotes = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const quotes = await quotationService.getRecycleOrderFirstLevelQuotes(orderId);
    res.json(quotes);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get first level quotes
*/
exports.getRefurbishOrderFirstLevelQuotes = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const quotes = await quotationService.getRefurbishOrderFirstLevelQuotes(orderId);
    res.json(quotes);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function quote accept
*/
exports.acceptQuote = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const details = req.body;
    const quote = await quotationService.acceptQuote(orderId, details);
    res.json(quote);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function quote accept
*/
exports.temproaryAcceptQuote = async function (req, res, next) {
  try {
    const { orderId, quoteId } = req.params;
    const quote = await quotationService.temproaryAcceptQuote(orderId, quoteId);
    res.json(quote);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for quote reject
*/
exports.rejectQuote = async function (req, res, next) {
  try {
    const { orderId, quoteId } = req.params;
    const details = req.body;
    const quote = await quotationService.rejectQuote(orderId, quoteId, details);
    res.json(quote);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get onsite verification details
*/
exports.getScheduledOnsiteVisitDetails = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const { userId } = req.userInfo;
    const quote = await quotationService.getScheduledOnsiteVisitDetails(orderId, userId);
    res.json(quote);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to submit order item level quotes
*/
exports.submitRecycleItemLevelQuote = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;
    const { orderId } = req.params;
    const quoteData = req.body;
    const quote = await quotationService.submitRecycleItemLevelQuote(userId, orderId, quoteData);
    res.status(201).send(quote);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to submit asset grading quote
*/
exports.submitRefurbishOrderAssetGradingQuote = async function (req, res, next) {
  try {
    const username = req.userInfo['cognito:username'];
    const userData = await userService.getUserDatabyCognito(username);

    const { orderId, quoteId } = req.params;
    const result = await quotationService.submitRefurbishOrderAssetGradingQuote(userData, orderId, quoteId);
    res.status(200).send(result);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get order item level quotes
*/
exports.getRecycleOrderItemLevelQuote = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const quotes = await quotationService.getRecycleOrderItemLevelQuote(orderId);
    res.json(quotes);
  } catch (error) {
    next(error);
  }
};

exports.getOrderItemsGradingList = async function (req, res, next) {
  try {
    const { orderId, quoteId } = req.params;
    const entries = await quotationService.getOrderItemsGradingList(orderId, quoteId);
    res.json(entries);
  } catch (error) {
    next(error);
  }
};

function bufferToStream(buffer) {
  const stream = new Readable();
  stream.push(buffer);
  stream.push(null);

  return stream;
}

exports.downloadOrderItemsGradingList = async function (req, res, next) {
  try {
    const { orderId, quoteId } = req.params;
    const wbBuffer = await quotationService.getOrderItemsGradingListInExcel(orderId, quoteId);
    const wbStream = bufferToStream(wbBuffer);
    const filename = `AssetGradeList_${orderId}_${quoteId}_${moment().format('DD-MMM-YYYY hh:mm')}.xlsx`;

    res.set('Content-Type', mime.getType(filename));
    res.attachment(filename);

    wbStream.pipe(res);
  } catch (error) {
    next(error);
  }
};

exports.saveOrderItemsGradingList = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;
    const { orderId, quoteId } = req.params;
    const payload = req.body;
    const result = await quotationService.saveOrderItemsGradingList(userId, orderId,
      quoteId, payload);
    res.status(200).send(result);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get order_quote id by orderId, quoteId
*/
exports.getOrderQuoteDetails = async function (req, res, next) {
  try {
    const { orderId, quoteId } = req.params;
    const projection = req.query && req.query.projection
      ? req.query.projection.split(',').map((str) => (str.trim())) : undefined;
    const result = await quotationService.getOrderQuoteDetails(orderId, quoteId, projection);
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to update order_quote table columns
*/
exports.updateOrderQuoteDetails = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;

    const { orderId, quoteId } = req.params;
    const payload = req.body;
    const result = await quotationService.updateOrderQuoteDetails(userId,
      orderId,
      quoteId,
      payload);
    res.status(200).send(result);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to notify BP for the onsite Visit
*/
exports.notifyBP = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;
    const { orderId } = req.params;
    const response = await quotationService.notifyBP(userId, orderId);
    res.status(200).send(response);
  } catch (error) {
    next(error);
  }
};

exports.getRecycleConsolidatedOrderItems = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const { userId } = req.userInfo;
    const quotes = await quotationService.getRecycleConsolidatedOrderItems(userId, orderId);
    res.json(quotes);
  } catch (error) {
    next(error);
  }
};
