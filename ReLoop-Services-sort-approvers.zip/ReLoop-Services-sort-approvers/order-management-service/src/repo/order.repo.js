const { Op } = require('sequelize');
const models = require('../models/index');
const s3Util = require('../utils/s3.util');
const ErrorTypes = require('../constants/error');
const quotationRepo = require('./quotation.repo');
const attributes = [
  ['order_id', 'orderId'], ['order_no', 'orderNumber'],
  ['order_sub_text', 'orderAdditionalInfo'], 'category', ['sub_category', 'subCategory'], ['order_type', 'orderType'],
  ['submission_deadline', 'submissionDeadline'], ['order_network', 'orderNetwork'],
  ['picture_loc', 'pictureLoc'], 'created_date', 'last_modified_date', ['created_by', 'createdBy'],
  ['updated_by', 'updatedBy'], 'preferred_pick_up_time', 'is_verification_reqd', ['order_position', 'orderPosition'],
  ['current_sequence', 'currentSequence'], ['logistics_scheduled_time', 'logisticsScheduledTime'],
  ['vehicle_type', 'vehicleType'], ['vehicle_licence_no', 'vehicleNumber'], ['recycle_asset_type', 'recycleAssetType'],
  ['total_weight', 'totalWeight'], ['logistic_spoc_number', 'logisticSpocContactNumber'],
  ['logistic_spoc_name', 'logisticSpocName'], ['recycler_contact_number', 'recyclerContactNumber'],
  ['recycler_contact_name', 'recyclerContactName'], ['logistic_provider', 'logisticProvider'],
  ['driver_name', 'driverName']];

const refurbishOrderItemAttr = [
  'id', ['order_id', 'orderId'], ['equipment_no', 'equipmentNumber'], ['asset_no', 'assetNumber'],
  ['item_type', 'itemType'], 'make', 'description', 'created_date', 'last_modified_date', ['created_by', 'createdBy'],
  ['updated_by', 'updatedBy'], ['building_loc', 'buildingLocation'], ['manufacture_serial', 'manufactureSerial'],
  ['bond_status', 'bondStatus'], 'model', ['age_in_year', 'ageInYear'], ['purchase_year', 'purchaseYear'],
];

const recycleOrderItemAttr = [
  'id', ['order_id', 'orderId'], 'description', 'created_date', 'last_modified_date',
  ['created_by', 'createdBy'], ['updated_by', 'updatedBy'], ['building_loc', 'buildingLocation'],
  'model', ['recycle_item_unit', 'recycleItemUnit'], ['item_quantity', 'itemQuantity'],
];

const uploadToS3 = async (file, orderNumber) => {
  const fileNamewithExt = file.originalname;
  const fileExt = fileNamewithExt.substr(fileNamewithExt.lastIndexOf('.') + 1);
  const key = `${orderNumber}_picture.${fileExt}`;
  const s3FileKey = await s3Util.pushFileToS3(file, key);
  return s3FileKey;
};

exports.getOrderHeader = async (orderId) => {
  const order = models.order.findOne({
    where: { order_id: orderId },
    attributes: [
      ['order_id', 'orderId'],
      [models.sequelize.fn('COUNT', models.sequelize.col('orderItems.id')), 'itemsCount'],
    ],
    include: [{
      model: models.order_item,
      as: 'orderItems',
      attributes: [],
    }],
    group: ['order.order_id'],
  });
  return order;
};

exports.getOrderHeaderData = async (userId, orderId) => {
  const order = await models.order.findOne({
    where: { order_id: orderId },
    attributes: [
      ['order_id', 'orderId'],
      ['submission_deadline', 'submissionDeadline'],
      ['picture_loc', 'pictureLoc'],
      ['order_network', 'order_network'],
      ['order_sub_text', 'additionalInfo'],
      ['current_sequence', 'currentSequence'],
      ['logistic_spoc_name', 'logisticSpocName'],
      ['logistic_spoc_number', 'logisticSpocContactNumber'],
      ['logistics_scheduled_time', 'logisticsScheduledTime'],
      ['order_no', 'orderNo'],
      [models.sequelize.fn('COUNT', models.sequelize.col('orderItems.id')), 'itemsCount'],
    ],
    include: [
      {
        model: models.order_item,
        as: 'orderItems',
        attributes: [],
      },
      {
        model: models.process_type,
        as: 'orderProcessType',
        required: true,
        attributes: [['process_type_name', 'processType']],
      },
      {
        model: models.category,
        as: 'order_category',
        attributes: [['category_name', 'categoryName']],
      },
      {
        model: models.sub_category,
        as: 'order_sub_category',
        attributes: [['sub_category_name', 'subCategoryName']],
      },
      {
        required: false,
        model: models.order_quote,
        as: 'order_quotes',
        where: { created_by: userId },
        attributes: ['id', ['total_price', 'totalPrice']],
      },
      {
        model: models.business_partner,
        as: 'businessPartner',
        attributes: [['bp_username', 'bpUserName']],
        include: [
          {
            model: models.location,
            as: 'loc',
            attributes: ['pincode', ['loc_details', 'locDetails']],
            include: [
              {
                model: models.city,
                as: 'city',
                attributes: ['city_name'],
              },
              {
                model: models.state,
                as: 'state',
                attributes: ['state_name', 'country_id'],
              },
            ],
          },
        ],
      },
    ],
    group: [
      'order.order_id',
      'businessPartner.bp_id',
      'businessPartner.loc.city.city_id',
      'businessPartner.loc.loc_id',
      'order_category.category_id',
      'order_sub_category.sub_category_id',
      'businessPartner.loc.state.state_id',
      'order_quotes.id',
      'orderProcessType.process_type_id',
    ],
  });
  const orderData = {
    orderId: order.dataValues.orderId,
    processType: order.dataValues.orderProcessType.dataValues.processType,
    submissionDeadline: order.dataValues.submissionDeadline,
    category: order.dataValues.order_category.dataValues.categoryName,
    subCategory: order.dataValues.order_sub_category.dataValues.subCategoryName,
    pictureLoc: order.dataValues.pictureLoc,
    orderNetwork: order.dataValues.order_network,
    additionalInfo: order.dataValues.additionalInfo || null,
    itemsCount: order.dataValues.itemsCount,
    currentSequence: order.dataValues.currentSequence,
    logisticSpocName: order.dataValues.logisticSpocName,
    logisticSpocContactNumber: order.dataValues.logisticSpocContactNumber,
    logisticsScheduledTime: order.dataValues.logisticsScheduledTime,
    orderNo: order.dataValues.orderNo,
    totalPrice: order.dataValues.order_quotes.length > 0
      ? order.dataValues.order_quotes[0].dataValues.totalPrice : null,
    bpUserName: order.dataValues.businessPartner
      ? order.dataValues.businessPartner.dataValues.bpUserName : null,
    // eslint-disable-next-line no-nested-ternary
    locPincode: order.dataValues.businessPartner
      ? order.dataValues.businessPartner.loc
        ? order.dataValues.businessPartner.loc.pincode : null : null,
    locDetails:
      // eslint-disable-next-line no-nested-ternary
      order.dataValues.businessPartner
        ? order.dataValues.businessPartner.loc
          ? order.dataValues.businessPartner.loc.dataValues.locDetails : null : null,
    // eslint-disable-next-line no-nested-ternary
    locCity: order.dataValues.businessPartner
      ? order.dataValues.businessPartner.loc
        ? order.dataValues.businessPartner.loc.city.city_name : null : null,
    // eslint-disable-next-line no-nested-ternary
    locState: order.dataValues.businessPartner
      ? order.dataValues.businessPartner.loc
        ? order.dataValues.businessPartner.loc.state.state_name : null : null,
  };
  return orderData;
};

const orderWorkflowQuery = (orderId, processType, processStageSequence) => ({
  where: { order_id: orderId },
  attributes: [['order_workflow_id', 'orderWorkflowId'], ['workflow_id', 'workflowId']],
  include: [{
    model: models.workflow,
    where: {
      process_type_id: processType,
      process_stage_sequence: processStageSequence,
    },
    as: 'workflow',
    attributes: [['workflow_id', 'workflowId'], ['process_type_id', 'processTypeId'], ['process_stage_name', 'processStageName'], ['process_stage_sequence', 'processStageSequence']],
  }, {
    model: models.order_workflow_approver,
    as: 'order_workflow_approvers',
    where: { is_active: true },
    required: false,
  }],
});

/*
  @desc Map over all the workflowApprovers and create a high level json data out of the nested data
  @desc For each order workflow, add worklow details on the header level
  @desc For each workflow approvers get the status and other relevant data
  @param [Array]  workflows
  @return [Array] updatedWorkflows
*/
const modifyWorkflowData = async (orderWorkflow) => {
  const updatedOrderWorkflow = { ...orderWorkflow.dataValues };
  const {
    processTypeId, processStageName,
    processStageSequence,
  } = updatedOrderWorkflow.workflow.dataValues;
  updatedOrderWorkflow.processTypeId = processTypeId;
  updatedOrderWorkflow.processStageName = processStageName;
  updatedOrderWorkflow.processStageSequence = processStageSequence;
  const workflowApprovers = [];
  const { workflowId } = updatedOrderWorkflow.workflow.dataValues;
  const workflowApproverList = await models.workflow_approver.findAll(
    {
      where: { workflow_id: workflowId },
      attributes: [['workflow_approver_id', 'workflowApproverId'], ['approver_sequence', 'approverSequence']],
      include: [{
        model: models.approver,
        as: 'approver',
      }],
    },
  );
  // Map over all the available order workflow approvers
  workflowApproverList.map((workflowApprover) => {
    const updatedApprover = { ...workflowApprover.dataValues };
    const { workflowApproverId } = updatedApprover;
    const orderWfApprover = updatedOrderWorkflow.order_workflow_approvers.find(
      (approver) => approver.dataValues.workflow_approver_id === workflowApproverId,
    );
    if (orderWfApprover) {
      const { order_workflow_approver_id, status } = orderWfApprover;
      updatedApprover.orderWorkflowApproverId = order_workflow_approver_id;
      updatedApprover.status = status;
    } else {
      updatedApprover.status = 'Not Assigned';
    }
    const {
      approver_id, approver_name, approver_role, approver_sequence,
    } = updatedApprover.approver.dataValues;
    updatedApprover.approverId = approver_id;
    updatedApprover.approverName = approver_name;
    updatedApprover.approverRole = approver_role;
    delete updatedApprover.approver;
    workflowApprovers.push(updatedApprover);
  });
  updatedOrderWorkflow.workflowApprovers = workflowApprovers;
  delete updatedOrderWorkflow.workflow;
  delete updatedOrderWorkflow.order_workflow_approvers;
  return updatedOrderWorkflow;
};

exports.getOrdersForGP = async (gpUserId) => {
  const order = await models.order
    .findAll({
      where:
        { created_by: gpUserId },
      order: [
        ['created_date', 'DESC'],
      ],
      attributes,
      include: [{
        model: models.process_type,
        as: 'orderProcessType',
        attributes: [['process_type_name', 'processTypeName']],
      }],
    });
  return order;
};

exports.getOrdersForRP = async (rpUserId) => {
  const OrderDetails = await models.order_invited_business_partner.findAll({
    attributes: [['invited_bp_id', 'invitedBpId']],
    where: { invited_bp_id: rpUserId },
    as: 'order_invited_business_partner',
    separate: true,
    include: [
      {
        model: models.order,
        where: {
          current_sequence: { [Op.notIn]: ['1', '2'] },
        },
        required: true,
        attributes: [
          'order_no',
          'order_id',
          'current_sequence',
          'order_position',
          'order_type',
          'created_date',
          'last_modified_date',
        ],
        as: 'order',
        include: [
          {
            model: models.business_partner,
            as: 'businessPartner',
            attributes: [['bp_username', 'bpUserName'], 'bp_id'],
          },
        ],
      },
    ],
  });
  const StatusValue = [];
  let finalStatus;
  /* eslint no-restricted-syntax: ["error", "FunctionExpression", "WithStatement",
  "BinaryExpression[operator='in']"] */
  for (const order of OrderDetails) {
    // eslint-disable-next-line no-await-in-loop
    const StatusDetails = await models.order_quote.findOne({
      attributes: models.order_quote.attributesAliasesHelper(['quoteId', 'quoteStatus', 'orderId', 'createdByUserId', 'assetGradeSubmitted']),
      where: {
        created_by: rpUserId,
        order_id: order.order.dataValues.order_id,
      },
    });
    if (StatusDetails) {
      // eslint-disable-next-line prefer-destructuring
      finalStatus = StatusDetails.dataValues.quoteStatus;
      if (finalStatus === 'Accepted') {
        if (order.order.dataValues.current_sequence > 6
          || order.order.dataValues.order_position === 'Completed') {
          finalStatus = 'Completed';
        } else if (
          order.order.dataValues.current_sequence === 4
          || order.order.dataValues.current_sequence === 5
          || order.order.dataValues.current_sequence === 6
        ) {
          finalStatus = 'In Progress';
        } else if (order.order.dataValues.current_sequence === 3) {
          finalStatus = 'Waiting';
        }
      }
      StatusValue.push({
        order_id: order.order.dataValues.order_id,
        order_no: order.order.dataValues.order_no,
        currentSequence: order.order.dataValues.current_sequence,
        orderPosition: order.order.dataValues.order_position,
        orderType: order.order.dataValues.order_type,
        created_by:
          order.order.dataValues.businessPartner.dataValues.bpUserName,
        created_date: order.order.dataValues.created_date,
        lastModifiedDate: order.order.dataValues.last_modified_date,
        quote_status: finalStatus,
        quoteId: StatusDetails.dataValues.quoteId,
        assetGradeSubmitted: StatusDetails.dataValues.assetGradeSubmitted,
      });
    } else {
      StatusValue.push({
        order_id: order.order.dataValues.order_id,
        order_no: order.order.dataValues.order_no,
        currentSequence: order.order.dataValues.current_sequence,
        orderPosition: order.order.dataValues.order_position,
        orderType: order.order.dataValues.order_type,
        created_by:
          order.order.dataValues.businessPartner.dataValues.bpUserName,
        created_date: order.order.dataValues.created_date,
        lastModifiedDate: order.order.dataValues.last_modified_date,
        quote_status: 'New',
        quoteId: undefined,
      });
    }
  }
  return StatusValue;
};

exports.getOrderDataByOrderId = async (
  orderId,
  approvalDataRequired,
  stageSequence,
  isRefurbish,
) => {
  const query = {
    where:
      { order_id: orderId },
    attributes,
    include: [{
      model: models.order_item,
      as: 'orderItems',
      attributes: isRefurbish ? refurbishOrderItemAttr : recycleOrderItemAttr,
    }, {
      model: models.category,
      as: 'order_category',
      attributes: [['category_name', 'categoryName']],
    },
    {
      model: models.sub_category,
      as: 'order_sub_category',
      attributes: [['sub_category_name', 'subCategoryName']],
    },
    {
      model: models.process_type,
      as: 'orderProcessType',
      attributes: [['process_type_name', 'processTypeName']],
    },
    {
      model: models.order_invited_business_partner,
      as: 'order_invited_business_partners',
      attributes: [['invited_bp_id', 'bpId'], ['invited_bp_username', 'bpUsername']],
    },
    {
      model: models.order_notes,
      as: 'order_notes',
      attributes: [
        ['activity', 'activity'], ['activity_comment', 'comment'],
        ['activity_time', 'timestamp'], ['updated_by', 'bpUserId'],
        ['approver_update_by', 'approverUserId'], ['activity_identifier', 'activity_identifier']],
    },
    {
      model: models.business_partner,
      as: 'businessPartner',
      attributes: [
        ['company_code', 'companyCode']],
    },
    ],
  };
  const order = await models.order.findOne(query);
  if (!order) {
    const err = new Error('order not found');
    err.type = ErrorTypes.RES_NOT_FOUND;
    throw err;
  }
  let workflowData = null;
  if (approvalDataRequired) {
    const orderWorkflow = await models.order_workflow.findOne(orderWorkflowQuery(
      orderId, order.dataValues.orderType, stageSequence,
    ));

    if (orderWorkflow) workflowData = await modifyWorkflowData(orderWorkflow);
  }
  // Format order response
  const orderData = { ...order.dataValues };
  if (approvalDataRequired) {
    orderData.workflow = workflowData;
  }
  orderData.categoryName = order.order_category.dataValues.categoryName;
  orderData.subCategoryName = order.order_sub_category.dataValues.subCategoryName;
  orderData.processType = order.orderProcessType.dataValues.processTypeName;
  orderData.recyclers = order.order_invited_business_partners.map((item) => {
    const { bpId, bpUsername } = item.dataValues;
    return { bpId, bpUsername };
  });
  orderData.orderNotes = order.order_notes.map((item) => item.dataValues);

  const acceptedQuoteDbRes = await models.order_quote.findOne({
    where: {
      order_id: orderData.orderId,
      quote_status: 'Accepted',
    },
    attributes: [['id', 'quoteId']],
  });
  if (acceptedQuoteDbRes) {
    orderData.acceptedOrderQuote = acceptedQuoteDbRes.dataValues;
  }
  // Delete unnecesaary data
  delete orderData.order_category;
  delete orderData.order_sub_category;
  delete orderData.order_process_type;
  delete orderData.order_invited_business_partners;
  delete orderData.order_notes;
  return orderData;
};

exports.getOrderItems = async (orderId, orderType) => {
  const prom = models.order_item.findAll({
    where: {
      order_id: orderId,
    },
    attributes: orderType === '1' ? refurbishOrderItemAttr : recycleOrderItemAttr,
  });
  return prom;
};

exports.getOrder = async (orderId, options = {}) => {
  if (!options.projection) {
    options.projection = ['order_id', 'current_sequence', 'order_type', 'order_no', 'order_position'];
  }
  const query = {
    where: { order_id: orderId },
    attributes: models.order.attributesAliasesHelper(options.projection),
  };
  const order = await models.order.findOne(query);
  return order;
};

const createOrderNo = async () => {
  let orderNo = '';
  const year = new Date().getFullYear();
  orderNo += year;
  const lastOrder = await models.order.findOne({ order: [['created_date', 'DESC']], attributes: [['order_no', 'orderNo']] });
  if (!lastOrder) return `${orderNo}001`;
  let lastOrderNumber = lastOrder.dataValues.orderNo;
  lastOrderNumber = lastOrderNumber.substr(lastOrderNumber.length - 3);
  let newOrderNum = Number(lastOrderNumber) + 1;
  if (newOrderNum.toString().length === 1) newOrderNum = `00${newOrderNum}`;
  else if (newOrderNum.toString().length === 2) newOrderNum = `0${newOrderNum}`;
  return `${orderNo}${newOrderNum}`;
};

exports.updateOrderHeaderData = async (userId, dbOrder, updatePayload) => {
  if (!dbOrder) {
    const err = new Error('Order data is missing');
    err.type = ErrorTypes.RES_NOT_FOUND;
    throw err;
  }
  const editableFields = {
    orderType: 'order_type',
    category: 'category',
    subcategory: 'sub_category',
    network: 'order_network',
    orderLocation: 'order_loc',
    additionalInfo: 'order_sub_text',
    picture: 'picture_loc',
    submissionDeadline: 'submission_deadline',
    totalWeight: 'total_weight',
    recycleAssetType: 'recycle_asset_type',
  };
  const {
    recyclerIds, picture,
  } = updatePayload;
  const { order_no, order_id } = dbOrder;

  let s3FileKey;
  if (picture !== undefined) {
    s3FileKey = await uploadToS3(picture, order_no);
  }

  const dbUpdatePayload = {};
  Object.keys(updatePayload).forEach((field) => {
    const columnName = editableFields[field];
    if (columnName) {
      if (field === 'picture') {
        dbUpdatePayload[columnName] = s3FileKey;
      } else if (field === 'totalWeight') {
        dbUpdatePayload[columnName] = (updatePayload[field] === 'null' || updatePayload[field] === 'undefined')
          ? null : updatePayload[field];
      } else {
        dbUpdatePayload[columnName] = updatePayload[field];
      }
    }
  });
  dbUpdatePayload.updated_by = userId;
  await models.order.update(dbUpdatePayload, {
    where: {
      order_id,
    },
  });

  // delete and create new recyclers and order relation
  await models.order_invited_business_partner.destroy({
    where: {
      order_id,
    },
  });

  if (recyclerIds && recyclerIds.length) {
    const recyclersInArr = recyclerIds.split(',');
    const dbres = await models.business_partner.findAll({
      where: {
        bp_id: recyclersInArr,
      },
      attributes: ['bp_username', 'bp_id'],
    });
    if (recyclersInArr.length) {
      const recyclersMappedToOrder = dbres.map((item) => ({
        order_id,
        invited_bp_id: item.dataValues.bp_id,
        invited_bp_username: item.dataValues.bp_username,
      }));
      await models.order_invited_business_partner.bulkCreate(recyclersMappedToOrder, { validate: true });
    }
  }
};

exports.createOrderHeader = async (orderHeaderData, userId, files, orderPosition) => {
  const {
    orderType, category, subcategory, network,
    orderLocation, additionalInfo, submissionDeadline,
    recyclerIds, totalWeight, recycleAssetType,
  } = orderHeaderData;

  const uuid = await createOrderNo();
  let s3FileKey;
  if (files.picture !== undefined) {
    const file = files.picture[0];
    s3FileKey = await uploadToS3(file, uuid);
  }

  const order = await models.order.create({
    order_no: uuid,
    order_type: orderType,
    category,
    sub_category: subcategory,
    order_network: network,
    order_loc: orderLocation,
    order_sub_text: additionalInfo,
    submission_deadline: submissionDeadline,
    picture_loc: s3FileKey,
    created_by: userId,
    updated_by: userId,
    order_position: orderPosition,
    current_sequence: '1',
    total_weight: totalWeight,
    recycle_asset_type: recycleAssetType,
  });

  if (recyclerIds && recyclerIds.length) {
    const recyclersInArr = recyclerIds.split(',');
    const dbres = await models.business_partner.findAll({
      where: {
        bp_id: recyclersInArr,
      },
      attributes: ['bp_username', 'bp_id'],
    });
    if (recyclersInArr.length) {
      const recyclersMappedToOrder = dbres.map((item) => ({
        order_id: order.order_id,
        invited_bp_id: item.dataValues.bp_id,
        invited_bp_username: item.dataValues.bp_username,
      }));
      await models.order_invited_business_partner.bulkCreate(recyclersMappedToOrder, { validate: true });
    }
  }

  return order;
};

exports.getOrderWorkflowByStage = async (orderId, processType, processStageSequence) => {
  let workflowData = {};
  const approvals = await models.order_workflow.findOne(
    orderWorkflowQuery(orderId, processType, processStageSequence),
  );
  if (approvals) workflowData = await modifyWorkflowData(approvals);
  return workflowData;
};

exports.getOrderItemAfterQuoteSubmission = async (orderId, bpId) => {
  const quotes = await models.order_quote.findOne({
    where: { order_id: orderId },
    attributes: [['comments', 'QuoteComment'], ['quote_status', 'quoteStatus']],
    include: [
      {
        model: models.business_partner,
        where: { bp_id: bpId },
        as: 'createdByBP',
        attributes: [],
      },
      {
        model: models.model_quote,
        as: 'modelQuotes',
        attributes: [
          ['model_quote_id', 'modelQuoteId'],
          ['item_type', 'itemType'],
          'make',
          'model',
          'price',
          'count',
        ],
      },
    ],
  });
  if (quotes) {
    const quoteOrderData = {
      orderItems: quotes.dataValues.modelQuotes,
      comment: quotes.dataValues.QuoteComment,
      quoteStatus: quotes.dataValues.quoteStatus,
    };
    return quoteOrderData;
  }
  return quotes;
};

exports.updateOrderById = async (orderId, updatePayload) => {
  const promise = models.order.update(
    models.order.attributesAliasesHelper(updatePayload, { method: 'in' }),
    {
      returning: true,
      where: {
        order_id: orderId,
      },
    },
  );
  return promise;
};

exports.checkOrderExits = async (orderId, userId) => {
  const order = await models.order.findOne({ where: { order_id: orderId, created_by: userId } });
  if (order != null) return true;
  return false;
};

exports.checkOrderInvitaionExits = async (orderId, userId) => {
  const orderInvitation = await models.order_invited_business_partner.findOne(
    { where: { order_id: orderId, invited_bp_id: userId } },
  );
  if (orderInvitation != null) return true;
  return false;
};

exports.checkOrderApproverExists = async (orderId, approverId) => {
  const orderWorkflowApprover = await models.order.findOne({
    where: { order_id: orderId },
    includes: [{
      model: models.order_workflow,
      as: 'order_workflows',
      required: true,
      include: [{
        model: models.order_workflow_approver,
        as: 'order_workflow_approvers',
        include: [{
          model: models.workflow_approver,
          as: 'workflow_approver',
          where: { approver_id: approverId },
        }],
      }],
    }],
  });
  if (orderWorkflowApprover != null) return true;
  return false;
};

exports.getOrderTypeForOrderId = async (orderId) => {
  const order = await models.order.findOne({ where: { order_id: orderId }, attributes: [['order_type', 'orderType']] });
  if (order) return order.dataValues.orderType;
  return false;
};

exports.getAllOrderTypes = async () => {
  const orderTypes = await models.process_type.findAll({
    attributes: models.process_type.attributesAliasesHelper(['processTypeName', 'processTypeId']),
  });
  return orderTypes;
};

exports.createOrderTypes = async (processTypes) => {
  const dbRes = await Promise.all(
    processTypes.map(async (processType) => {
      const { processTypeName, processTypeId } = processType;
      await models.process_type.create(
        models.process_type.attributesAliasesHelper({
          processTypeId,
          processTypeName,
        }, { method: 'in ', allowNewFields: false }),
      );
    }),
  );
  return dbRes;
};

exports.getRecycleOrderItemsForRP = async (userId, orderId) => {
  const orderQuote = await models.order_quote.findOne({
    where: { order_id: orderId, created_by: userId },
    attributes: [
      ['id', 'orderQuoteId'],
      ['recycle_price_per_kg', 'pricePerKg'],
      ['comments', 'quoteComments'],
      ['quote_status', 'quoteStatus'],
    ],
    include: [
      {
        model: models.order_quote_item,
        as: 'orderItemQuotes',
        attributes: [
          ['id', 'orderItemQuoteId'],
          ['recycle_item_unit', 'itemUnit'],
        ],
        include: [
          {
            model: models.order_item,
            as: 'order_item',
            attributes: [['model', 'orderItem']],
          },
        ],
      },
    ],
  });
  let result = {};
  if (orderQuote) {
    const orderQuoteData = orderQuote.dataValues;
    const orderItemsModel = orderQuoteData.orderItemQuotes;
    const orderItems = [];
    orderItemsModel.forEach((orderItem) => {
      orderItems.push({
        orderItemQuoteId: orderItem.dataValues.orderItemQuoteId,
        orderItem: orderItem.dataValues.order_item.dataValues.orderItem,
        itemUnit: orderItem.dataValues.itemUnit,
      });
    });
    result = {
      isInitialQuoteSubmitted: true,
      orderQuoteId: orderQuoteData.orderQuoteId,
      pricePerKg: orderQuoteData.pricePerKg,
      quoteComments: orderQuoteData.quoteComments,
      quoteStatus: orderQuoteData.quoteStatus,
      orderItems,
    };
  } else {
    const orderItems = await models.order_item.findAll({
      where: { order_id: orderId },
      attributes: [
        ['id', 'orderItemId'],
        ['model', 'orderItem'],
      ],
    });
    result = { orderItems, isInitialQuoteSubmitted: false };
  }
  return result;
};

exports.getLogisticsData = async (orderId) => {
  const order = await models.order.findOne({
    where: { order_id: orderId },
    attributes: models.order.attributesAliasesHelper([
      'orderId',
      'vehicleType',
      'vehicleNumber',
      'driverName',
      'logisticProvider',
      'recyclerContactName',
      'recyclerContactNumber',
    ]),
  });

  if (
    order.dataValues.vehicleType === null
    || order.dataValues.vehicleNumber === null
    || order.dataValues.driverName === null
  ) {
    order.dataValues.isLogisticDataSubmitted = false;
  } else {
    order.dataValues.isLogisticDataSubmitted = true;
  }
  return order;
};

exports.getOrderNotificationData = async (orderId, userId) => {
  const recyclerWithQuote = await quotationRepo.getAcceptedQuoteForOrder(
    orderId
  );
  const recyclerId =
    recyclerWithQuote?.dataValues?.createdByBP?.dataValues?.recyclerId;
  const order = await this.getOrder(orderId, ['quoteId']);
  const greenPartner = await models.business_partner.findOne({
    where: { bp_id: userId },
    attributes: [['bp_username', 'greenPartnerName']],
  });
  const recycler = await models.business_partner.findOne({
    where: { bp_id: recyclerId },
    attributes: [['bp_email_id', 'recyclerEmail']],
  });
  const orderNumber = order?.dataValues?.order_no;
  return {
    orderNo: orderNumber,
    recyclerDetail: recycler?.dataValues?.recyclerEmail,
    greenPartnerDetail: greenPartner?.dataValues?.greenPartnerName,
  };
};
