import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { Wizard, WizardStep, Input } from '@ui5/webcomponents-react';
import Workflow from '../account/Workflow';

const WorkflowWizard = ({ steps, processTypeId, onNextClick, onChangeSelection }) => {
    useEffect(() => {
        const dom = document.querySelectorAll('ui5-wizard');
        const recycleWorkflowDOM = dom[0].shadowRoot;
        const refurbishWorkflowDOM = dom[1].shadowRoot;
        const recyclestyle = document.createElement('style');
        const refurbishstyle = document.createElement('style');
        recyclestyle.innerHTML = '.ui5-wiz-content { overflow: hidden !important; background: none !important }';
        refurbishstyle.innerHTML = '.ui5-wiz-content { overflow: hidden !important; background: none !important }';
        refurbishWorkflowDOM.appendChild(refurbishstyle);
        recycleWorkflowDOM.appendChild(recyclestyle);
    });
    return (
        <Wizard style={{ height: '400px', overflow: 'hidden' }} onStepChange={(e) => onChangeSelection(e)}>
            {Object.keys(steps).map((idx) => (
                <WizardStep
                    branching
                    ref={{
                        current: '[Circular]'
                    }}
                    titleText={steps[idx].name}
                    selected={steps[idx].selected}
                    disabled={steps[idx].disabled}
                    key={idx}
                >
                    <>
                        <Input
                            style={{
                                position: 'fixed',
                                top: 0,
                                left: 0,
                                opacity: 0
                            }}
                        />
                        <div
                            style={{
                                width: '100%',
                                height: '400px',
                                position: 'absolute',
                                top: 0,
                                left: 0,
                                zIndex: 9,
                                margin: '20px'
                            }}
                        >
                            {steps[idx].selected && (
                                <Workflow
                                    toDislay={steps[idx].selected ? 'inherit' : 'hidden'}
                                    approvers={steps[idx].approvers}
                                    processTypeId={processTypeId}
                                    processStageName={steps[idx].name}
                                    processStageSequence={idx}
                                    showTable={steps[idx].showTable}
                                    workflowId={steps[idx].workflowId}
                                />
                            )}
                        </div>
                    </>
                </WizardStep>
            ))}
        </Wizard>
    );
};

WorkflowWizard.propTypes = {
    steps: PropTypes.object,
    processTypeId: PropTypes.oneOf(['1', '2']),
    onNextClick: PropTypes.func.isRequired,
    onChangeSelection: PropTypes.func
};

WorkflowWizard.defaultProps = {
    steps: {}
};

export default WorkflowWizard;
