import { createStore, applyMiddleware, combineReducers } from 'redux';
import thunk from 'redux-thunk';
import promise from 'redux-promise-middleware';
import { composeWithDevTools } from 'redux-devtools-extension';
import userInfo from './reducer/loginReducer';
import isLoading from './reducer/loadingReducer';
import location from './reducer/locationReducer';
import messageToaster from './reducer/messageReducer';
import notification from './reducer/notificationReducer';
import documents from './reducer/documentsReducer';
// Account
import businessInfo from './reducer/account/businessInfoReducer';
import networkInfo from './reducer/account/networkInfoReducer';
import approverInfo from './reducer/account/approverInfoReducer';
import workflowInfo from './reducer/account/workflowInfoReducer';
// Quote
import orderItemQuotation from './reducer/quotation/orderItemQuoteReducer';
import orderQuotation from './reducer/quotation/orderQuoteReducer';
import quoteEvents from './reducer/quotation/quoteEventsReducer';
// Order
import category from './reducer/order/categoryReducer';
import consolidatedOrderItem from './reducer/order/consolidatedOrderItemReducer';
import privateNetworkOwner from './reducer/order/networkOwnerReducer';
import approver from './reducer/order/orderApproverReducer';
import orderEvents from './reducer/order/orderEventsReducer';
import orderItem from './reducer/order/orderItemReducer';
import orderList from './reducer/order/orderListReducer';
import onSiteVisitDetails from './reducer/order/orderOnsiteVisitReducer';
import orderType from './reducer/order/orderTypeReducer';
import previewOrderItemInfo from './reducer/order/previewOrderDataReducer';
import subCategory from './reducer/order/subCategoryReducer';

const accountReducer = {
    businessInfo,
    networkInfo,
    approverInfo,
    workflowInfo
};

const quoteReducer = {
    orderItemQuotation,
    orderQuotation,
    quoteEvents
};

const orderReducer = {
    category,
    consolidatedOrderItem,
    privateNetworkOwner,
    approver,
    orderEvents,
    orderItem,
    orderList,
    onSiteVisitDetails,
    orderType,
    previewOrderItemInfo,
    subCategory
};

const reducers = {
    account: combineReducers(accountReducer),
    location,
    userInfo,
    isLoading,
    order: combineReducers(orderReducer),
    quote: combineReducers(quoteReducer),
    toast: messageToaster,
    notification,
    documents
};

const rootReducer = combineReducers(reducers);

export const store = createStore(rootReducer, composeWithDevTools(applyMiddleware(...[thunk, promise])));
