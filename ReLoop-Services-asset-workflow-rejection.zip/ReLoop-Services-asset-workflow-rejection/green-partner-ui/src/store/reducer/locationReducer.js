import { ActionType } from 'redux-promise-middleware';
import { FETCH_STATES_INFO, FETCH_CITIES_INFO, FETCH_INDUSTRY_INFO } from '../actionType';

const initialState = {
    states: [],
    cities: [],
    industry: []
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_STATES_INFO}_${ActionType.Fulfilled}`:
            return { ...state, states: payload.data };

        case `${FETCH_CITIES_INFO}_${ActionType.Fulfilled}`:
            return { ...state, cities: payload.data };

        case FETCH_INDUSTRY_INFO:
            return { ...state, industry: payload };

        default:
            return state;
    }
};
