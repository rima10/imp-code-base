import { ActionType } from 'redux-promise-middleware';
import {
    FETCH_ORDER_DOCUMENTS,
    ORDER_DOCUMENTS_LOADING,
    ORDER_DOCUMENTS_FAILED,
    ORDER_DOCUMENTS_LOADED
} from '../actionType';

const initialState = {
    isLoading: true,
    errMsg: null,
    data: []
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_ORDER_DOCUMENTS}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${FETCH_ORDER_DOCUMENTS}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: payload.data };

        case `${FETCH_ORDER_DOCUMENTS}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: [] };

        case ORDER_DOCUMENTS_LOADING:
            return { ...state, isLoading: true, errMsg: null };

        case ORDER_DOCUMENTS_LOADED:
            return { ...state, isLoading: false, errMsg: null };

        case ORDER_DOCUMENTS_FAILED:
            return { ...state, isLoading: true, errMsg: payload };

        default:
            return state;
    }
};
