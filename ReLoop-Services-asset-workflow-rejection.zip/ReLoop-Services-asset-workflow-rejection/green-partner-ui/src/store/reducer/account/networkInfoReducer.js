import { ActionType } from 'redux-promise-middleware';
import {
    FETCH_BP_NETWORK_INFO,
    CREATE_BP_NETWORK_INFO,
    DELETE_BP_NETWORK_INFO,
    FETCH_NETWORK_RECYCLERS
} from '../../actionType';

const initialState = {
    isLoading: false,
    errMsg: null,
    data: []
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_BP_NETWORK_INFO}_${ActionType.Pending}`:
        case `${CREATE_BP_NETWORK_INFO}_${ActionType.Pending}`:
        case `${DELETE_BP_NETWORK_INFO}_${ActionType.Pending}`:
        case `${FETCH_NETWORK_RECYCLERS}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${FETCH_BP_NETWORK_INFO}_${ActionType.Fulfilled}`:
        case `${FETCH_NETWORK_RECYCLERS}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: payload.data };

        case `${FETCH_BP_NETWORK_INFO}_${ActionType.Rejected}`:
        case `${FETCH_NETWORK_RECYCLERS}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: [] };

        case `${CREATE_BP_NETWORK_INFO}_${ActionType.Rejected}`:
        case `${DELETE_BP_NETWORK_INFO}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload };

        default:
            return state;
    }
};
