import { ActionType } from 'redux-promise-middleware';
import { FETCH_RECYCLE_ORDER_QUOTATION, FETCH_REFURBISH_ORDER_QUOTATION } from '../../actionType';

const initialState = {
    isLoading: true,
    errMsg: null,
    data: {}
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_RECYCLE_ORDER_QUOTATION}_${ActionType.Pending}`:
        case `${FETCH_REFURBISH_ORDER_QUOTATION}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${FETCH_RECYCLE_ORDER_QUOTATION}_${ActionType.Fulfilled}`:
        case `${FETCH_REFURBISH_ORDER_QUOTATION}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: payload.data };

        case `${FETCH_RECYCLE_ORDER_QUOTATION}_${ActionType.Rejected}`:
        case `${FETCH_REFURBISH_ORDER_QUOTATION}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: {} };

        default:
            return state;
    }
};
