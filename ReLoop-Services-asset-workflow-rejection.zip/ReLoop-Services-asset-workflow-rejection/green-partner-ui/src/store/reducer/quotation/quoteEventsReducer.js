import { ActionType } from 'redux-promise-middleware';
import { TEMPORARY_ACCEPT_QUOTE, REJECT_QUOTE, ACCEPT_QUOTE } from '../../actionType';

const initialState = {
    isLoading: false
};

export default (state = initialState, action) => {
    const { type } = action;
    switch (type) {
        case `${TEMPORARY_ACCEPT_QUOTE}_${ActionType.Pending}`:
        case `${REJECT_QUOTE}_${ActionType.Pending}`:
        case `${ACCEPT_QUOTE}_${ActionType.Pending}`:
            return { ...state, isLoading: true };

        case `${TEMPORARY_ACCEPT_QUOTE}_${ActionType.Fulfilled}`:
        case `${REJECT_QUOTE}_${ActionType.Fulfilled}`:
        case `${ACCEPT_QUOTE}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false };

        case `${TEMPORARY_ACCEPT_QUOTE}_${ActionType.Rejected}`:
        case `${REJECT_QUOTE}_${ActionType.Rejected}`:
        case `${ACCEPT_QUOTE}_${ActionType.Rejected}`:
            return { ...state, isLoading: false };

        default:
            return state;
    }
};
