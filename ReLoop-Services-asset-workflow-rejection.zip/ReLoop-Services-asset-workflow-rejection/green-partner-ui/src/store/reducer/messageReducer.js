import { ActionType } from 'redux-promise-middleware';
import {
    SHOW_MSG_TOASTER,
    HIDE_MSG_TOASTER,
    FETCH_BP_BUSINESS_INFO,
    UPDATE_BP_BUSINESS_INFO,
    FETCH_BP_NETWORK_INFO,
    CREATE_BP_NETWORK_INFO,
    DELETE_BP_NETWORK_INFO,
    FETCH_BP_APPROVER_INFO,
    CREATE_BP_APPROVER_INFO,
    DELETE_BP_APPROVER_INFO,
    FETCH_BP_WORKFLOW_INFO,
    CREATE_BP_WORKFLOW_INFO,
    DELETE_BP_WORKFLOW_INFO,
    DELETE_BP_WORKFLOW_APPROVER_INFO,
    FETCH_STATES_INFO,
    FETCH_CITIES_INFO,
    FETCH_NOTIFICATIONS,
    READ_NOTIFICATION,
    FETCH_ORDER_LIST,
    FETCH_REFURBISH_ORDER_INFO,
    FETCH_RECYCLE_ORDER_INFO,
    FETCH_CONSOLIDATED_ORDER_INFO,
    FETCH_RECYCLE_ORDER_QUOTATION,
    FETCH_REFURBISH_ORDER_QUOTATION,
    TEMPORARY_ACCEPT_QUOTE,
    REJECT_QUOTE,
    ACCEPT_QUOTE,
    FETCH_APPROVER,
    FETCH_ONSITE_VISIT_INFO,
    FETCH_REFURBISH_ITEM_LEVEL_QUOTE,
    FETCH_RECYCLE_ITEM_LEVEL_QUOTE,
    FETCH_ORDER_DOCUMENTS,
    UPLOAD_DOCUMENT,
    SCHEDULE_LOGISTICS,
    CREATE_ORDER_WORKFLOW,
    CREATE_ORDER,
    CREATE_DRAFT_ORDER,
    FETCH_ORDER_TYPE,
    FETCH_CATEGORY,
    FETCH_SUB_CATEGORY,
    FETCH_NETWORK_RECYCLERS,
    FETCH_NETWORK_OWNER
} from '../actionType';
import StatusColor from '../../asset/constants/statusColor';

const initialState = {
    show: false,
    status: 'Information',
    message: ''
};

const messageToaster = (state = initialState, action) => {
    const { type, payload } = action;

    switch (type) {
        case SHOW_MSG_TOASTER: {
            return {
                ...state,
                message: payload.message,
                status: payload.status,
                show: true
            };
        }

        case HIDE_MSG_TOASTER: {
            return {
                ...initialState
            };
        }

        case `${FETCH_BP_BUSINESS_INFO}_${ActionType.Rejected}`:
        case `${UPDATE_BP_BUSINESS_INFO}_${ActionType.Rejected}`:
        case `${FETCH_BP_NETWORK_INFO}_${ActionType.Rejected}`:
        case `${CREATE_BP_NETWORK_INFO}_${ActionType.Rejected}`:
        case `${DELETE_BP_NETWORK_INFO}_${ActionType.Rejected}`:
        case `${FETCH_BP_APPROVER_INFO}_${ActionType.Rejected}`:
        case `${CREATE_BP_APPROVER_INFO}_${ActionType.Rejected}`:
        case `${DELETE_BP_APPROVER_INFO}_${ActionType.Rejected}`:
        case `${FETCH_BP_WORKFLOW_INFO}_${ActionType.Rejected}`:
        case `${CREATE_BP_WORKFLOW_INFO}_${ActionType.Rejected}`:
        case `${DELETE_BP_WORKFLOW_INFO}_${ActionType.Rejected}`:
        case `${DELETE_BP_WORKFLOW_APPROVER_INFO}_${ActionType.Rejected}`:
        case `${FETCH_STATES_INFO}_${ActionType.Rejected}`:
        case `${FETCH_CITIES_INFO}_${ActionType.Rejected}`:
        case `${FETCH_NOTIFICATIONS}_${ActionType.Rejected}`:
        case `${READ_NOTIFICATION}_${ActionType.Rejected}`:
        case `${FETCH_ORDER_LIST}_${ActionType.Rejected}`:
        case `${FETCH_REFURBISH_ORDER_INFO}_${ActionType.Rejected}`:
        case `${FETCH_RECYCLE_ORDER_INFO}_${ActionType.Rejected}`:
        case `${FETCH_CONSOLIDATED_ORDER_INFO}_${ActionType.Rejected}`:
        case `${FETCH_RECYCLE_ORDER_QUOTATION}_${ActionType.Rejected}`:
        case `${FETCH_REFURBISH_ORDER_QUOTATION}_${ActionType.Rejected}`:
        case `${TEMPORARY_ACCEPT_QUOTE}_${ActionType.Rejected}`:
        case `${REJECT_QUOTE}_${ActionType.Rejected}`:
        case `${ACCEPT_QUOTE}_${ActionType.Rejected}`:
        case `${FETCH_APPROVER}_${ActionType.Rejected}`:
        case `${FETCH_ONSITE_VISIT_INFO}_${ActionType.Rejected}`:
        case `${FETCH_REFURBISH_ITEM_LEVEL_QUOTE}_${ActionType.Rejected}`:
        case `${FETCH_RECYCLE_ITEM_LEVEL_QUOTE}_${ActionType.Rejected}`:
        case `${FETCH_ORDER_DOCUMENTS}_${ActionType.Rejected}`:
        case `${UPLOAD_DOCUMENT}_${ActionType.Rejected}`:
        case `${SCHEDULE_LOGISTICS}_${ActionType.Rejected}`:
        case `${CREATE_ORDER_WORKFLOW}_${ActionType.Rejected}`:
        case `${CREATE_ORDER}_${ActionType.Rejected}`:
        case `${CREATE_DRAFT_ORDER}_${ActionType.Rejected}`:
        case `${FETCH_ORDER_TYPE}_${ActionType.Rejected}`:
        case `${FETCH_CATEGORY}_${ActionType.Rejected}`:
        case `${FETCH_SUB_CATEGORY}_${ActionType.Rejected}`:
        case `${FETCH_NETWORK_RECYCLERS}_${ActionType.Rejected}`:
        case `${FETCH_NETWORK_OWNER}_${ActionType.Rejected}`: {
            return {
                ...state,
                // optional chaining checks
                message: payload?.response?.data?.error?.message ?? 'Something went wrong',
                status: StatusColor.Negative,
                show: true
            };
        }

        default: {
            return state;
        }
    }
};

export default messageToaster;
