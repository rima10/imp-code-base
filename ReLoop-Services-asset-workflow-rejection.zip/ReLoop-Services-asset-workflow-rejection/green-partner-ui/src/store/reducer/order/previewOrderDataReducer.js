import { SET_PREVIEW_ORDER_ITEM_INFO, CLEAR_PREVIEW_ORDER_ITEMS } from '../../actionType';

const initialState = {
    data: []
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case SET_PREVIEW_ORDER_ITEM_INFO:
            return { ...state, data: payload };

        case CLEAR_PREVIEW_ORDER_ITEMS:
            return { ...state, data: [] };

        default:
            return state;
    }
};
