import { ActionType } from 'redux-promise-middleware';
import {
    UPLOAD_DOCUMENT,
    SCHEDULE_LOGISTICS,
    CREATE_ORDER_WORKFLOW,
    CREATE_ORDER,
    CREATE_DRAFT_ORDER
} from '../../actionType';

const initialState = {
    isLoading: false
};

export default (state = initialState, action) => {
    const { type } = action;
    switch (type) {
        case `${UPLOAD_DOCUMENT}_${ActionType.Pending}`:
        case `${SCHEDULE_LOGISTICS}_${ActionType.Pending}`:
        case `${CREATE_ORDER_WORKFLOW}_${ActionType.Pending}`:
        case `${CREATE_ORDER}_${ActionType.Pending}`:
        case `${CREATE_DRAFT_ORDER}_${ActionType.Pending}`:
            return { ...state, isLoading: true };

        case `${UPLOAD_DOCUMENT}_${ActionType.Fulfilled}`:
        case `${SCHEDULE_LOGISTICS}_${ActionType.Fulfilled}`:
        case `${CREATE_ORDER_WORKFLOW}_${ActionType.Fulfilled}`:
        case `${CREATE_ORDER}_${ActionType.Fulfilled}`:
        case `${CREATE_DRAFT_ORDER}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false };

        case `${UPLOAD_DOCUMENT}_${ActionType.Rejected}`:
        case `${SCHEDULE_LOGISTICS}_${ActionType.Rejected}`:
        case `${CREATE_ORDER_WORKFLOW}_${ActionType.Rejected}`:
        case `${CREATE_ORDER}_${ActionType.Rejected}`:
        case `${CREATE_DRAFT_ORDER}_${ActionType.Rejected}`:
            return { ...state, isLoading: false };

        default:
            return state;
    }
};
