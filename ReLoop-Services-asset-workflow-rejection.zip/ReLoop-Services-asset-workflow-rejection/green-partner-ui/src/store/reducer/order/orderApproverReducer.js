import { ActionType } from 'redux-promise-middleware';
import { FETCH_APPROVER } from '../../actionType';

const initialState = {
    isLoading: false,
    errMsg: null,
    data: { 1: [], 3: [], 5: [] }
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_APPROVER}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${FETCH_APPROVER}_${ActionType.Fulfilled}`: {
            const approvers = payload.data.workflowApprovers || [];
            const { processStageSequence } = payload.data;
            const approverObj = { ...state.data };
            approverObj[processStageSequence] = approvers;
            return { ...state, isLoading: false, errMsg: null, data: approverObj };
        }

        case `${FETCH_APPROVER}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: { 1: [], 3: [], 5: [] } };

        default:
            return state;
    }
};
