import { ActionType } from 'redux-promise-middleware';
import {
    FETCH_REFURBISH_ORDER_INFO,
    FETCH_RECYCLE_ORDER_INFO,
    SET_UPDATED_ORDER_ITEMS,
    SET_UPDATED_ORDER_HEADER_DATA
} from '../../actionType';

const initialState = {
    isLoading: true,
    errMsg: null,
    data: {}
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_REFURBISH_ORDER_INFO}_${ActionType.Pending}`:
        case `${FETCH_RECYCLE_ORDER_INFO}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${FETCH_REFURBISH_ORDER_INFO}_${ActionType.Fulfilled}`:
        case `${FETCH_RECYCLE_ORDER_INFO}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: payload.data };

        case `${FETCH_REFURBISH_ORDER_INFO}_${ActionType.Rejected}`:
        case `${FETCH_RECYCLE_ORDER_INFO}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: {} };

        case SET_UPDATED_ORDER_ITEMS:
            if (state.data && state.data.orderItems) {
                state.data.orderItems = payload;
            }
            return { ...state };

        case SET_UPDATED_ORDER_HEADER_DATA:
            return { ...state, data: payload };

        default:
            return state;
    }
};
