// User Info Related Action Types
export const SET_USER_INFO = 'SET_USER_INFO';
export const setUserInfo = (userInfo, isLoggedIn, csrf) => ({
    type: SET_USER_INFO,
    payload: { userInfo, isLoggedIn, csrf }
});

export const SET_LOAD_IN_PROGRESS = 'SET_LOAD_IN_PROGRESS';
export const loadInProgress = () => ({
    type: SET_LOAD_IN_PROGRESS
});

export const SET_LOAD_COMPLETED = 'SET_LOAD_COMPLETED';
export const loadCompleted = () => ({
    type: SET_LOAD_COMPLETED
});

// Message Toast Related Action Types
export const SHOW_MSG_TOASTER = 'SHOW_MSG_TOASTER';
export const HIDE_MSG_TOASTER = 'HIDE_MSG_TOASTER';

// Location Info Related Action Types
export const FETCH_STATES_INFO = 'FETCH_STATES_INFO';
export const FETCH_CITIES_INFO = 'FETCH_CITIES_INFO';
export const FETCH_INDUSTRY_INFO = 'FETCH_INDUSTRY_INFO';

export const setIndustryInfo = (industryInfo) => ({
    type: FETCH_INDUSTRY_INFO,
    payload: industryInfo
});

// Business Info Related Action Types
export const FETCH_BP_BUSINESS_INFO = 'FETCH_BP_BUSINESS_INFO';
export const UPDATE_BP_BUSINESS_INFO = 'UPDATE_BP_BUSINESS_INFO';

// Private Network Info Related Action Types
export const FETCH_BP_NETWORK_INFO = 'FETCH_BP_NETWORK_INFO';
export const CREATE_BP_NETWORK_INFO = 'CREATE_BP_NETWORK_INFO';
export const DELETE_BP_NETWORK_INFO = 'DELETE_BP_NETWORK_INFO';

// Approver Info Related Action Types
export const FETCH_BP_APPROVER_INFO = 'FETCH_BP_APPROVER_INFO';
export const CREATE_BP_APPROVER_INFO = 'CREATE_BP_APPROVER_INFO';
export const DELETE_BP_APPROVER_INFO = 'DELETE_BP_APPROVER_INFO';

// Workflow Info Related Action Types
export const FETCH_BP_WORKFLOW_INFO = 'FETCH_BP_WORKFLOW_INFO';
export const CREATE_BP_WORKFLOW_INFO = 'CREATE_BP_WORKFLOW_INFO';
export const DELETE_BP_WORKFLOW_INFO = 'DELETE_BP_WORKFLOW_INFO';
export const DELETE_BP_WORKFLOW_APPROVER_INFO = 'DELETE_BP_WORKFLOW_APPROVER_INFO';

// Notification Related Action Types
export const FETCH_NOTIFICATIONS = 'FETCH_NOTIFICATIONS';
export const READ_NOTIFICATION = 'READ_NOTIFICATION';

// Order Related Action Types
export const FETCH_ORDER_LIST = 'FETCH_ORDER_LIST';
export const FETCH_REFURBISH_ORDER_INFO = 'FETCH_REFURBISH_ORDER_INFO';
export const FETCH_RECYCLE_ORDER_INFO = 'FETCH_RECYCLE_ORDER_INFO';
export const FETCH_CONSOLIDATED_ORDER_INFO = 'FETCH_CONSOLIDATED_ORDER_INFO';
export const FETCH_APPROVER = 'FETCH_APPROVER';
export const FETCH_ONSITE_VISIT_INFO = 'FETCH_ONSITE_VISIT_INFO';
export const FETCH_REFURBISH_ITEM_LEVEL_QUOTE = 'FETCH_REFURBISH_ITEM_LEVEL_QUOTE';
export const FETCH_RECYCLE_ITEM_LEVEL_QUOTE = 'FETCH_RECYCLE_ITEM_LEVEL_QUOTE';
export const FETCH_ORDER_DOCUMENTS = 'FETCH_ORDER_DOCUMENTS';
export const UPLOAD_DOCUMENT = 'UPLOAD_DOCUMENT';
export const SCHEDULE_LOGISTICS = 'SCHEDULE_LOGISTICS';
export const CREATE_ORDER_WORKFLOW = 'CREATE_ORDER_WORKFLOW';
export const CREATE_ORDER = 'CREATE_ORDER';
export const CREATE_DRAFT_ORDER = 'CREATE_DRAFT_ORDER';
export const FETCH_ORDER_TYPE = 'FETCH_ORDER_TYPE';
export const FETCH_CATEGORY = 'FETCH_CATEGORY';
export const FETCH_SUB_CATEGORY = 'FETCH_SUB_CATEGORY';
export const FETCH_NETWORK_RECYCLERS = 'FETCH_NETWORK_RECYCLERS';
export const FETCH_NETWORK_OWNER = 'FETCH_NETWORK_OWNER';

// Quote Related Action Types
export const FETCH_RECYCLE_ORDER_QUOTATION = 'FETCH_RECYCLE_ORDER_QUOTATION';
export const FETCH_REFURBISH_ORDER_QUOTATION = 'FETCH_REFURBISH_ORDER_QUOTATION';
export const TEMPORARY_ACCEPT_QUOTE = 'TEMPORARY_ACCEPT_QUOTE';
export const REJECT_QUOTE = 'REJECT_QUOTE';
export const ACCEPT_QUOTE = 'ACCEPT_QUOTE';

export const CLEAR_PREVIEW_ORDER_ITEMS = 'CLEAR_PREVIEW_ORDER_ITEMS';
export const SET_PREVIEW_ORDER_ITEM_INFO = 'SET_PREVIEW_ORDER_ITEM_INFO';

export const clearPreviewOrderItems = () => ({
    type: CLEAR_PREVIEW_ORDER_ITEMS
});

export const setPreviewOrderItemInfo = (previewOrderItemInfo) => ({
    type: SET_PREVIEW_ORDER_ITEM_INFO,
    payload: previewOrderItemInfo
});

export const ORDER_DOCUMENTS_LOADING = 'ORDER_DOCUMENTS_LOADING';
export const ORDER_DOCUMENTS_FAILED = 'ORDER_DOCUMENTS_FAILED';
export const ORDER_DOCUMENTS_LOADED = 'ORDER_DOCUMENTS_LOADED';

export const orderDocumentsLoading = () => ({
    type: ORDER_DOCUMENTS_LOADING
});

export const orderDocumentsFailed = (errMsg) => ({
    type: ORDER_DOCUMENTS_FAILED,
    payload: errMsg
});

export const orderDocumentsLoaded = () => ({
    type: ORDER_DOCUMENTS_LOADED
});

export const SET_UPDATED_ORDER_ITEMS = 'SET_UPDATED_ORDER_ITEMS';
export const setOrderItems = (data) => ({
    type: SET_UPDATED_ORDER_ITEMS,
    payload: data
});

export const SET_UPDATED_ORDER_HEADER_DATA = 'SET_UPDATED_ORDER_HEADER_DATA';
export const setOrderHeaderData = (data) => ({
    type: SET_UPDATED_ORDER_HEADER_DATA,
    payload: data
});
