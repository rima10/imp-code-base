import { showMessage } from './toast';
import {
    FETCH_RECYCLE_ORDER_QUOTATION,
    FETCH_REFURBISH_ORDER_QUOTATION,
    TEMPORARY_ACCEPT_QUOTE,
    REJECT_QUOTE,
    ACCEPT_QUOTE,
    FETCH_REFURBISH_ITEM_LEVEL_QUOTE,
    FETCH_RECYCLE_ITEM_LEVEL_QUOTE
} from '../actionType';
import http from '../../utils/httpService';
import StatusColor from '../../asset/constants/statusColor';
import { setMoveToNextStep } from './order';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

export const getRecycleOrderQuotation = (orderId) => async (dispatch) => {
    dispatch({
        type: FETCH_RECYCLE_ORDER_QUOTATION,
        payload: http.get(`${API_BASE_URL}order/quotation/recycle/initial/${orderId}`, {
            withCredentials: true
        })
    });
};

export const getRefurbishOrderQuotation = (orderId) => async (dispatch) => {
    dispatch({
        type: FETCH_REFURBISH_ORDER_QUOTATION,
        payload: http.get(`${API_BASE_URL}order/quotation/refurbish/initial/${orderId}`, {
            withCredentials: true
        })
    });
};

export const temporaryAcceptQuote = (orderId, quoteId, orderType) => async (dispatch) => {
    await dispatch({
        type: TEMPORARY_ACCEPT_QUOTE,
        payload: http.post(
            `${API_BASE_URL}order/quotation/temporaryAcceptQuote/${orderId}/${quoteId}`,
            {},
            {
                withCredentials: true
            }
        )
    });
    if (orderType === '1') {
        dispatch(getRefurbishOrderQuotation(orderId));
    } else {
        dispatch(getRecycleOrderQuotation(orderId));
    }
    dispatch(showMessage({ message: 'Successfully accepted the quote', status: StatusColor.Positive }));
};

export const rejectQuote = (orderId, quoteId, orderType) => async (dispatch) => {
    await dispatch({
        type: REJECT_QUOTE,
        payload: http.post(
            `${API_BASE_URL}order/quotation/rejectQuote/${orderId}/${quoteId}`,
            {},
            {
                withCredentials: true
            }
        )
    });
    if (orderType === '1') {
        dispatch(getRefurbishOrderQuotation(orderId));
    } else {
        dispatch(getRecycleOrderQuotation(orderId));
    }
    dispatch(showMessage({ message: 'Successfully rejected the quote', status: StatusColor.Positive }));
};

export const acceptQuote = (orderId, payload, orderType) => async (dispatch) => {
    await dispatch({
        type: ACCEPT_QUOTE,
        payload: http.post(`${API_BASE_URL}order/quotation/acceptQuote/${orderId}`, payload, {
            withCredentials: true
        })
    });
    if (orderType === '1') {
        dispatch(getRefurbishOrderQuotation(orderId));
    } else {
        dispatch(getRecycleOrderQuotation(orderId));
    }
    dispatch(setMoveToNextStep(orderId, '4', orderType));
    dispatch(showMessage({ message: 'Successfully accepted the quote', status: StatusColor.Positive }));
};

export const getRefurbishOrderItemLevelQuote = (orderId, quoteId) => async (dispatch) => {
    dispatch({
        type: FETCH_REFURBISH_ITEM_LEVEL_QUOTE,
        payload: http.get(`${API_BASE_URL}order/quotation/refurbish/grading/${orderId}/${quoteId}`, {
            withCredentials: true
        })
    });
};

export const getRecycleOrderItemLevelQuote = (orderId) => async (dispatch) => {
    dispatch({
        type: FETCH_RECYCLE_ITEM_LEVEL_QUOTE,
        payload: http.get(`${API_BASE_URL}order/quotation/recycle/final/${orderId}`, {
            withCredentials: true
        })
    });
};
