import {
    FETCH_BP_BUSINESS_INFO,
    UPDATE_BP_BUSINESS_INFO,
    FETCH_BP_NETWORK_INFO,
    CREATE_BP_NETWORK_INFO,
    DELETE_BP_NETWORK_INFO,
    FETCH_BP_APPROVER_INFO,
    CREATE_BP_APPROVER_INFO,
    DELETE_BP_APPROVER_INFO,
    FETCH_BP_WORKFLOW_INFO,
    CREATE_BP_WORKFLOW_INFO,
    DELETE_BP_WORKFLOW_INFO,
    DELETE_BP_WORKFLOW_APPROVER_INFO
} from '../actionType';
import { showMessage } from './toast';
import http from '../../utils/httpService';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

// Business Info Action Creators
// Action Creator to Get Business Information
export const getBusinessInfo = () => async (dispatch) => {
    dispatch({
        type: FETCH_BP_BUSINESS_INFO,
        payload: http.get(`${API_BASE_URL}user/`, {
            withCredentials: true
        })
    });
};

// Action Creator to Create OR Update Business Information
export const updateBusinessInfo = (payload) => async (dispatch, getState) => {
    const userId = getState().userInfo.bp_id;
    await dispatch({
        type: UPDATE_BP_BUSINESS_INFO,
        payload: http.patch(`${API_BASE_URL}user/${userId}`, payload, {
            withCredentials: true
        })
    });
    dispatch(getBusinessInfo());
    dispatch(showMessage({ message: 'Updated Business Information', status: 'Positive' }));
};

// Private Network Action Creators
// Action Creator to Get Private Network Information
export const getNetworkInfo = () => async (dispatch) => {
    dispatch({
        type: FETCH_BP_NETWORK_INFO,
        payload: http.get(`${API_BASE_URL}user/privateNetwork`, {
            withCredentials: true
        })
    });
};

// Action Creator to Create Private Network
export const registerBPNetworkInfo = (payload) => async (dispatch) => {
    await dispatch({
        type: CREATE_BP_NETWORK_INFO,
        payload: http.post(`${API_BASE_URL}user/privateNetwork?bp=gp`, payload, {
            withCredentials: true
        })
    });
    dispatch(getNetworkInfo());
    dispatch(showMessage({ message: 'Private Network Added', status: 'Positive' }));
};

// Action Creator to Delete Private Network
export const deleteBPNetworkInfo = (payload) => async (dispatch) => {
    await dispatch({
        type: DELETE_BP_NETWORK_INFO,
        payload: http.delete(`${API_BASE_URL}user/privateNetwork`, {
            data: payload,
            withCredentials: true
        })
    });
    dispatch(getNetworkInfo());
    dispatch(showMessage({ message: 'Private Network Deleted', status: 'Positive' }));
};

// Approver Action Creators
// Action Creator to Get Approver Information
export const getApproverInfo = () => async (dispatch) => {
    dispatch({
        type: FETCH_BP_APPROVER_INFO,
        payload: http.get(`${API_BASE_URL}user/approver/`, {
            withCredentials: true
        })
    });
};

// Action Creator to Create Approver
export const registerBPApproverInfo = (payload) => async (dispatch) => {
    await dispatch({
        type: CREATE_BP_APPROVER_INFO,
        payload: http.post(`${API_BASE_URL}user/approver/`, payload, {
            withCredentials: true
        })
    });
    dispatch(getApproverInfo());
    dispatch(showMessage({ message: 'Successfully Added Approver', status: 'Positive' }));
};

// Action Creator to Delete Approver
export const deleteBPApproverInfo = (payload) => async (dispatch) => {
    await dispatch({
        type: DELETE_BP_APPROVER_INFO,
        payload: http.delete(`${API_BASE_URL}user/approver/`, {
            data: payload,
            withCredentials: true
        })
    });
    dispatch(getApproverInfo());
    dispatch(showMessage({ message: 'Successfully Deleted Approver', status: 'Positive' }));
};

// Workflow Action Creators
// Action Creator to Get Workflow Information
export const getWorkflowsInfo = () => async (dispatch) => {
    dispatch({
        type: FETCH_BP_WORKFLOW_INFO,
        payload: http.get(`${API_BASE_URL}user/workflow/`, {
            withCredentials: true
        })
    });
};

// Action Creator to Create Workflow
export const registerBPWorkflowInfo = (payloadArray) => async (dispatch) => {
    await Promise.all(
        payloadArray.map(async (payload) => {
            await dispatch({
                type: CREATE_BP_WORKFLOW_INFO,
                payload: http.post(`${API_BASE_URL}user/workflow/`, payload, {
                    withCredentials: true
                })
            });
        })
    );
    dispatch(getWorkflowsInfo());
    dispatch(showMessage({ message: 'Successfully Added Workflow', status: 'Positive' }));
};

// Action Creator to Delete Workflow
export const deleteBPWorkflowInfo = (payload) => async (dispatch) => {
    const { workflowId, processTypeId } = payload;
    await dispatch({
        type: DELETE_BP_WORKFLOW_INFO,
        payload: http.delete(`${API_BASE_URL}user/workflow/${workflowId}/${processTypeId}`, {
            withCredentials: true
        })
    });
    dispatch(getWorkflowsInfo());
    dispatch(showMessage({ message: 'Successfully Deleted Workflow', status: 'Positive' }));
};

// Action Creator to Delete Approver from Workflow
export const deleteBPWorkflowApproverInfo = (payload) => async (dispatch) => {
    await dispatch({
        type: DELETE_BP_WORKFLOW_APPROVER_INFO,
        payload: http.delete(`${API_BASE_URL}user/workflow/approver/`, {
            data: payload,
            withCredentials: true
        })
    });
    dispatch(getWorkflowsInfo());
    dispatch(showMessage({ message: 'Successfully Deleted Workflow Approver', status: 'Positive' }));
};
