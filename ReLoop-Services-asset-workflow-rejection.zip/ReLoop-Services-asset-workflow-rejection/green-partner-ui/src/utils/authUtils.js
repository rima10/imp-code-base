import axios from 'axios';

const { REACT_APP_USERPOOLBASEURI, REACT_APP_CLIENTID, REACT_APP_CALLBACKURI, REACT_APPAPI_BASE_URL } = process.env;
export async function validate(accessToken) {
    try {
        const options = {
            method: 'POST',
            withCredentials: true
        };
        if (accessToken) {
            options.headers = {
                authorization: `Bearer ${accessToken}`
            };
        }
        return new Promise((resolve, reject) => {
            axios(`${REACT_APPAPI_BASE_URL}auth/validate`, options)
                .then((response) => {
                    if (response.status === 401) reject(response.statusText);
                    else resolve(response);
                })
                .catch((error) => reject(error));
        });
    } catch (error) {
        return false;
    }
}

export async function getToken() {
    const params = new URL(document.location).searchParams;
    const code = params.get('code');
    const details = {
        grant_type: 'authorization_code',
        client_id: REACT_APP_CLIENTID,
        code,
        redirect_uri: REACT_APP_CALLBACKURI
    };
    let formBody = [];
    for (const property in details) {
        const encodedKey = encodeURIComponent(property);
        const encodedValue = encodeURIComponent(details[property]);
        formBody.push(`${encodedKey}=${encodedValue}`);
    }
    formBody = formBody.join('&');
    return new Promise((resolve, reject) => {
        fetch(`${REACT_APP_USERPOOLBASEURI}/oauth2/token`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
            },
            body: formBody
        })
            .then((response) => response.json())
            .then((response) => {
                resolve({ idToken: response.id_token, refreshToken: response.refresh_token });
            })
            .catch((error) => reject(error));
    });
}
