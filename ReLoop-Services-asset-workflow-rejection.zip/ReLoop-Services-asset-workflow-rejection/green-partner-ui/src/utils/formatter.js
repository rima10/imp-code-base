const camelCaseToSentence = (value) => {
    let camelCaseWord = value;
    camelCaseWord = camelCaseWord.trim();
    const temp = camelCaseWord.replace(/([A-Z])/g, ' $1');
    const sentence = temp.charAt(0).toUpperCase() + temp.slice(1);
    return sentence;
};

export { camelCaseToSentence };
