import {
    validateContactNumber,
    validateGST,
    validateIsEmpty,
    validatePAN,
    validateCompanyCode,
    validatePincode,
    validateCIN
} from './common';

const validateInput = (value, field, fieldConfig) => {
    if (field === 'businessName') {
        return validateIsEmpty(value, field);
    }
    if (field === 'gstin') {
        return validateGST(value);
    }
    if (field === 'pan') {
        return validatePAN(value);
    }
    if (field === 'cin') {
        return validateCIN(value);
    }
    if (field === 'companyCode') {
        return validateCompanyCode(value, fieldConfig.required);
    }
    if (field === 'phoneNumber') {
        return validateContactNumber(value, field);
    }
    if (field === 'address') {
        return validateIsEmpty(value, field);
    }
    if (field === 'pincode') {
        return validatePincode(value);
    }
    return { isValid: true, errorMessage: '' };
};

export default validateInput;
