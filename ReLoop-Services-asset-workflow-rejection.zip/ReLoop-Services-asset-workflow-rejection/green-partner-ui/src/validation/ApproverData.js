import { validateEmail, validateContactNumber, validateIsEmpty } from './common';

const validateInput = (value, field) => {
    if (field === 'emailAddress') {
        return validateEmail(value);
    }
    if (field === 'phoneNumber') {
        return validateContactNumber(value);
    }
    if (field === 'approverRole') {
        return validateIsEmpty(value, field);
    }
    if (field === 'approverName') {
        return validateIsEmpty(value, field);
    }
    return { isValid: true, errorMessage: '' };
};

export default validateInput;
