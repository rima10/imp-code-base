export const getBusinessInfoData = (state) => state.account.businessInfo.data;

export const isBusinessInfoLoading = (state) => state.account.businessInfo.isLoading;

export const getWorkflowData = (state) => state.account.workflowInfo.data;

export const isWorkflowInfoLoading = (state) => state.account.workflowInfo.isLoading;

export const getNetworkInfoData = (state) => state.account.networkInfo.data;

export const isApproverInfoLoading = (state) => state.account.approverInfo.isLoading;

export const isNetworkInfoLoading = (state) => state.account.networkInfo.isLoading;

export const getApproverInfoData = (state) => state.account.approverInfo.data;

export const getIndustryData = (state) => state.location.industry;

export const getStatesData = (state) => state.location.states;

export const getCitiesData = (state) => state.location.cities;

export const getUserData = (state) => state.userInfo;

export const isLoadingData = (state) => state.isLoading;

export const getIsPartOfPvtNwk = (state) => state.userInfo.isPartOfPvtNwk;

export const getToastData = (state) => state.toast;

export const getNotificationData = (state) => state.notification.data;

// Order Related Selectors

export const isOrderListLoading = (state) => state.order.orderList.isLoading;

export const getOrderListData = (state) => state.order.orderList.data;

export const getOrderItemData = (state) => state.order.orderItem.data;

export const isOrderItemLoading = (state) => state.order.orderItem.isLoading;

export const getConsolidatedOrderItemData = (state) => state.order.consolidatedOrderItem.data;

export const isConsolidatedOrderItemLoading = (state) => state.order.consolidatedOrderItem.isLoading;

export const getOrderQuotationData = (state) => state.quote.orderQuotation.data;

export const isOrderQuotationLoading = (state) => state.quote.orderQuotation.isLoading;

export const getOrderItemQuoteData = (state) => state.quote.orderItemQuotation.data;

export const getOnsiteDetailsData = (state) => state.order.onSiteVisitDetails.data;

export const isOnsiteDataLoading = (state) => state.order.onSiteVisitDetails.isLoading;

export const getPreviewOrderItemData = (state) => state.order.previewOrderItemInfo.data;

export const getOrderDocumentData = (state) => state.documents.data;

export const isDocumentLoading = (state) => state.documents.isLoading;

export const getOrderId = (state) => state.order.orderItem.data.orderId;

export const getOrderNo = (state) => state.order.orderItem.data.orderNumber;

export const getOrderCurrentSequence = (state) => state.order.orderItem.data.currentSequence;

export const getGpName = (state) => state.userInfo.bp_username;

export const getOrderItemType = (state) => state.order.orderItem.data.orderType;

export const getRpName = (state) => {
    const quoteData = state.quote.orderQuotation.data?.quotesData.find((quote) => quote.quoteStatus === 'Accepted');
    return quoteData?.name;
};

export const getOrderTypeData = (state) => state.order.orderType.data;

export const getCategoryData = (state) => state.order.category.data;

export const getSubCategoryData = (state) => state.order.subCategory.data;

export const getOrderApproverStep3Data = (state) => state.order.approver.data['3'];

export const getOrderApproverStep5Data = (state) => state.order.approver.data['5'];

export const getQuotesData = (state) => state.quote.orderQuotation.data.quotesData;

export const getPrivateNetworkOwnerData = (state) => state.order.privateNetworkOwner.data;
