import React from 'react';
import PropTypes from 'prop-types';
import { BusyIndicator } from '@ui5/webcomponents-react';

const LoadingIndicator = ({ text }) => (
    <div className="overlay">
        <BusyIndicator
            text={text}
            style={{
                position: 'fixed',
                zIndex: 9999,
                top: '50%',
                left: '50%'
            }}
            active
        />
    </div>
);

LoadingIndicator.propTypes = {
    text: PropTypes.string
};

LoadingIndicator.defaultProps = {
    text: ''
};

export default LoadingIndicator;
