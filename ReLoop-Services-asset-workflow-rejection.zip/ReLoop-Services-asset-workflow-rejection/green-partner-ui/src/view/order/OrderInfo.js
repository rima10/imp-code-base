import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import {
    TabContainer,
    Tab,
    Breadcrumbs,
    BreadcrumbsItem,
    Title,
    Toolbar,
    ToolbarSpacer,
    Button,
    BusyIndicator
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import { useHistory, useParams } from 'react-router-dom';
import {
    getOrderListData,
    getOrderItemData,
    getConsolidatedOrderItemData,
    getOrderQuotationData,
    isOrderItemLoading,
    isConsolidatedOrderItemLoading,
    isOrderQuotationLoading,
    getOrderDocumentData
} from '../../selectors/common';
import {
    getRefurbishOrderItemInfo,
    getConsolidatedOrderItemInfo,
    getRecycleOrderItemInfo,
    getOrderDocuments,
    completeOrder
} from '../../store/action/order';
import { getRecycleOrderQuotation, getRefurbishOrderQuotation } from '../../store/action/quote';
import { showMessage } from '../../store/action/toast';
import OrderDetailsContainer from './orderDetails/Container';
import DocumentContainer from './documentDetails/DocumentContainer';
import LoadingIndicator from '../common/Loading';
import StatusColor from '../../asset/constants/statusColor';

const applyCSS = async () => {
    // Set timeout is used to trigger async job which will be invoked after the components is rendered.
    setTimeout(() => {
        const shadowDOM = document.querySelector('ui5-tabcontainer').shadowRoot;
        const style = document.createElement('style');
        style.innerHTML = '.ui5-tc__headerList { justify-content: space-around !important}';
        shadowDOM.appendChild(style);
        const fontStyle = document.createElement('style');
        fontStyle.innerHTML = '.ui5-tab-strip-item { font-size: var(--sapFontSize) !important;}';
        shadowDOM.appendChild(fontStyle);
    }, 0);
};

const OrderInfo = ({
    orderInfo,
    startGetRefurbishOrderItemInfo,
    startGetRefurbishConsolidatedOrderItemInfo,
    orderItemInfo,
    consolidatedOrderItemInfo,
    orderQuotation,
    startGetRefurbishOrderQuotation,
    isOrderItemInfoLoading,
    isConsolidatedOrderItemInfoLoading,
    isOrderQuotationLoading,
    startGetRecycleOrderItemInfo,
    startGetRecycleOrderQuotation,
    startGetOrderDocumentsInfo,
    orderDocInfo,
    startUpdateAsCompleteOrder,
    startShowMessage
}) => {
    const history = useHistory();
    const { orderNumber } = useParams();

    const onBreadCrumbClick = () => {
        history.push('/order/previousOrder');
    };

    const [orderType, setOrderType] = useState();
    const [orderId, setOrderId] = useState();
    useEffect(() => {
        if (orderInfo && orderInfo.length) {
            const { orderId } = orderInfo.find((order) => order.orderNumber === orderNumber);
            const { orderType } = orderInfo.find((order) => order.orderNumber === orderNumber);
            setOrderId(orderId);
            setOrderType(orderType);

            if (orderType === '1') {
                startGetRefurbishOrderItemInfo(orderId);
                startGetRefurbishConsolidatedOrderItemInfo(orderId);
                startGetRefurbishOrderQuotation(orderId);
            } else {
                startGetRecycleOrderItemInfo(orderId);
                startGetRecycleOrderQuotation(orderId);
                startGetOrderDocumentsInfo(orderId);
            }
            startGetOrderDocumentsInfo(orderId);
        }
    }, [orderInfo]);

    const getLoadingConditions = () => {
        if (orderType === '1') {
            return isOrderItemInfoLoading || isConsolidatedOrderItemInfoLoading || isOrderQuotationLoading;
        }
        return isOrderItemInfoLoading || isOrderQuotationLoading;
    };

    useEffect(() => {
        if (!getLoadingConditions()) {
            applyCSS();
        }
    }, [isOrderItemInfoLoading, isConsolidatedOrderItemInfoLoading, isOrderQuotationLoading]);

    const [isCompleteOrderAllowed, setCompleteOrder] = useState(false);
    const mandatoryDocs = {
        1: [
            'Delivery Challan',
            'E-way Bill',
            'Sales Invoice',
            'Service Invoice',
            'Asset List',
            'Asset Grading',
            'Form 2',
            'Form 6',
            'Data Destruction Certificate'
        ],
        2: ['E-way Bill', 'Sales Invoice', 'Form 2', 'Form 6', 'Recycling Certificate']
    };
    const validateMandatoryDocs = (docs, orderDocuments) => {
        let isValid = true;
        if (orderItemInfo.orderPosition === 'Completed' || orderItemInfo.currentSequence < 6) {
            isValid = false;
        }
        docs.forEach((docName) => {
            if (!isValid) return;
            const docFound = orderDocuments.find((odoc) => odoc.docName === docName && odoc.order_docs.length);
            if (!docFound) {
                isValid = false;
            }
        });

        setCompleteOrder(isValid);
    };
    useEffect(() => {
        if (orderDocInfo && orderType) {
            validateMandatoryDocs(mandatoryDocs[orderType], orderDocInfo);
        }
    }, [orderDocInfo, orderType]);

    const getStyleForOrderPosition = (orderPosition) => {
        const colorMap = {
            'Draft': '#0A6EDA',
            'In Progress': '#EC890C',
            'Completed': '#7C8E50'
        };
        return {
            color: colorMap[orderPosition]
        };
    };

    const [callInProgress, setCallInProgress] = useState(false);
    const completeOrderClickHandler = () => {
        setCallInProgress(true);
        startUpdateAsCompleteOrder(orderId)
            .then(() => {
                setCallInProgress(false);
                startShowMessage({
                    message: `Your Order ${orderItemInfo.orderNumber} has been marked as Completed.`,
                    status: StatusColor.Positive
                });
                history.push('/order/previousOrder');
            })
            .catch(() => {
                setCallInProgress(false);
            });
    };

    if (getLoadingConditions()) {
        return <LoadingIndicator />;
    }
    return (
        <>
            <Breadcrumbs onItemClick={onBreadCrumbClick} style={{ ...spacing.sapUiMediumMarginBottom }}>
                <BreadcrumbsItem>Previous Order</BreadcrumbsItem>
                <BreadcrumbsItem>{orderItemInfo.orderNumber}</BreadcrumbsItem>
            </Breadcrumbs>
            <Toolbar style={spacing.sapUiTinyMarginTopBottom}>
                <Title>{`Order ${orderItemInfo.orderNumber}`}</Title>
                <ToolbarSpacer />
                {!isCompleteOrderAllowed && (
                    <Title style={getStyleForOrderPosition(orderItemInfo.orderPosition)}>
                        {orderItemInfo.orderPosition}
                    </Title>
                )}
                {isCompleteOrderAllowed && (
                    <BusyIndicator active={callInProgress}>
                        <Button onClick={completeOrderClickHandler}>Complete Order</Button>
                    </BusyIndicator>
                )}
            </Toolbar>
            <TabContainer fixed>
                <Tab icon="form" selected text="Order Details">
                    <OrderDetailsContainer
                        orderId={orderId}
                        orderType={orderType}
                        consolidatedOrderItemInfo={consolidatedOrderItemInfo}
                        orderItemInfo={orderItemInfo}
                        orderQuotation={orderQuotation}
                    />
                </Tab>
                <Tab icon="documents" text="Order Documents">
                    <DocumentContainer orderId={orderId} orderNo={orderItemInfo.orderNumber} />
                </Tab>
                <Tab icon="clinical-tast-tracker" text="Order Tracking" disabled>
                    Content Tab 3
                </Tab>
            </TabContainer>
        </>
    );
};

const mapStateToProps = (state) => ({
    orderInfo: getOrderListData(state),
    orderItemInfo: getOrderItemData(state),
    consolidatedOrderItemInfo: getConsolidatedOrderItemData(state),
    orderQuotation: getOrderQuotationData(state),
    isOrderItemInfoLoading: isOrderItemLoading(state),
    isConsolidatedOrderItemInfoLoading: isConsolidatedOrderItemLoading(state),
    isOrderQuotationLoading: isOrderQuotationLoading(state),
    orderDocInfo: getOrderDocumentData(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetRefurbishOrderItemInfo: (orderId) => dispatch(getRefurbishOrderItemInfo(orderId)),
    startGetRefurbishConsolidatedOrderItemInfo: (orderId) => dispatch(getConsolidatedOrderItemInfo(orderId)),
    startGetRefurbishOrderQuotation: (orderId) => dispatch(getRefurbishOrderQuotation(orderId)),
    startGetRecycleOrderItemInfo: (orderId) => dispatch(getRecycleOrderItemInfo(orderId)),
    startGetRecycleOrderQuotation: (orderId) => dispatch(getRecycleOrderQuotation(orderId)),
    startGetOrderDocumentsInfo: (orderId) => dispatch(getOrderDocuments(orderId)),
    startUpdateAsCompleteOrder: (orderId) => dispatch(completeOrder(orderId)),
    startShowMessage: (payload) => dispatch(showMessage(payload))
});

OrderInfo.propTypes = {
    orderInfo: PropTypes.array,
    orderItemInfo: PropTypes.object,
    consolidatedOrderItemInfo: PropTypes.object,
    orderQuotation: PropTypes.object,
    isOrderItemInfoLoading: PropTypes.bool,
    isConsolidatedOrderItemInfoLoading: PropTypes.bool,
    isOrderQuotationLoading: PropTypes.bool,
    orderDocInfo: PropTypes.array,
    startGetOrderDocumentsInfo: PropTypes.func.isRequired,
    startUpdateAsCompleteOrder: PropTypes.func.isRequired,
    startShowMessage: PropTypes.func.isRequired,
    startGetRefurbishOrderItemInfo: PropTypes.func.isRequired,
    startGetRefurbishConsolidatedOrderItemInfo: PropTypes.func.isRequired,
    startGetRefurbishOrderQuotation: PropTypes.func.isRequired,
    startGetRecycleOrderItemInfo: PropTypes.func.isRequired,
    startGetRecycleOrderQuotation: PropTypes.func.isRequired
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderInfo);
