import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { Route, Switch, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import PrivateRoute from '../login/PrivateRoute';
import PreviousOrder from './PreviousOrder';
import OrderCreationForm from './OrderCreationForm';
import OrderInfo from './OrderInfo';
import ErrorComponent from '../common/Error';
import { getOrderList } from '../../store/action/order';

const OrderComponent = ({ startGetOrderInfo }) => {
    useEffect(() => {
        startGetOrderInfo();
    }, []);

    return (
        <Switch>
            <PrivateRoute exact path="/order/newOrder" component={OrderCreationForm} />
            <PrivateRoute exact path="/order/previousOrder" component={PreviousOrder} />
            <PrivateRoute exact path="/order/previousOrder/:orderNumber" component={OrderInfo} />
            <Route exact path="/404" component={() => <ErrorComponent text="Page Not Found" />} />
            <Redirect from="/" to="/404" />
        </Switch>
    );
};

const mapStateToProps = () => ({});

const mapDispatchToProps = (dispatch) => ({
    startGetOrderInfo: () => dispatch(getOrderList())
});

OrderComponent.propTypes = {
    startGetOrderInfo: PropTypes.func.isRequired
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderComponent);
