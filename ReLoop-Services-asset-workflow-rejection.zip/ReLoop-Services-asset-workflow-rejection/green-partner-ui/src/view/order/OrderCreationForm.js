import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { FileUploader, Button, Label, Text, Toolbar, BusyIndicator } from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import AccountTable from '../common/Table';
import CommentDialog from '../common/Dialog';
import { getWorkflowsInfo, getNetworkInfo } from '../../store/action/account';
import { updateOrderInfo, updateDraftOrderInfo, getPrivateNetworkOwner } from '../../store/action/order';
import { readExcelInfo, downloadFile } from '../../store/action/taskAction';
import {
    getToastData,
    getWorkflowData,
    getNetworkInfoData,
    getIsPartOfPvtNwk,
    getPreviewOrderItemData
} from '../../selectors/common';
import { clearPreviewOrderItems } from '../../store/actionType';
import MessageBar from '../common/MessageBar';
import OrderHeaderFormEdit from './OrderHeaderFormEdit';

const OrderCreationForm = ({
    startUpdateOrderInfo,
    startUpdateDraftOrderInfo,
    startGetWorkflowInfo,
    startReadExcelInfo,
    startClearPreviewOrderItems,
    startGetPrivateNetworkRecyclers,
    orderInfo,
    workflowsInfo,
    previewOrderItemInfo,
    privateNetworkRecyclers,
    toast,
    startGetPrivateNetworkOwner,
    isPartOfPvtNwk,
    networkRecycler
}) => {
    const columns = ['Approver Sequence', 'Approver Role', 'Approver Name'];
    const refurbishAssetColumns = [
        'Equipment No.',
        'Asset No.',
        'Location',
        'Bond Status',
        'Category',
        'Make',
        'Model',
        'Manuf. Serial No.',
        'Age in Years',
        'Purchase Year',
        'Description'
    ];
    const recycleAssetColumns = ['Item', 'Quantity', 'Unit', 'Location', 'Remarks'];

    const [rows, setRows] = useState([]);
    const initState = {
        orderType: '1',
        category: '1',
        subcategory: '1',
        network: 'Private',
        recyclerIds: [],
        recycleAssetType: 'Non-Fixed',
        picture: {
            name: ''
        }
    };
    const [orderPayload, setOrderPayload] = useState({ ...initState });
    useEffect(() => {
        if (privateNetworkRecyclers.length !== 0) {
            const updatedPayload = { ...orderPayload };
            updatedPayload.recyclerIds = [];
            privateNetworkRecyclers.forEach((item) => {
                updatedPayload.recyclerIds.push(item.nwk_member);
            });
            setOrderPayload(updatedPayload);
        }
    }, [privateNetworkRecyclers.length]);

    const onInputChangeLocal = (event, fieldName, value, actualOrderPayload) => {
        // actualOrderPayload is the child component local copy of values
        const orderPayloadCopy = { ...orderPayload, ...actualOrderPayload };
        orderPayloadCopy[fieldName] = value;
        setOrderPayload(orderPayloadCopy);
        if (value) {
            // eslint-disable-next-line no-use-before-define
            const OrderFormFieldSpecCopy = { ...OrderFormFieldSpec };
            OrderFormFieldSpecCopy[fieldName].valueState = 'None';
            // eslint-disable-next-line no-use-before-define
            setOrderFormFieldSpec(OrderFormFieldSpecCopy);
        }
    };
    const [OrderFormFieldSpec, setOrderFormFieldSpec] = useState({
        orderType: {
            valueState: 'None',
            valueStateMessage: '',
            required: true,
            onInputChange: onInputChangeLocal
        },
        category: {
            valueState: 'None',
            valueStateMessage: '',
            required: true,
            onInputChange: onInputChangeLocal
        },
        subcategory: {
            valueState: 'None',
            valueStateMessage: '',
            required: true,
            onInputChange: onInputChangeLocal
        },
        recycleAssetType: {
            valueState: 'None',
            valueStateMessage: '',
            required: true,
            onInputChange: onInputChangeLocal
        },
        orderLocCity: {
            valueState: 'None',
            valueStateMessage: '',
            required: true,
            onInputChange: onInputChangeLocal
        },
        totalWeight: {
            valueState: 'None',
            valueStateMessage: '',
            required: false,
            onInputChange: onInputChangeLocal
        },
        network: {
            valueState: 'None',
            valueStateMessage: '',
            required: true,
            onInputChange: onInputChangeLocal
        },
        recyclerIds: {
            valueState: 'None',
            valueStateMessage: '',
            required: true,
            onInputChange: onInputChangeLocal
        },
        submissionDeadline: {
            valueState: 'None',
            valueStateMessage: '',
            required: true,
            onInputChange: onInputChangeLocal
        },
        additionalInfo: {
            valueState: 'None',
            valueStateMessage: '',
            required: false,
            onInputChange: onInputChangeLocal
        },
        picture: {
            valueState: 'None',
            valueStateMessage: '',
            required: false,
            onInputChange: onInputChangeLocal
        },
        assetExcel: {
            valueState: 'None',
            valueStateMessage: '',
            required: true
        }
    });
    const [assetRows, setAssetRows] = useState([]);
    const [assetTableVisible, setAssetTableVisible] = useState(false);

    const dialogRef = useRef(null);
    const history = useHistory();
    const getWorkflowDetails = (workflowsInfo) => {
        const newRows = [];
        const workflowApprover = [];
        if (workflowsInfo.length !== 0) {
            const workflow = workflowsInfo.find(
                (workflow) =>
                    workflow.process_stage_sequence === '1' && workflow.process_type_id === orderPayload.orderType
            );
            if (workflow) {
                workflowApprover.push(workflow.workflow_approvers);
                workflowApprover[0].forEach((index) => {
                    const row = [];
                    row.push({ name: 'approver_sequence', value: index.approver_sequence, type: 'text' });
                    row.push({ name: 'approver_role', value: index.approver.approver_role, type: 'text' });
                    row.push({ name: 'approver_name', value: index.approver.approver_name, type: 'text' });
                    newRows.push(row);
                });
                return newRows;
            }
        }
    };

    const getOrderItemDetails = (previewOrderItemInfo, limit) => {
        const newRows = [];
        const limitedRows = previewOrderItemInfo.slice(0, limit);
        if (orderPayload.orderType === '1') {
            limitedRows.forEach((asset) => {
                const row = [];
                row.push({ name: 'Equipment No.', value: asset['Equipment No'], type: 'text' });
                row.push({ name: 'Asset No.', value: asset['Asset No'], type: 'text' });
                row.push({ name: 'Location', value: asset.Location, type: 'text' });
                row.push({ name: 'Bond Status', value: asset['Bond Status'], type: 'text' });
                row.push({ name: 'Category', value: asset.Category, type: 'text' });
                row.push({ name: 'Make', value: asset.Make, type: 'text' });
                row.push({ name: 'Model', value: asset.Model, type: 'text' });
                row.push({ name: 'Manuf. Serial No.', value: asset['Manuf. Serial No.'], type: 'text' });
                row.push({ name: 'Age in Years', value: asset['Age in Years'], type: 'text' });
                row.push({ name: 'Purchase Year', value: asset['Purchase Year'], type: 'text' });
                row.push({ name: 'Description', value: asset.Description, type: 'text' });
                newRows.push(row);
            });
        } else {
            limitedRows.forEach((asset) => {
                const row = [];
                row.push({ name: 'Item', value: asset.Item, type: 'text' });
                row.push({ name: 'Quantity', value: asset.Quantity || '-', type: 'text' });
                row.push({ name: 'Unit', value: asset.Unit || '-', type: 'text' });
                row.push({ name: 'Location', value: asset.Location, type: 'text' });
                row.push({ name: 'Remarks', value: asset.Remarks, type: 'text' });
                newRows.push(row);
            });
        }
        return newRows;
    };

    useEffect(() => {
        startGetWorkflowInfo();
        startClearPreviewOrderItems();
    }, []);
    useEffect(() => {
        if (isPartOfPvtNwk) {
            startGetPrivateNetworkOwner();
        } else {
            startGetPrivateNetworkRecyclers();
        }
    }, [isPartOfPvtNwk]);
    useEffect(() => {
        const rows = getWorkflowDetails(workflowsInfo);
        setRows(rows);
    }, [workflowsInfo.length, orderPayload.orderType]);

    useEffect(() => {
        const newState = initState;
        Object.keys(initState).forEach((field) => {
            newState[field] = initState[field];
        });
        newState.orderType = orderPayload.orderType;
        privateNetworkRecyclers.forEach((item) => {
            newState.recyclerIds.push(item.nwk_member);
        });
        setOrderPayload(newState);
        // reset form validations
        const OrderFormFieldSpecCopy = { ...OrderFormFieldSpec };
        Object.keys(OrderFormFieldSpecCopy).forEach((field) => {
            OrderFormFieldSpecCopy[field].valueState = 'None';
        });
        setOrderFormFieldSpec(OrderFormFieldSpecCopy);
        setAssetRows([]);
        setAssetTableVisible(false);
    }, [orderPayload.orderType]);

    const minDisplayRows = 10;
    const minTableHeight = '400px';
    const loadMoreAssetList = () => {
        setAssetRows((previousRows) => [
            ...getOrderItemDetails(previewOrderItemInfo, previousRows.length + minDisplayRows)
        ]);
    };
    useEffect(() => {
        if (previewOrderItemInfo) {
            const newrows = getOrderItemDetails(previewOrderItemInfo, minDisplayRows);
            setAssetRows(newrows);
            const isTableVisible = !!newrows.length;
            setAssetTableVisible(isTableVisible);
        }
    }, [previewOrderItemInfo]);
    const validateAssetExcelUpload = (file) => {
        const oneMBinBytes = 1 * 1024 * 1024;
        const temp = { ...OrderFormFieldSpec };
        if (file.size > oneMBinBytes) {
            temp.assetExcel.valueState = 'Error';
            temp.assetExcel.valueStateMessage = <span> Cannot upload File of size above 1 MB </span>;
            setOrderFormFieldSpec(temp);
            return false;
        }
        if (file.type !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
            temp.assetExcel.valueState = 'Error';
            temp.assetExcel.valueStateMessage = <span> Only Excel (.xlsx) files are accepted </span>;
            setOrderFormFieldSpec(temp);
            return false;
        }
        return true;
    };

    const onDeleteClick = async () => {
        setAssetTableVisible(false);
        const updatedPayload = { ...orderPayload };
        updatedPayload.assetExcel = '';
        setOrderPayload(updatedPayload);
    };

    const [onExcelUpload, setOnExcelUpload] = useState(false);
    const onFileChangeHandler = (event) => {
        const fileform = new FormData();
        const fileMeta = event.target.files[0];
        fileform.append(event.target.name, fileMeta);
        const updatedPayload = { ...orderPayload };
        updatedPayload[event.target.name] = fileMeta;
        setOrderPayload(updatedPayload);
        if (event.target.name === 'assetExcel') {
            if (validateAssetExcelUpload(fileMeta)) {
                startClearPreviewOrderItems();
                setOnExcelUpload(true);
                setAssetTableVisible(true);
                startReadExcelInfo(fileform)
                    .then(() => {
                        setOnExcelUpload(false);
                    })
                    .catch(() => {
                        onDeleteClick();
                        setOnExcelUpload(false);
                    });
            }
        }
    };
    const onDownloadBtnClick = () => {
        const orderType = orderPayload.orderType === '1' ? 'Refurbish' : 'Recycle';
        downloadFile(null, `${orderType}_Assetlist_Template.xlsx`);
    };
    const onCancel = () => {
        dialogRef.current.close();
    };
    const validateOrderForm = () => {
        let isValid = true;
        const OrderFormFieldSpecCopy = { ...OrderFormFieldSpec };
        if (!orderPayload.assetExcel) {
            isValid = false;
            OrderFormFieldSpecCopy.assetExcel.valueState = 'Error';
            OrderFormFieldSpecCopy.assetExcel.valueStateMessage = <span> Asset List should be uploaded </span>;
        }
        if (!orderPayload.recyclerIds || !orderPayload.recyclerIds.length) {
            isValid = false;
            OrderFormFieldSpecCopy.recyclerIds.valueState = 'Error';
            OrderFormFieldSpecCopy.recyclerIds.valueStateMessage = <span> Field is required </span>;
        }
        if (!orderPayload.submissionDeadline) {
            OrderFormFieldSpecCopy.submissionDeadline.valueState = 'Error';
            OrderFormFieldSpecCopy.submissionDeadline.valueStateMessage = <span> Field is required </span>;
            isValid = false;
        }
        dialogRef.current.close();
        setOrderFormFieldSpec(OrderFormFieldSpecCopy);
        return isValid;
    };
    const onSubmit = (event, draftVal) => {
        if (isPartOfPvtNwk) {
            orderPayload.recyclerIds = [networkRecycler?.nwkOwner];
        }
        // event.comments comes from the commentDialog box which has input box
        if (event.comments) {
            orderPayload.commentsForApprover = event.comments;
        }
        event.preventDefault();
        if (!validateOrderForm()) {
            document.getElementById('order-form-main').scrollIntoView();
            return;
        }

        // Remove asset type flag for refurbishing order
        if (orderPayload.orderType === '1') {
            Reflect.deleteProperty(orderPayload, 'recycleAssetType');
            Reflect.deleteProperty(orderPayload, 'totalWeight');
        }
        const formdata = new FormData();
        for (const [key, value] of Object.entries(orderPayload)) {
            if (key === 'assetExcel' || key === 'picture') {
                formdata.append(key, value);
                continue;
            }
            formdata.append(`${key}`, `${value}`);
        }
        formdata.append('processStageSequence', '1');
        orderInfo = formdata;
        dialogRef.current.close();
        startClearPreviewOrderItems();

        let postPromise;
        if (draftVal === 'draft') {
            postPromise = startUpdateDraftOrderInfo(orderInfo);
        } else {
            postPromise = startUpdateOrderInfo(orderInfo);
        }
        postPromise.then(() => {
            history.push('/order/previousOrder');
        });
    };
    const onSendAssetListClick = () => {
        dialogRef.current.show();
    };
    const getAssetListColumns = () => (orderPayload.orderType === '1' ? refurbishAssetColumns : recycleAssetColumns);

    const getTableHeight = () => (orderPayload.orderType === '1' ? minTableHeight : '100%');
    const buttons = [
        {
            name: 'Delete',
            icon: 'delete',
            onClick: onDeleteClick
        }
    ];
    return (
        <div id="order-form-main">
            <Label style={{ fontSize: '1.3rem', fontWeight: 'Bold', marginBottom: '20px' }}>Order Creation</Label>
            <Toolbar style={spacing.sapUiTinyMargin}>
                <Label style={{ fontSize: '1rem', fontWeight: 'bold' }}>Order Details</Label>
            </Toolbar>
            <OrderHeaderFormEdit
                formFields={OrderFormFieldSpec}
                setFormFieldsState={setOrderFormFieldSpec}
                orderPayloadParent={orderPayload}
            />
            {assetTableVisible === true && (
                <div>
                    <BusyIndicator style={{ width: '100%' }} active={onExcelUpload}>
                        <AccountTable
                            columns={getAssetListColumns()}
                            edit={false}
                            text="Asset List"
                            rows={assetRows}
                            buttons={buttons}
                            lazyLoading={loadMoreAssetList}
                            height={getTableHeight()}
                        />
                    </BusyIndicator>
                </div>
            )}
            {assetTableVisible === false && (
                <div>
                    <Toolbar>
                        <Label style={{ fontSize: '1rem', fontWeight: 'bold' }}>Asset List</Label>
                    </Toolbar>
                    <div style={{ display: 'flex', flexDirection: 'column', ...spacing.sapUiLargeMargin }}>
                        <Text>
                            1. Please download the Excel template and fill the given columns with your asset data.
                        </Text>
                        <Button
                            data-layout-span="XL3"
                            icon="download"
                            style={{ position: 'absolute', ...spacing.sapUiMediumMargin }}
                            width="20%"
                            onClick={onDownloadBtnClick}
                        >
                            Download Excel Template
                        </Button>
                    </div>
                    <div style={spacing.sapUiLargeMargin}>
                        <Text style={spacing.sapUiMediumMarginTop}>
                            2. Then upload the Excel file here for the internal approval.
                        </Text>
                        <div style={spacing.sapUiMediumMargin}>
                            <FileUploader
                                name="assetExcel"
                                placeholder="Upload Excel Asset list"
                                value={orderPayload.assetExcel || ''}
                                onChange={onFileChangeHandler}
                                accept=".xlsx"
                                valueState={OrderFormFieldSpec.assetExcel.valueState}
                                valueStateMessage={OrderFormFieldSpec.assetExcel.valueStateMessage}
                            >
                                <Button>Upload file</Button>
                            </FileUploader>
                        </div>
                    </div>
                </div>
            )}

            <AccountTable columns={columns} edit={false} text="Internal Approval Workflow (Asset List)" rows={rows} />
            <div style={spacing.sapUiTinyMargin}>
                <Button
                    style={{ float: 'right', ...spacing.sapUiMediumMarginBegin }}
                    onClick={() => onSendAssetListClick()}
                    design="Emphasized"
                >
                    Send Asset List for Internal Approval
                </Button>
                <Button
                    style={{ float: 'right' }}
                    onClick={(e) => {
                        onSubmit(e, 'draft');
                    }}
                    design="Emphasized"
                >
                    Save as Draft
                </Button>
                <CommentDialog
                    ref={dialogRef}
                    onCancel={onCancel}
                    onSubmit={onSubmit}
                    headerText="Send Asset List for Internal Approval"
                />
                {toast.show && <MessageBar message={toast.message} type={toast.type} />}
            </div>
        </div>
    );
};

const mapStateToProps = (state) => ({
    isPartOfPvtNwk: getIsPartOfPvtNwk(state),
    workflowsInfo: getWorkflowData(state),
    previewOrderItemInfo: getPreviewOrderItemData(state),
    privateNetworkRecyclers: getNetworkInfoData(state),
    toast: getToastData(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetWorkflowInfo: () => dispatch(getWorkflowsInfo()),
    startUpdateOrderInfo: (payload) => dispatch(updateOrderInfo(payload)),
    startUpdateDraftOrderInfo: (payload) => dispatch(updateDraftOrderInfo(payload)),
    startReadExcelInfo: (payload) => dispatch(readExcelInfo(payload)),
    startClearPreviewOrderItems: () => dispatch(clearPreviewOrderItems()),
    startGetPrivateNetworkRecyclers: () => dispatch(getNetworkInfo()),
    startGetPrivateNetworkOwner: () => dispatch(getPrivateNetworkOwner())
});

OrderCreationForm.propTypes = {
    orderInfo: PropTypes.object,
    workflowsInfo: PropTypes.array,
    previewOrderItemInfo: PropTypes.array,
    startUpdateOrderInfo: PropTypes.func.isRequired,
    startUpdateDraftOrderInfo: PropTypes.func.isRequired,
    startGetWorkflowInfo: PropTypes.func.isRequired,
    startReadExcelInfo: PropTypes.func.isRequired,
    startClearPreviewOrderItems: PropTypes.func.isRequired,
    startGetPrivateNetworkRecyclers: PropTypes.func.isRequired,
    privateNetworkRecyclers: PropTypes.array,
    toast: PropTypes.object,
    isPartOfPvtNwk: PropTypes.bool,
    startGetPrivateNetworkOwner: PropTypes.func.isRequired,
    networkRecycler: PropTypes.object
};

OrderCreationForm.defaultProps = {
    orderInfo: {},
    workflowsInfo: [],
    previewOrderItemInfo: [],
    privateNetworkRecyclers: []
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderCreationForm);
