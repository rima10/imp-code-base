import React, { useRef, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Button, Toolbar, ToolbarSpacer, Bar, Label } from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import moment from 'moment';
import AccountTable from '../../common/Table';
import { getApprover, scheduleLogistics, downloadAssetGradeList } from '../../../store/action/order';
import { getRefurbishOrderItemLevelQuote } from '../../../store/action/quote';
import {
    getOrderCurrentSequence,
    getOrderApproverStep5Data,
    getOrderItemQuoteData,
    getQuotesData,
    getOrderItemData
} from '../../../selectors/common';
import CalendarDialog from '../../common/CalendarDialog';

const ApproveFinalQuote = ({
    approver,
    startGetApprover,
    orderItemQuotation,
    orderId,
    startGetItemQuote,
    startScheduleLogistics,
    startDownloadAssetGradeList,
    orderQuotation,
    currentSequence,
    orderItemInfo
}) => {
    const dialogRef = useRef(null);
    const [assetRows, setAssetRows] = useState([]);
    const [approverRows, setApproverRows] = useState([]);

    const approverColumns = ['Approver Role', 'Approver Name', 'Status', 'Comments'];

    const assetColumns = [
        {
            heading: 'Equipment No.',
            key: 'equipmentNumber'
        },
        {
            heading: 'Asset No.',
            key: 'assetNumber'
        },
        {
            heading: 'Location',
            key: 'buildingLocation',
            showOnDemand: true
        },
        {
            heading: 'Bond Status',
            key: 'bondStatus',
            showOnDemand: true
        },
        {
            heading: 'Item Type',
            key: 'itemType',
            showOnDemand: true
        },
        {
            heading: 'Make',
            key: 'make',
            showOnDemand: true
        },
        {
            heading: 'Model',
            key: 'model',
            showOnDemand: true
        },
        {
            heading: 'Age in Years',
            key: 'ageInYear',
            showOnDemand: true
        },
        {
            heading: 'Description',
            key: 'description',
            showOnDemand: true
        },
        {
            heading: 'Grade',
            key: 'grade'
        },
        {
            heading: 'Data wipe',
            key: 'dataWipeStatus',
            cellStyle: (value) => {
                switch (value) {
                    case 'Erased':
                        return { color: 'green' };
                    case 'In Progress':
                        return { color: 'orange' };
                    case 'Not Erased':
                        return { color: 'red' };
                }
            }
        },
        {
            heading: 'Report status',
            key: 'reportStatus'
        },
        {
            heading: 'Accessories',
            key: 'accessoriesStatus'
        },
        {
            heading: 'List price',
            key: 'listPrice',
            cellStyle: () => ({
                textAlign: 'right'
            })
        },
        {
            heading: 'To be invoiced',
            key: 'invoiceAmount',
            cellStyle: () => ({
                textAlign: 'right'
            })
        },
        {
            heading: 'Service cost',
            key: 'serviceCost',
            cellStyle: () => ({
                textAlign: 'right'
            })
        }
    ];
    const [assetColumnsHeader, setAssetColumnsHeader] = useState([]);
    const [totalRow, setTotalRows] = useState({ invoiceAmount: 0, serviceCost: 0 });
    const [showExtraColumns, setShowExtraColumns] = useState(false);
    const [tableBusyIndicator, setTableBusyIndicator] = useState(false);
    const calculateTotalAmount = (assetGradeListRows, field1, field2) => {
        const totalRowCopy = { ...totalRow };
        totalRowCopy[field1] = 0;
        if (field2) {
            totalRowCopy[field2] = 0;
        }
        assetGradeListRows.forEach((item) => {
            totalRowCopy[field1] += item[field1] ? Number(item[field1]) : 0;
            if (field2) {
                totalRowCopy[field2] += item[field2] ? Number(item[field2]) : 0;
            }
        });
        if (field1) {
            totalRowCopy[field1] = Math.round(totalRowCopy[field1] * 100) / 100;
        }
        if (field2) {
            totalRowCopy[field2] = Math.round(totalRowCopy[field2] * 100) / 100;
        }
        setTotalRows(totalRowCopy);
    };

    const getOrderItemQuoteDetails = (orderItemQuotes, limit, showExtraColumnsLocal = showExtraColumns) => {
        if (!Array.isArray(orderItemQuotation)) return [];
        const newRows = [];
        const limitedRows = orderItemQuotes.slice(0, limit);
        limitedRows.forEach((orderItem) => {
            const row = [];
            assetColumns.forEach((colItem) => {
                if (!showExtraColumnsLocal && colItem.showOnDemand) return;
                row.push({
                    name: colItem.heading,
                    value: orderItem[colItem.key],
                    type: 'text',
                    style: colItem.cellStyle ? colItem.cellStyle(orderItem[colItem.key]) : {}
                });
            });
            newRows.push(row);
        });
        return newRows;
    };

    const minDisplayRows = 10;
    const minTableHeight = '400px';
    const initColumnHeaders = (showExtraColumnsLocal = showExtraColumns) => {
        const headers = [];
        assetColumns.forEach((item) => {
            if (!showExtraColumnsLocal && item.showOnDemand) return;
            headers.push(item.heading);
        });
        setAssetColumnsHeader(headers);

        setAssetRows((previousRows) => {
            const limit = previousRows.length ? previousRows.length : minDisplayRows;
            return [...getOrderItemQuoteDetails(orderItemQuotation, limit, showExtraColumnsLocal)];
        });
    };

    const loadMoreAssetRows = () => {
        if (!Array.isArray(orderItemQuotation)) return;
        setTableBusyIndicator(true);
        setAssetRows((previousRows) => {
            if (orderItemQuotation.length <= previousRows.length) {
                return previousRows;
            }
            return [...getOrderItemQuoteDetails(orderItemQuotation.slice(0), previousRows.length + minDisplayRows)];
        });
        setTableBusyIndicator(false);
    };

    useEffect(() => {
        if (orderItemQuotation && Array.isArray(orderItemQuotation)) {
            calculateTotalAmount(orderItemQuotation, 'invoiceAmount', 'serviceCost');
        }
        initColumnHeaders();
    }, [orderItemQuotation]);

    const processStageSequence = 5;
    const getOrderCreationApproverActivityId = (workflowApprover) => {
        // eslint-disable-next-line max-len
        return `pss_${processStageSequence}|gpapp_${workflowApprover.approverId}|wkappid_${workflowApprover.workflowApproverId}`;
    };
    const getApproverDetails = (approvers) => {
        const newRows = [];
        approvers.forEach((approver) => {
            const row = [];
            row.push({ name: approverColumns[0], value: approver.approverRole, type: 'text' });
            row.push({ name: approverColumns[1], value: approver.approverName, type: 'text' });
            row.push({ name: approverColumns[2], value: approver.status, type: 'text' });

            const approverComments = orderItemInfo.orderNotes.find((item) => {
                return item.activity_identifier === getOrderCreationApproverActivityId(approver);
            });
            row.push({
                name: approverColumns[4],
                value: approverComments ? approverComments.comment : '-',
                type: 'text'
            });
            newRows.push(row);
        });
        return newRows;
    };
    const [currentAcceptedQuote, setCurrentAcceptedQuote] = useState();

    useEffect(() => {
        const acceptedOrderQuotation = orderQuotation.find(
            (item) => item.quoteStatus === 'Accepted' && item.assetGradeSubmitted
        );
        if (acceptedOrderQuotation) {
            setCurrentAcceptedQuote(acceptedOrderQuotation);
            startGetApprover(orderId, '1', '5');
            startGetItemQuote(orderId, acceptedOrderQuotation.quoteId);
        }
    }, []);

    useEffect(() => {
        if (approver.length !== 0) {
            const row = getApproverDetails(approver);
            setApproverRows(row);
        }
    }, [approver]);
    const onCancel = () => {
        dialogRef.current.close();
    };
    const onSubmit = (calendarPayload) => {
        const { date, time, logisticSpocName, logisticSpocContactNumber } = calendarPayload;
        let formattedDate = new Date(`${date} ${time} UTC`);
        formattedDate = formattedDate.toISOString();
        const payload = {
            scheduledLogisticDate: formattedDate,
            logisticSpocName,
            logisticSpocContactNumber
        };
        startScheduleLogistics(orderId, payload);
        dialogRef.current.close();
    };
    const onScheduleClick = () => {
        dialogRef.current.show();
    };

    const onDownloadAssetGradeList = () => {
        setTableBusyIndicator(true);
        const acceptedOrderQuotation = orderQuotation.find((item) => item.quoteStatus === 'Accepted');
        startDownloadAssetGradeList(orderId, acceptedOrderQuotation.quoteId)
            .then((response) => {
                setTableBusyIndicator(false);
                const responseBlob = new Blob([response.data]);
                const url = window.URL.createObjectURL(responseBlob);
                const a = document.createElement('a');
                a.href = url;
                a.target = '_blank';
                a.download = 'AssetGradeList.xlsx';
                a.click();
            })
            .catch(() => {
                setTableBusyIndicator(false);
            });
    };

    const assetTableButtons = [
        {
            name: 'Show Asset Columns',
            icon: 'eye',
            hide: showExtraColumns,
            onClick: () => {
                setShowExtraColumns(true);
                initColumnHeaders(true);
            }
        },
        {
            name: 'Hide Asset Columns',
            icon: 'eye-closed',
            hide: !showExtraColumns,
            onClick: () => {
                setShowExtraColumns(false);
                initColumnHeaders(false);
            }
        },
        {
            name: 'Download as Excel',
            icon: 'download',
            onClick: onDownloadAssetGradeList,
            disabled: tableBusyIndicator
        }
    ];
    const renderButton = () => {
        const showButtons = currentSequence <= 5;
        let btnDisabled = false;
        // btn is disabled, if anyone of this below conditions are met
        if (approver && approver.length) {
            const isAllApproved = approver.filter((x) => x.status === 'Approved').length === approver.length;
            if (!isAllApproved) {
                btnDisabled = true;
            }
        }
        if (!currentAcceptedQuote) {
            btnDisabled = true;
        }
        return (
            <>
                {showButtons && (
                    <Toolbar toolbarStyle="Clear">
                        <ToolbarSpacer />
                        <Button design="Emphasized" onClick={onScheduleClick} disabled={btnDisabled}>
                            Schedule Pick up date
                        </Button>
                    </Toolbar>
                )}
            </>
        );
    };

    const calendarOptions = {
        minDate: moment().format('YYYY-MM-DD'),
        dateRequired: true,
        timeRequired: true
    };
    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <AccountTable
                isBusy={tableBusyIndicator}
                columns={assetColumnsHeader}
                rows={assetRows}
                buttons={assetTableButtons}
                edit={false}
                text="List of Verified Assets"
                lazyLoading={loadMoreAssetRows}
                height={assetRows.length ? minTableHeight : '100%'}
            />
            <Bar
                startContent={
                    <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                        Total value to be Invoiced (exclude tax)
                    </Label>
                }
                endContent={
                    <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                        {totalRow && totalRow.invoiceAmount} INR
                    </Label>
                }
                style={{ background: '#f2f2f2' }}
            />
            <Bar
                startContent={
                    <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>Total service costs (exclude tax) </Label>
                }
                endContent={
                    <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                        {totalRow && totalRow.serviceCost} INR
                    </Label>
                }
                style={{ background: '#f2f2f2' }}
            />
            <AccountTable
                columns={approverColumns}
                edit={false}
                text="Final Quote Approval Workflow"
                rows={approverRows}
            />
            {renderButton()}
            <CalendarDialog
                ref={dialogRef}
                onCancel={onCancel}
                onSubmit={onSubmit}
                headerText="Schedule Pickup Date for your Assets"
                showEstHours={false}
                options={calendarOptions}
            />
        </div>
    );
};

const mapStateToProps = (state) => ({
    approver: getOrderApproverStep5Data(state),
    orderItemQuotation: getOrderItemQuoteData(state),
    orderQuotation: getQuotesData(state),
    currentSequence: getOrderCurrentSequence(state),
    orderItemInfo: getOrderItemData(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetApprover: (orderId, processType, sequenceNo) => dispatch(getApprover(orderId, processType, sequenceNo)),
    startGetItemQuote: (orderId, quoteId) => dispatch(getRefurbishOrderItemLevelQuote(orderId, quoteId)),
    startScheduleLogistics: (orderId, quoteId, payload) => dispatch(scheduleLogistics(orderId, quoteId, payload)),
    startDownloadAssetGradeList: (orderId, quoteId) => dispatch(downloadAssetGradeList(orderId, quoteId))
});

ApproveFinalQuote.propTypes = {
    orderItemInfo: PropTypes.object,
    approver: PropTypes.array,
    startGetApprover: PropTypes.func.isRequired,
    startGetItemQuote: PropTypes.func.isRequired,
    startScheduleLogistics: PropTypes.func.isRequired,
    orderId: PropTypes.string,
    orderItemQuotation: PropTypes.object,
    orderQuotation: PropTypes.array,
    startDownloadAssetGradeList: PropTypes.func.isRequired,
    currentSequence: PropTypes.string
};

export default connect(mapStateToProps, mapDispatchToProps)(ApproveFinalQuote);
