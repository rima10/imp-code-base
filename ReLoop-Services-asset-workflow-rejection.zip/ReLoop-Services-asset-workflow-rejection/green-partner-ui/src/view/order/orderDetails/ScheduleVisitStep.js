import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { getOnsiteVisitDetails } from '../../../store/action/order';
import { getOnsiteDetailsData, isOnsiteDataLoading, getOrderItemQuoteData } from '../../../selectors/common';
import AccountTable from '../../common/Table';

const ScheduleOnsiteVisit = ({ isLoading, startGetOnsiteVisitDetails, onSiteDetails, orderId, orderItemQuotation }) => {
    useEffect(() => {
        startGetOnsiteVisitDetails(orderId);
    }, []);
    const [rows, setRows] = useState([]);
    const columns = ['Selected Recycler Company', 'Scheduled Time', 'Quote Status', 'Total Price'];

    const getVisitDetails = (onSiteDetails) => {
        const newRows = [];
        const row = [];
        row.push({ name: columns[0], value: onSiteDetails.createdByBP.recyclerName, type: 'text' });
        row.push({
            name: columns[1],
            value:
                // eslint-disable-next-line max-len
                `${new Date(onSiteDetails.onsiteScheduledTime).toDateString()} ${new Date(
                    onSiteDetails.onsiteScheduledTime
                ).toLocaleTimeString()}`,
            type: 'text'
        });
        row.push({ name: columns[2], value: onSiteDetails.quoteStatus, type: 'text' });
        row.push({ name: columns[3], value: onSiteDetails.totalPrice || orderItemQuotation.totalPrice, type: 'text' });
        newRows.push(row);
        return newRows;
    };

    useEffect(() => {
        // eslint-disable-next-line eqeqeq
        if (onSiteDetails && !Object.keys(onSiteDetails).length == 0) {
            const row = getVisitDetails(onSiteDetails);
            setRows(row);
        }
    }, [onSiteDetails, orderItemQuotation]);

    if (isLoading) {
        return null;
    }
    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <AccountTable columns={columns} edit={false} text="Selected Recycler" rows={rows} />
        </div>
    );
};

const mapStateToProps = (state) => ({
    onSiteDetails: getOnsiteDetailsData(state),
    isLoading: isOnsiteDataLoading(state),
    orderItemQuotation: getOrderItemQuoteData(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetOnsiteVisitDetails: (orderId) => dispatch(getOnsiteVisitDetails(orderId))
});

ScheduleOnsiteVisit.propTypes = {
    isLoading: PropTypes.bool,
    onSiteDetails: PropTypes.object,
    orderId: PropTypes.string,
    orderItemQuotation: PropTypes.object,
    startGetOnsiteVisitDetails: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(ScheduleOnsiteVisit);
