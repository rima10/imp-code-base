import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { BusyIndicator, Label, Form, FormGroup, FormItem, Text } from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import { getOrderItemData } from '../../../selectors/common';

const Logistics = ({ orderItemInfo }) => {
    const [loading, setLoading] = useState(true);
    useEffect(() => {}, []);
    useEffect(() => {
        if (orderItemInfo && orderItemInfo.logisticsScheduledTime) {
            setLoading(false);
        }
    }, [orderItemInfo.logisticsScheduledTime]);

    const getDate = (logisticsScheduledTime) => {
        if (logisticsScheduledTime !== null && logisticsScheduledTime !== undefined) {
            const logisticsScheduledDate = new Date(logisticsScheduledTime).toDateString();
            return logisticsScheduledDate;
        }
    };

    const getTime = (logisticsScheduledTime) => {
        if (logisticsScheduledTime !== null && logisticsScheduledTime !== undefined) {
            const logisticsScheduledDate = new Date(logisticsScheduledTime);
            let hours = logisticsScheduledDate.getUTCHours();
            let minutes = logisticsScheduledDate.getUTCMinutes();
            let seconds = logisticsScheduledDate.getUTCSeconds();
            let meridian;
            if (hours.toString().length === 1) {
                hours = `0${hours.toString()}`;
            }
            if (minutes.toString().length === 1) {
                minutes = `0${minutes.toString()}`;
            }
            if (seconds.toString().length === 1) {
                seconds = `0${seconds.toString()}`;
            }
            if (hours > 11) {
                hours -= 12;
                meridian = 'PM';
                return `${hours}:${minutes}:${seconds} PM`;
            }
            meridian = 'AM';
            return `${hours}:${minutes}:${seconds} ${meridian}`;
        }
    };
    return (
        <BusyIndicator active={loading} size="Medium">
            <div style={spacing.sapUiMediumMargin}>
                <Label style={{ fontSize: '1rem', fontWeight: 'Bold' }}>Logistic Details</Label>
                <div style={spacing.sapUiLargeMargin}>
                    <Form columnsL={2} columnsM={2} columnsS={2} labelSpanM={5} style={spacing.sapUiLargeMarginBottom}>
                        <FormGroup>
                            <FormItem label="Date">
                                <Text style={spacing.sapUiTinyMargin}>
                                    {getDate(orderItemInfo.logisticsScheduledTime)}
                                </Text>
                            </FormItem>
                            <FormItem label="Time">
                                <Text style={spacing.sapUiTinyMargin}>
                                    {getTime(orderItemInfo.logisticsScheduledTime)}
                                </Text>
                            </FormItem>
                            <FormItem label="Name (Order Responsible)">
                                <Text style={spacing.sapUiTinyMargin}> {orderItemInfo.logisticSpocName} </Text>
                            </FormItem>
                            <FormItem label="Contact (Order Responsible)">
                                <Text style={spacing.sapUiTinyMargin}> {orderItemInfo.logisticSpocContactNumber} </Text>
                            </FormItem>
                            <FormItem label="Logistics Provider">
                                <Text style={spacing.sapUiTinyMargin}> {orderItemInfo.logisticProvider} </Text>
                            </FormItem>
                        </FormGroup>
                        <FormGroup>
                            <FormItem label="Driver Name">
                                <Text style={spacing.sapUiTinyMargin}> {orderItemInfo.driverName} </Text>
                            </FormItem>
                            <FormItem label="Vehicle Type">
                                <Text style={spacing.sapUiTinyMargin}> {orderItemInfo.vehicleType}</Text>
                            </FormItem>
                            <FormItem label="Vehicle Number">
                                <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.vehicleNumber}</Text>
                            </FormItem>
                            <FormItem label="Recycler Contact Name">
                                <Text style={spacing.sapUiTinyMargin}> {orderItemInfo.recyclerContactName}</Text>
                            </FormItem>
                            <FormItem label="Recycler Contact Number">
                                <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.recyclerContactNumber}</Text>
                            </FormItem>
                        </FormGroup>
                    </Form>
                </div>
            </div>
        </BusyIndicator>
    );
};

const mapStateToProps = (state) => ({
    orderItemInfo: getOrderItemData(state)
});

const mapDispatchToProps = () => ({});

Logistics.propTypes = {
    orderItemInfo: PropTypes.object
};

export default connect(mapStateToProps, mapDispatchToProps)(Logistics);
