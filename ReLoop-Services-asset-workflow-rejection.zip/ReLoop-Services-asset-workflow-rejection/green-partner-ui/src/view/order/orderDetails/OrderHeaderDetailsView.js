import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import {
    Form,
    FormGroup,
    FormItem,
    Text,
    Toolbar,
    Label,
    ToolbarSpacer,
    Button,
    Token,
    Link
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import moment from 'moment';
import OrderHeaderFormEdit from '../OrderHeaderFormEdit';
import LoadingIndicator from '../../common/Loading';
import { updateOrderHeaderData, downloadDocument } from '../../../store/action/order';

const OrderHeaderView = ({ orderItemInfo, startUpdateOrderHeaderData, startDownloadPicture }) => {
    const [isLoading, setLoading] = useState(false);
    const [isEditAllowed, setIsEditAllowed] = useState(false);
    const [mode, setMode] = useState('view');
    const [orderPayload, setOrderPayload] = useState({});
    useEffect(() => {
        if (orderItemInfo && orderItemInfo.orderPosition === 'Draft') {
            setIsEditAllowed(true);
        }
        const order = { ...orderPayload };
        order.orderType = orderItemInfo.orderType;
        order.category = orderItemInfo.category;
        order.subcategory = orderItemInfo.subCategory;
        order.network = orderItemInfo.orderNetwork;
        order.recyclerIds = orderItemInfo.recyclers.map((item) => item.bpId);
        order.submissionDeadline = moment(orderItemInfo.submissionDeadline).format('MMM D, y, h:mm:ss a');
        order.additionalInfo = orderItemInfo.orderAdditionalInfo;
        order.picture = {
            name: '',
            location: orderItemInfo.pictureLoc
        };
        if (order.orderType === '2') {
            order.recycleAssetType = orderItemInfo.recycleAssetType;
            order.totalWeight = orderItemInfo.totalWeight;
        }
        setOrderPayload(order);
    }, [orderItemInfo]);

    const [OrderFormFieldSpec, setOrderFormFieldSpec] = useState({
        orderType: {
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        category: {
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        subcategory: {
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        orderLocCity: {
            valueState: 'None',
            valueStateMessage: '',
            required: false
        },
        network: {
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        recyclerIds: {
            valueState: 'None',
            valueStateMessage: '',
            required: true,
            validate: (orderPayload) => orderPayload.recyclerIds && orderPayload.recyclerIds.length
        },
        submissionDeadline: {
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        additionalInfo: {
            valueState: 'None',
            valueStateMessage: '',
            required: false
        },
        picture: {
            valueState: 'None',
            valueStateMessage: '',
            required: false
        },
        recycleAssetType: {
            valueState: 'None',
            valueStateMessage: '',
            required: (orderPayload) => orderPayload.orderType === '2'
        },
        totalWeight: {
            valueState: 'None',
            valueStateMessage: '',
            required: false
        }
    });

    const validateOrderForm = (orderPayloadFromEditForm) => {
        let isValidPayload = true;
        const OrderFormFieldSpecCopy = { ...OrderFormFieldSpec };
        Object.keys(OrderFormFieldSpecCopy).forEach((field) => {
            const currentFieldItem = OrderFormFieldSpecCopy[field];
            const isRequired =
                typeof currentFieldItem.required === 'boolean'
                    ? currentFieldItem.required
                    : currentFieldItem.required(orderPayloadFromEditForm);
            if (isRequired) {
                if (currentFieldItem.validate) {
                    isValidPayload = currentFieldItem.validate(orderPayloadFromEditForm);
                    if (!isValidPayload) {
                        currentFieldItem.valueState = 'Error';
                        currentFieldItem.valueStateMessage = <span>Field is required</span>;
                    }
                } else if (
                    orderPayloadFromEditForm[field] === undefined ||
                    orderPayloadFromEditForm[field] === null ||
                    orderPayloadFromEditForm[field] === ''
                ) {
                    isValidPayload = false;
                    currentFieldItem.valueState = 'Error';
                    currentFieldItem.valueStateMessage = <span>Field is required</span>;
                } else if (currentFieldItem.valueState !== 'None') {
                    isValidPayload = false;
                } else {
                    currentFieldItem.valueState = 'None';
                }
            }
        });
        setOrderFormFieldSpec(OrderFormFieldSpecCopy);
        return isValidPayload;
    };

    const onSubmit = (orderPayloadFromEditForm) => {
        if (!validateOrderForm(orderPayloadFromEditForm)) {
            return;
        }
        setLoading(true);
        const formdata = new FormData();
        for (const [key, value] of Object.entries(orderPayloadFromEditForm)) {
            if (key === 'picture') {
                // nested if is important, to omit picture field if its empty
                if (value.name) {
                    formdata.append(key, value);
                }
                continue;
            }
            formdata.append(`${key}`, `${value}`);
        }
        const { orderId } = orderItemInfo;
        startUpdateOrderHeaderData(orderId, formdata)
            .then(() => {
                setMode('view');
                setLoading(false);
            })
            .catch(() => {
                setLoading(false);
            });
    };

    const downloadPicture = () => {
        startDownloadPicture(orderItemInfo.orderId, orderItemInfo.pictureLoc);
    };

    return (
        <>
            {isLoading && <LoadingIndicator />}
            {mode === 'view' && (
                <div style={spacing.sapUiMediumMarginTop}>
                    <Toolbar style={spacing.sapUiTinyMargin}>
                        <Label style={{ fontSize: '1rem', fontWeight: 'bold' }}>Order Details</Label>
                        {isEditAllowed && (
                            <>
                                <ToolbarSpacer />
                                <Button
                                    onClick={() => {
                                        setMode('edit');
                                    }}
                                >
                                    Edit
                                </Button>
                            </>
                        )}
                    </Toolbar>
                    {orderItemInfo.orderType === '1' && (
                        <Form
                            columnsL={2}
                            columnsM={2}
                            columnsS={2}
                            labelSpanM={5}
                            style={spacing.sapUiLargeMarginTopBottom}
                        >
                            <FormGroup>
                                <FormItem label="Order Type">
                                    <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.processType}</Text>
                                </FormItem>
                                <FormItem label="Category">
                                    <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.categoryName}</Text>
                                </FormItem>
                                <FormItem label="Subcategory">
                                    <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.subCategoryName}</Text>
                                </FormItem>
                                <FormItem label="Network">
                                    <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.orderNetwork}</Text>
                                </FormItem>
                            </FormGroup>
                            <FormGroup>
                                <FormItem label="Recyclers">
                                    <Text style={spacing.sapUiTinyMargin}>
                                        {orderItemInfo.recyclers.map((item, index) => (
                                            <Token
                                                key={`rpName|${index}`}
                                                style={spacing.sapUiTinyMargin}
                                                readonly
                                                text={item.bpUsername}
                                            />
                                        ))}
                                    </Text>
                                </FormItem>
                                <FormItem label="Quote Submission Deadline">
                                    <Text style={spacing.sapUiTinyMargin}>
                                        {new Date(orderItemInfo.submissionDeadline).toDateString()}
                                    </Text>
                                </FormItem>
                                <FormItem label="Additional information">
                                    <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.orderAdditionalInfo}</Text>
                                </FormItem>
                                <FormItem label="Picture">
                                    <Link style={spacing.sapUiTinyMargin} target="_blank" onClick={downloadPicture}>
                                        {orderItemInfo.pictureLoc}
                                    </Link>
                                </FormItem>
                            </FormGroup>
                        </Form>
                    )}
                    {orderItemInfo.orderType === '2' && (
                        <Form
                            columnsL={2}
                            columnsM={2}
                            columnsS={2}
                            labelSpanM={5}
                            style={spacing.sapUiLargeMarginTopBottom}
                        >
                            <FormGroup>
                                <FormItem label="Order Type">
                                    <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.processType}</Text>
                                </FormItem>
                                <FormItem label="Category">
                                    <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.categoryName}</Text>
                                </FormItem>
                                <FormItem label="Subcategory">
                                    <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.subCategoryName}</Text>
                                </FormItem>
                                <FormItem label="Asset Type ">
                                    <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.recycleAssetType || '-'}</Text>
                                </FormItem>
                                <FormItem label="Total Weight ">
                                    <Text style={spacing.sapUiTinyMargin}>
                                        {orderItemInfo.totalWeight ? `${orderItemInfo.totalWeight} KG` : '-'}
                                    </Text>
                                </FormItem>
                            </FormGroup>
                            <FormGroup>
                                <FormItem label="Network">
                                    <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.orderNetwork}</Text>
                                </FormItem>
                                <FormItem label="Recyclers">
                                    <Text style={spacing.sapUiTinyMargin}>
                                        {orderItemInfo.recyclers.map((item, idx) => (
                                            <Token
                                                key={idx}
                                                style={spacing.sapUiTinyMargin}
                                                readonly
                                                text={item.bpUsername}
                                            />
                                        ))}
                                    </Text>
                                </FormItem>
                                <FormItem label="Quote Submission Deadline">
                                    <Text style={spacing.sapUiTinyMargin}>
                                        {new Date(orderItemInfo.submissionDeadline).toDateString()}
                                    </Text>
                                </FormItem>
                                <FormItem label="Additional information">
                                    <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.orderAdditionalInfo}</Text>
                                </FormItem>
                                <FormItem label="Picture">
                                    <Link style={spacing.sapUiTinyMargin} target="_blank" onClick={downloadPicture}>
                                        {orderItemInfo.pictureLoc}
                                    </Link>
                                </FormItem>
                            </FormGroup>
                        </Form>
                    )}
                </div>
            )}
            {mode === 'edit' && (
                <OrderHeaderFormEdit
                    orderId={orderItemInfo.orderId}
                    formFields={OrderFormFieldSpec}
                    setFormFieldsState={setOrderFormFieldSpec}
                    onSubmit={onSubmit}
                    orderPayloadParent={orderPayload}
                />
            )}
        </>
    );
};

OrderHeaderView.propTypes = {
    orderItemInfo: PropTypes.object,
    startUpdateOrderHeaderData: PropTypes.func.isRequired,
    startDownloadPicture: PropTypes.func.isRequired
};

const mapStateToProps = () => ({});

const mapDispatchToProps = (dispatch) => ({
    startUpdateOrderHeaderData: (orderId, payload) => dispatch(updateOrderHeaderData(orderId, payload)),
    startDownloadPicture: (orderId, key) => dispatch(downloadDocument(orderId, key))
});

export default connect(mapStateToProps, mapDispatchToProps)(OrderHeaderView);
