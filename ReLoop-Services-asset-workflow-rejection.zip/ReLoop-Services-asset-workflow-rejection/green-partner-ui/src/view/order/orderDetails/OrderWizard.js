import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { Wizard, WizardStep, Toolbar } from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import OrderCreation from './OrderCreationStep';
import RecycleOrderCreation from './RecycleOrderCreationStep';
import RecycleQuoteSubmission from './RecycleQuoteSubmissionStep';
import QuoteSubmission from './QuoteSubmissionStep';
import QuoteSelection from './QuoteSelectionStep';
import ScheduleOnsiteVisit from './ScheduleVisitStep';
import RecycleApproveFinalQuote from './RecycleApproveQuoteStep';
import ApproveFinalQuote from './ApproveQuoteStep';
import Logistics from './LogisticsStep';

const applyCSS = async () => {
    const dom = document.querySelector('ui5-wizard');
    if (dom) {
        // Set timeout is used to trigger async job which will be invoked after the components is rendered.
        setTimeout(() => {
            const shadowDOM = dom.shadowRoot;
            const style = document.createElement('style');
            style.innerHTML = '.ui5-wiz-content { overflow: hidden !important; background: none !important }';
            shadowDOM.appendChild(style);
        }, 0);
    }
};

const OrderWizard = ({
    steps,
    orderId,
    orderType,
    consolidatedOrderItemInfo,
    orderItemInfo,
    orderQuotation,
    onNextStep
}) => {
    useEffect(() => {
        applyCSS();
    });
    const getStepContent = (step) => {
        switch (step) {
            case '1':
                return <OrderCreation orderItemInfo={orderItemInfo} onNextStep={onNextStep} />;
            case '2':
                return (
                    <QuoteSubmission
                        currentSequence={orderItemInfo.currentSequence}
                        consolidatedOrderItemInfo={consolidatedOrderItemInfo}
                        onNextStep={onNextStep}
                    />
                );
            case '3':
                return (
                    <QuoteSelection
                        currentSequence={orderItemInfo.currentSequence}
                        orderId={orderId}
                        orderType={orderItemInfo.orderType}
                        orderQuotation={orderQuotation}
                        onNextStep={onNextStep}
                    />
                );
            case '4':
                return <ScheduleOnsiteVisit orderId={orderId} />;
            case '5':
                return (
                    <ApproveFinalQuote
                        currentSequence={orderItemInfo.currentSequence}
                        orderId={orderId}
                        orderType={orderItemInfo.orderType}
                    />
                );
            case '6':
                return <Logistics />;
            default:
                return 'Unknown step';
        }
    };

    const getRecycleStepContent = (step) => {
        switch (step) {
            case '1':
                return <RecycleOrderCreation orderItemInfo={orderItemInfo} onNextStep={onNextStep} />;
            case '2':
                return (
                    <RecycleQuoteSubmission
                        currentSequence={orderItemInfo.currentSequence}
                        orderItemInfo={orderItemInfo}
                        onNextStep={onNextStep}
                    />
                );
            case '3':
                return (
                    <QuoteSelection
                        currentSequence={orderItemInfo.currentSequence}
                        orderId={orderId}
                        totalWeight={orderItemInfo.totalWeight}
                        orderType={orderItemInfo.orderType}
                        orderQuotation={orderQuotation}
                        onNextStep={onNextStep}
                    />
                );
            case '4':
                return <ScheduleOnsiteVisit orderId={orderId} />;
            case '5':
                return (
                    <RecycleApproveFinalQuote
                        currentSequence={orderItemInfo.currentSequence}
                        orderId={orderId}
                        orderType={orderItemInfo.orderType}
                    />
                );
            case '6':
                return <Logistics />;
            default:
                return 'Unknown step';
        }
    };
    return (
        <Wizard style={{ height: '100%' }}>
            {Object.keys(steps).map((idx) => (
                <WizardStep
                    titleText={steps[idx].name}
                    selected={steps[idx].selected}
                    disabled={steps[idx].disabled}
                    key={idx}
                >
                    {idx === '1' || idx === '6' ? null : <Toolbar style={{ ...spacing.sapUiTinyMarginTopBottom }} />}
                    {!steps[idx].disabled &&
                        (orderItemInfo.orderType === '1' ? getStepContent(idx) : getRecycleStepContent(idx))}
                </WizardStep>
            ))}
        </Wizard>
    );
};

OrderWizard.propTypes = {
    orderId: PropTypes.string,
    orderType: PropTypes.string,
    orderItemInfo: PropTypes.object,
    consolidatedOrderItemInfo: PropTypes.object,
    orderQuotation: PropTypes.object,
    steps: PropTypes.object,
    onNextStep: PropTypes.func.isRequired
};

OrderWizard.defaultProps = {
    steps: {}
};

export default OrderWizard;
