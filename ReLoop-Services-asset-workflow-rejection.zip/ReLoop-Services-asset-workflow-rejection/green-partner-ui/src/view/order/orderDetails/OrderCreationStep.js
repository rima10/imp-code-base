import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { Button, Toolbar, ToolbarSpacer, FileUploader } from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import { useHistory } from 'react-router-dom';
import AccountTable from '../../common/Table';
import { createOrderWorkflow, cancelOrder, updateAssetListFromExcel, resendApprovalRequest } from '../../../store/action/order';
import LoadingIndicator from '../../common/Loading';
import { showMessage } from '../../../store/action/toast';
import CommentDialog from '../../common/Dialog';
import OrderHeaderView from './OrderHeaderDetailsView';
import StatusColor from '../../../asset/constants/statusColor';

const OrderCreation = ({
    orderItemInfo,
    onNextStep,
    startCreateOrderWorkflow,
    startCancelOrder,
    startShowMessage,
    startUpdateAssetListFromExcel,
    startResendApprovalRequest
}) => {
    const [assetRows, setAssetRows] = useState([]);
    const [approverRows, setApproverRows] = useState([]);
    const [showLoader, setShowLoader] = useState(false);
    const [orderEditAllowed, setOrderEditAllowed] = useState(false);
    const history = useHistory();
    const dialogRef = useRef(null);
    const resendApprovalDialogRef = useRef(null);
    const processStageSequence = '1';

    const [rejectedWorkflow, setRejectedWorkflow] = useState(false);
    const rejectedWorkflowMessage = `The asset list proposal has been rejected by one or more approver(s). 
    Please check the comment section for more details or contact your colleagues. You can either re-upload 
    the updated Excel file or re-send it for approval without any changes.`;

    const assetColumns = [
        'Equipment No.',
        'Asset No.',
        'Location',
        'Bond Status',
        'Item Type',
        'Make',
        'Model',
        'Manuf. Serial No.',
        'Age in Years',
        'Purchase Year',
        'Description'
    ];

    const approverColumns = ['Approver Sequence', 'Approver Name', 'Approver Role', 'Status', 'Comments'];

    const sendForApproval = (event) => {
        const payload = {
            orderId: orderItemInfo.orderId,
            processStageSequence,
            processType: orderItemInfo.orderType
        };
        if (event.comments) {
            // comes from the comment dialog box
            payload.commentsForApprover = event.comments;
        }
        startCreateOrderWorkflow(payload);
        dialogRef.current.close();
    };

    const resendForApproval = (event) => {
        const payload = {};
        if (event.comments) {
            // comes from the comment dialog box
            payload.comment = event.comments;
            payload.processType = orderItemInfo.orderType;
        }
        const { orderWorkflowApproverId } = rejectedWorkflow;
        startResendApprovalRequest(orderItemInfo.orderId, orderWorkflowApproverId, payload);
        resendApprovalDialogRef.current.close();
    };

    const getOrderItemDetails = (orderItems, limit) => {
        const newRows = [];
        const limitedRows = orderItems.slice(0, limit);
        limitedRows.forEach((index) => {
            const row = [];
            row.push({ name: assetColumns[0], value: index.equipmentNumber, type: 'text' });
            row.push({ name: assetColumns[1], value: index.assetNumber, type: 'text' });
            row.push({ name: assetColumns[2], value: index.buildingLocation, type: 'text' });
            row.push({ name: assetColumns[3], value: index.bondStatus, type: 'text' });
            row.push({ name: assetColumns[4], value: index.itemType, type: 'text' });
            row.push({ name: assetColumns[5], value: index.make, type: 'text' });
            row.push({ name: assetColumns[6], value: index.model, type: 'text' });
            row.push({ name: assetColumns[7], value: index.manufactureSerial, type: 'text' });
            row.push({ name: assetColumns[8], value: index.ageInYear, type: 'text' });
            row.push({ name: assetColumns[9], value: index.purchaseYear, type: 'text' });
            row.push({ name: assetColumns[10], value: index.description, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };
    const minDisplayRows = 10;
    const minTableHeight = '400px';
    const loadMoreAssetRows = () => {
        setAssetRows((previousRows) => [
            ...getOrderItemDetails(orderItemInfo.orderItems, previousRows.length + minDisplayRows)
        ]);
    };
    useEffect(() => {
        if (orderItemInfo.orderItems) {
            const rows = getOrderItemDetails(orderItemInfo.orderItems, minDisplayRows);
            setAssetRows(rows);
        }
        if (orderItemInfo.orderPosition === 'Draft') {
            setOrderEditAllowed(true);
        }
    }, [orderItemInfo.orderItems]);

    const getOrderCreationApproverActivityId = (workflowApprover) =>
        // eslint-disable-next-line max-len
        `pss_${processStageSequence}|gpapp_${workflowApprover.approverId}|wkappid_${workflowApprover.workflowApproverId}`;
    const getApproverDetails = (workflowApprovers) => {
        const newRows = [];
        workflowApprovers.forEach((workflowApprover) => {
            const row = [];
            row.push({
                name: approverColumns[0],
                value: workflowApprover.approverSequence,
                type: 'text'
            });
            row.push({
                name: approverColumns[1],
                value: workflowApprover.approverName,
                type: 'text'
            });
            row.push({
                name: approverColumns[2],
                value: workflowApprover.approverRole,
                type: 'text'
            });
            row.push({
                name: approverColumns[3],
                value: workflowApprover.status,
                type: 'text'
            });

            // sort ordernotes to latest first
            orderItemInfo.orderNotes.sort((a, b) => (new Date(b.timestamp) - new Date(a.timestamp)));

            const approverComments = orderItemInfo.orderNotes.find(
                (item) => (item.activity_identifier === getOrderCreationApproverActivityId(workflowApprover)
                    && (workflowApprover.status === 'Approved' || workflowApprover.status === 'Rejected'))
            );
            row.push({
                name: approverColumns[4],
                value: approverComments ? approverComments.comment : '-',
                type: 'text'
            });
            newRows.push(row);
        });
        return newRows;
    };

    function checkIfWorkflowRejected() {
        if (orderItemInfo.workflow) {
            const { workflowApprovers } = orderItemInfo.workflow;
            const rejectedApprover = workflowApprovers.find((workflowApprover) => workflowApprover.status === "Rejected");
            if (rejectedApprover) {
                setRejectedWorkflow(rejectedApprover);
            }
        }
    };

    useEffect(() => {
        if (orderItemInfo.workflow) {
            const rows = getApproverDetails(orderItemInfo.workflow.workflowApprovers);
            setApproverRows(rows);
            checkIfWorkflowRejected();
        }
    }, [orderItemInfo.workflow]);

    const getNextBtnDisabled = (workflow) => {
        if (!workflow) return false;
        const { workflowApprovers } = workflow;
        let isDisabled = false;
        for (let i = 0; i < workflowApprovers.length; i += 1) {
            if (workflowApprovers[i].status !== 'Approved') {
                isDisabled = true;
                break;
            }
        }
        return isDisabled;
    };

    const onCancelOrder = () => {
        setShowLoader(true);
        const { orderId, orderNumber } = orderItemInfo;
        startCancelOrder(orderId)
            .then(() => {
                setShowLoader(false);
                startShowMessage({
                    message: `Your Order ${orderNumber} has been cancelled.`,
                    status: StatusColor.Positive
                });
                history.push('/order/previousOrder');
            })
            .catch(() => {
                setShowLoader(false);
            });
    };

    const renderButton = () => {
        if (Number(orderItemInfo.currentSequence) === 1 && orderItemInfo.orderPosition !== 'Cancelled') {
            if (orderItemInfo.orderPosition !== 'Draft') {
                return (
                    <>
                        <Toolbar>
                            <ToolbarSpacer />
                            <Button onClick={onCancelOrder}>Cancel Order</Button>
                            <Button
                                design="Emphasized"
                                disabled={getNextBtnDisabled(orderItemInfo.workflow)}
                                onClick={() => onNextStep(1)}
                            >
                                Check Order Before Submission
                            </Button>
                        </Toolbar>
                    </>
                );
            }
            return (
                <>
                    <Toolbar toolbarStyle="Clear">
                        <ToolbarSpacer />
                        <Button onClick={onCancelOrder}>Cancel Order</Button>
                        <Button design="Emphasized" onClick={() => dialogRef.current.show()}>
                            Send Asset List for Internal Approval
                        </Button>
                    </Toolbar>
                </>
            );
        }
        return <></>;
    };

    const validateAssetExcelUpload = (file) => {
        const oneMBinBytes = 1 * 1024 * 1024;
        if (file.size > oneMBinBytes) {
            startShowMessage({
                message: 'Cannot upload File of size above 1 MB',
                status: StatusColor.Negative
            });
            return false;
        }
        if (file.type !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
            startShowMessage({
                message: 'Only Excel (.xlsx) files are accepted',
                status: StatusColor.Negative
            });
            return false;
        }
        return true;
    };

    const [isTableOperation, setTableOperation] = useState(false);
    const onFileChangeHandler = (event) => {
        const processType = orderItemInfo.orderType;
        const fileform = new FormData();
        const fileMeta = event.target.files[0];
        fileform.append(event.target.name, fileMeta);
        if (validateAssetExcelUpload(fileMeta)) {
            setTableOperation(true);
            startUpdateAssetListFromExcel(orderItemInfo.orderId, processType, fileform)
                .then(() => {
                    setTableOperation(false);
                })
                .catch(() => {
                    setTableOperation(false);
                });
        }
    };
    const assetTableButtons = [
        {
            name: 'Update Asset List',
            hide: !orderEditAllowed && !rejectedWorkflow,
            html: (
                <FileUploader name="assetExcel" accept=".xlsx" onChange={onFileChangeHandler} hideInput>
                    <Button icon="download">Update Asset List</Button>
                </FileUploader>
            )
        },
        {
            name: 'Resend for Approval',
            icon: 'response',
            hide: !rejectedWorkflow,
            onClick: (event) => {
                resendApprovalDialogRef.current.show();
            }
        }
    ];

    return (
        <div style={{ height: '100%', margin: '10px' }}>
            {showLoader && <LoadingIndicator />}
            <OrderHeaderView orderItemInfo={orderItemInfo} />
            <AccountTable
                isBusy={isTableOperation}
                text="Asset List"
                columns={assetColumns}
                rows={assetRows}
                lazyLoading={loadMoreAssetRows}
                height={minTableHeight}
                buttons={assetTableButtons}
                tableError={rejectedWorkflow ? rejectedWorkflowMessage : false}
            />
            <AccountTable
                text="Asset List Approval Workflow"
                columns={approverColumns}
                edit={false}
                rows={approverRows}
            />
            {renderButton()}
            <CommentDialog
                ref={dialogRef}
                onCancel={() => dialogRef.current.close()}
                onSubmit={sendForApproval}
                headerText="Send Asset List for Internal Approval"
            />
            <CommentDialog
                ref={resendApprovalDialogRef}
                onCancel={() => resendApprovalDialogRef.current.close()}
                onSubmit={resendForApproval}
                headerText="Resend Asset List for Internal Approval"
            />
        </div>
    );
};

const mapStateToProps = () => ({});

const mapDispatchToProps = (dispatch) => ({
    startCreateOrderWorkflow: (payload) => dispatch(createOrderWorkflow(payload)),
    startResendApprovalRequest: (orderId, orderWorkflowApprId, payload) =>
        dispatch(resendApprovalRequest(orderId, orderWorkflowApprId, payload)),
    startCancelOrder: (orderId) => dispatch(cancelOrder(orderId)),
    startShowMessage: (payload) => dispatch(showMessage(payload)),
    startUpdateAssetListFromExcel: (orderId, processType, payload) =>
        dispatch(updateAssetListFromExcel(orderId, processType, payload))
});

OrderCreation.propTypes = {
    orderItemInfo: PropTypes.object,
    onNextStep: PropTypes.func.isRequired,
    startCreateOrderWorkflow: PropTypes.func.isRequired,
    startCancelOrder: PropTypes.func.isRequired,
    startShowMessage: PropTypes.func.isRequired,
    startUpdateAssetListFromExcel: PropTypes.func.isRequired,
    startResendApprovalRequest: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderCreation);
