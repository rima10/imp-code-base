import React from 'react';
import PropTypes from 'prop-types';
import { AnalyticalTable, Button, ObjectStatus, Text } from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import { rejectQuote, temporaryAcceptQuote } from '../../../store/action/quote';

const RecycleQuotesTable = ({
    orderId,
    orderType,
    orderQuotation,
    approverLength,
    totalWeight,
    startRejectQuote,
    startTemporaryAcceptQuote,
    currentSequence
}) => {
    const getValueState = (value) => {
        if (value === 'In Review') {
            return 'Warning';
        }
        if (value === 'Accepted' || value === 'Temporarily Accepted') {
            return 'Success';
        }
        if (value === 'Rejected') {
            return 'Error';
        }
        return 'Information';
    };
    const getQuoteStatus = (value) => {
        if (value === 'Accepted' || value === 'Temporarily Accepted') {
            return 'Accepted';
        }
        return value;
    };

    const onAcceptQuote = (quoteId) => {
        startTemporaryAcceptQuote(orderId, quoteId, orderType);
    };

    const onRejectQuote = (quoteId) => {
        startRejectQuote(orderId, quoteId, orderType);
    };

    const renderButton = (value) => {
        let disabled = false;
        if (currentSequence >= 4) {
            disabled = true;
        }
        if (value) {
            const status = orderQuotation.quotesData.find((quote) => quote.quoteId === value).quoteStatus;
            if (status === 'Accepted' || status === 'Temporarily Accepted') {
                return (
                    <>
                        <Button disabled={disabled} onClick={() => onRejectQuote(value)} design="Negative">
                            Reject Quote
                        </Button>
                    </>
                );
            }
            if (
                orderQuotation.quotesOverallStatus === 'Accepted' ||
                orderQuotation.quotesOverallStatus === 'Temporarily Accepted'
            ) {
                return <Button disabled>Accept Quote</Button>;
            }
            return (
                <Button onClick={() => onAcceptQuote(value)} disabled={disabled}>
                    Accept Quote
                </Button>
            );
        }
        return null;
    };

    const renderName = (value) => {
        if (typeof value === 'object' && value !== null) {
            return (
                <Text>
                    {value.name} ({value.count})
                </Text>
            );
        }
        return <Text>{value}</Text>;
    };

    const renderPrice = (instance) => {
        let price = '-';
        if (!instance.cell.value) price = '';
        if (totalWeight && instance.cell.value) price = instance.cell.value * totalWeight;
        return <Text>{price}</Text>;
    };

    const getQuotesTableColumns = () => {
        const columns = [
            {
                Header: 'Recycler Company',
                accessor: 'name',
                Cell: (instance) => renderName(instance.cell.value),
                width: 240
            },
            {
                Header: 'Price/kg (INR)',
                accessor: 'pricePerKg',
                Cell: (instance) => <Text>{instance.cell.value}</Text>
            },
            {
                Header: 'Total Price (INR)',
                id: 'totalPrice',
                accessor: 'pricePerKg',
                Cell: (instance) => renderPrice(instance)
            },
            {
                Header: 'Comments',
                accessor: 'quoteComments',
                Cell: (instance) => <Text>{instance.cell.value}</Text>
            },
            {
                Header: 'Status',
                accessor: 'quoteStatus',
                Cell: (instance) => (
                    <ObjectStatus state={getValueState(instance.cell.value)}>
                        {getQuoteStatus(instance.cell.value)}
                    </ObjectStatus>
                )
            }
        ];
        if (approverLength === 0) {
            columns.push({
                Header: 'Action',
                accessor: 'quoteId',
                Cell: (instance) => renderButton(instance.cell.value)
            });
        }
        return columns;
    };

    return (
        <AnalyticalTable
            columns={getQuotesTableColumns()}
            data={orderQuotation.quotesData}
            isTreeTable
            minRows={1}
            subRowsKey="data"
        />
    );
};

const mapStateToProps = () => ({});

const mapDispatchToProps = (dispatch) => ({
    startRejectQuote: (orderId, quoteId, orderType) => dispatch(rejectQuote(orderId, quoteId, orderType)),
    startTemporaryAcceptQuote: (orderId, quoteId, orderType) =>
        dispatch(temporaryAcceptQuote(orderId, quoteId, orderType))
});

RecycleQuotesTable.propTypes = {
    orderQuotation: PropTypes.object,
    orderId: PropTypes.string,
    orderType: PropTypes.string,
    approverLength: PropTypes.number,
    startRejectQuote: PropTypes.func.isRequired,
    totalWeight: PropTypes.string,
    startTemporaryAcceptQuote: PropTypes.func.isRequired,
    currentSequence: PropTypes.string
};

export default connect(mapStateToProps, mapDispatchToProps)(RecycleQuotesTable);
