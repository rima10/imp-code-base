import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import { getAccessToken } from '../../store/action/taskAction';
import LoadingIndicator from '../common/Loading';
import ErrorComponent from '../common/Error';
import { getUserData, isLoadingData } from '../../selectors/common';

const LoginSuccess = ({ userInfo, isLoading = true, startGetAccessToken }) => {
    useEffect(() => {
        startGetAccessToken();
    }, []);

    const redirect = (isInitialSetupDone) =>
        isInitialSetupDone ? <Redirect to="/order/newOrder" /> : <Redirect to="/initialSetup" />;

    if (isLoading) {
        return <LoadingIndicator />;
    }
    const isInitialSetupDone = userInfo.isBusinessDataPresent;
    return userInfo.isLoggedIn ? redirect(isInitialSetupDone) : <ErrorComponent text="Login Failed" redirect />;
};

const mapStateToProps = (state) => ({
    isLoading: isLoadingData(state),
    userInfo: getUserData(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetAccessToken: () => dispatch(getAccessToken())
});

LoginSuccess.propTypes = {
    startGetAccessToken: PropTypes.func.isRequired,
    isLoading: PropTypes.bool,
    userInfo: PropTypes.object
};

export default connect(mapStateToProps, mapDispatchToProps)(LoginSuccess);
