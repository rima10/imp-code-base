import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Route, useHistory } from 'react-router-dom';
import CognitoRedirect from './CognitoRedirect';
import { validateUser } from '../../store/action/taskAction';
import LoadingIndicator from '../common/Loading';
import { getUserData, isLoadingData } from '../../selectors/common';

const PrivateRoute = ({ check, component: Component, path, isLoading, startValidateUser, userInfo, ...rest }) => {
    useEffect(() => {
        startValidateUser();
    }, []);
    const history = useHistory();
    const redirect = <CognitoRedirect />;
    const routeComponent = (props) => {
        if (isLoading) return <LoadingIndicator />;
        if (check && userInfo.isPartOfPvtNwk === true) {
            history.push('/404');
        } else if (path === '/initialSetup' && userInfo.isBusinessDataPresent) {
            history.push('/404');
        } else {
            return userInfo.isLoggedIn ? <Component {...props} userInfo={userInfo} /> : redirect;
        }
    };
    return <Route path={path} {...rest} render={(props) => routeComponent(props)} />;
};

const mapStateToProps = (state) => ({
    isLoading: isLoadingData(state),
    userInfo: getUserData(state)
});

const mapDispatchToProps = (dispatch) => ({
    startValidateUser: () => dispatch(validateUser())
});

PrivateRoute.propTypes = {
    component: PropTypes.elementType,
    path: PropTypes.string,
    startValidateUser: PropTypes.func.isRequired,
    isLoading: PropTypes.bool,
    userInfo: PropTypes.object,
    check: PropTypes.bool
};

PrivateRoute.defaultProps = {
    userInfo: {}
};

export default connect(mapStateToProps, mapDispatchToProps)(PrivateRoute);
