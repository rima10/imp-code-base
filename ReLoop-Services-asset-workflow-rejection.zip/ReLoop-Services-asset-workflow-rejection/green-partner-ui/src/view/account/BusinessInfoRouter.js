import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import BusinessInfoForm from './BusinessInfoForm';
import BusinessInfoView from './BusinessInfoView';
import { getUserData, getBusinessInfoData, isBusinessInfoLoading } from '../../selectors/common';
import { getBusinessInfo } from '../../store/action/account';
import LoadingIndicator from '../common/Loading';

const BusinessInfo = ({ businessInfo, startGetBusinessInfo, isLoading, userInfo }) => {
    const [showBiForm, setShowBiForm] = useState(!userInfo.isBusinessDataPresent);

    useEffect(() => {
        startGetBusinessInfo();
    }, []);

    const onEditClick = () => {
        setShowBiForm(true);
    };

    const onBiSave = () => {
        setShowBiForm(false);
    };

    const isBiView = !showBiForm && userInfo.isBusinessDataPresent;
    const component = isBiView ? (
        <BusinessInfoView businessInfo={businessInfo} onEditClick={onEditClick} />
    ) : (
        <BusinessInfoForm businessInfo={businessInfo} onBiSave={onBiSave} />
    );

    return (
        <>
            {isLoading && <LoadingIndicator />}
            {component}
        </>
    );
};

const mapStateToProps = (state) => ({
    userInfo: getUserData(state),
    businessInfo: getBusinessInfoData(state),
    isLoading: isBusinessInfoLoading(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetBusinessInfo: () => dispatch(getBusinessInfo())
});

BusinessInfo.propTypes = {
    startGetBusinessInfo: PropTypes.func.isRequired,
    isLoading: PropTypes.bool.isRequired,
    userInfo: PropTypes.instanceOf(Object).isRequired,
    businessInfo: PropTypes.instanceOf(Object).isRequired
};

export default connect(mapStateToProps, mapDispatchToProps)(BusinessInfo);
