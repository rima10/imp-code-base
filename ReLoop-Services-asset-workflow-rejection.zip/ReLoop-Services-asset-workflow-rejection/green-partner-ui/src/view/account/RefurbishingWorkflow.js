import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import WorkflowWizard from '../common/WorkflowWizard';

const defaultSteps = {
    1: {
        name: 'Order Creation',
        selected: true,
        disabled: false,
        showTable: false
    },
    2: {
        name: 'Order Submission',
        selected: false,
        disabled: true,
        showTable: false
    },
    3: {
        name: 'Quotation Request',
        selected: false,
        disabled: false,
        showTable: false
    },
    4: {
        name: 'Logistics',
        selected: false,
        disabled: false,
        showTable: false
    }
};

const onSiteSteps = {
    1: {
        name: 'Order Creation',
        selected: true,
        disabled: false,
        showTable: false
    },
    2: {
        name: 'Order Submission',
        selected: false,
        disabled: true,
        showTable: false
    },
    3: {
        name: 'Quote Selection',
        selected: false,
        disabled: false,
        showTable: false
    },
    4: {
        name: 'Schedule Onsite Visit',
        selected: false,
        disabled: true,
        showTable: false
    },
    5: {
        name: 'Approval of Final Quote',
        selected: false,
        disabled: false,
        showTable: false
    },
    6: {
        name: 'Logistics',
        selected: false,
        disabled: true,
        showTable: false
    }
};

const RefurbishingWorkflow = ({ workflows = [], isOnSite }) => {
    const [steps, setSteps] = useState(onSiteSteps);
    useEffect(() => {
        isOnSite = isOnSite ? setSteps(onSiteSteps) : setSteps(defaultSteps);
    }, [isOnSite]);

    const onNextClick = (stepId) => {
        const newSteps = { ...steps };
        stepId = Number(stepId);
        if (stepId !== Object.keys(steps).length) {
            newSteps[stepId].selected = false;
            newSteps[stepId + 1].selected = true;
            newSteps[stepId + 1].disabled = false;
            setSteps(newSteps);
        }
    };
    const processArr = [];
    useEffect(() => {
        const updatedSteps = { ...steps };
        if (workflows.length) {
            workflows.forEach((workflow) => {
                // eslint-disable-next-line camelcase
                const { process_stage_sequence, workflow_approvers, workflow_id } = workflow;
                const step = updatedSteps[process_stage_sequence];
                processArr.push(process_stage_sequence);
                // eslint-disable-next-line camelcase
                step.approvers = workflow_approvers;
                step.showTable = true;
                // eslint-disable-next-line camelcase
                step.workflowId = workflow_id;
            });
        }
        Object.keys(updatedSteps).forEach((step) => {
            if (!processArr.includes(step)) {
                steps[step].showTable = false;
                steps[step].approvers = [];
                steps[step].workflowId = '';
            }
        });
        setSteps(updatedSteps);
    }, [JSON.stringify(workflows)]);

    return <WorkflowWizard steps={steps} processTypeId="1" onNextClick={onNextClick} />;
};

RefurbishingWorkflow.propTypes = {
    workflows: PropTypes.array,
    isOnSite: PropTypes.bool
};

RefurbishingWorkflow.defaultProps = {
    workflows: []
};

export default RefurbishingWorkflow;
