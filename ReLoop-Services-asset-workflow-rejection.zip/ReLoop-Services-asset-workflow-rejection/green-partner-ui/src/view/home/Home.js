import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { Card, CardHeader, Dialog, Button, Link, Bar, Text } from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import { spacing } from '@ui5/webcomponents-react-base';
import BusinessProfileWorkflow from './BusinessProfileWorkflow';
import SetupProfile from './SetupProfile';
import { downloadPrivacyStatement } from '../../store/action/taskAction';

const Home = ({ startDownloadPrivacyStatement }) => {
    const [isHidden, setIsHidden] = useState(true);
    const dialogRef = useRef();

    useEffect(() => {
        dialogRef.current.show();
    }, []);

    const onCancel = () => {
        dialogRef.current.close();
    };

    const onViewPrivacyStatement = (key) => {
        startDownloadPrivacyStatement(key);
    };

    return (
        <>
            <Card header={<CardHeader titleText="Home" />} />
            {isHidden ? <SetupProfile toggleHidden={() => setIsHidden()} /> : <BusinessProfileWorkflow />}
            <Dialog
                ref={dialogRef}
                headerText="Welcome to EverLoop!"
                footer={
                    <Bar
                        style={{ background: 'var(--sapShellColor)' }}
                        endContent={<Button onClick={onCancel}>OK</Button>}
                    />
                }
            >
                <Text style={{ fontSize: 'var(--sapFontSize)', ...spacing.sapUiSmallMargin }}>
                    You can learn about how we collect and use data in our
                    <Link onClick={() => onViewPrivacyStatement('Privacy Information Notice - Version 3.0.pdf')}>
                        &nbsp;EverLoop Privacy Information Notice
                    </Link>
                </Text>
            </Dialog>
        </>
    );
};

const mapDispatchToProps = (dispatch) => ({
    startDownloadPrivacyStatement: (key) => dispatch(downloadPrivacyStatement(key))
});

Home.propTypes = {
    startDownloadPrivacyStatement: PropTypes.func.isRequired
};

export default connect(null, mapDispatchToProps)(Home);
