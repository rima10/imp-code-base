import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Title, Label, FlexBox } from '@ui5/webcomponents-react';
import bg from '../../asset/images/background-image.png';
import BusinessProfileWizard from './BusinessProfileWizard';
import { getUserData } from '../../selectors/common';
import { isEmpty } from '../../validation/common';

const defaultSteps = {
    1: {
        name: 'Business Profile',
        selected: true,
        disabled: false
    },
    3: {
        name: "Approver's Data",
        selected: false,
        disabled: true
    },
    4: {
        name: 'Approval Workflows',
        selected: false,
        disabled: true
    }
};

const BusinessProfileWorkflow = ({ userInfo }) => {
    if (isEmpty(userInfo.isPartOfPvtNwk) || userInfo.isPartOfPvtNwk === false) {
        defaultSteps[2] = {
            name: 'Private Network',
            selected: false,
            disabled: true
        };
    }

    const [steps, setSteps] = useState(defaultSteps);

    const onNextClick = (stepId) => {
        const newSteps = { ...steps };
        stepId = Number(stepId);
        Object.keys(newSteps).forEach((stepNo) => {
            if (stepId === Number(stepNo)) {
                newSteps[stepNo].selected = true;
                newSteps[stepNo].disabled = false;
            } else {
                newSteps[stepNo].disabled = true;
                newSteps[stepNo].selected = false;
            }
        });
        setSteps(newSteps);
    };

    return (
        <>
            <FlexBox alignItems="Center" style={{ backgroundImage: `url(${bg})`, height: '270px' }} direction="Column">
                <Title
                    style={{
                        fontSize: 'x-large',
                        textAlign: 'center',
                        marginTop: '60px',
                        color: '#000000'
                    }}
                >
                    <b>Welcome to EverLoop!</b>
                </Title>
                <Label
                    wrappingType="Normal"
                    style={{
                        fontSize: 'large',
                        textAlign: 'center',
                        marginTop: '20px',
                        color: '#000000'
                    }}
                >
                    The platform for recycling and refurbishing your electronic assets.
                </Label>
                <br />
                <Label
                    wrappingType="Normal"
                    style={{
                        fontSize: 'large',
                        textAlign: 'center',
                        color: '#000000'
                    }}
                >
                    In order to use the platform and be able to create orders, you have to pre-setup your account first.
                </Label>
            </FlexBox>
            <BusinessProfileWizard steps={steps} onNextClick={onNextClick} />
        </>
    );
};

const mapStateToProps = (state) => ({
    userInfo: getUserData(state)
});

BusinessProfileWorkflow.propTypes = {
    userInfo: PropTypes.object
};

export default connect(mapStateToProps)(BusinessProfileWorkflow);
