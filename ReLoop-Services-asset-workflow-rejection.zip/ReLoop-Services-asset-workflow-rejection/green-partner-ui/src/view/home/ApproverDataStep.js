import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Grid, Input, Button, Label, FlexBox, Title, Icon, Loader } from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import { useHistory, withRouter } from 'react-router-dom';
import { showMessage } from '../../store/action/toast';
import { getUserData } from '../../store/action/taskAction';
import { registerBPApproverInfo } from '../../store/action/account';
import validateInput from '../../validation/ApproverData';
import { isApproverInfoLoading } from '../../selectors/common';
import { camelCaseToSentence } from '../../utils/formatter';
import StatusColor from '../../asset/constants/statusColor';

const ApproverDataStep = ({
    onNextClick,
    startRegisterBPApproverInfo,
    isLoading,
    startGetUserData,
    startShowMessage
}) => {
    const [inputBox, setInputBox] = useState([
        {
            approverRole: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                required: true
            },
            approverName: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                required: true
            },
            emailAddress: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                required: true
            }
        }
    ]);

    const history = useHistory();

    const onSave = () => {
        let isValid = true;
        const tempInputBox = [...inputBox];
        if (!tempInputBox.length) {
            isValid = false;
            startShowMessage({
                message: "Add Approver's Data to continue.",
                status: StatusColor.Negative
            });
        } else {
            tempInputBox.forEach((input, idx) => {
                Object.keys(input).forEach((field) => {
                    // check to find whether value is empty for required fields
                    if (tempInputBox[idx][field].required && tempInputBox[idx][field].value === '') {
                        const fieldName = camelCaseToSentence(field);
                        tempInputBox[idx][field].valueState = 'Error';
                        tempInputBox[idx][field].valueStateMessage = <span>{fieldName} is required</span>;
                        isValid = false;
                    }
                    // check to find whether any field has error state
                    if (tempInputBox[idx][field].valueState === 'Error') {
                        isValid = false;
                    }
                });
            });
        }
        if (isValid) {
            const payload = { approvers: [] };
            inputBox.forEach((input) => {
                payload.approvers.push({
                    approverEmailId: input.emailAddress.value,
                    approverName: input.approverName.value,
                    approverRole: input.approverRole.value
                });
            });
            startRegisterBPApproverInfo(payload).then(() => onNextClick('4'));
        } else {
            setInputBox(tempInputBox);
        }
    };

    const onInputChange = (event) => {
        const tempInputBox = [...inputBox];
        const { id } = event.target;
        const split = id.split('-');
        const field = split[0];
        const idx = split[1];
        let { value } = event.target;
        if (field === 'emailAddress') {
            value = value.toLowerCase();
        }
        const { isValid, errorMessage } = validateInput(value, field);
        tempInputBox[idx][field].value = value;
        tempInputBox[idx][field].valueStateMessage = <span>{errorMessage}</span>;
        if (isValid) {
            tempInputBox[idx][field].valueState = 'None';
        } else {
            tempInputBox[idx][field].valueState = 'Error';
        }
        setInputBox(tempInputBox);
    };

    const onDeleteClick = (index) => {
        let tempInputBox = [...inputBox];
        tempInputBox = tempInputBox.filter((value, idx) => idx !== index);
        setInputBox(tempInputBox);
    };

    const onSkip = () => {
        startGetUserData()
            .then(() => history.push('/order/newOrder'))
            .catch(() => console.log('Something went wrong!'));
    };

    return (
        <>
            <FlexBox alignItems="Center" direction="Column">
                {isLoading && <Loader />}
                <Title style={{ fontSize: 'larger', marginTop: '2rem' }}>
                    In order to create Approval Workflows please add all the approver details.
                </Title>
                <Title style={{ fontSize: 'larger', marginTop: '0.5rem' }}>
                    This step could be skipped and set up later under
                    <b> Menu &gt; Account Management &gt; Approver’s Data.</b>
                </Title>
            </FlexBox>
            <Grid style={{ margin: '20px' }}>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label required style={{ fontSize: 'larger', marginTop: '2rem' }}>
                        Approver Role
                    </Label>
                </div>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label required style={{ fontSize: 'larger', marginTop: '2rem' }}>
                        Approver Name
                    </Label>
                </div>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label required style={{ fontSize: 'larger', marginTop: '2rem' }}>
                        Email Address
                    </Label>
                </div>
                {inputBox.map((inputElements, index) =>
                    Object.keys(inputElements).map((inputElement, idx) => (
                        <div key={idx} data-layout-span="XL4 L4 M4 S4">
                            <Input
                                id={`${inputElement}-${index}`}
                                value={inputElements[inputElement].value}
                                valueState={inputElements[inputElement].valueState}
                                valueStateMessage={inputElements[inputElement].valueStateMessage}
                                onInput={onInputChange}
                            />
                            {idx === Object.keys(inputElements).length - 1 ? (
                                <Icon
                                    showTooltip
                                    id={`delete-${index}`}
                                    name="delete"
                                    onClick={() => onDeleteClick(index)}
                                    tooltip="Delete Row"
                                    style={{ ...spacing.sapUiTinyMarginBegin, width: '1.5rem', cursor: 'pointer' }}
                                />
                            ) : null}
                        </div>
                    ))
                )}
            </Grid>
            <Button
                design="Transparent"
                style={{ color: 'blue', marginLeft: '15px' }}
                onClick={() => {
                    const tempInputBox = [...inputBox];
                    tempInputBox.push({
                        approverRole: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            required: true
                        },
                        approverName: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            required: true
                        },
                        emailAddress: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            required: true
                        }
                    });

                    setInputBox(tempInputBox);
                }}
            >
                + Add Approver
            </Button>
            <Grid style={{ ...spacing.sapUiMediumMarginTop }}>
                <div data-layout-indent="XL8 L8 M8 S8" data-layout-span="XL4 L4 M4 S4">
                    <Button style={{ ...spacing.sapUiSmallMarginEnd }} onClick={() => onSkip()}>
                        Skip Steps 3 and 4
                    </Button>
                    <Button onClick={() => onSave()} design="Emphasized">
                        Save &amp; Go Next
                    </Button>
                </div>
            </Grid>
        </>
    );
};

const mapStateToProps = (state) => ({
    isLoading: isApproverInfoLoading(state)
});

const mapDispatchToProps = (dispatch) => ({
    startRegisterBPApproverInfo: (payload) => dispatch(registerBPApproverInfo(payload)),
    startGetUserData: async () => dispatch(getUserData()),
    startShowMessage: (payload) => dispatch(showMessage(payload))
});

ApproverDataStep.propTypes = {
    onNextClick: PropTypes.func.isRequired,
    startRegisterBPApproverInfo: PropTypes.func.isRequired,
    isLoading: PropTypes.bool,
    startGetUserData: PropTypes.func.isRequired,
    startShowMessage: PropTypes.func.isRequired
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(ApproverDataStep));
