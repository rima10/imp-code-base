const path = require('path');
const chai = require('chai');
const chaiHttp = require('chai-http');

chai.use(chaiHttp);
const { assert } = chai; // we are using the "assert" style of Chai

// db related requires
const { order_quote, business_partner } = require(path.resolve('src/models/index'));
const QuotationRepo = require('../src/repo/quotation.repo');

const sinon = require('sinon');
var app, authUtil;

/**
 * pre requisites: 
 * make sure your local db has order, order_item, model_quote and order_quote entries
 */
describe('RP Asset grading apis', function () {
    var testUser = {}, order = {}, orderQuoteItems = [];
    before(async function () {
        const bpDbRes = await business_partner.findOne({});
        testUser = bpDbRes.dataValues;

        authUtil = require('../src/utils/auth.util');
        sinon.stub(authUtil, 'validateMiddleware')
            .callsFake(function (req, res, next) {
                req.userInfo = {};
                req.userInfo['cognito:username'] = testUser.bp_userid;
                return next();
            });
        sinon.stub(authUtil, 'isGpOrRp')
            .callsFake(function (req, res, next) {
                return next();
            });
        sinon.stub(authUtil, 'isRpUser')
            .callsFake(function (req, res, next) {
                return next();
            });
        app = require('../app');

        const orderQuoteDbRes = await order_quote.findOne({
            where: {},
            attributes: order_quote.attributesAliasesHelper([], { method: 'out' })
        });
        if (!orderQuoteDbRes) throw new Error("prerequisite db records not found");

        order.orderId = orderQuoteDbRes.dataValues.orderId;
        order.quoteId = orderQuoteDbRes.dataValues.quoteId;
    });
    after(async function () {
    });
    it('should get the list of order items with asset grading data', (done) => {
        const url = `/api/order/quotation/refurbish/grading/${order.orderId}/${order.quoteId}`;
        chai.request(app)
            .get(url)
            .end((error, response) => {
                assert.isNull(error);
                assert.equal(response.statusCode, 200);
                assert.isAtLeast(response.body.length, 1);
                orderQuoteItems = response.body;
                done();
            });
    });
    it('should save the order quote items with asset grading data', (done) => {
        const url = `/api/order/quotation/refurbish/grading/${order.orderId}/${order.quoteId}`;
        orderQuoteItems[0].grade = "B";
        orderQuoteItems[0].dataWipe = null;
        chai.request(app)
            .post(url)
            .send(orderQuoteItems)
            .end((error, response) => {
                assert.isNull(error);
                assert.equal(response.statusCode, 200);
                const assertItem = response.body.find((item) => item.order_item_id == orderQuoteItems[0].orderItemId);
                assert.equal(orderQuoteItems[0].grade, assertItem.grade);
                done();
            });
    });

    it('should not allow to submit the order without having all asset grading entries', (done) => {
        const url = `/api/order/quotation/refurbish/grading/${order.orderId}/${order.quoteId}/submit`;
        // prerequisite is to save one asset grading fields as null  
        chai.request(app)
            .post(url)
            .send(orderQuoteItems)
            .end((error, response) => {
                assert.equal(response.statusCode, 500);
                done();
            });
    });

    it('should successfully submit the order ', async (done) => {
        // prerequisite is to save all asset grading fields with proper values
        const updateAssetGrading = {
            grade: "A",
            dataWipeStatus: "ERASED",
            reportStatus: "my status",
            accessoriesStatus: "NA",
            serviceCost: 0,
            invoiceAmount: 199.99
        }
        orderQuoteItems.forEach((item, index) => {
            orderQuoteItems[index] = {
                ...item,
                ...updateAssetGrading
            };
        });
        await QuotationRepo.updateOrderQuoteItems({ userId: testUser.bp_id}, order.orderId, order.quoteId, orderQuoteItems);
        const url = `/api/order/quotation/refurbish/grading/${order.orderId}/${order.quoteId}/submit`;
        chai.request(app)
            .post(url)
            .end((error, response) => {
                assert.isNull(error);
                assert.equal(response.statusCode, 200);
                done();
            });
    });

    it('should save asset grading comments into order quote', (done) => {
        const url = `/api/order/quotation/${order.orderId}/${order.quoteId}`;
        const payload = {
            assetGradeComments: "new comments"
        }
        chai.request(app)
            .post(url)
            .send(payload)
            .end((error, response) => {
                assert.isNull(error);
                assert.equal(response.statusCode, 200);
                done();
            });
    });
});
