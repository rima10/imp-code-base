const ErrorTypes = require('../../constants/error');
/**
 * Create Array from map.
 * Creates tree or flat structure based on treeType flag
 * `createNestedGroup` helper method.
 *
 * @param {Object} itemMap
 * @param {Boolean} treeType
 * @returns {Object[]}
 */
const createArrayFromMap = (itemMap, treeType) => {
  const consolidatedArray = [];
  Object.keys(itemMap).map((itemType) => {
    let itemTypeObj = null;
    const itemObj = itemMap[itemType];
    const itemArr = Object.keys(itemObj);
    if (treeType) {
      itemTypeObj = {
        name: { name: itemType, count: 0 },
        data: [],
      };
    }
    itemArr.map((make) => {
      let makeObj = null;
      const makeObject = itemObj[make];
      const makeArr = Object.keys(makeObject);
      if (treeType) {
        makeObj = {
          name: { name: make, count: 0 },
          data: [],
        };
      }
      makeArr.map((model) => {
        const modelObj = {
          name: { name: model, count: Number(makeObject[model].count) },
          totalPrice: makeObject[model].price, // price per unit
          overallPrice: makeObject[model].totalPrice, // oevrall price = price * count
        };
        if (treeType) {
          itemTypeObj.name.count += modelObj.name.count;
          makeObj.name.count += modelObj.name.count;
          makeObj.data.push(modelObj);
        } else {
          consolidatedArray.push({
            itemType,
            make,
            model,
            count: modelObj.name.count,
          });
        }
      });
      if (treeType) {
        itemTypeObj.data.push(makeObj);
      }
    });
    if (treeType) consolidatedArray.push(itemTypeObj);
  });
  return consolidatedArray;
};

/**
 * Group Items by property.
 * `createNestedGroup` helper method.
 *
 * @param {String} property
 * @param {Object[]} list
 * @param {Boolean} uniqueRows
 * @returns {Object}
 */
const groupItems = (list, property, uniqueRows) => list.reduce((acc, obj) => {
  const key = obj.dataValues[property];
  if (property === 'model') {
    if (!acc[key]) {
      acc[key] = {};
      if (uniqueRows) {
        const { count, price } = obj.dataValues;
        acc[key].count = count;
        acc[key].price = price;
        acc[key].totalPrice = count * price;
      } else acc[key].count = 1;
    } else if (!uniqueRows) acc[key].count += 1;
  } else {
    if (!acc[key]) acc[key] = [];
    acc[key].push(obj);
  }
  return acc;
}, {});

/**
 * Creates nested groups by object properties.
 * `properties` array nest from highest(index = 0) to lowest level.
 *
 * @param {Object[]} arr
 * @param {String[]} properties
 * @param {Boolean} uniqueRows
 * @returns {Object}
 */
const createNestedGroup = (arr, properties, uniqueRows) => {
  const propertyList = [...properties];
  if (properties.length === 1) {
    return groupItems(arr, properties[0], uniqueRows);
  }
  const property = propertyList.shift();
  const grouped = groupItems(arr, property, uniqueRows);
  Object.keys(grouped).map((key) => {
    grouped[key] = createNestedGroup(grouped[key], [...propertyList], uniqueRows);
  });
  return grouped;
};

/**
 * Creates consolidated Object items data.
 * group data together with itemType, make and model
 * @param {Object} orderData
 * @returns {Object[]}
 */
exports.createConsolidatedOrderData = (orderData) => {
  const updatedOrder = { ...orderData };
  const { orderItems } = updatedOrder;
  const group = createNestedGroup(orderItems, ['itemType', 'make', 'model'], false);
  const consolidatedArray = createArrayFromMap(group, false);
  return consolidatedArray;
};

/**
 * Creates tree structure for quotation data.
 * group data together with itemType, make and model
 * @param {Object} orderData
 * @returns {Object[]}
 */
exports.createQuotesTreeData = (quotes) => {
  const updatedQuotes = [...quotes];
  let totalPrice = 0;
  updatedQuotes.map((quote) => {
    const { price, count } = quote.dataValues;
    totalPrice += price * count;
    return totalPrice;
  });
  const group = createNestedGroup(updatedQuotes, ['itemType', 'make', 'model'], true);
  const modelQuotes = createArrayFromMap(group, true);
  return { modelQuotes, totalPrice };
};

exports.calcTotalPrice = (items) => {
  let totalPrice = 0;
  items.map((item) => {
    totalPrice += item.price * item.count;
  });
  return totalPrice;
};

exports.formatDcData = (orderData, dcNo, gst, hsnCode) => {
  const dcData = {};
  const gpData = orderData.dataValues.businessPartner.dataValues;
  const {
    bpUsername, gstNumber, cin, pan, loc,
  } = gpData;
  if (!loc) {
    const err = new Error('Location details not maintained');
    err.type = ErrorTypes.MISSING_DATA;
    throw err;
  }
  const {
    state, city, locDetails, pincode,
  } = loc.dataValues;
  dcData.dcNo = dcNo;
  dcData.dcDate = new Date().toDateString();
  dcData.consignorName = bpUsername;
  dcData.consignorCIN = cin;
  dcData.consignorPAN = pan;
  dcData.consignorGST = gstNumber;
  dcData.consignorState = `${state.state_name}, ${city.city_name}-${pincode}`;
  dcData.consignorAddress = locDetails;

  const quotesData = orderData.dataValues.order_quotes[0].dataValues;
  const rpData = quotesData.createdByBP.dataValues;
  if (!rpData.loc) {
    const err = new Error('Location details not maintained');
    err.type = ErrorTypes.MISSING_DATA;
    throw err;
  }
  const rpLocData = rpData.loc.dataValues;
  dcData.consigneeName = rpData.bpUsername;
  dcData.consigneeCIN = rpData.cin;
  dcData.consigneePAN = rpData.pan;
  dcData.consigneeGST = rpData.gstNumber;
  dcData.consigneeState = `${rpLocData.state.state_name}, ${rpLocData.city.city_name}-${rpLocData.pincode}`;
  dcData.consigneeAddress = rpLocData.locDetails;

  dcData.vehicleDetails = '';

  dcData.transporterDetails = '';
  dcData.lrGcNote = '';
  dcData.consigneeAdress2 = '';

  dcData.rows = [];
  const { modelQuotes } = quotesData;
  const total = {
    qty: 0,
    value: 0,
    taxAmount: 0,
    amount: 0,
  };
  modelQuotes.map((quote, index) => {
    const {
      model, price, count,
    } = quote.dataValues;
    const totalPrice = price * count;
    const sgst = Math.ceil((totalPrice) * (gst / 200));
    const totalAmount = Math.ceil(totalPrice + (sgst * 2));
    total.qty += Number(count);
    total.value += totalPrice;
    total.taxAmount += sgst;
    total.amount += totalAmount;
    dcData.rows.push([index + 1, model, hsnCode, count, 'Nos', price, totalPrice,
      `${gst / 2}%`, sgst, `${gst / 2}%`, sgst, '', '', totalAmount]);
  });
  dcData.rows.push(['', '', '', total.qty, '', '', total.value,
    '', total.taxAmount, '', total.taxAmount, '', '', total.amount]);
  return dcData;
};

exports.formatF6Data = (orderData, weight, invoiceNumber) => {
  const f6Data = {};
  const gpData = orderData.dataValues.businessPartner.dataValues;
  const {
    bpUsername, loc,
  } = gpData;
  const { vehicleType, vehicleLicenseNo, itemsCount } = orderData.dataValues;
  if (!loc) {
    const err = new Error('Location details not maintained');
    err.type = ErrorTypes.MISSING_DATA;
    throw err;
  }
  const {
    state, city, locDetails, pincode,
  } = loc.dataValues;
  f6Data.senderName = bpUsername;
  f6Data.senderAddress = `${locDetails}, ${city.dataValues.city_name}, ${state.dataValues.state_name}, Pincode-${pincode}`;
  f6Data.vehicleType = vehicleType;
  f6Data.vehicleNumber = vehicleLicenseNo;

  const quotesData = orderData.dataValues.order_quotes[0].dataValues;
  const rpData = quotesData.createdByBP.dataValues;
  if (!rpData.loc) {
    const err = new Error('Location details not maintained');
    err.type = ErrorTypes.MISSING_DATA;
    throw err;
  }
  const rpLocData = rpData.loc.dataValues;
  f6Data.recyclerName = rpData.bpUsername;
  f6Data.recyclerAddress = `${rpLocData.locDetails}, ${rpLocData.city.dataValues.city_name}, ${rpLocData.state.dataValues.state_name}, Pincode-${rpLocData.pincode}`;
  f6Data.recyclerAuthNo = rpData.authNumber;
  f6Data.weight = weight;
  f6Data.invoiceNo = invoiceNumber;
  f6Data.qty = itemsCount;
  const today = new Date();
  let month = `${today.getMonth() + 1}`;
  let day = `${today.getDate()}`;
  const year = today.getFullYear();
  if (month.length < 2) month = `0${month}`;
  if (day.length < 2) day = `0${day}`;
  f6Data.day = day.split('');
  f6Data.mon = month.split('');
  f6Data.year = year.toString().split('');
  return f6Data;
};

exports.formatF2Data = (orderData, weight) => {
  const f2Data = {};
  const gpData = orderData.dataValues.businessPartner.dataValues;
  const {
    bpUsername, loc,
  } = gpData;
  if (!loc) {
    const err = new Error('Location details not maintained');
    err.type = ErrorTypes.MISSING_DATA;
    throw err;
  }
  const {
    state, city, locDetails, pincode,
  } = loc.dataValues;
  f2Data.gpName = bpUsername;
  f2Data.gpAddress = `${locDetails}, ${city.dataValues.city_name}, ${state.dataValues.state_name}, Pincode-${pincode}`;

  const quotesData = orderData.dataValues.order_quotes[0].dataValues;
  const rpData = quotesData.createdByBP.dataValues;
  if (!rpData.loc) {
    const err = new Error('Location details not maintained');
    err.type = ErrorTypes.MISSING_DATA;
    throw err;
  }
  const rpLocData = rpData.loc.dataValues;
  f2Data.rpName = rpData.bpUsername;
  f2Data.rpAddress = `${rpLocData.locDetails}, ${rpLocData.city.dataValues.city_name}, ${rpLocData.state.dataValues.state_name}, Pincode-${rpLocData.pincode}`;
  f2Data.totalWeight = weight;
  return f2Data;
};
