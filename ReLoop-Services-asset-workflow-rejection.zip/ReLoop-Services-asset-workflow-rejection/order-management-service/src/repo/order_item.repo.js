const Models = require('../models/index');

function getModelMapKey(orderItem) {
  // delimiter used here is ||
  return `${orderItem.model}||${orderItem.make}||${orderItem.itemType}`;
}

const refurbishAssetListColumns = [{
  heading: 'Equipment No',
  key: 'equipmentNumber',
}, {
  heading: 'Asset No',
  key: 'assetNumber',
}, {
  heading: 'Company Name',
  key: 'companyName',
}, {
  heading: 'Comapany Code',
  key: 'companyCode',
}, {
  heading: 'Location',
  key: 'buildingLocation',
}, {
  heading: 'Bond Status',
  key: 'bondStatus',
}, {
  heading: 'Category',
  key: 'itemType',
}, {
  heading: 'Make',
  key: 'make',
}, {
  heading: 'Model',
  key: 'model',
}, {
  heading: 'Manuf. Serial No.',
  key: 'manufactureSerial',
}, {
  heading: 'Age in Years',
  key: 'ageInYear',
}, {
  heading: 'Purchase Year',
  key: 'purchaseYear',
}, {
  heading: 'Description',
  key: 'description',
}];

const recycleAssetListColumns = [{
  heading: 'Item',
  key: 'model',
}, {
  heading: 'Quantity',
  key: 'itemQuantity',
}, {
  heading: 'Unit',
  key: 'recycleItemUnit',
}, {
  heading: 'Location',
  key: 'buildingLocation',
}, {
  heading: 'Remarks',
  key: 'description',
}];

exports.createOrderItems = async (excelRows, userId, orderId, orderType) => {
  const columnsMap = orderType === '1' ? refurbishAssetListColumns : recycleAssetListColumns;
  const orderItems = excelRows.map((row) => {
    const orderItem = {};
    columnsMap.forEach((colItem) => {
      orderItem[colItem.key] = row[colItem.heading] || null;
    });
    // orderId, createdBy, updatedBy
    orderItem.orderId = orderId;
    orderItem.createdByUserId = userId;
    orderItem.updatedByUserId = userId;
    return orderItem;
  });

  return Models.order_item.bulkCreate(
    Models.order_item.attributesAliasesHelper(orderItems, { method: 'in', allowNewFields: false })
  );
};

exports.getOrderItemsWithOrderQuoteItems = async (orderId, orderQuoteId) => {
  const dbres = await Models.order_item.findAll({
    where: { order_id: orderId },
    attributes: Models.order_item.attributesAliasesHelper([
      'orderItemId',
      'equipmentNumber',
      'assetNumber',
      'buildingLocation',
      'bondStatus',
      'ageInYear',
      'description',
      'model',
      'make',
      'itemType',
    ]),
    include: [{
      model: Models.order_quote_item,
      as: 'order_quote_items',
      where: { order_quote_id: orderQuoteId },
      attributes: Models.order_quote_item.attributesAliasesHelper([], { method: 'out' }),
      required: false,
    }],
  });
  // unwind the exact quote item data from array structure, if available
  const orderItemsWithQuotes = dbres.map((element) => {
    let item = { ...element.dataValues };
    if (element.dataValues.order_quote_items && element.dataValues.order_quote_items.length) {
      item = { ...item, ...element.dataValues.order_quote_items[0].dataValues };
    }
    delete item.order_quote_items;
    return item;
  });

  const modelQuoteDbRes = await Models.model_quote.findAll({
    where: {
      order_quote_id: orderQuoteId,
    },
    attributes: Models.model_quote.attributesAliasesHelper([], { method: 'out' }),
  });

  const modelQuotesMap = new Map();
  modelQuoteDbRes.forEach((item) => {
    const modelKey = getModelMapKey(item.dataValues);
    modelQuotesMap.set(modelKey, item);
  });

  orderItemsWithQuotes.forEach((item, index) => {
    const modelKey = getModelMapKey(item);
    if (modelQuotesMap.has(modelKey)) {
      orderItemsWithQuotes[index].listPrice = modelQuotesMap.get(modelKey).price;
    }
  });

  return orderItemsWithQuotes;
};

exports.deleteOrderItemsForOrder = async (orderId) => {
  const promise = Models.order_item.destroy({
    where: {
      order_id: orderId,
    },
  });
  return promise;
};
