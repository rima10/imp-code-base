const Models = require('../models/index');

exports.getNetworkOwnerByMemberId = async (memberId) => {
  const pvtNetworks = await Models.bp_private_nwk.findOne({
    where: { nwk_member: memberId },
    attributes: ['nwk_owner'],
    include: [{
      model: Models.business_partner,
      attributes: ['bp_username'],
      as: 'nwk_owner_business_partner',
    }],
  });
  let privateNetworkOwner = {};
  if (pvtNetworks) {
    privateNetworkOwner = {
      nwkOwner: pvtNetworks.dataValues.nwk_owner,
      nwkOwnerName: pvtNetworks.dataValues.nwk_owner_business_partner.dataValues.bp_username,
    };
  }
  return privateNetworkOwner;
};
