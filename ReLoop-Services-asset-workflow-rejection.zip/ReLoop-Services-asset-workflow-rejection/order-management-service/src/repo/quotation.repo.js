const models = require('../models/index');
const orderDataFormatUtil = require('../utils/order/dataFormat.util');
const ErrorTypes = require('../constants/error');

const formatOrderQuotesData = (quotes, isRefurbishOrder) => {
  const quotesData = [];
  let quotesOverallStatus = 'In Review';
  const acceptedStatus = ['Accepted', 'Temporarily Accepted'];
  quotes.forEach((quote) => {
    const quoteData = { ...quote.dataValues };
    // Set quotesOverallStatus flag to accepted if any quote has been accepted by green partner
    if (!acceptedStatus.includes(quotesOverallStatus)
      && acceptedStatus.includes(quoteData.quoteStatus)) {
      quotesOverallStatus = quoteData.quoteStatus;
    }

    quoteData.recyclerId = quoteData.createdByBP.dataValues.recyclerId;
    quoteData.name = quoteData.createdByBP.dataValues.recyclerName;
    delete quoteData.createdByBP;
    if (isRefurbishOrder && quote.modelQuotes.length) {
      const result = orderDataFormatUtil.createQuotesTreeData(quoteData.modelQuotes);
      quoteData.totalPrice = result.totalPrice;
      quoteData.data = result.modelQuotes;
      delete quoteData.modelQuotes;
    } else if (!isRefurbishOrder && quote.orderItemQuotes.length) {
      const orderQuoteItems = quote.orderItemQuotes.reduce((acc, item) => {
        acc.push({ name: `${item.dataValues.order_item.dataValues.model} (Unit in ${item.dataValues.recycleItemUnit})` });
        return acc;
      }, []);
      quoteData.data = orderQuoteItems;
      delete quoteData.orderItemQuotes;
    } else quoteData.data = [];

    quotesData.push(quoteData);
  });
  return { quotesOverallStatus, quotesData };
};

exports.getRecycleInitialQuote = async (orderId) => {
  const quotes = await models.order_quote
    .findAll({
      where:
        { order_id: orderId },
      attributes: [['id', 'quoteId'], ['quote_status', 'quoteStatus'], ['comments', 'quoteComments'], ['recycle_price_per_kg', 'pricePerKg'], ['comments', 'quoteComments'], ['asset_grading_submitted', 'assetGradeSubmitted']],
      include: [{
        model: models.business_partner,
        as: 'createdByBP',
        attributes: [['bp_id', 'recyclerId'], ['bp_username', 'recyclerName']],
      }, {
        model: models.order_quote_item,
        as: 'orderItemQuotes',
        attributes: [['id', 'quoteItemId'], ['order_item_id', 'orderItemId'], ['recycle_item_unit', 'recycleItemUnit']],
        include: [
          {
            model: models.order_item,
            as: 'order_item',
            attributes: [
              ['id', 'orderItemId'], 'model'],
          },
        ],
      }],
    });
  return formatOrderQuotesData(quotes, false);
};

exports.getRefurbishInitialQuote = async (orderId) => {
  const quotes = await models.order_quote.findAll({
    where: { order_id: orderId },
    attributes: [
      ['id', 'quoteId'],
      ['id', 'quoteId'],
      ['quote_status', 'quoteStatus'],
      ['comments', 'quoteComments'],
      ['asset_grading_submitted', 'assetGradeSubmitted']],
    include: [{
      model: models.business_partner,
      as: 'createdByBP',
      attributes: [['bp_id', 'recyclerId'], ['bp_username', 'recyclerName']],
    }, {
      model: models.model_quote,
      as: 'modelQuotes',
      attributes: [['model_quote_id', 'modelQuoteId'], ['item_type', 'itemType'], 'make', 'model', 'price', 'count'],
    }],
  });
  return formatOrderQuotesData(quotes, true);
};

const formatRecycleOrderItemLevelQuote = (itemLevelQuote) => {
  const orderItemGroupByUnit = itemLevelQuote.reduce((groupedOrderItem, quote) => {
    const quoteItem = quote.dataValues;
    const uom = quoteItem.itemUnit.toLowerCase();
    if (uom === 'kg') {
      groupedOrderItem.kg.push(quoteItem);
    } else groupedOrderItem.other.push(quoteItem);
    return groupedOrderItem;
  }, { kg: [], other: [] });
  const quoteItemData = [];
  Object.keys(orderItemGroupByUnit).map((unit) => {
    if (unit === 'kg') {
      const kgItems = {
        item: [],
        finalQty: '',
        unit: 'kg',
        pricePerUnit: '',
        totalPrice: '',
      };
      orderItemGroupByUnit[unit].forEach((quoteItem, index) => {
        kgItems.item.push(quoteItem.order_item.dataValues.model);
        if (index === orderItemGroupByUnit[unit].length - 1) {
          kgItems.finalQty = quoteItem.recycleFinalQty;
          kgItems.pricePerUnit = quoteItem.pricePerUnit;
          kgItems.totalPrice = quoteItem.toBeInvoiced;
        }
      });
      kgItems.item = kgItems.item.join(', ');
      quoteItemData.push(kgItems);
    } else {
      orderItemGroupByUnit[unit].forEach((quoteItem) => {
        const otherItems = {
          item: quoteItem.order_item.dataValues.model,
          finalQty: quoteItem.recycleFinalQty,
          unit: quoteItem.itemUnit.toLowerCase(),
          pricePerUnit: quoteItem.pricePerUnit,
          totalPrice: quoteItem.toBeInvoiced,
        };
        quoteItemData.push(otherItems);
      });
    }
  });
  return quoteItemData;
};

exports.getRecycleOrderItemLevelQuote = async (orderId) => {
  const orderQuote = await models.order_quote.findOne(
    {
      where: { order_id: orderId, quote_status: 'Accepted' },
      attributes: [
        ['id', 'orderQuoteId'],
        ['recycle_price_per_kg', 'pricePerKg'],
        ['asset_grading_submitted', 'isFinalQuoteSubmitted']],
      include: [{
        model: models.order_quote_item,
        as: 'orderItemQuotes',
        attributes: [
          ['id', 'orderItemQuoteId'],
          ['recycle_price_per_unit', 'pricePerUnit'], ['recycle_final_qty', 'recycleFinalQty'],
          ['to_be_invoiced', 'toBeInvoiced'], ['recycle_item_unit', 'itemUnit']],
        include: [{
          model: models.order_item,
          as: 'order_item',
          attributes: ['model'],
        }],
      },
      {
        model: models.business_partner,
        as: 'createdByBP',
        attributes: [['bp_id', 'recyclerId'], ['bp_username', 'recyclerName']],
      }],
    },
  );
  let result;
  if (orderQuote) {
    const orderQuoteData = orderQuote.dataValues;
    result = {
      quoteId: orderQuoteData.orderQuoteId,
      pricePerKg: orderQuoteData.pricePerKg,
      recyclerName: orderQuoteData.createdByBP.dataValues.recyclerName,
      recyclerId: orderQuoteData.createdByBP.dataValues.recyclerId,
      isFinalQuoteSubmitted: orderQuoteData.isFinalQuoteSubmitted !== null,
    };
    result.orderQuoteItems = formatRecycleOrderItemLevelQuote(orderQuote.orderItemQuotes);
    result.totalPrice = result.orderQuoteItems
      .reduce((acc, quoteItem) => acc + Number(quoteItem.totalPrice), 0);
  } else result = {};
  return result;
};

exports.updateOrderQuoteItems = async (userId, orderId, orderQuoteId, payload) => {
  const bulkUpdatePayload = payload.map((item) => (
    {
      ...item,
      orderId,
      orderQuoteId,
      createdByUserId: userId,
      updatedByUserId: userId,
    }
  ));
  const dbBulkUpdatePayload = models.order_quote_item.attributesAliasesHelper(bulkUpdatePayload, { method: 'in', allowNewFields: false });
  const updateOptions = {
    updateOnDuplicate: ['last_modified_date', 'grade', 'data_wipe', 'report_status', 'accessories_status',
      'to_be_invoiced', 'service_cost', 'created_by', 'updated_by'],
  };
  return models.order_quote_item.bulkCreate(dbBulkUpdatePayload, updateOptions);
};

exports.getOrderQuote = async (orderId, quoteId, projection) => {
  let method = 'in';
  if (!projection || !projection) {
    // eslint-disable-next-line no-param-reassign
    projection = [];
    method = 'out';
  }
  const res = await models.order_quote.findOne({
    where: {
      order_id: orderId,
      id: quoteId,
    },
    attributes: models.order_quote.attributesAliasesHelper(projection, { method }),
  });
  return res;
};

exports.updateOrderQuote = async (userId, orderId, quoteId, updatePayload) => {
  const updatePayloadCopy = { ...updatePayload };
  updatePayloadCopy.updatedByUserId = userId;
  updatePayloadCopy.lastModifiedDate = new Date();

  const dbUpdatePayload = models.order_quote.attributesAliasesHelper(updatePayloadCopy, {
    allowNewFields: false,
    method: 'in',
  });
  return models.order_quote.update(
    dbUpdatePayload,
    {
      where: {
        order_id: orderId,
        id: quoteId,
      },
    },
  );
};

exports.updateTotalPrice = async (orderId, quoteId) => {
  const quote = await models.order_quote.findOne({
    where: { order_id: orderId, id: quoteId },
    attributes: ['id'],
    include: [{
      model: models.order_quote_item,
      as: 'orderItemQuotes',
      attributes: [['to_be_invoiced', 'toBeInvoiced'], ['service_cost', 'serviceCost']],
    }],
  });
  let totalPrice = quote.dataValues.orderItemQuotes.reduce((acc, itemQuote) => {
    let updatedAcc = acc;
    updatedAcc += Number(itemQuote.dataValues.toBeInvoiced);
    return updatedAcc;
  }, 0);
  totalPrice = Math.round(totalPrice * 100) / 100;
  await quote.update({ total_price: totalPrice });
  return quote;
};

exports.checkQuoteStatus = async (orderId, userId) => {
  const quoteStatus = await models.order_quote.findOne(
    {
      where: { order_id: orderId, created_by: userId },
      attributes: [['id', 'quoteId'], ['quote_status', 'quoteStatus']],
    },
  );
  if (quoteStatus && quoteStatus.dataValues.quoteStatus === 'Accepted') return true;
  return false;
};

exports.getAllNetworkMembersForOwner = async (ownerId) => {
  const promise = models.bp_private_nwk.findAll({
    where: { nwK_owner: ownerId },
    attributes: [['nwk_member', 'recyclerId']],
  });
  return promise;
};

/*
  @desc Check if recycler has already submitted the quote for the order
  @param String orderId
  @param String userId
*/
exports.checkExistingQuote = async (orderId, userId) => {
  const existingQuote = await models.order_quote.findOne({
    where: {
      order_id: orderId,
      created_by: userId,
    },
  });
  if (existingQuote) {
    const err = new Error('Quote already submitted by recycler');
    err.type = ErrorTypes.NOT_ALLOWED_REDO;
    throw err;
  }
};

exports.getOrderQuoteWithQuoteItems = async (quoteId, options = { quoteItemAttributes: [] }) => {
  const updatedQuote = await models.order_quote.findOne(
    {
      where: { id: quoteId },
      attributes: [['id', 'quoteId']],
      include: [
        {
          model: models.order_quote_item,
          as: 'orderItemQuotes',
          attributes: models.order_quote_item.attributesAliasesHelper(options.quoteItemAttributes),
        }],
    },
  );
  return updatedQuote;
};

exports.getOrderQuoteWithModelQuoteItems = async (quoteId, options = { modelQuoteAttributes: [] }) => {
  const updatedQuote = await models.order_quote.findOne(
    {
      where: { id: quoteId },
      attributes: [['id', 'quoteId']],
      include: [
        {
          model: models.model_quote,
          as: 'modelQuotes',
          attributes: models.model_quote.attributesAliasesHelper(options.modelQuoteAttributes),
        }],
    },
  );
  return updatedQuote;
};

exports.createRecycleInitialQuote = async (userId, orderId, quoteData) => {
  const {
    orderItems, quoteComments, pricePerKg,
  } = quoteData;
  const quote = await models.order_quote.create({
    order_id: orderId,
    created_by: userId,
    quote_status: 'In Review',
    recycle_price_per_kg: pricePerKg,
    comments: quoteComments,
  });

  // Create order quote item for each order item
  const dbOrderItems = await Promise.all(orderItems.map(async (orderItem) => {
    const {
      orderItemId, itemUnit,
    } = orderItem;
    await models.order_quote_item.create({
      order_id: orderId,
      order_quote_id: quote.id,
      order_item_id: orderItemId,
      recycle_item_unit: itemUnit,
    });
  }));

  return {
    quote,
    orderItems: dbOrderItems,
  };
};

exports.createRefurbishInitialQuote = async (userId, orderId, quoteData) => {
  const {
    orderItems, quoteComments,
  } = quoteData;
  const quote = await models.order_quote.create({
    order_id: orderId,
    created_by: userId,
    quote_status: 'In Review',
    comments: quoteComments,
  });

  // Create model quotes for each consolidated order item
  const dbModelQuotes = await Promise.all(orderItems.map(async (orderItem) => {
    const {
      itemType, make, model, price, count,
    } = orderItem;
    await models.model_quote.create({
      order_quote_id: quote.id,
      item_type: itemType,
      make,
      model,
      price,
      count,
    });
  }));

  return {
    quote,
    modelQuotes: dbModelQuotes,
  };
};

exports.acceptQuote = async (orderId, details) => {
  const { scheduledOnsiteDate, estimatedTime, comment } = details;
  let selectedQuote = await models.order_quote.findOne(
    { where: { order_id: orderId, quote_status: 'Temporarily Accepted' } },
  );
  if (selectedQuote) {
    selectedQuote = selectedQuote.update({
      quote_status: 'Accepted',
      onsite_scheduled_time: scheduledOnsiteDate,
      duration_time: estimatedTime,
      schedule_onsite_visit_comment: comment,
    });
  }
  return selectedQuote;
};

exports.temproaryAcceptQuote = async (orderId, quoteId) => {
  const alreadyApprovedQuotes = await models.order_quote.findAll(
    { where: { order_id: orderId, quote_status: 'Temporarily Accepted' } },
  );
  if (alreadyApprovedQuotes.length) {
    const err = new Error('A quote has already been accepted for this order'); 
    err.type = ErrorTypes.NOT_ALLOWED_REDO;
    throw err;
  }
  let selectedQuote = await models.order_quote.findOne(
    { where: { id: quoteId, order_id: orderId } },
  );
  if (selectedQuote) {
    selectedQuote = selectedQuote.update({ quote_status: 'Temporarily Accepted' });
  }
  return selectedQuote;
};

exports.rejectQuote = async (orderId, quoteId, details) => {
  const { comment } = details;
  let selectedQuote = await models.order_quote.findOne(
    { where: { id: quoteId, order_id: orderId } },
  );
  if (selectedQuote) {
    selectedQuote = selectedQuote.update({ quote_status: 'Rejected' });
  }
  return selectedQuote;
};

exports.getAcceptedQuoteForOrder = async (orderId, options = { orderQuoteProjection: [] }) => {
  const quote = await models.order_quote.findOne({
    where: {
      order_id: orderId,
      quote_status: 'Accepted',
    },
    attributes: models.order_quote.attributesAliasesHelper(options.orderQuoteProjection),
    include: [{
      model: models.business_partner,
      as: 'createdByBP',
      attributes: [['bp_id', 'recyclerId'], ['bp_username', 'recyclerName']],
    }],
  });
  return quote;
};

exports.updateRecycleOrderQuoteItem = async (orderItemQuote) => {
  const {
    orderQuoteItemsId, finalQty, pricePerUnit,
  } = orderItemQuote;
  await Promise.all(orderQuoteItemsId.map(async (orderQuoteItem) => {
    const existingQuoteItem = await models.order_quote_item.findOne(
      { where: { id: orderQuoteItem } },
    );
    if (!existingQuoteItem) {
      const err = new Error('Order quote item does not exist');
      err.type = ErrorTypes.RES_NOT_FOUND;
      throw err;
    }
    await existingQuoteItem.update({
      recycle_final_qty: finalQty,
      recycle_price_per_unit: pricePerUnit,
      to_be_invoiced: finalQty * pricePerUnit,
    });
  }));
};

exports.getRecycleConsolidatedOrderItems = async (userId, orderId) => {
  const orderQuote = await models.order_quote.findOne({
    where: { order_id: orderId, created_by: userId },
    attributes: [
      ['id', 'orderQuoteId'],
      ['recycle_price_per_kg', 'pricePerKg'],
      ['asset_grading_comments', 'quoteComments'],
      ['asset_grading_submitted', 'isFinalQuoteSubmitted'],
    ],
    include: [
      {
        model: models.order_quote_item,
        as: 'orderItemQuotes',
        attributes: [
          ['id', 'orderItemQuoteId'],
          ['recycle_price_per_unit', 'pricePerUnit'],
          ['recycle_final_qty', 'recycleFinalQty'],
          ['recycle_item_unit', 'itemUnit'],
        ],
        include: [
          {
            model: models.order_item,
            as: 'order_item',
            attributes: [
              ['id', 'orderItemId'],
              ['model', 'orderItem'],
            ],
          },
        ],
      },
    ],
  });
  const orderQuoteData = orderQuote.dataValues;
  const result = {
    quoteId: orderQuoteData.orderQuoteId,
    pricePerKg: orderQuoteData.pricePerKg,
    quoteComments: orderQuoteData.quoteComments,
    isFinalQuoteSubmitted: orderQuoteData.isFinalQuoteSubmitted !== null,
  };
  const orderItemGroupByUnit = orderQuote.dataValues.orderItemQuotes.reduce(
    (groupedOrderItem, quote) => {
      const quoteItem = quote.dataValues;
      const uom = quoteItem.itemUnit.toLowerCase();
      if (uom === 'kg') {
        groupedOrderItem.kg.push(quoteItem);
      } else groupedOrderItem.pc.push(quoteItem);
      return groupedOrderItem;
    },
    { kg: [], pc: [] },
  );
  const quoteItemData = [];
  Object.keys(orderItemGroupByUnit).map((unit) => {
    if (unit === 'kg') {
      const kgItems = {
        orderItem: [],
        itemUnit: 'kg',
        orderQuoteItemId: [],
        finalQty: '',
        pricePerUnit: '',
      };
      orderItemGroupByUnit[unit].map((quoteItem) => {
        kgItems.orderItem.push(quoteItem.order_item.dataValues.orderItem);
        kgItems.orderQuoteItemId.push(quoteItem.orderItemQuoteId);
        kgItems.finalQty = quoteItem.recycleFinalQty;
        kgItems.pricePerUnit = quoteItem.pricePerUnit;
      });
      kgItems.orderItem = kgItems.orderItem.join(', ');
      quoteItemData.push(kgItems);
    } else {
      orderItemGroupByUnit[unit].map((quoteItem) => {
        const otherItems = {
          orderItem: quoteItem.order_item.dataValues.orderItem,
          itemUnit: quoteItem.itemUnit.toLowerCase(),
          orderQuoteItemId: [quoteItem.orderItemQuoteId],
          finalQty: quoteItem.recycleFinalQty,
          pricePerUnit: quoteItem.pricePerUnit,
        };
        quoteItemData.push(otherItems);
      });
    }
  });
  result.orderQuoteItems = quoteItemData;
  return result;
};

exports.getQuotationNotificationsData = async (orderId, recyclerId) => {
  const order = await models.order.findOne({
    where: { order_id: orderId },
    attributes: models.order.attributesAliasesHelper(['orderId', 'orderNumber']),
    include: [{
      model: models.business_partner,
      as: 'businessPartner',
      attributes: models.business_partner.attributesAliasesHelper(['emailId']),
    }],
  });
  const recycler = await models.business_partner.findOne({
    where: { bp_id: recyclerId }, attributes: [['bp_username', 'recyclerName']],
  });

  const response = {};
  response.order = order.dataValues;
  response.recycler = recycler.dataValues;
  response.receiver = { ...order.dataValues.businessPartner.dataValues };
  return response;
};
