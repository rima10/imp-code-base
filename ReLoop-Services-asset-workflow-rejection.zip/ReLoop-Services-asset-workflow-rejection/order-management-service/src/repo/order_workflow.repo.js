const Models = require('../models/index');

exports.createOrderWorkflowSkeleton = async (orderId, workflowId) => {
  const existingOrderWorklow = await Models.order_workflow.findOne(
    { where: { order_id: orderId, workflow_id: workflowId } },
  );
  if (existingOrderWorklow) {
    return existingOrderWorklow;
  }
  const OrderWorkflowDetail = await Models.order_workflow.create({
    order_id: orderId,
    workflow_id: workflowId,
  });
  return OrderWorkflowDetail;
};

/**
 * get the workflow id from the account management of a particular business user 
 * for a specific process type(refurbish,recycle) and
 * process sequence(order creation,order submission)
 * */

exports.getWorkflow = async (userId, processStageSequence, ProcessType) => {
  const promise = Models.workflow
    .findOne({
      where:
      {
        bp_id: userId,
        process_type_id: ProcessType,
        process_stage_sequence: processStageSequence,
      },

    });
  return promise;
};

exports.checkOrderHasRejectedWorkflow = async (orderId) => {
  const currentRejectedWorflow = await Models.order_workflow.findOne({
    where: {
      order_id: orderId,
      overall_status: 'Rejected',
    },
    attributes: Models.order_workflow.attributesAliasesHelper([]),
  });
  return (currentRejectedWorflow ? currentRejectedWorflow.dataValues : null);
};

exports.updateOrderWorkflowPipelineInactive = async (orderWorkflowId) => {
  const payload = { is_active: false };
  const result = await Models.order_workflow_approver.update(payload, {
    where: {
      order_workflow_id: orderWorkflowId,
    },
  });

  return result;
};
