const Models = require('../models/index');
const dataFormatUtil = require('../utils/order/dataFormat.util');
const ErrorTypes = require('../constants/error');

exports.getAllDocumentsByOrderId = async (orderId) => {
  const documents = await Models.doc.findAll({
    attributes: Models.doc.attributesAliasesHelper(['docId', 'docName']),
    include: [{
      model: Models.order_doc,
      as: 'order_docs',
      where: { order_id: orderId },
      required: false,
      attributes: Models.order_doc.attributesAliasesHelper(['orderDocId', 'storageKey', 'lastModifiedDate', 'documentText']),
      include: [{
        model: Models.business_partner,
        as: 'createdBy',
        attributes: Models.business_partner.attributesAliasesHelper([['bp_username', 'bpUserName']]),
      }],
    }],
  });
  return documents;
};

exports.updateOrderDocumentAfterUpload = async (userId, orderId, documentDetails) => {
  let document = null;
  const { documentName, documentText, s3FileKey } = documentDetails;
  const doc = await Models.doc.findOne({ where: { doc_name: documentName } });
  if (!doc) {
    const err = new Error('Document type is not found');
    err.type = ErrorTypes.RES_NOT_FOUND;
    throw err;
  }

  const docQuery = { where: { order_id: orderId, doc_id: doc.doc_id } };
  if (documentName === 'other') {
    docQuery.where.document_text = documentText;
  }
  const existingDocument = await Models.order_doc.findOne(docQuery);
  if (existingDocument) {
    document = await existingDocument.update({
      storage_metadata: s3FileKey,
      last_modified_date: new Date(),
      updated_by: userId,
    });
  } else {
    document = await Models.order_doc.create({
      order_id: orderId,
      doc_id: doc.doc_id,
      storage_metadata: s3FileKey,
      created_by: userId,
      document_text: documentText,
    });
  }
  return document;
};

exports.getDCData = async (orderId, dcNo, gst, hsnCode) => {
  const orderData = await Models.order.findOne({
    where: { order_id: orderId },
    attributes: [['order_id', 'orderId']],
    include: [{
      model: Models.business_partner,
      as: 'businessPartner',
      attributes: [['bp_username', 'bpUsername'], ['gst_number', 'gstNumber'], 'cin', 'pan'],
      include: [{
        model: Models.location,
        as: 'loc',
        attributes: ['pincode', ['loc_details', 'locDetails']],
        include: [{ model: Models.city, as: 'city' }, { model: Models.state, as: 'state' }],
      }],
    },
    {
      model: Models.order_quote,
      as: 'order_quotes',
      where: { quote_status: 'Accepted' },
      attributes: ['id'],
      include: [{
        model: Models.business_partner,
        as: 'createdByBP',
        attributes: [['bp_username', 'bpUsername'], ['gst_number', 'gstNumber'], 'cin', 'pan'],
        include: [{
          model: Models.location,
          as: 'loc',
          attributes: ['pincode', ['loc_details', 'locDetails']],
          include: [{ model: Models.city, as: 'city' }, { model: Models.state, as: 'state' }],
        }],
      }, {
        model: Models.model_quote,
        as: 'modelQuotes',
        attributes: ['model', 'price', 'count'],
      }],
    }],
  });
  if (!orderData || !orderData.dataValues.order_quotes.length) {
    const err = new Error('No quotations has been accepted for the order');
    err.type = ErrorTypes.RES_NOT_AVAILABLE;
    throw err;
  }
  return dataFormatUtil.formatDcData(orderData, dcNo, gst, hsnCode);
};

exports.generateForm6Data = async (orderId, weight, invoiceNo) => {
  const orderData = await Models.order.findOne({
    where: { order_id: orderId },
    attributes: [
      ['order_id', 'orderId'], ['vehicle_type', 'vehicleType'], ['vehicle_licence_no', 'vehicleLicenseNo'],
      [Models.sequelize.fn('COUNT', Models.sequelize.col('orderItems.id')), 'itemsCount']
    ],
    group: ['order.order_id', 'businessPartner.bp_id', 'businessPartner.loc.loc_id', 'businessPartner.loc.city.city_id',
      'businessPartner.loc.state.state_id', 'order_quotes.id', 'order_quotes.createdByBP.bp_id', 'order_quotes.createdByBP.loc.loc_id', 'order_quotes.createdByBP.loc.city.city_id',
      'order_quotes.createdByBP.loc.state.state_id'],
    include: [{
      model: Models.business_partner,
      as: 'businessPartner',
      attributes: [['bp_username', 'bpUsername']],
      include: [{
        model: Models.location,
        as: 'loc',
        attributes: ['pincode', ['loc_details', 'locDetails']],
        include: [{ model: Models.city, as: 'city' }, { model: Models.state, as: 'state' }],
      }],
    },
    {
      model: Models.order_item,
      as: 'orderItems',
      attributes: [],
    },
    {
      model: Models.order_quote,
      as: 'order_quotes',
      where: { quote_status: 'Accepted' },
      attributes: ['id'],
      include: [{
        model: Models.business_partner,
        as: 'createdByBP',
        attributes: [['bp_username', 'bpUsername'], ['auth_number', 'authNumber']],
        include: [{
          model: Models.location,
          as: 'loc',
          attributes: ['pincode', ['loc_details', 'locDetails']],
          include: [{ model: Models.city, as: 'city' }, { model: Models.state, as: 'state' }],
        }],
      }],
    }],
  });
  if (!orderData.dataValues.order_quotes.length) {
    const err = new Error('No quotations has been accepted for the order');
    err.type = ErrorTypes.RES_NOT_AVAILABLE;
    throw err;
  }
  return dataFormatUtil.formatF6Data(orderData, weight, invoiceNo);
};

exports.generateForm2Data = async (orderId, weight) => {
  const orderData = await Models.order.findOne({
    where: { order_id: orderId },
    attributes: [['order_id', 'orderId']],
    include: [{
      model: Models.business_partner,
      as: 'businessPartner',
      attributes: [['bp_username', 'bpUsername']],
      include: [{
        model: Models.location,
        as: 'loc',
        attributes: ['pincode', ['loc_details', 'locDetails']],
        include: [{ model: Models.city, as: 'city' }, { model: Models.state, as: 'state' }],
      }],
    },
    {
      model: Models.order_quote,
      as: 'order_quotes',
      where: { quote_status: 'Accepted' },
      attributes: ['id'],
      include: [{
        model: Models.business_partner,
        as: 'createdByBP',
        attributes: [['bp_username', 'bpUsername'], ['auth_number', 'authNumber']],
        include: [{
          model: Models.location,
          as: 'loc',
          attributes: ['pincode', ['loc_details', 'locDetails']],
          include: [{ model: Models.city, as: 'city' }, { model: Models.state, as: 'state' }],
        }],
      }],
    }],
  });
  if (!orderData.dataValues.order_quotes.length) {
    const err = new Error('No quotations has been accepted for the order');
    err.type = ErrorTypes.RES_NOT_AVAILABLE;
    throw err;
  }
  return dataFormatUtil.formatF2Data(orderData, weight);
};
