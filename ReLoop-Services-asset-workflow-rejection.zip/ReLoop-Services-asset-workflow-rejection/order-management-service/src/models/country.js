const attributesMap = [
  ['countryId', 'country_id'],
  ['countryName', 'country_name'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

/**
 * @swagger
 *  components:
 *    schemas:
 *      Country:
 *        type: object
 *        required:
 *        properties:
 *          country_id:
 *            type: string
 *          country_name:
 *            type: string
 *        example:
 *           country_id: 1
 *           country_name: India
 */
module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('country', {
    country_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    country_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'country',
    schema: 'address',
    timestamps: false,
    indexes: [
      {
        name: 'country_pkey',
        unique: true,
        fields: [
          { name: 'country_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.hasMany(models.location, { as: 'locations', foreignKey: 'country_id' });
    model.hasMany(models.state, { as: 'states', foreignKey: 'country_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
