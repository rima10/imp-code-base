const attributesMap = [
  ['cityId', 'city_id'],
  ['cityName', 'city_name'],
  ['stateId', 'state_id'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

/**
 * @swagger
 *  components:
 *    schemas:
 *      City:
 *        type: object
 *        required:
 *        properties:
 *          city_name:
 *            type: string
 *          state_id:
 *            type: string
 *          country_id:
 *            type: string
 *        example:
 *           city_name: New Delhi
 *           state_name: Delhi
 *           country_id: 1
 */
module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('city', {
    city_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    city_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    state_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'state',
        key: 'state_id',
      },
    },
  }, {
    sequelize,
    tableName: 'city',
    schema: 'address',
    timestamps: false,
    indexes: [
      {
        name: 'city_pkey',
        unique: true,
        fields: [
          { name: 'city_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.hasMany(models.location, { as: 'locations', foreignKey: 'city_id' });
    model.belongsTo(models.state, { as: 'state', foreignKey: 'state_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
