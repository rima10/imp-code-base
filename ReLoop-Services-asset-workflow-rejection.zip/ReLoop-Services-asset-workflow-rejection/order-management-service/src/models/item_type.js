const attributesMap = [
  ['itemTypeId', 'item_type_id'],
  ['itemTypeName', 'item_type_name'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('item_type', {
    item_type_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    item_type_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'item_type',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'item_type_pkey',
        unique: true,
        fields: [
          { name: 'item_type_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.hasMany(models.order_item, { as: 'order_item', foreignKey: 'item_type' });
    model.hasMany(models.model_quote, { as: 'modelQuote', foreignKey: 'item_type' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
