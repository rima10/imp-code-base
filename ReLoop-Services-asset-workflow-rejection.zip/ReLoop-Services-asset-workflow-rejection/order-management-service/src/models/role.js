const Sequelize = require('sequelize');

const attributesMap = [
  ['roleId', 'role_id'],
  ['roleType', 'role_type'],
  ['createdDate', 'created_date'],
  ['lastModifiedDate', 'last_modified_date'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('role', {
    role_id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
    },
    role_type: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
  }, {
    sequelize,
    tableName: 'role',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'role_pkey',
        unique: true,
        fields: [
          { name: 'role_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.hasMany(models.role_bp_mapping, { as: 'role_bp_mappings', foreignKey: 'role_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
