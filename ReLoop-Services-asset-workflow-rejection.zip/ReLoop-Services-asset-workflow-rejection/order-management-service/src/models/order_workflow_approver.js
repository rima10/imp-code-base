const attributesMap = [
  ['orderWorkflowApproverId', 'order_workflow_approver_id'],
  ['orderWorkflowId', 'order_workflow_id'],
  ['workflowApproverId', 'workflow_approver_id'],
  ['status', 'status'],
  ['approverSequence', 'approver_sequence'],
  ['isActive', 'is_active'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('order_workflow_approver', {
    order_workflow_approver_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_workflow_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order_workflow',
        key: 'order_workflow_id',
      },
    },
    workflow_approver_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'workflow_approver',
        key: 'workflow_approver_id',
      },
    },
    approver_sequence: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    status: {
      type: DataTypes.ENUM('Approved', 'Pending', 'Rejected'),
      allowNull: true,
      defaultValue: 'Pending',
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      defaultValue: true,
    },
  }, {
    sequelize,
    tableName: 'order_workflow_approver',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'order_workflow_approver_pkey',
        unique: true,
        fields: [
          { name: 'order_workflow_approver_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.order_workflow, { as: 'orderWorkflow', foreignKey: 'order_workflow_id' });
    model.belongsTo(models.workflow_approver, { as: 'workflow_approver', foreignKey: 'workflow_approver_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
