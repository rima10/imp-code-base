const Sequelize = require('sequelize');

const attributesMap = [
  ['notificationId', 'notificatn_id'],
  ['emailTo', 'to_email'],
  ['notificationBody', 'notification_body'],
  ['notificationStatus', 'notification_status'],
  ['notificationText', 'notification_text'],
  ['createdDate', 'created_date'],
  ['lastModifiedDate', 'last_modified_date'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('notification_mapping', {
    notificatn_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    to_email: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    notification_body: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    notification_status: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    notification_text: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
  }, {
    sequelize,
    tableName: 'notification_mapping',
    schema: 'notification',
    timestamps: false,
    indexes: [
      {
        name: 'notification_mapping_pkey',
        unique: true,
        fields: [
          { name: 'notificatn_id' },
        ],
      },
    ],
  });

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
