const attributesMap = [
  ['rcySubcategoryMapId', 'rcy_cat_map_id'],
  ['bpUserId', 'rcy_id'],
  ['subcategoryId', 'subcat_id'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('recycling_sub_category', {
    rcy_cat_map_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    rcy_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    subcat_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'sub_category',
        key: 'sub_category_id',
      },
    },
  }, {
    sequelize,
    tableName: 'recycling_sub_category',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'recycling_sub_category_pkey',
        unique: true,
        fields: [
          { name: 'rcy_cat_map_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.business_partner, { as: 'rcy', foreignKey: 'rcy_id' });
    model.belongsTo(models.sub_category, { as: 'subcat', foreignKey: 'subcat_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
