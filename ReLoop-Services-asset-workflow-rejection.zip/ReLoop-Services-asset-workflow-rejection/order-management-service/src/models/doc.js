const Sequelize = require('sequelize');

const attributesMap = [
  ['docId', 'doc_id'],
  ['docName', 'doc_name'],
  ['storageKey', 'storage_metadata'],
  ['createdDate', 'created_date'],
  ['lastModifiedDate', 'last_modified_date'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('doc', {
    doc_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    doc_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    storage_metadata: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
  }, {
    sequelize,
    tableName: 'doc',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'doc_pkey',
        unique: true,
        fields: [
          { name: 'doc_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.hasMany(models.order_doc, { as: 'order_docs', foreignKey: 'doc_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
