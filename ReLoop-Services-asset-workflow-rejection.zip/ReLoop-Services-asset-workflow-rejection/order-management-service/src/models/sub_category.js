const attributesMap = [
  ['subcategoryId', 'sub_category_id'],
  ['categoryId', 'category_id'],
  ['subcategoryName', 'sub_category_name'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

/**
 * @swagger
 *  components:
 *    schemas:
 *      SubCategory:
 *        type: object
 *        required:
 *        properties:
 *          sub_category_id:
 *            type: string
 *          category_id:
 *            type: string
 *          sub_category_name:
 *            type: string
 *        example:
 *           category_id: 1
 *           sub_category_id: 1
 *           sub_category_name: IT and Telecom
 */

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('sub_category', {
    sub_category_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    category_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'category',
        key: 'category_id',
      },
    },
    sub_category_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'sub_category',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'sub_category_pkey',
        unique: true,
        fields: [
          { name: 'sub_category_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.category, { as: 'category', foreignKey: 'category_id' });
    model.hasMany(models.order, { as: 'orders', foreignKey: 'sub_category' });
    model.hasMany(models.recycling_sub_category, { as: 'recycling_sub_categories', foreignKey: 'subcat_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
