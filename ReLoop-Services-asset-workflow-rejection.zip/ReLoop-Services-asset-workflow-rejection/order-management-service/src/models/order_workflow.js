const attributesMap = [
  ['orderWorkflowId', 'order_workflow_id'],
  ['orderId', 'order_id'],
  ['workflowId', 'workflow_id'],
  ['orderWorkflowStatus', 'overall_status'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  /**
 * @swagger
 *  components:
 *    schemas:
 *      Order Workflow:
 *        type: object
 *        required:
 *        properties:
 *          order_workflow_id:
 *            type: string
 *          order_id:
 *            type: string
 *          workflow_id:
 *            type: string
 *          overall_status:
 *            type: string
 * */
  const model = sequelize.define('order_workflow', {
    order_workflow_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order',
        key: 'order_id',
      },
    },
    workflow_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'workflow',
        key: 'workflow_id',
      },
    },
    overall_status: {
      type: DataTypes.ENUM('Approved', 'Pending', 'Rejected'),
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'order_workflow',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'order_workflow_pkey',
        unique: true,
        fields: [
          { name: 'order_workflow_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.order, { as: 'order', foreignKey: 'order_id' });
    model.hasMany(models.order_workflow_approver, { as: 'order_workflow_approvers', foreignKey: 'order_workflow_id' });
    model.belongsTo(models.workflow, { as: 'workflow', foreignKey: 'workflow_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
