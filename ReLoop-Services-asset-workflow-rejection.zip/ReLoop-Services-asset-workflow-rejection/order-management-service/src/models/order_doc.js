const Sequelize = require('sequelize');

const attributesMap = [
  ['orderDocId', 'order_doc_id'],
  ['orderId', 'order_id'],
  ['docId', 'doc_id'],
  ['storageKey', 'storage_metadata'],
  ['documentText', 'document_text'],
  ['createdDate', 'created_date'],
  ['lastModifiedDate', 'last_modified_date'],
  ['createdByUserId', 'created_by'],
  ['updatedByUserId', 'updated_by'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('order_doc', {
    order_doc_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order',
        key: 'order_id',
      },
    },
    doc_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'doc',
        key: 'doc_id',
      },
    },
    storage_metadata: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    document_text: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    created_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    updated_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
  }, {
    sequelize,
    tableName: 'order_doc',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'order_doc_pkey',
        unique: true,
        fields: [
          { name: 'order_doc_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.business_partner, { as: 'createdBy', foreignKey: 'created_by' });
    model.belongsTo(models.business_partner, { as: 'updated_by_business_partner', foreignKey: 'updated_by' });
    model.belongsTo(models.doc, { as: 'doc', foreignKey: 'doc_id' });
    model.belongsTo(models.order, { as: 'order', foreignKey: 'order_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
