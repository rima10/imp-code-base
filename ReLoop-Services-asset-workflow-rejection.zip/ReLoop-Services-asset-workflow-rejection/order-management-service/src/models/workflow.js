const attributesMap = [
  ['workflowId', 'workflow_id'],
  ['processStageName', 'process_stage_name'],
  ['processStageSequence', 'process_stage_sequence'],
  ['processTypeId', 'process_type_id'],
  ['bpUserId', 'bp_id'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('workflow', {
    workflow_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    process_stage_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    process_stage_sequence: {
      type: DataTypes.DECIMAL,
      allowNull: false,
    },
    bp_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    process_type_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'process_type',
        key: 'process_type_id',
      },
    },
  }, {
    sequelize,
    tableName: 'workflow',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'workflow_pkey',
        unique: true,
        fields: [
          { name: 'workflow_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.hasMany(models.order_workflow, { as: 'order_workflows', foreignKey: 'workflow_id' });
    model.belongsTo(models.business_partner, { as: 'bp', foreignKey: 'bp_id' });
    model.belongsTo(models.process_type, { as: 'process_type', foreignKey: 'process_type_id' });
    model.hasMany(models.workflow_approver, { as: 'workflow_approvers', foreignKey: 'workflow_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
