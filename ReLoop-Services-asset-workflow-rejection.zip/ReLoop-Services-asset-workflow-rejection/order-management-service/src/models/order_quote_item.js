const Sequelize = require('sequelize');

const attributesMap = [
  ['orderItemQuoteId', 'id'],
  ['orderId', 'order_id'],
  ['orderQuoteId', 'order_quote_id'],
  ['orderItemId', 'order_item_id'],
  ['grade', 'grade'],
  ['dataWipeStatus', 'data_wipe'],
  ['serviceCost', 'service_cost'],
  ['invoiceAmount', 'to_be_invoiced'],
  ['reportStatus', 'report_status'],
  ['accessoriesStatus', 'accessories_status'],
  ['recycleItemUnit', 'recycle_item_unit'],
  ['recycleFinalQty', 'recycle_final_qty'],
  ['recyclePricePerUnit', 'recycle_price_per_unit'],
  ['createdByUserId', 'created_by'],
  ['updatedByUserId', 'updated_by'],
  ['createdDate', 'created_date'],
  ['lastModifiedDate', 'last_modified_date'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);
/**
 * @swagger
 *  components:
 *    schemas:
 *      OrderItemQuote:
 *        type: object
 *        required:
 *        properties:
 *          id:
 *            type: string
 *          order_item_id:
 *            type: string
 *          grade:
 *            type: string
 *          data_wipe:
 *            type: string
 *          report_status:
 *            type: string
 *          to_be_invoiced:
 *            type: decimal
 *          service_cost:
 *            type: decimal
 *          items:
 *            $ref: '#/components/schemas/OrderItem'
 *        example:
 *           orderItemQuoteId: 1
 *           orderId: 20
 *           orderItemId: 2
 *           orderQuoteId: 6
 *           grade: C
 *           dataWipeStatus: Erased
 *           reportStatus: MBT_2/case damage
 *           listPrice: 1000
 *           invoiceAmount: 400
 *           serviceCost: 2
 *           accessoriesStatus: Working
 *           recycleItemUnit: KG/PC
 *           recycleFinalQty: 100
 *           recyclePricePerUnit: 10
 */
module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('order_quote_item', {
    id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    order_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order',
        key: 'order_id',
      },
      primaryKey: true,
    },
    order_quote_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order_quote',
        key: 'id',
      },
      primaryKey: true,
    },
    order_item_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order_item',
        key: 'id',
      },
      primaryKey: true,
    },
    grade: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    data_wipe: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    report_status: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    accessories_status: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    to_be_invoiced: {
      type: DataTypes.DECIMAL,
      allowNull: true,
    },
    service_cost: {
      type: DataTypes.DECIMAL,
      allowNull: true,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    created_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    updated_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    recycle_item_unit: {
      type: DataTypes.ENUM('kg', 'pc'),
      allowNull: true,
    },
    recycle_final_qty: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    recycle_price_per_unit: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'order_quote_item',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'order_quote_item_pkey',
        unique: true,
        fields: [
          { name: 'id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.business_partner, { as: 'created_by_business_partner', foreignKey: 'created_by' });
    model.belongsTo(models.business_partner, { as: 'updated_by_business_partner', foreignKey: 'updated_by' });
    model.belongsTo(models.order, { as: 'order', foreignKey: 'order_id' });
    model.belongsTo(models.order_item, { as: 'order_item', foreignKey: 'order_item_id' });
    model.belongsTo(models.order_quote, { as: 'order_quote', foreignKey: 'order_quote_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
