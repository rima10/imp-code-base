const Sequelize = require('sequelize');

const attributesMap = [
  ['userId', 'bp_id'],
  ['emailId', 'bp_email_id'],
  ['username', 'bp_username'],
  ['phoneNumber', 'bp_phone_number'],
  ['locationId', 'loc_id'],
  ['gstNumber', 'gst_number'],
  ['cinNumber', 'cin'],
  ['panNumber', 'pan'],
  ['panNumber', 'pan'],
  ['industryType', 'industry_type'],
  ['overallRating', 'overall_rating'],
  ['optedNetwork', 'opted_network'],
  ['hasPvtNetwork', 'has_pvt_network'],
  ['isPvtNetwork', 'is_part_of_pvt_nwk'],
  ['archive', 'archive'],
  ['createdDate', 'created_date'],
  ['lastModifiedDate', 'last_modified_date'],
  ['accountContactName', 'account_contact_name'],
  ['companyCode', 'company_code'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

/**
 * @swagger
 *  components:
 *    schemas:
 *      User:
 *        type: object
 *        required:
 *        properties:
 *          bpUserId:
 *            type: string
 *          bpUsername:
 *            type: string
 *          bpEmailID:
 *            type: string
 *            format: email
 *            description: Email for the user, needs to be unique.
 *          bp_phone_number:
 *            type: number
 *        example:
 *           bp_userid: cognito123
 *           bp_username: testUser1
 *           bp_email_id: fake@email.com
 *           bp_phone_number: 9696969696
 */
module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('business_partner', {
    bp_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    bp_userid: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: 'business_partner_bp_userid_key',
    },
    bp_username: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    bp_email_id: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    bp_phone_number: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    loc_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'location',
        key: 'loc_id',
      },
    },
    certification_details: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    certificate_metadata: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    recycling_unit_capacity: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    gst_number: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    industry_type: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    company_code: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    overall_rating: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    opted_network: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    has_pvt_network: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    is_part_of_pvt_nwk: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    archive: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    cin: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    pan: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    auth_number: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    account_contact_name: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'business_partner',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'business_partner_bp_userid_key',
        unique: true,
        fields: [
          { name: 'bp_userid' },
        ],
      },
      {
        name: 'business_partner_pkey',
        unique: true,
        fields: [
          { name: 'bp_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.hasMany(models.bp_private_nwk, { as: 'bpPrivateNwkOwner', foreignKey: 'nwk_owner' });
    model.hasMany(models.bp_private_nwk, { as: 'bpPrivateNwkMember', foreignKey: 'nwk_member' });
    model.hasMany(models.order_invited_business_partner, { as: 'order_invited_business_partners', foreignKey: 'invited_bp_id' });
    model.hasMany(models.order, { as: 'orders', foreignKey: 'created_by' });
    model.hasMany(models.order, { as: 'updated_by_orders', foreignKey: 'updated_by' });
    model.hasMany(models.order_doc, { as: 'order_docs', foreignKey: 'created_by' });
    model.hasMany(models.order_item, { as: 'order_items', foreignKey: 'created_by' });
    model.hasMany(models.order_item, { as: 'updated_by_order_items', foreignKey: 'updated_by' });
    model.hasMany(models.order_notes, { as: 'order_notes', foreignKey: 'updated_by' });
    model.hasMany(models.order_quote, { as: 'order_quotes', foreignKey: 'created_by' });
    model.hasMany(models.order_quote, { as: 'updated_by_order_quotes', foreignKey: 'updated_by' });
    model.hasMany(models.order_quote_item, { as: 'order_quote_items', foreignKey: 'created_by' });
    model.hasMany(models.order_quote_item, { as: 'updated_by_order_quote_items', foreignKey: 'updated_by' });
    model.hasMany(models.order_status, { as: 'order_statuses', foreignKey: 'created_by' });
    model.hasMany(models.order_status, { as: 'updated_by_order_statuses', foreignKey: 'updated_by' });
    model.hasMany(models.quote_history, { as: 'quote_histories', foreignKey: 'updated_by' });
    model.hasMany(models.approver, { as: 'approvers', foreignKey: 'bp_id' });
    model.hasMany(models.certificate, { as: 'certificates', foreignKey: 'bp_id' });
    model.hasMany(models.rating, { as: 'ratings', foreignKey: 'bp_id' });
    model.hasMany(models.rating, { as: 'given_by_ratings', foreignKey: 'given_by' });
    model.hasMany(models.recycling_category, { as: 'recycling_categories', foreignKey: 'rcy_id' });
    model.hasMany(models.recycling_sub_category, { as: 'recycling_sub_categories', foreignKey: 'rcy_id' });
    model.hasMany(models.role_bp_mapping, { as: 'role_bp_mappings', foreignKey: 'bp_id' });
    model.hasMany(models.workflow, { as: 'workflows', foreignKey: 'bp_id' });
    model.belongsTo(models.location, { as: 'loc', foreignKey: 'loc_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
