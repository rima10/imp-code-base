const attributesMap = [
  ['rcyCategoryMapId', 'rec_map_id'],
  ['bpUserId', 'rcy_id'],
  ['categoryId', 'cat_id'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('recycling_category', {
    rec_map_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    rcy_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    cat_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'category',
        key: 'category_id',
      },
    },
  }, {
    sequelize,
    tableName: 'recycling_category',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'recycling_category_pkey',
        unique: true,
        fields: [
          { name: 'rec_map_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.business_partner, { as: 'rcy', foreignKey: 'rcy_id' });
    model.belongsTo(models.category, { as: 'cat', foreignKey: 'cat_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
