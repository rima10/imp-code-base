const attributesMap = [
  ['makeId', 'make_id'],
  ['makeName', 'make_name'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('make', {
    make_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    make_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'make',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'make_pkey',
        unique: true,
        fields: [
          { name: 'make_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.hasMany(models.order_item, { as: 'order_item', foreignKey: 'make' });
    model.hasMany(models.model_quote, { as: 'modelQuote', foreignKey: 'make' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
