const attributesMap = [
  ['stateId', 'state_id'],
  ['stateName', 'state_name'],
  ['countryId', 'country_id'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

/**
 * @swagger
 *  components:
 *    schemas:
 *      State:
 *        type: object
 *        required:
 *        properties:
 *          state_id:
 *            type: string
 *          state_name:
 *            type: string
 *          country_id:
 *            type: string
 *        example:
 *           state_id: 1
 *           state_name: Delhi
 *           country_id: 1
 */
module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('state', {
    state_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    state_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    country_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'country',
        key: 'country_id',
      },
    },
  }, {
    sequelize,
    tableName: 'state',
    schema: 'address',
    timestamps: false,
    indexes: [
      {
        name: 'state_pkey',
        unique: true,
        fields: [
          { name: 'state_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.country, { as: 'country', foreignKey: 'country_id' });
    model.hasMany(models.city, { as: 'cities', foreignKey: 'state_id' });
    model.hasMany(models.location, { as: 'locations', foreignKey: 'state_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
