const Sequelize = require('sequelize');

const attributesMap = [
  ['quoteHistoryId', 'quote_history_id'],
  ['orderQuoteId', 'order_quote_id'],
  ['activity', 'activity'],
  ['activityTime', 'activity_time'],
  ['activityComment', 'activity_comment'],
  ['updatedByUserId', 'updated_by'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('quote_history', {
    quote_history_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_quote_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order_quote',
        key: 'id',
      },
    },
    activity: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    activity_time: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    activity_comment: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    updated_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
  }, {
    sequelize,
    tableName: 'quote_history',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'quote_history_pkey',
        unique: true,
        fields: [
          { name: 'quote_history_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.business_partner, { as: 'updated_by_business_partner', foreignKey: 'updated_by' });
    model.belongsTo(models.order_quote, { as: 'order_quote', foreignKey: 'order_quote_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
