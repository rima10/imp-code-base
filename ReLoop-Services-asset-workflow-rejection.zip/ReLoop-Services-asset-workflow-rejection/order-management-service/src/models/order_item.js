const Sequelize = require('sequelize');

const attributesMap = [
  ['orderItemId', 'id'],
  ['orderId', 'order_id'],
  ['equipmentNumber', 'equipment_no'],
  ['assetNumber', 'asset_no'],
  ['itemType', 'item_type'],
  ['model', 'model'],
  ['make', 'make'],
  ['description', 'description'],
  ['itemQuantity', 'item_quantity'],
  ['companyName', 'company_name'],
  ['companyCode', 'company_code'],
  ['buildingLocation', 'building_loc'],
  ['manufactureSerial', 'manufacture_serial'],
  ['bondStatus', 'bond_status'],
  ['ageInYear', 'age_in_year'],
  ['purchaseYear', 'purchase_year'],
  ['recycleItemUnit', 'recycle_item_unit'],
  ['createdDate', 'created_date'],
  ['lastModifiedDate', 'last_modified_date'],
  ['createdByUserId', 'created_by'],
  ['updatedByUserId', 'updated_by'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

/**
 * @swagger
 *  components:
 *    schemas:
 *      OrderItem:
 *        type: object
 *        required:
 *        properties:
 *          id:
 *            type: string
 *          order_id:
 *            type: string
 *          equipment_no:
 *            type: string
 *          asset_no:
 *            type: string
 *          category_no:
 *            type: string
 *          make:
 *            type: string
 *          description:
 *            type: string
 *          last_modified_date:
 *            type: date
 *          created_date:
 *            type: date
 *          updated_by:
 *            type: string
 *          building_loc:
 *            type: string
 *          created_by:
 *            type: string
 *          manufacture_serial:
 *            type: string
 *          bond_status:
 *            type: string
 *          model:
 *            type: string
 *          age_in_year:
 *            type: date
 *          purchase_year:
 *            type: date
 *        example:
 *           id: 1
 *           order_id: 2
 *           equipment_no: aaa123
 *           asset_no: 123we
 *           category_no: mobile
 *           make: samsung
 *           created_date: 2021-06-14 15:23:59.171827+05:30
 *           last_modified_date: 2021-06-14 15:23:59.171827+05:30
 *           created_by: 12
 *           updated_by: 12
 *           description: SAMSUNG Galaxy Note 3
 *           building_loc: BLR04
 *           manufacture_serial: ACY45
 *           bond_status: debonded
 *           model: samsung 4250
 *           age_in_year: 11
 *           Purchase Year: 2010 and Older
 */
module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('order_item', {
    id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order',
        key: 'order_id',
      },
    },
    equipment_no: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    asset_no: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    item_type: {
      type: DataTypes.STRING,
      allowNull: true,
      references: {
        model: 'item_type',
        key: 'item_type_name',
      },
    },
    make: {
      type: DataTypes.STRING,
      allowNull: true,
      references: {
        model: 'make',
        key: 'make_name',
      },
    },
    description: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    item_quantity: {
      type: DataTypes.DECIMAL,
      allowNull: true,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    created_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    updated_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    company_name: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    company_code: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    building_loc: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    manufacture_serial: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    bond_status: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    model: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    age_in_year: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    purchase_year: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    recycle_item_unit: {
      type: DataTypes.ENUM('kg', 'pc'),
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'order_item',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'order_item_pkey',
        unique: true,
        fields: [
          { name: 'id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.business_partner, { as: 'created_by_business_partner', foreignKey: 'created_by' });
    model.belongsTo(models.business_partner, { as: 'updated_by_business_partner', foreignKey: 'updated_by' });
    model.belongsTo(models.order, { as: 'order', foreignKey: 'order_id' });
    model.hasMany(models.order_quote_item, { as: 'order_quote_items', foreignKey: 'order_item_id' });
    model.belongsTo(models.item_type, { as: 'itemType', foreignKey: 'item_type' });
    model.belongsTo(models.make, { as: 'orderItemMake', foreignKey: 'make' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
