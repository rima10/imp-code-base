const orderService = require('../services/order.service');
const authUtil = require('../utils/auth.util');
/*
  @desc controller function for create order
*/
exports.createOrder = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;
    const orderDetails = req.body;
    const { files } = req;
    const order = await orderService.createOrder(userId, orderDetails, files);
    res.status(201).json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for create order as draft
*/
exports.createOrderAsDraft = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;
    const orderDetails = req.body;
    const { files } = req;
    const order = await orderService.saveOrderAsDraft(userId, orderDetails, files);
    res.status(201).json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get the order details for recycler in order list page
*/
exports.getOrdersList = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;
    const groups = req.userInfo['cognito:groups'];
    let order;
    if (groups.includes(authUtil.ROLES.GP_USER)) {
      order = await orderService.getOrdersForGP(userId);
    } else if (groups.includes(authUtil.ROLES.RP_USER)) {
      order = await orderService.getOrdersForRP(userId);
    }
    res.status(200).json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to cancel an order
*/
exports.cancelOrder = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const response = await orderService.cancelOrder(orderId);
    res.status(200).send(response);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to complete an order
*/
exports.completeOrder = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const response = await orderService.completeOrder(orderId);
    res.status(200).send(response);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get orders based on order id
*/
exports.getRecycleOrderByOrderId = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const order = await orderService.getRecycleOrderByOrderId(orderId);
    res.json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get orders based on order id
*/
exports.getRefurbishOrderByOrderId = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const order = await orderService.getRefurbishOrderByOrderId(orderId);
    res.json(order);
  } catch (error) {
    next(error);
  }
};
/*
@desc controller function to get orders based on order id
*/
exports.getFileURL = async function (req, res, next) {
  try {
    const fileURL = await orderService.getFileURL(req, res, next);
    res.json(fileURL);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get order type
*/
exports.getAllOrderTypes = async function (req, res, next) {
  try {
    const orderTypes = await orderService.getAllOrderTypes();
    res.json(orderTypes);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get consolidated order based on order id for approvers
*/
exports.getRefurbishConsolidatedOrderData = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const order = await orderService.getRefurbishConsolidatedOrderData(orderId);
    res.json(order);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get consolidated order based on order id for recycler
*/
exports.getConsolidatedOrderDataForRP = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const { userId } = req.userInfo;
    const order = await orderService.getConsolidatedOrderDataForRP(userId, orderId);
    res.json(order);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function for creating order type
*/
exports.createOrderTypes = async function (req, res, next) {
  try {
    const { processTypes } = req.body;
    const orderTypes = await orderService.createOrderTypes(processTypes);
    res.json(orderTypes);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to approval stats for order for a stage
*/
exports.getOrderWorkflowByStage = async (req, res, next) => {
  try {
    const { orderId } = req.params;
    const { processType, processStageSequence } = req.query;
    const approvals = await orderService.getOrderWorkflowByStage(orderId, processType, processStageSequence);
    res.json(approvals);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to move order to next step
*/
exports.moveOrderToNextStep = async (req, res, next) => {
  try {
    const { orderId, nextStage } = req.params;
    const { userId } = req.userInfo;
    const { addApprovers } = req.query;
    const order = await orderService.moveOrderToNextStep(userId, orderId, nextStage, addApprovers);
    res.json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to schedule logistics
*/
exports.scheduleLogistics = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const { userId } = req.userInfo;
    const details = req.body;
    const order = await orderService.scheduleLogistics(userId, orderId, details);
    res.json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to accept logistics by recycler
*/
exports.acceptLogistics = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const { userId } = req.userInfo;
    const details = req.body;
    const order = await orderService.acceptLogistics(userId, orderId, details);
    res.json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get the header data of the order
*/
exports.getOrderHeaderData = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const { userId } = req.userInfo;
    const order = await orderService.getOrderHeaderData(userId, orderId);
    res.status(200).json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to update order header data of the order
*/
exports.updateOrderHeaderData = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const { userId } = req.userInfo;

    const updatePayload = req.body;
    const { files } = req;
    if (files && files.picture !== undefined) {
      [updatePayload.picture] = files.picture;
    }
    const updatedOrder = await orderService.updateOrderHeaderData(userId, orderId, updatePayload);
    res.status(200).json(updatedOrder);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get the order items for a particular recycling order
*/
exports.getRecycleOrderItemsForRP = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const { userId } = req.userInfo;
    const order = await orderService.getRecycleOrderItemsForRP(userId, orderId);
    res.status(200).json(order);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get Logistics Data based order id
*/
exports.getLogisticsData = async function (req, res, next) {
  try {
    const { orderId } = req.params;
    const order = await orderService.getLogisticsData(orderId);
    res.json(order);
  } catch (error) {
    next(error);
  }
};
