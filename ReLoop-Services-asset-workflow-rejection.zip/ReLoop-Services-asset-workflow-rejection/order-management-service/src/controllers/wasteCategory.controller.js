const wasteCategoryService = require('../services/wasteCategory.service');

/*
  @desc controller function for Wate Category creation
*/
exports.createCategories = async function (req, res, next) {
  try {
    const categories = req.body;
    const response = await wasteCategoryService.createCategories(categories);
    res.status(201).json(response);
  } catch (error) {
    next(error);
  }
};

/*
    @desc controller function for fetching waste category
  */
exports.getCategories = async function (req, res, next) {
  try {
    const response = await wasteCategoryService.getCategories();
    res.status(200).json(response);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function for Wate Category creation
*/
exports.createSubcategories = async function (req, res, next) {
  try {
    const { subcategories } = req.body;
    const { categoryID } = req.params;
    const response = await wasteCategoryService.createSubcategories(categoryID, subcategories);
    res.status(201).json(response);
  } catch (error) {
    next(error);
  }
};

/*
    @desc controller function for fetching waste category
  */
exports.getsubCategories = async function (req, res, next) {
  try {
    const { categoryID } = req.params;
    const response = await wasteCategoryService.getsubCategories(categoryID);
    res.status(200).json(response);
  } catch (error) {
    next(error);
  }
};
