const userService = require('../services/user.service');
/*
  @desc service function to get private network
*/
exports.getNetworkOwnerByMemberId = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const userPrivateNtws = await userService.getNetworkOwnerByMemberId(userId);
    res.status(200).json(userPrivateNtws);
  } catch (error) {
    next(error);
  }
};
