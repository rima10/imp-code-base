const ErrorTypes = require('../constants/error');
const approvalService = require('./approval.service');
const OrderWorkflowRepo = require('../repo/order_workflow.repo');
const OrderRepo = require('../repo/order.repo');
const ApprovalRepo = require('../repo/approval.repo');

exports.createOrderWorkflow = async (userId, orderId, workflowData) => {
  const update = { orderPosition: 'In Progress' };
  const [rowsUpdate, [order]] = await OrderRepo.updateOrderById(orderId, update);
  if (!rowsUpdate || !order) {
    const err = new Error('Invalid Order Id');
    err.type = ErrorTypes.FAILED_UPDATE;
    throw err;
  }

  return exports.createOrderWorkflowData(userId, workflowData);
};

exports.createOrderWorkflowData = async (userId, workflowData) => {
  const {
    orderId, processStageSequence, processType, addApprovers, commentsForApprover,
  } = workflowData;
  const workflow = await OrderWorkflowRepo.getWorkflow(userId, processStageSequence, processType);
  if (workflow) {
    const orderWorkflow = await OrderWorkflowRepo.createOrderWorkflowSkeleton(orderId, workflow.workflow_id);
    if (addApprovers !== 'false') {
      const { order_workflow_id, workflow_id } = orderWorkflow;
      await approvalService.createOrderWfApprover(orderId, workflow_id, order_workflow_id, '1');
    }

    if (commentsForApprover) {
      const orderNotes = {
        orderId,
        activityName: `${workflow.process_stage_name} comments from GP`,
        activityComment: commentsForApprover,
        activityIdentifier: `pss_${processStageSequence}|gp_${userId}`,
        isInternal: true,
        userId,
      };
      await ApprovalRepo.createOrderNotes(orderNotes);
    }

    return orderWorkflow;
  }
};
