const Models = require('../models/index');
const UserRepo = require('../repo/user.repo');

exports.getUserDatabyCognito = async (cognitoId) => {
  const res = await Models.business_partner.findOne({
    where: {
      bp_userid: cognitoId,
      // Will be used when existing useer archive flag is set to false
      // [Op.not]: [{ archive: true }],
    },
    attributes: ['bp_id', 'bp_username', 'bp_email_id'],
  });
  if (!res) return false;
  const userData = Models.business_partner.attributesAliasesHelper(res.dataValues, { method: 'out' });
  return userData;
};

exports.getApproverDatabyCognito = async (cognitoId) => {
  const approverData = await Models.approver.findOne({
    where: {
      approver_userid: cognitoId,
    },
    attributes: [['approver_id', 'approverId']],
  });
  return approverData;
};

exports.getNetworkOwnerByMemberId = async (memberId) => UserRepo.getNetworkOwnerByMemberId(memberId);
