const XLSX = require('xlsx');
const ErrorTypes = require('../constants/error');
const models = require('../models/index');
const orderService = require('./order.service');
const kakfaUtil = require('../utils/kafka.util');
const quotationRepo = require('../repo/quotation.repo');
const orderItemRepo = require('../repo/order_item.repo');
const orderRepo = require('../repo/order.repo');

const moveToNextStep = async (gpUserId, orderId) => {
  const nextStage = 5;
  orderService.moveOrderToNextStep(gpUserId, orderId, nextStage, true);
};

exports.getRefurbishOrderFirstLevelQuotes = async (orderId) => quotationRepo.getRefurbishInitialQuote(orderId);

exports.getRecycleOrderFirstLevelQuotes = async (orderId) => quotationRepo.getRecycleInitialQuote(orderId);

const notifyBP = async (type, orderId, recyclerId) => {
  const data = await quotationRepo.getQuotationNotificationsData(orderId, recyclerId);
  const notification = {
    type,
    receivers: [{ receiverType: 'bp', email: data.receiver.emailId }],
    values: {
      orderNo: data.order.orderNumber,
      recycler: data.recycler.recyclerName,
    },
  };
  kakfaUtil.runProducer('user-notification', notification);
};

exports.notifyBP = async (userId, orderId) => {
  notifyBP('accept schedule', orderId, userId);
  const order = await orderRepo.getOrder(orderId);
  await order.update({ current_sequence: 5 });
  return true;
};

exports.inviteRecyclersForQuote = async (orderId, recyclers) => {
  await Promise.all(recyclers.map(async (recycler) => {
    await models.order_invited_business_partner.create({
      order_id: orderId,
      invited_bp_id: recycler.recyclerId,
    });
  }));
};

exports.inviteRecyclers = async (userId, orderId, recyclers) => {
  let inviteRecyclers = recyclers;
  if (!inviteRecyclers) {
    inviteRecyclers = await quotationRepo.getAllNetworkMembersForOwner(userId);
  }
  await exports.inviteRecyclersForQuote(orderId, inviteRecyclers);
};

/*
  @desc Create order quote data for recycling order
  @desc by creating order quotes items with respective unit of measurement
  @param Object params
  @return Object - quote data
*/
exports.submitRecycleInitialQuote = async (userId, orderId, quoteData) => {
  await quotationRepo.checkExistingQuote(orderId, userId);
  const { quote } = await quotationRepo.createRecycleInitialQuote(userId, orderId, quoteData);

  const queryOptions = {
    quoteItemAttributes: [
      ['id', 'orderQuoteItemId'], ['order_item_id', 'orderItemId'], ['recycle_item_unit', 'recycleItemUnit'],
    ],
  };
  const updatedQuote = await quotationRepo.getOrderQuoteWithQuoteItems(quote.id, queryOptions);

  notifyBP('quote submitted', orderId, userId);
  return updatedQuote;
};

/*
  @desc Create order quote data for refurbishing order
  @desc by creating model quotes for the consolidated order items
  @param Object params
  @return Object - quote data
*/
exports.submitRefurbishInitialQuote = async (userId, orderId, quoteData) => {
  await quotationRepo.checkExistingQuote(orderId, userId);
  const { quote } = await quotationRepo.createRefurbishInitialQuote(userId, orderId, quoteData);

  const queryOptions = {
    modelQuoteAttributes: ['modelQuoteId', 'make', 'itemType', 'model', 'price'],
  };
  const updatedQuote = await quotationRepo.getOrderQuoteWithModelQuoteItems(quote.id, queryOptions);

  notifyBP('quote submitted', orderId, userId);
  return updatedQuote;
};

exports.acceptQuote = async (orderId, details) => quotationRepo.acceptQuote(orderId, details);

exports.temproaryAcceptQuote = async (orderId, quoteId) => quotationRepo.temproaryAcceptQuote(orderId, quoteId);

exports.rejectQuote = async (orderId, quoteId, details) => quotationRepo.rejectQuote(orderId, quoteId, details);

exports.getCurrentAcceptedOrderQuotation = async (orderId) => {
  const res = await models.order_quote.findOne({
    where: { order_id: orderId, quote_status: 'Accepted' },
    attributes: models.order_quote.attributesAliasesHelper([], { method: 'out' }),
  });
  return res ? res.dataValues : undefined;
};

exports.getScheduledOnsiteVisitDetails = async (orderId) => {
  const queryOptions = {
    orderQuoteProjection: [
      'quoteId',
      'quoteStatus',
      'totalPrice',
      'onsiteScheduledTime',
      'durationTime',
      ['schedule_onsite_visit_comment', 'comments'],
    ],
  };
  return quotationRepo.getAcceptedQuoteForOrder(orderId, queryOptions);
};

exports.submitRecycleItemLevelQuote = async (userId, orderId, quoteData) => {
  const { orderItemQuotes, quoteComments, quoteId } = quoteData;

  const queryOptions = {
    orderQuoteProjection: ['quoteId'],
  };
  const firstLevelQuote = await quotationRepo.getAcceptedQuoteForOrder(orderId, queryOptions);
  if (firstLevelQuote === null || firstLevelQuote.dataValues.quoteId !== quoteId) {
    const err = new Error('The First level quote is not accepted, cannot submit item level quote');
    err.type = ErrorTypes.NOT_ALLOWED_ACTION;
    throw err;
  }

  await Promise.all(orderItemQuotes.map(async (orderItemQuote) => {
    quotationRepo.updateRecycleOrderQuoteItem(orderItemQuote);
  }));

  const updatePayload = {
    assetGradeSubmitted: true,
    assetGradeComments: quoteComments,
  };
  await quotationRepo.updateOrderQuote(userId, orderId, quoteId, updatePayload);

  const orderData = await orderRepo.getOrder(orderId, { projection: ['createdByUserId'] });
  const gpUserId = orderData.dataValues.createdByUserId;
  moveToNextStep(gpUserId, orderId);
  notifyBP('asset grading completed', orderId, userId);

  return quotationRepo.getOrderQuoteWithQuoteItems(firstLevelQuote.dataValues.quoteId);
};

function validateOrderQuoteItems(orderQuoteItems) {
  const requiredFields = ['orderItemQuoteId', 'grade', 'dataWipeStatus', 'reportStatus', 'accessoriesStatus',
    'serviceCost', 'invoiceAmount'];

  for (let i = 0; i < orderQuoteItems.length; i++) {
    let valid = true;
    const item = orderQuoteItems[i];
    requiredFields.forEach((field) => {
      if (item[field] === null || item[field] === undefined || item[field] === '') {
        valid = false;
      }
    });
    if (!valid) return false;
  }
  return true;
}

exports.submitRefurbishOrderAssetGradingQuote = async (user, orderId, quoteId) => {
  const { userId } = user;
  const orderQuoteItems = await orderItemRepo.getOrderItemsWithOrderQuoteItems(orderId, quoteId);
  if (!validateOrderQuoteItems(orderQuoteItems)) {
    const err = new Error('Order Asset Grading Quotation is incomplete. Cannot submit incomplete Quotation.');
    err.type = ErrorTypes.NOT_ALLOWED_ACTION;
    throw err;
  }
  await quotationRepo.updateTotalPrice(orderId, quoteId);

  const updatePayload = {
    assetGradeSubmitted: true,
  };
  await quotationRepo.updateOrderQuote(userId, orderId, quoteId, updatePayload);

  const orderData = await orderRepo.getOrder(orderId, { projection: ['createdByUserId'] });
  const gpUserId = orderData.dataValues.createdByUserId;
  await moveToNextStep(gpUserId, orderId);

  notifyBP('asset grading completed', orderId, userId);
  return true;
};

exports.getRecycleOrderItemLevelQuote = async (orderId) => quotationRepo.getRecycleOrderItemLevelQuote(orderId);

exports.getOrderItemsGradingList = async function (orderId, quoteId) {
  return orderItemRepo.getOrderItemsWithOrderQuoteItems(orderId, quoteId);
};
const assetColumns = [{
  heading: 'Equipment No.',
  key: 'equipmentNumber',
}, {
  heading: 'Asset No.',
  key: 'assetNumber',
}, {
  heading: 'Location',
  key: 'buildingLocation',
}, {
  heading: 'Bond Status',
  key: 'bondStatus',
}, {
  heading: 'Item Type',
  key: 'itemType',
}, {
  heading: 'Make',
  key: 'make',
}, {
  heading: 'Model',
  key: 'model',
}, {
  heading: 'Age in Years',
  key: 'ageInYear',
}, {
  heading: 'Description',
  key: 'description',
}, {
  heading: 'Grade',
  key: 'grade',
}, {
  heading: 'Data wipe',
  key: 'dataWipeStatus',
}, {
  heading: 'Report status',
  key: 'reportStatus',
}, {
  heading: 'Accessories',
  key: 'accessoriesStatus',
}, {
  heading: 'List price',
  key: 'listPrice',
}, {
  heading: 'To be invoiced',
  key: 'invoiceAmount',
}, {
  heading: 'Service cost',
  key: 'serviceCost',
}];
exports.getOrderItemsGradingListInExcel = async function (orderId, quoteId) {
  const orderItems = await orderItemRepo.getOrderItemsWithOrderQuoteItems(orderId, quoteId);
  // create new excel workbook and add orderItems json into a sheet
  const excelOrderItems = orderItems.map((item) => {
    const excelRow = {};
    assetColumns.forEach((colItem) => {
      excelRow[colItem.heading] = item[colItem.key];
    });
    return excelRow;
  });
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(excelOrderItems);
  XLSX.utils.book_append_sheet(wb, ws, 'Asset Grade list');
  const wbOpts = { bookType: 'xlsx', type: 'buffer' };
  const bufferData = XLSX.write(wb, wbOpts);
  return bufferData;
};

exports.saveOrderItemsGradingList = async function (userId, orderId, quoteId, payload) {
  return quotationRepo.updateOrderQuoteItems(userId, orderId, quoteId, payload);
};

exports.getOrderQuoteDetails = async function (orderId, quoteId, projection) {
  return quotationRepo.getOrderQuote(orderId, quoteId, projection);
};

exports.updateOrderQuoteDetails = async function (userId, orderId, quoteId, payload) {
  return quotationRepo.updateOrderQuote(userId, orderId, quoteId, payload);
};

exports.getRecycleConsolidatedOrderItems = async (userId, orderId) => quotationRepo.getRecycleConsolidatedOrderItems(userId, orderId);
