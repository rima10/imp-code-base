const Models = require('../models/index');

exports.createCategories = async function (categories) {
  const res = await Promise.all(categories.map(async (category) => {
    await Models.category.create({ category_name: category.categoryName });
  }));
  return res;
};

exports.getCategories = async function () {
  const categories = await Models.category.findAll({
    attributes:
      [['category_id', 'categoryId'], ['category_name', 'categoryName']],
  });
  return categories;
};

exports.createSubcategories = async function (categoryID, subcategories) {
  const res = await Promise.all(subcategories.map(async (subcategory) => {
    const { subcategoryName } = subcategory;
    await Models.sub_category.create({
      category_id: categoryID,
      sub_category_name: subcategoryName,
    });
  }));
  return res;
};

exports.getsubCategories = async function (categoryID) {
  const subcategories = await Models.sub_category.findAll({
    where: { category_id: categoryID },
    attributes: [['sub_category_id', 'subcategoryId'], ['category_id', 'categoryId'], ['sub_category_name', 'subcategoryName']],
  });
  return subcategories;
};
