const mime = require('mime');
const Models = require('../models/index');
const form6 = require('../templates/form6');
const form2 = require('../templates/form2');
const dc = require('../templates/dc');
const docUtil = require('../utils/docs.util');
const s3UtilFunctions = require('../utils/s3.util');
const dataFormatUtil = require('../utils/order/dataFormat.util');
const DocRepo = require('../repo/doc.repo');

const uploadDocToS3 = async (orderId, documentName, file, fileName, userId, documentText) => {
  const s3FileKey = await s3UtilFunctions.pushFileToS3(file, fileName);
  const documentDetails = {
    s3FileKey,
    documentName,
    documentText,
  };
  return DocRepo.updateOrderDocumentAfterUpload(userId, orderId, documentDetails);
};
exports.uploadDocToS3 = uploadDocToS3;

const uploadGeneratedDocToS3 = async (temp, formOptions, orderId, fileName, docName, userId) => {
  const s3Stream = await docUtil.generateDocument(temp, formOptions);
  const file = { buffer: s3Stream, mimeType: 'application/pdf' };
  await uploadDocToS3(orderId, docName, file, fileName, userId);
};

exports.generateForm6 = async (req, res) => {
  const { orderId } = req.params;
  const { userId } = req.userInfo;
  const {
    weight, invoiceNo, orderNo,
  } = req.body;
  const form6Data = await DocRepo.generateForm6Data(orderId, weight, invoiceNo);
  const temp = form6.getForm6Temp(form6Data);
  const formOptions = {
    type: 'pdf',
    format: 'A4',
    orientation: 'portrait',
  };
  const fileName = `Form 6_${orderNo}.pdf`;
  const stream = await docUtil.generateDocument(temp, formOptions);
  res.attachment(fileName);
  await uploadGeneratedDocToS3(temp, formOptions, orderId, fileName, 'Form 6', userId);
  return stream;
};

exports.generateDC = async (req, res) => {
  const { orderId } = req.params;
  const { userId } = req.userInfo;
  const {
    dcNo, gst, hsnCode, orderNo,
  } = req.body;
  const dcData = await DocRepo.getDCData(orderId, dcNo, gst, hsnCode);
  const temp = dc.getDCTemp(dcData);
  const formOptions = {
    type: 'pdf',
    format: 'A4',
    orientation: 'landscape',
  };
  const fileName = `Delivery Challan_${orderNo}.pdf`;
  const stream = await docUtil.generateDocument(temp, formOptions);
  res.attachment(fileName);
  await uploadGeneratedDocToS3(temp, formOptions, orderId, fileName, 'Delivery Challan', userId);
  return stream;
};

exports.generateForm2 = async (req, res) => {
  const { orderId } = req.params;
  const { userId } = req.userInfo;
  const {
    weight, orderNo,
  } = req.body;
  const form2Data = await DocRepo.generateForm2Data(orderId, weight);
  const temp = form2.getForm2Temp(form2Data);
  const formOptions = {
    type: 'pdf',
    format: 'A4',
    orientation: 'portrait',
  };
  const fileName = `Form 2_${orderNo}.pdf`;
  const stream = await docUtil.generateDocument(temp, formOptions);
  res.attachment(fileName);
  await uploadGeneratedDocToS3(temp, formOptions, orderId, fileName, 'Form 2', userId);
  return stream;
};

exports.downloadFile = async (req, res) => {
  const { key } = req.params;
  const result = await s3UtilFunctions.downloadFile(key, res);
  const { stream, data } = result;
  res.set('Content-Type', mime.getType(key));
  res.set('Content-Length', data.ContentLength);
  res.attachment(key);
  return stream;
};

exports.getOrderDocuments = async (orderId) => DocRepo.getAllDocumentsByOrderId(orderId);

exports.uploadDocument = async (req) => {
  const { orderId } = req.params;
  const { userId } = req.userInfo;
  const { files } = req;
  const { documentName, orderNo, documentText } = req.body;
  const doc = await Models.doc.findOne({ where: { doc_name: documentName } });
  const documentType = doc.doc_name;
  const file = files.document[0];
  const fileNamewithExt = file.originalname;
  const fileExt = fileNamewithExt.substr(fileNamewithExt.lastIndexOf('.') + 1);
  let key;
  if (documentName === 'other') {
    key = `${documentText}_${orderNo}.${fileExt}`;
  } else key = `${documentType}_${orderNo}.${fileExt}`;
  const document = await uploadDocToS3(orderId, documentName, file, key, userId, documentText);
  return document;
};
