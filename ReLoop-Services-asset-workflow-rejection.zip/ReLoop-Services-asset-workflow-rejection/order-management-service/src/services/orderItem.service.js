const ErrorTypes = require('../constants/error');
const utilFunctions = require('../utils/commonFunctions.util');

const docService = require('./doc.service');
const OrderWorkflowService = require('./orderWorkflow.service');

const OrderRepo = require('../repo/order.repo');
const OrderItemRepo = require('../repo/order_item.repo');
const OrderWorkflowRepo = require('../repo/order_workflow.repo');
const ApprovalRepo = require('../repo/approval.repo');

const readExcel = async (file) => {
  const excelData = utilFunctions.convertExcelToJson(file.buffer);
  const header = excelData.shift();
  const assetList = [];
  excelData.forEach((row) => {
    const assetRow = {};
    Object.keys(row).forEach((key) => {
      const value = row[key];
      assetRow[header[key]] = value;
    });
    assetList.push(assetRow);
  });
  return assetList;
};
exports.readExcel = readExcel;

const assetExcelHandler = async (userId, orderDetails, excelFile, orderType) => {
  try {
    const { order_no, order_id } = orderDetails;
    const rows = await readExcel(excelFile);
    if (!rows || !rows.length) {
      const err = new Error('Asset list cannot be empty');
      err.type = ErrorTypes.NOT_ALLOWED_EMPTY_DATA;
      throw err;
    }

    await OrderItemRepo.createOrderItems(rows, userId, order_id, orderType);

    // after creating the order, save the asset file
    const docItemReq = {
      files: { document: [excelFile] },
      params: { orderId: order_id },
      body: { documentName: 'Asset List', orderNo: order_no },
      userInfo: { userId },
    };
    await docService.uploadDocument(docItemReq);

    return Promise.resolve(true);
  } catch (err) {
    return Promise.reject(err);
  }
};
exports.assetExcelHandler = assetExcelHandler;

exports.updateAssetExcelOrderItems = async (userId, orderId, assetExcelFile) => {
  const dbOrder = await OrderRepo.getOrder(orderId);
  const orderDetails = dbOrder.dataValues;

  const rejectedWorkflow = await OrderWorkflowRepo.checkOrderHasRejectedWorkflow(orderId);
  if (orderDetails.order_position !== 'Draft' && !rejectedWorkflow) {
    const err = new Error('Cannot update ongoing order data.');
    err.type = ErrorTypes.NOT_ALLOWED_ACTION;
    throw err;
  }

  // delete existing asset rows for an order
  await OrderItemRepo.deleteOrderItemsForOrder(orderId);

  // created new asset list items in db
  await assetExcelHandler(userId, orderDetails, assetExcelFile, orderDetails.order_type);

  // for rejected workflow scenario, recreate new workflow approver pipeline newly
  if (rejectedWorkflow) {
    const { orderWorkflowId } = rejectedWorkflow;
    await OrderWorkflowRepo.updateOrderWorkflowPipelineInactive(orderWorkflowId);
    await OrderWorkflowService.createOrderWorkflowData(
      userId,
      {
        processStageSequence: orderDetails.current_sequence,
        processType: orderDetails.order_type,
        orderId,
        commentsForApprover: 'Asset list is updated',
      },
    );
    await ApprovalRepo.updateWorkflowOverallStatus(orderWorkflowId);
  }

  const dbRows = await OrderRepo.getOrderItems(orderId, orderDetails.order_type);
  return Promise.resolve(dbRows);
};
