const router = require('express').Router();
const multer = require('multer');

const upload = multer();
const orderController = require('../controllers/order.controller');
const userController = require('../controllers/user.controller');
const authUtil = require('../utils/auth.util');
const orderVisUtil = require('../utils/order/orderVisibility.util');
const validator = require('../utils/validate.util');

module.exports = (app) => {
  /**
 * @swagger
 * /api/order/:
 *   post:
 *    description:  Endpoint to create Order
 *    tags:
 *      - Order
 *    requestBody:
 *      content:
 *        multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *              orderType:
 *                type: string
 *                example: 1
 *              category:
 *                type: integer
 *                example: 1
 *              subcategory:
 *                type: integer
 *                example: 1
 *              network:
 *                type: string
 *                example: Private
 *              orderLocation:
 *                type: string
 *              additionalInfo:
 *                type: string
 *              submissionDeadline:
 *                example: Jul 1, 2021, 11:52:23 AM
 *              recyclerIds:
 *                 type: string
 *                 description: comma separated recycler ids
 *              totalWeight:
 *                 type: number
 *              recycleAssetType:
 *                type: string
 *              processStageSequence:
 *                type: string
 *              picture:
 *                type: string
 *                format: binary
 *              assetExcel:
 *                type: string
 *                format: binary
 *    responses:
 *      200:
 *        description: A list of user's orders.
 *        content:
 *          application/json:
 *            schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Order'
 */
  router.post('/',
    upload.fields([{
      name: 'picture', maxCount: 1,
    }, {
      name: 'assetExcel', maxCount: 1,
    }]),
    [authUtil.validateMiddleware, authUtil.isGpUser],
    validator.createOrderValidations, validator.validate,
    orderController.createOrder);

  /**
  * @swagger
  * /api/order/draft:
  *   post:
  *    description:  Endpoint to create Order as draft
  *    tags:
  *      - Order
  *    parameters:
  *      - name: userId
  *        description: id of the green partner
  *        in: path
  *        required: true
  *        type: number
  *    requestBody:
  *      content:
  *        multipart/form-data:
  *          schema:
  *            type: object
  *            properties:
  *              orderType:
  *                type: string
  *                example: Refurbish
  *              category:
  *                type: integer
  *                example: 1
  *              subcategory:
  *                type: integer
  *                example: 1
  *              network:
  *                type: string
  *                example: Private
  *              orderLocation:
  *                type: string
  *              additionalInfo:
  *                type: string
  *              submissionDeadline:
  *                type: string
  *              recyclerIds:
  *                type: string
  *                description: comma separated recycler ids
  *              totalWeight:
  *                type: number
  *              recycleAssetType:
  *                type: string
  *              picture:
  *                type: string
  *                format: binary
  *              assetExcel:
  *                type: string
  *                format: binary
  */
  router.post('/draft',
    upload.fields([{
      name: 'picture', maxCount: 1,
    }, {
      name: 'assetExcel', maxCount: 1,
    }]),
    [authUtil.validateMiddleware, authUtil.isGpUser],
    orderController.createOrderAsDraft);

  /**
 * @swagger
 * /api/order/:
 *   get:
 *    description: Endpoint to get orders list for GP or RP
 *    tags:
 *      - Order
 *    responses:
 *       200:
 *         description: A list of user's orders.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Order'
 */
  router.get('/',
    [authUtil.validateMiddleware, authUtil.isGpOrRp],
    orderController.getOrdersList);

  /**
  * @swagger
 * /api/order/{orderId}/cancel:
 *   patch:
 *    description: Endpoint to cancel an order
 *    tags:
 *      - Order
 *    parameters:
 *       - name: orderId
 *         description: id of the order
 *         in: path
 *         required: true
 *         type: number
 *    responses:
 *       200:
 *         description: A successful response on order cancellation.
 */

  router.patch('/:orderId/cancel',
    [authUtil.validateMiddleware, authUtil.isGpUser],
    validator.orderIdValidations, validator.validate,
    orderController.cancelOrder);

  /**
* @swagger
* /api/order/{orderId}/complete:
*   patch:
*    description: Endpoint to complete an order
*    tags:
*      - Order
*    parameters:
*       - name: orderId
*         description: id of the order
*         in: path
*         required: true
*         type: number
*    responses:
*       200:
*         description: A successful response on order completion.
*/

  router.patch('/:orderId/complete',
    [authUtil.validateMiddleware, authUtil.isGpUser],
    validator.orderIdValidations, validator.validate,
    orderController.completeOrder);

  /**
 * @swagger
 * /api/order/refurbish/{orderId}:
 *   get:
 *    description:  Endpoint to get refurbish order data by order id
 *    tags:
 *      - Order
 *    parameters:
 *       - name: orderId
 *         description: id of the particular order
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: order details.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Order'
 */
  router.get('/refurbish/:orderId',
    [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isGPAsset],
    validator.orderIdValidations, validator.validate,
    orderController.getRefurbishOrderByOrderId);

  /**
 * @swagger
 * /api/order/recycle/{orderId}:
 *   get:
 *    description:  Endpoint to get recycle order data for order id
 *    tags:
 *      - Order
 *    parameters:
 *       - name: orderId
 *         description: id of the particular order
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: order details.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Order'
 */
  router.get('/recycle/:orderId',
    [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isGPAsset],
    validator.orderIdValidations, validator.validate,
    orderController.getRecycleOrderByOrderId);

  /**
 * @swagger
 * /api/order/orderTypes:
 *   get:
 *    description:  Endpoint to get order Types
 *    tags:
 *      - OrderType
 *    responses:
 *       200:
 *         description: A list of order types.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/OrderType'
 */
  router.get('/orderTypes', [authUtil.validateMiddleware, authUtil.isGpUser], orderController.getAllOrderTypes);

  /**
 * @swagger
 * /api/order/orderTypes:
 *   post:
 *    description:  Endpoint to create Order Type
 *    tags:
 *      - OrderType
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              processTypes:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    processTypeName:
 *                      type: string
 *                      description: Process Type name.
 *                      example: Refurbish
 *                    processTypeid:
 *                      type: string
 *                      description: Process Type Id.
 *                      example: 1
 */
  router.post('/orderTypes', orderController.createOrderTypes);

  /**
  * @swagger
  * /api/order/refurbish/consolidated/{orderId}:
  *   get:
  *    description:  Endpoint to get consolidated order data based on order id
  *    tags:
  *      - Order
  *    parameters:
  *       - name: orderId
  *         description: id of the particular order
  *         in: path
  *         required: true
  *         type: string
  *    responses:
  *       200:
  *         description: order details.
  *         content:
  *           application/json:
  *             schema:
  *              type: array
  *              items:
  *                $ref: '#/components/schemas/Order'
  */
  router.get('/refurbish/consolidated/:orderId',
    [authUtil.validateMiddleware, authUtil.isGpOrRp, authUtil.isGPorRPAsset],
    orderController.getRefurbishConsolidatedOrderData);

  /**
  * @swagger
  * /api/order/workflow/{orderId}:
  *   get:
  *    description:  Endpoint to get workflow approvals for an order
  *    tags:
  *      - Order
  *    parameters:
  *       - name: orderId
  *         description: id of the particular order
  *         in: path
  *         required: true
  *         type: string
  *       - name: processType
  *         description: id of process type
  *         in: query
  *         required: true
  *         type: string
  *       - name: processStageSequence
  *         description: stage sequence number
  *         in: query
  *         required: true
  *         type: string
  *    responses:
  *       200:
  *         description: order details.
  *         content:
  *           application/json:
  *             schema:
  *              type: object
  *              items:
  */
  router.get('/workflow/:orderId',
    [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isGPAsset],
    validator.getStageApprovalStatusValidations, validator.validate,
    orderController.getOrderWorkflowByStage);

  /**
  * @swagger
  * /api/order/refurbish/consolidated/{orderId}/rp:
  *   get:
  *    description:  Endpoint to get consolidated order data for RP
  *    tags:
  *      - Order
  *    parameters:
  *       - name: orderId
  *         description: id of the particular order
  *         in: path
  *         required: true
  *         type: string
  *    responses:
  *       200:
  *         description: order details.
  *         content:
  *           application/json:
  *             schema:
  *              type: array
  *              items:
  *                $ref: '#/components/schemas/Order'
  */
  router.get('/refurbish/consolidated/:orderId/rp',
    [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isRPAsset],
    orderController.getConsolidatedOrderDataForRP);

  /**
    * @swagger
    * /api/order/moveOrderToNextStep/{orderId}/{nextStage}:
    *   post:
    *    description:  Endpoint to get consolidated order data based on order id
    *    tags:
    *      - Order
    *    parameters:
    *       - name: orderId
    *         description: id of the particular order
    *         in: path
    *         required: true
    *         type: string
    *       - name: nextStage
    *         description: next stage sequence number
    *         in: path
    *         required: true
    *         type: string
    *    responses:
    *       201:
    *         description: order details.
    *         content:
    *           application/json:
    *             schema:
    *              type: object
    *              items:
    *               $ref: '#/components/schemas/Order'
    */
  router.post('/moveOrderToNextStep/:orderId/:nextStage',
    [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isGPAsset],
    orderController.moveOrderToNextStep);

  /**
 * @swagger
 * /api/order/scheduleLogistics/{orderId}:
 *   post:
 *    description:  Endpoint to schedule logistics
 *    tags:
 *      - Order
 *    parameters:
 *       - name: orderId
 *         description: id of the particular order
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              scheduledLogisticDate:
 *                type: string
 *                description: timestmap.
 *                example: Jul 1, 2021, 11:52:23 AM
 *    responses:
 *       201:
 *         description: order details.
 *         content:
 *           application/json:
 *             schema:
 *              type: object
 *              items:
 *                $ref: '#/components/schemas/Order'
 */
  router.post('/scheduleLogistics/:orderId',
    [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isGPAsset],
    validator.scheduleLogisticsValidations, validator.validate,
    orderController.scheduleLogistics);

  /**
   * @swagger
   * /api/order/acceptLogistics/{orderId}:
   *   post:
   *    description:  Endpoint to accept logistics by recycler
   *    tags:
   *      - Order
   *    parameters:
   *       - name: orderId
   *         description: id of the particular order
   *         in: path
   *         required: true
   *         type: string
   *    requestBody:
   *      required: true
   *      content:
   *        application/json:
   *          schema:
   *            type: object
   *            required:
   *            properties:
   *              vehicleType:
   *                type: string
   *                description: vehicle type.
   *                example: AMT (Semi Trailer)
   *              vehicleNumber:
   *                type: string
   *                description: vehicle Number.
   *                example: HR26DQ5551
   *              driverName:
   *                type: string
   *                description: Driver Name.
   *                example: John Doe
   *              logisticProvider:
   *                type: string
   *                description: Logistic Provider.
   *                example: XYZ Ltd
   *              recyclerContactName:
   *                type: string
   *                description: Recycler Contact Name.
   *                example: Alen
   *              recyclerContactNumber:
   *                type: string
   *                description: Recycler Contact Number.
   *                example: 9876543210
   *              userId:
   *                type: string
   *                description: user ID.
   *                example: 1
   *    responses:
   *       201:
   *         description: order details.
   *         content:
   *           application/json:
   *             schema:
   *              type: object
   *              items:
   *                $ref: '#/components/schemas/Order'
   */
  router.post('/acceptLogistics/:orderId',
    [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isRPAsset],
    orderController.acceptLogistics);

  /**
  * @swagger
  * /api/order/headerData/{orderId}:
  *   get:
  *    description:  Endpoint to get order header data
  *    tags:
  *      - Initial Quote Submission
  *    parameters:
  *       - name: orderId
  *         description: id of the order
  *         in: path
  *         required: true
  *         type: number
  *    responses:
  *       200:
  *         description: A list of header data of order.
  *         content:
  *           application/json:
  *             schema:
  *              type: object
  *              items:
  *                $ref: '#/components/schemas/Order'
  */
  router.get('/headerData/:orderId',
    [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isRPAsset],
    orderController.getOrderHeaderData);

  /**
  * @swagger
  * /api/order/headerData/{orderId}:
  *   patch:
  *    description:  Endpoint to create Order as draft
  *    tags:
  *      - Order
  *    parameters:
  *      - name: orderId
  *        description: id of the draft order
  *        in: path
  *        required: true
  *        type: number
  *    requestBody:
  *      content:
  *        multipart/form-data:
  *          schema:
  *            type: object
  *            properties:
  *              orderType:
  *                type: string
  *                example: Refurbish
  *              category:
  *                type: integer
  *                example: 1
  *              subcategory:
  *                type: integer
  *                example: 1
  *              network:
  *                type: string
  *                example: Private
  *              orderLocation:
  *                type: string
  *              additionalInfo:
  *                type: string
  *              submissionDeadline:
  *                type: string
  *              recyclerIds:
  *                type: string
  *                description: comma separated recycler ids
  *              totalWeight:
  *                type: number
  *              recycleAssetType:
  *                type: string
  *              picture:
  *                type: string
  *                format: binary
  */
  router.patch('/headerData/:orderId',
    upload.fields([{
      name: 'picture', maxCount: 1,
    }]),
    [authUtil.validateMiddleware, authUtil.isGpUser],
    validator.orderHeaderDataValidations, validator.validate,
    orderController.updateOrderHeaderData);

  /**
   * @swagger
   * /api/user/getNetworkOwner:
   *   get:
   *    description:  Endpoint to get business partner private networks
   *    tags:
   *      - Private Network
   *    responses:
   *       200:
   *         description: A list of user's private networks.
   *         content:
   *           application/json:
   *             schema:
   *              type: array
   *              items:
   *                $ref: '#/components/schemas/PrivateNetwork'
   */
  router.get('/getNetworkOwner',
    [authUtil.validateMiddleware, authUtil.isGpOrRp],
    userController.getNetworkOwnerByMemberId);

  /**
  * @swagger
  * /api/order/recycle/orderItems/{orderId}:
  *   get:
  *    description:  Endpoint to get recycle order items
  *    tags:
  *      - Order
  *    parameters:
  *       - name: orderId
  *         description: id of the particular order
  *         in: path
  *         required: true
  *         type: string
  *    responses:
  *       200:
  *         description: A list of recycle order items of an order.
  *         content:
  *           application/json:
  *             schema:
  *              type: object
  *              items:
  *                $ref: '#/components/schemas/OrderItem'
  */
  router.get('/recycle/orderItems/:orderId',
    [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isRPAsset],
    orderController.getRecycleOrderItemsForRP);

  /**
   * @swagger
   * /api/order/logistics/{orderId}:
   *   get:
   *    description:  Endpoint to get logistics data
   *    tags:
   *      - Order
   *    parameters:
   *       - name: orderId
   *         description: id of the particular order
   *         in: path
   *         required: true
   *         type: string
   *    responses:
   *       201:
   *         description: logistic details.
   *         content:
   *           application/json:
   *             schema:
   *              type: object
   *              items:
   *                $ref: '#/components/schemas/Order'
   */
  router.get('/logistics/:orderId',
    [
      authUtil.validateMiddleware, authUtil.isRpUser,
      authUtil.isRPAsset, orderVisUtil.isQuoteAccepted,
    ],
    orderController.getLogisticsData);

  app.use('/api/order', router);
};
