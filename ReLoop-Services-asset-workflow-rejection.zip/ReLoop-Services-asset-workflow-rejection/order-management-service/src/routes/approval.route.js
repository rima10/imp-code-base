const router = require('express').Router();
const approvalController = require('../controllers/approval.controller');
const authUtil = require('../utils/auth.util');
const validator = require('../utils/validate.util');

module.exports = (app) => {
  router.get('/',
    [authUtil.validateMiddleware, authUtil.isGPApproverUser],
    approvalController.getAllOrdersByApproverId);

  /**
  * @swagger
  * /api/order/approval/{orderId}:
  *   get:
  *    description:  Endpoint to get order data based on order id
  *    tags:
  *      - Order
  *    parameters:
  *       - name: orderId
  *         description: id of the particular order
  *         in: path
  *         required: true
  *         type: string
  *    responses:
  *       200:
  *         description: order details.
  *         content:
  *           application/json:
  *             schema:
  *              type: array
  *              items:
  *                $ref: '#/components/schemas/Order'
  */
  router.get('/:orderId',
    [authUtil.validateMiddleware, authUtil.isGPApproverUser, authUtil.isApproverAsset],
    validator.orderIdValidations, validator.validate,
    approvalController.getOrderForApprover);

  router.post('/:orderId/approve/:orderWorkflowApproverId',
    [authUtil.validateMiddleware, authUtil.isGPApproverUser],
    approvalController.approve);

  router.post('/:orderId/reject/:orderWorkflowApproverId',
    [authUtil.validateMiddleware, authUtil.isGPApproverUser],
    approvalController.reject);

  router.post('/:orderId/resend/:orderWorkflowApproverId',
    [authUtil.validateMiddleware, authUtil.isGpUser],
    approvalController.resendApprovalRequest);

  app.use('/api/order/approval', router);
};
