const router = require('express').Router();
const quotationController = require('../controllers/quotation.controller');
const authUtil = require('../utils/auth.util');
const orderVisUtil = require('../utils/order/orderVisibility.util');
const validator = require('../utils/validate.util');

module.exports = (app) => {
  /**
* @swagger
* /api/order/quotation/inviteRecyclers:
*   post:
*    description:  Endpoint to invite recyclers
*    tags:
*      - Quotation
*    requestBody:
*      required: true
*      content:
*        application/json:
*          schema:
*            type: object
*            required:
*            properties:
*              orderId:
*                type: string
*                description: order id.
*                example: 1
*              recyclers:
*                type: array
*                items:
*                  type: object
*                  properties:
*/
  router.post('/inviteRecyclers',
    [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isGPAsset],
    validator.inviteRecyclersValidations, validator.validate,
    quotationController.inviteRecyclers);

  /**
 * @swagger
 * /api/order/quotation/recycle/initial/{orderId}:
 *   post:
 *    description:  Endpoint to submit recycle initial quotes
 *    tags:
 *      - Quotation
 *    parameters:
 *       - name: orderId
 *         description: order id
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              orderId:
 *                type: string
 *                description: order id.
 *                example: 1
 *              pricePerKg:
 *                type: number
 *                description: price per KG
 *                example: 500
 *              orderItems:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    orderItemId:
 *                      type: string
 *                      description: order item id
 *                      example: 1
 *                    itemUnit:
 *                      type: string
 *                      description: item unit
 *                      example: KG
 *    responses:
 *       200:
 *         description: order details.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/OrderQuote'
 */
  router.post('/recycle/initial/:orderId',
    [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isRPAsset],
    validator.submitRecycleInitialQuoteValidations, validator.validate,
    quotationController.submitRecycleInitialQuote);

  /**
 * @swagger
 * /api/order/quotation/refurbish/initial/${orderId}:
 *   post:
 *    description:  Endpoint to invite recyclers
 *    tags:
 *      - Quotation
 *    parameters:
 *       - name: orderId
 *         description: order id
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              orderId:
 *                type: string
 *                description: order id.
 *                example: 1
 *              orderItems:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    itemType:
 *                      type: string
 *                      description: item type name
 *                      example: Laptop
 *                    make:
 *                      type: string
 *                      description: make name
 *                      example: SAMSUNG
 *                    model:
 *                      type: string
 *                      description: model name
 *                      example: T-450
 *                    price:
 *                      type: number
 *                      description: price
 *                      example: 4000
 *                    count:
 *                      type: number
 *                      description: count
 *                      example: 40
 *    responses:
 *       200:
 *         description: order details.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/OrderQuote'
 */
  router.post('/refurbish/initial/:orderId',
    [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isRPAsset],
    validator.submitRefurbishInitialQuoteValidations, validator.validate,
    quotationController.submitRefurbishInitialQuote);

  /**
 * @swagger
 * /api/order/quotation/recycle/initial/{orderId}:
 *   get:
 *    description:  Endpoint to get consolidated order quotes data based on order id
 *    tags:
 *      - Quotation
 *    parameters:
 *       - name: orderId
 *         description: id of the particular order
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: quotation details.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/OrderQuote'
 */
  router.get('/recycle/initial/:orderId',
    [authUtil.validateMiddleware, authUtil.isGpOrApprover, authUtil.isGPorApproverAsset],
    validator.orderIdValidations, validator.validate,
    quotationController.getRecycleOrderFirstLevelQuotes);

  /**
 * @swagger
 * /api/order/quotation/refurbish/initial/{orderId}:
 *   get:
 *    description:  Endpoint to get consolidated order quotes data based on order id
 *    tags:
 *      - Quotation
 *    parameters:
 *       - name: orderId
 *         description: id of the particular order
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: quotation details.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/OrderQuote'
 */
  router.get('/refurbish/initial/:orderId',
    [authUtil.validateMiddleware, authUtil.isGpOrApprover, authUtil.isGPorApproverAsset],
    validator.orderIdValidations, validator.validate,
    quotationController.getRefurbishOrderFirstLevelQuotes);

  /**
 * @swagger
 * /api/order/quotation/acceptQuote/{orderId}:
 *   post:
 *    description:  Endpoint to accept order quote
 *    tags:
 *      - Quotation
 *    parameters:
 *       - name: orderId
 *         description: id of the particular order
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              scheduledOnsiteDate:
 *                type: string
 *                description: timestmap.
 *                example: Jul 1, 2021, 11:52:23 AM
 *              estimatedTime:
 *                type: string
 *                description: estimated time required for asset garding
 *                example: 4 Hours
 *    responses:
 *       201:
 *         description: quotation details.
 *         content:
 *           application/json:
 *             schema:
 *              type: object
 *              items:
 *                $ref: '#/components/schemas/OrderQuote'
 */
  router.post('/acceptQuote/:orderId',
    [authUtil.validateMiddleware, authUtil.isGpUser, authUtil.isGPAsset],
    validator.acceptQuoteValidations, validator.validate,
    quotationController.acceptQuote);

  /**
 * @swagger
 * /api/order/quotation/temporaryAcceptQuote/{orderId}/{quoteId}:
 *   post:
 *    description:  Endpoint to accept order quote
 *    tags:
 *      - Quotation
 *    parameters:
 *       - name: orderId
 *         description: id of the particular order
 *         in: path
 *         required: true
 *         type: string
 *       - name: quoteId
 *         description: id of the particular quote
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       201:
 *         description: quotation details.
 *         content:
 *           application/json:
 *             schema:
 *              type: object
 *              items:
 *                $ref: '#/components/schemas/OrderQuote'
 */
  router.post('/temporaryAcceptQuote/:orderId/:quoteId',
    [authUtil.validateMiddleware, authUtil.isGpOrApprover, authUtil.isGPorApproverAsset],
    validator.acceptTemporaryQuoteValidations, validator.validate,
    quotationController.temproaryAcceptQuote);

  /**
 * @swagger
 * /api/order/quotation/rejectQuote/{orderId}/{quoteId}:
 *   post:
 *    description:  Endpoint to reject order quote
 *    tags:
 *      - Quotation
 *    parameters:
 *       - name: orderId
 *         description: id of the particular order
 *         in: path
 *         required: true
 *         type: string
 *       - name: quoteId
 *         description: id of the particular quote
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       201:
 *         description: quotation details.
 *         content:
 *           application/json:
 *             schema:
 *              type: object
 *              items:
 *                $ref: '#/components/schemas/OrderQuote'
 */
  router.post('/rejectQuote/:orderId/:quoteId',
    [authUtil.validateMiddleware, authUtil.isGpOrApprover, authUtil.isGPorApproverAsset],
    validator.acceptTemporaryQuoteValidations, validator.validate,
    quotationController.rejectQuote);

  /**
 * @swagger
 * /api/order/quotation/onsiteSchedule/{orderId}:
 *   get:
 *    description:  Endpoint to get onsite visit details
 *    tags:
 *      - Quotation
 *    parameters:
 *       - name: orderId
 *         description: id of the particular order
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       201:
 *         description: quotation details.
 *         content:
 *           application/json:
 *             schema:
 *              type: object
 *              items:
 *                $ref: '#/components/schemas/OrderQuote'
 */
  router.get('/onsiteSchedule/:orderId',
    [
      authUtil.validateMiddleware, authUtil.isGpOrRp, authUtil.isGPorRPAsset,
      orderVisUtil.isQuoteAccepted,
    ],
    validator.orderIdValidations, validator.validate,
    quotationController.getScheduledOnsiteVisitDetails);

  /**
 * @swagger
 * /api/order/quotation/recycle/final/{orderId}:
 *   post:
 *    description:  submit the quote at item level
 *    tags:
 *      - Quotation
 *    parameters:
 *       - name: orderId
 *         description: order id
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              orderItemQuotes:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    orderQuoteItemsId:
 *                      type: string
 *                      description: this field should be an array
 *                      example: []
 *                    finalQty:
 *                      type: number
 *                      description: final quantity
 *                      example: 456
 *                    pricePerUnit:
 *                      type: number
 *                      description: price per unit
 *                      example: 500
 *    responses:
 *       200:
 *         description: order item quote details.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/OrderItemQuote'
 */
  router.post('/recycle/final/:orderId',
    [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isRPAsset],
    validator.submitRecycleFinalQuoteValidations, validator.validate,
    quotationController.submitRecycleItemLevelQuote);

  /**
 * @swagger
 * /api/order/quotation/recycle/final/{orderId}:
 *   get:
 *    description:  Endpoint to get order item quote for a particular order
 *    tags:
 *      - Quotation
 *    parameters:
 *       - name: orderId
 *         description: orderId
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: A list of order item quotes.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/OrderItemQuote'
 */

  router.get('/recycle/final/:orderId',
    [authUtil.validateMiddleware, authUtil.isGpOrApprover, authUtil.isGPorApproverAsset],
    validator.orderIdValidations, validator.validate,
    quotationController.getRecycleOrderItemLevelQuote);

  /**
* @swagger
* /api/order/quotation/refurbish/grading/{orderId}/{quoteId}:
*   get:
*    description:  Endpoint to get order item quotes for a particular order and quote
*    tags:
*      - Quotation
*    parameters:
*       - name: orderId
*         description: Order Id
*         in: path
*         required: true
*         type: number
*       - name: quoteId
*         description: Order quote Id
*         in: path
*         required: true
*         type: number
*    responses:
*       200:
*         description: A list of order item quotes.
*         content:
*           application/json:
*             schema:
*              type: array
*              items:
*                  type: object
*                  properties:
*                    orderItemId:
*                      type: integer
*                      example: 111
*                    equipmentNumber:
*                      type: string
*                      example: 50861403
*                    assetNumber:
*                      type: string
*                      example: RZ1F30LZCDP
*                    model:
*                      type: string
*                      example: Thinkpad T240
*                    make:
*                      type: string
*                      example: SAMSUNG
*                    itemType:
*                      type: string
*                      example: Mobile
*                    orderId:
*                      type: integer
*                      example: 20
*                    orderQuoteId:
*                      type: integer
*                      example: 6
*                    grade:
*                      type: string
*                      example: A
*                    dataWipeStatus:
*                      type: string
*                      example: Erased
*                    reportStatus:
*                      type: string
*                      example: MBT_2/case damage
*                    accessoriesStatus:
*                      type: string
*                      example: Working
*                    serviceCost:
*                      type: integer
*                      example: 20.00
*                    invoiceAmount:
*                      type: integer
*                      example: 200
*                    listPrice:
*                      type: integer
*                      example: 1000
*/
  router.get('/refurbish/grading/:orderId/:quoteId',
    [
      authUtil.validateMiddleware, authUtil.isGpOrRPorApprover,
      authUtil.isGPorRPorApproverAsset, orderVisUtil.isQuoteAccepted],
    validator.quoteValidations, validator.validate,
    quotationController.getOrderItemsGradingList);

  /**
* @swagger
* /api/order/quotation/refurbish/grading/{orderId}/{quoteId}/excel:
*   get:
*    description: Endpoint to download order item asset grading in excel
*    tags:
*      - Quotation
*    parameters:
*       - name: orderId
*         description: Order Id
*         in: path
*         required: true
*         type: number
*       - name: quoteId
*         description: Order quote Id
*         in: path
*         required: true
*         type: number
*    responses:
*       200:
*         description: excel document downloaded.
*/
  router.get('/refurbish/grading/:orderId/:quoteId/excel',
    [authUtil.validateMiddleware],
    validator.quoteValidations, validator.validate,
    quotationController.downloadOrderItemsGradingList);

  /**
* @swagger
* /api/order/quotation/refurbish/grading/{orderId}/{quoteId}:
*   post:
*    description: Endpoint to save changes in order item level quotes
*    tags:
*      - Quotation
*    parameters:
*       - name: orderId
*         description: Order Id
*         in: path
*         required: true
*         type: number
*       - name: quoteId
*         description: Order quote Id
*         in: path
*         required: true
*         type: number
*    requestBody:
*      required: true
*      content:
*        application/json:
*          schema:
*            type: array
*            required:
*            items:
*                type: object
*                properties:
*                    orderItemId:
*                      type: integer
*                      example: 111
*                    equipmentNumber:
*                      type: string
*                      example: 50861403
*                    assetNumber:
*                      type: string
*                      example: RZ1F30LZCDP
*                    model:
*                      type: string
*                      example: Thinkpad T240
*                    make:
*                      type: string
*                      example: SAMSUNG
*                    itemType:
*                      type: string
*                      example: Mobile
*                    orderId:
*                      type: integer
*                      example: 20
*                    orderQuoteId:
*                      type: integer
*                      example: 6
*                    grade:
*                      type: string
*                      example: A
*                    dataWipeStatus:
*                      type: string
*                      example: Erased
*                    reportStatus:
*                      type: string
*                      example: MBT_2/case damage
*                    accessoriesStatus:
*                      type: string
*                      example: Working
*                    serviceCost:
*                      type: integer
*                      example: 20.00
*                    invoiceAmount:
*                      type: integer
*                      example: 200
*                    listPrice:
*                      type: integer
*                      example: 1000
*    responses:
*       200:
*         description: A list of created/updated order item quotes.
*         content:
*           application/json:
*             schema:
*              type: array
*              items:
*                  type: object
*/
  router.post('/refurbish/grading/:orderId/:quoteId',
    [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isRPAsset],
    validator.quoteValidations, validator.validate,
    quotationController.saveOrderItemsGradingList);

  /**
* @swagger
* /api/order/quotation/refurbish/grading/{orderId}/{quoteId}/submit:
*   post:
*    description: Endpoint to submit the asset grading verification for an order
*    tags:
*      - Quotation
*    parameters:
*       - name: orderId
*         description: Order Id
*         in: path
*         required: true
*         type: number
*       - name: quoteId
*         description: Order quote Id
*         in: path
*         required: true
*         type: number
*    responses:
*       200:
*         description: Successful response true
*/
  router.post('/refurbish/grading/:orderId/:quoteId/submit',
    [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isRPAsset],
    validator.quoteValidations, validator.validate,
    quotationController.submitRefurbishOrderAssetGradingQuote);

  /**
* @swagger
* /api/order/quotation/{orderId}/{quoteId}:
*   get:
*    description: Endpoint to get order quote by order id and quote id
*    tags:
*      - Quotation
*    parameters:
*       - name: orderId
*         description: Order Id
*         in: path
*         required: true
*         type: number
*       - name: quoteId
*         description: Order quote Id
*         in: path
*         required: true
*         type: number
*    responses:
*       200:
*         description: A list of order item quotes.
*         content:
*           application/json:
*             schema:
*              type: object
*              $ref: '#/components/schemas/OrderQuote'
*/
  router.get('/:orderId/:quoteId',
    [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isRPAsset],
    quotationController.getOrderQuoteDetails);

  /**
* @swagger
* /api/order/quotation/{orderId}/{quoteId}:
*   post:
*    description: Endpoint to update order quote details by order id and quote id
*    tags:
*      - Quotation
*    parameters:
*       - name: orderId
*         description: Order Id
*         in: path
*         required: true
*         type: number
*       - name: quoteId
*         description: Order quote Id
*         in: path
*         required: true
*         type: number
*    requestBody:
*      required: true
*      content:
*        application/json:
*          schema:
*            type: object
*            required:
*            $ref: '#/components/schemas/OrderQuote'
*    responses:
*       200:
*         description: Successful response for update
*/
  router.post('/:orderId/:quoteId',
    [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isRPAsset],
    validator.quoteValidations, validator.validate,
    quotationController.updateOrderQuoteDetails);

  router.post('/schedule/accept/:orderId',
    [authUtil.validateMiddleware, authUtil.isRpUser],
    validator.orderIdValidations, validator.validate,
    quotationController.notifyBP);

  /**
 * @swagger
 * /api/order/quotation/recycle/consolidated/{orderId}:
 *   get:
 *    description:  Endpoint to get recycle consolidated order items for order id
 *    tags:
 *      - Quotation
 *    parameters:
 *       - name: orderId
 *         description: orderId
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: A list of consolidated order items.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/OrderItemQuote'
 */
  router.get('/recycle/consolidated/:orderId',
    [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isRPAsset],
    quotationController.getRecycleConsolidatedOrderItems);

  app.use('/api/order/quotation', router);
};
