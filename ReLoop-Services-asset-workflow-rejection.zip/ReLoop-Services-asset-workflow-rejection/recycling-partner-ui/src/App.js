import React from 'react';
import { hot } from 'react-hot-loader';
import { ThemeProvider } from '@ui5/webcomponents-react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import { Provider } from 'react-redux';
import '@ui5/webcomponents/dist/Assets';
import '@ui5/webcomponents-icons/dist/AllIcons';
import './asset/style/style.css';
import { store } from './store/store';
import Main from './view/Main';
import PrivateRoute from './view/login/PrivateRoute';
import LoginSuccess from './view/login/loginSuccess';
import ErrorComponent from './view/common/Error';
import CognitoRedirect from './view/login/CognitoRedirect';

const App = () => (
    <Provider store={store}>
        <ThemeProvider>
            <BrowserRouter>
                <Switch>
                    <Route path="/loginSuccessful">
                        <LoginSuccess />
                    </Route>
                    <Route exact path="/logout" component={() => <ErrorComponent text="User signed out" redirect />} />
                    <Route exact path="/login" component={CognitoRedirect} />
                    <PrivateRoute path="/" component={Main} />
                </Switch>
            </BrowserRouter>
        </ThemeProvider>
    </Provider>
);

export default hot(module)(App);
