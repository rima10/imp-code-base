import { createStore, applyMiddleware, combineReducers } from 'redux';
import thunk from 'redux-thunk';
import promise from 'redux-promise-middleware';
import { composeWithDevTools } from 'redux-devtools-extension';
import businessInfo from './reducer/account/businessInfoReducer';
import networkInfo from './reducer/account/privateNetworkReducer';
import serviceLocation from './reducer/account/serviceLocationReducer';
import certificates from './reducer/account/certificatesReducer';
import location from './reducer/locationReducer';
import userInfo from './reducer/loginReducer';
import isLoading from './reducer/loadingReducer';
import notification from './reducer/notificationReducer';
import toast from './reducer/messageReducer';
import orderList from './reducer/order/orderListReducer';
import orderHeaderData from './reducer/order/orderHeaderReducer';
import consolidatedOrderItems from './reducer/order/consolidatedOrderItemReducer';
import recycleOrderItems from './reducer/order/recycleOrderItemReducer';
import recycleConsolidatedOrderItems from './reducer/order/recycleConsolidatedOrderItemReducer';
import logisticsData from './reducer/order/logisticsDataReducer';
import onsiteVisitData from './reducer/order/orderOnsiteVisitReducer';
import orderEvents from './reducer/order/orderEventsReducer';
import orderDocDetails from './reducer/order/orderDocumentsReducer';

const accountReducer = {
    businessInfo,
    networkInfo,
    serviceLocation,
    certificates
};

const orderReducer = {
    orderList,
    orderHeaderData,
    consolidatedOrderItems,
    orderEvents,
    onsiteVisitData,
    orderDocDetails,
    recycleOrderItems,
    recycleConsolidatedOrderItems,
    logisticsData
};

const reducers = {
    account: combineReducers(accountReducer),
    location,
    userInfo,
    isLoading,
    notification,
    toast,
    order: combineReducers(orderReducer)
};

const rootReducer = combineReducers(reducers);

export const store = createStore(rootReducer, composeWithDevTools(applyMiddleware(...[thunk, promise])));
