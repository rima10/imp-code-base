import { ActionType } from 'redux-promise-middleware';
import { SET_ORDER_DOCUMENTS } from '../../actionType';

const initialState = {
    isLoading: false,
    errMsg: null,
    data: []
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${SET_ORDER_DOCUMENTS}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${SET_ORDER_DOCUMENTS}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: payload.data };

        case `${SET_ORDER_DOCUMENTS}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: [] };

        default:
            return state;
    }
};
