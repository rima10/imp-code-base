import { ActionType } from 'redux-promise-middleware';
import { FETCH_RECYCLE_CONSOLIDATED_ORDER_ITEMS } from '../../actionType';

const initialState = {
    isLoading: false,
    errMsg: null,
    data: {}
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_RECYCLE_CONSOLIDATED_ORDER_ITEMS}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${FETCH_RECYCLE_CONSOLIDATED_ORDER_ITEMS}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: payload.data };

        case `${FETCH_RECYCLE_CONSOLIDATED_ORDER_ITEMS}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: {} };

        default:
            return state;
    }
};
