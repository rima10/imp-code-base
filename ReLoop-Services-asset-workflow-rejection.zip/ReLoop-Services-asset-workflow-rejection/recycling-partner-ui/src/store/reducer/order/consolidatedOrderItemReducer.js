import { ActionType } from 'redux-promise-middleware';
import { FETCH_CONSOLIDATED_ORDER_ITEMS_INFO } from '../../actionType';

const initialState = {
    isLoading: false,
    errMsg: null,
    data: {}
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_CONSOLIDATED_ORDER_ITEMS_INFO}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${FETCH_CONSOLIDATED_ORDER_ITEMS_INFO}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: payload.data };

        case `${FETCH_CONSOLIDATED_ORDER_ITEMS_INFO}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: {} };

        default:
            return state;
    }
};
