import { ActionType } from 'redux-promise-middleware';
import { SET_ONSITE_VISIT_DETAILS, SET_ONSITE_VISIT_SCHEDULE } from '../../actionType';

const initialState = {
    isLoading: false,
    errMsg: null,
    data: {}
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${SET_ONSITE_VISIT_SCHEDULE}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${SET_ONSITE_VISIT_SCHEDULE}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null };

        case `${SET_ONSITE_VISIT_SCHEDULE}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload };

        case `${SET_ONSITE_VISIT_DETAILS}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${SET_ONSITE_VISIT_DETAILS}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: payload.data };

        case `${SET_ONSITE_VISIT_DETAILS}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: {} };

        default:
            return state;
    }
};
