import { ActionType } from 'redux-promise-middleware';
import { FETCH_STATES_INFO, FETCH_CITIES_INFO } from '../actionType';

const initialState = {
    states: [],
    cities: {}
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_STATES_INFO}_${ActionType.Fulfilled}`:
            return { ...state, states: payload.data };

        case `${FETCH_CITIES_INFO}_${ActionType.Fulfilled}`: {
            const stateId = payload.data[0].state_id;
            if (Object.keys(state.cities).includes(stateId)) {
                return state;
            }
            const obj = {};
            obj[stateId] = payload.data;
            return { ...state, cities: { ...state.cities, ...obj } };
        }

        default:
            return state;
    }
};
