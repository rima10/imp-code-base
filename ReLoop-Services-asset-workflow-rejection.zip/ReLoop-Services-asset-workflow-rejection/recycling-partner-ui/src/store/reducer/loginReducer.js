import { SET_USER_INFO } from '../actionType';

export default (state = {}, action) => {
    const { type, payload } = action;
    switch (type) {
        case SET_USER_INFO: {
            const { userInfo } = payload;
            const updatedPayload = { ...state, ...userInfo, isLoggedIn: payload.isLoggedIn };
            if (payload.csrf) {
                updatedPayload.csrf = payload.csrf;
            }
            return updatedPayload;
        }

        default:
            return state;
    }
};
