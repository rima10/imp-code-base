import { setUserInfo, loadInProgress, loadCompleted, setNotificationsInfo } from '../actionType';
import { getToken } from '../../utils/authUtils';
import http from '../../utils/httpService';
import { getErrorMessage } from '../../utils/errorMessage';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

export const validateUser = (tokenObj) => async (dispatch, getState) => {
    try {
        const { isLoggedIn } = getState().userInfo;
        if (!isLoggedIn) {
            dispatch(loadInProgress());
            const params = {
                withCredentials: true
            };
            if (tokenObj) {
                params.headers = {
                    authorization: `Bearer ${tokenObj.idToken}`,
                    refresh: tokenObj.refreshToken
                };
            }
            const response = await http.post(`${API_BASE_URL}auth/validate?app=rp`, null, params);
            const { cognitoId } = response.data;
            const userData = await http.get(`${API_BASE_URL}user/cognito/${cognitoId}?bp=rp`, {
                withCredentials: true
            });
            userData.data.cognitoId = cognitoId;
            const csrfData = await http.head(`${API_BASE_URL}getCsrf`, { withCredentials: true });
            const csrf = csrfData.headers['csrf-token'];
            dispatch(setUserInfo(userData.data, true, csrf));
            dispatch(loadCompleted());
        }
    } catch (error) {
        dispatch(setUserInfo(null, false));
        dispatch(loadCompleted());
    }
};

export const getAccessToken = () => async (dispatch, getState) => {
    const tokenObj = await getToken();
    await validateUser(tokenObj)(dispatch, getState);
};

export const logout = () => async () => {
    await http.post(`${API_BASE_URL}auth/logout`, null, {
        withCredentials: true
    });
};

export const getNotificationInfo = () => async (dispatch) => {
    try {
        const notifications = await http.get(`${API_BASE_URL}notification/getNotifications?$skip=0&top=5`, {
            withCredentials: true
        });
        dispatch(setNotificationsInfo(notifications.data));
    } catch (error) {
        console.log(error);
    }
};

export const readNotification = (bpNotificationId) => async (dispatch, getState) => {
    try {
        await http.post(`${API_BASE_URL}notification/readNotification/${bpNotificationId}`, null, {
            withCredentials: true
        });
        dispatch(getNotificationInfo()(dispatch, getState));
    } catch (error) {
        console.log(error);
    }
};

export const getUserData = () => async (dispatch, getState) => {
    try {
        const { cognitoId } = getState().userInfo;
        const userData = await http.get(`${API_BASE_URL}user/cognito/${cognitoId}?bp=rp`, {
            withCredentials: true
        });
        dispatch(setUserInfo(userData.data, true));
    } catch (error) {
        console.log(error);
    }
};

export const downloadPrivacyStatement = (key) => async (dispatch, getState) => {
    try {
        const downloadPromise = await http.get(`${API_BASE_URL}user/privacyStatement/${key}`, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([downloadPromise.data], { type: downloadPromise.headers['content-type'] });
        const url = window.URL.createObjectURL(responseBlob);
        window.open(url, '_blank');
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        console.log(errorMessage);
    }
};

export const getRPPersonalData = () => async (dispatch) => {
    try {
        const response = await http.get(`${API_BASE_URL}user/getRPPersonalData`, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([response.data]);
        const url = window.URL.createObjectURL(responseBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `EverLoop_Personal_Data_${new Date().toLocaleString()}.xlsx`;
        a.click();
    } catch (error) {
        console.log(error);
    }
};
