import sinon from 'sinon';
import { getStates, getCities } from '../../store/action/location';
import mockedAxios from '../../__mocks__/axios';

jest.mock('axios');

describe('Location Action Creator Tests', () => {
    it('returns the action object on getStates call', async () => {
        mockedAxios.get.mockReturnValue({
            data: [
                {
                    state_id: 1,
                    state_name: 'Delhi',
                    country_id: 1
                }
            ]
        });
        const fakeDispatch = sinon.spy();
        const fakePayload = {
            data: [
                {
                    state_id: 1,
                    state_name: 'Delhi',
                    country_id: 1
                }
            ]
        };
        const expected = {
            type: 'FETCH_STATES_INFO',
            payload: fakePayload
        };
        await getStates()(fakeDispatch);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expected);
    });

    it('returns the action object on getCities call', async () => {
        mockedAxios.get.mockReturnValue({
            data: [
                {
                    city_id: '3',
                    city_name: 'Zunheboto',
                    state_id: '3'
                }
            ]
        });
        const fakeDispatch = sinon.spy();
        const fakePayload = {
            data: [
                {
                    city_id: '3',
                    city_name: 'Zunheboto',
                    state_id: '3'
                }
            ]
        };
        const expected = {
            type: 'FETCH_CITIES_INFO',
            payload: fakePayload
        };
        const stateId = '3';
        await getCities(stateId)(fakeDispatch);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expected);
    });
});
