import { showMessage, hideToast } from '../../store/action/toast';

describe('Toast Action Creator Tests', () => {
    it('returns the action object on showMessage call', () => {
        const messagePayload = 'Successfully added';
        const expected = {
            type: 'SHOW_MSG_TOASTER',
            payload: messagePayload
        };
        expect(showMessage(messagePayload)).toEqual(expected);
    });

    it('returns the action object on hideToast call', () => {
        const expected = {
            type: 'HIDE_MSG_TOASTER'
        };
        expect(hideToast()).toEqual(expected);
    });
});
