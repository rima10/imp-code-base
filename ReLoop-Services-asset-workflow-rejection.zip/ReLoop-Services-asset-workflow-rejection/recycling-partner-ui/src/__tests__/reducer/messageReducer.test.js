import messageToaster from '../../store/reducer/messageReducer';
import StatusColor from '../../asset/constants/statusColor';

const getInitialState = () => ({
    show: false,
    status: StatusColor.Information,
    message: ''
});

const getPayload = () => ({
    message: 'Test Message',
    status: 'Negative'
});

describe('Message Reducer', () => {
    it('returns the initial state', () => {
        const fakeAction = {
            type: undefined
        };
        const originalState = getInitialState();
        const expected = getInitialState();
        expect(messageToaster(originalState, fakeAction)).toEqual(expected);
    });

    it('sets to initial state when HIDE_MSG_TOASTER action is received', () => {
        const fakeAction = {
            type: 'HIDE_MSG_TOASTER'
        };
        const originalState = getInitialState();
        const expected = getInitialState();
        expect(messageToaster(originalState, fakeAction)).toEqual(expected);
    });

    it('sets the message and status when SHOW_MSG_TOASTER action is received', () => {
        const payload = getPayload();
        const fakeAction = {
            type: 'SHOW_MSG_TOASTER',
            payload
        };
        const originalState = getInitialState();
        const expected = {
            ...originalState,
            message: payload.message,
            status: payload.status,
            show: true
        };
        expect(messageToaster(originalState, fakeAction)).toEqual(expected);
    });

    it('sets the message and status when REJECTED actions are received', () => {
        const payload = getPayload();
        const fakeAction = {
            type: 'FETCH_BP_BUSINESS_INFO_REJECTED',
            payload
        };
        const originalState = getInitialState();
        const expected = {
            ...originalState,
            message: 'Something went wrong',
            status: payload.status,
            show: true
        };
        expect(messageToaster(originalState, fakeAction)).toEqual(expected);
    });
});
