import orderList from '../../../store/reducer/order/orderListReducer';

const getInitialState = () => ({ isLoading: false, errMsg: null, data: [] });

const getPayload = () => ({
    data: [
        {
            order_id: '1',
            order_no: '2021001',
            created_by: 'XYZ',
            created_date: '2021-08-23T05:03:16.117Z',
            quote_status: 'New'
        }
    ]
});

describe('Order List Reducer', () => {
    it('returns the initial state', () => {
        const fakeAction = {
            type: undefined
        };
        const originalState = getInitialState();
        const expected = getInitialState();
        expect(orderList(originalState, fakeAction)).toEqual(expected);
    });

    it('sets Loading to true when FETCH_ORDER_LIST_PENDING action is received', () => {
        const fakeAction = {
            type: 'FETCH_ORDER_LIST_PENDING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true, errMsg: null };
        const actual = orderList(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets order header data when FETCH_ORDER_LIST_FULFILLED action is received', () => {
        const payload = getPayload();
        const fakeAction = {
            type: 'FETCH_ORDER_LIST_FULFILLED',
            payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: null, data: payload.data };
        const actual = orderList(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets errMsg when FETCH_ORDER_LIST_REJECTED action is received', () => {
        const payload = 'Something went wrong';
        const fakeAction = {
            type: 'FETCH_ORDER_LIST_REJECTED',
            payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: payload, data: [] };
        const actual = orderList(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });
});
