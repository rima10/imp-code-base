import location from '../../store/reducer/locationReducer';

const getInitialState = () => ({
    states: [],
    cities: {}
});

const getStatePayload = () => ({
    data: [
        {
            state_id: '1',
            state_name: 'Kashmir',
            country_id: '1'
        }
    ]
});

const getCityPayload = () => ({
    data: [
        {
            city_id: '1',
            city_name: 'Pūnch',
            state_id: '1'
        },
        {
            city_id: '115',
            city_name: 'Udhampur',
            state_id: '1'
        }
    ]
});

describe('Location Reducer', () => {
    it('returns the initial state', () => {
        const fakeAction = {
            type: undefined
        };
        const originalState = getInitialState();
        const expected = getInitialState();
        expect(location(originalState, fakeAction)).toEqual(expected);
    });

    it('sets states data when FETCH_STATES_INFO_FULFILLED action is received', () => {
        const payload = getStatePayload();
        const fakeAction = {
            type: 'FETCH_STATES_INFO_FULFILLED',
            payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, states: payload.data };
        const actual = location(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets cities data when FETCH_CITIES_INFO_FULFILLED action is received', () => {
        const payload = getCityPayload();
        const fakeAction = {
            type: 'FETCH_CITIES_INFO_FULFILLED',
            payload
        };
        const originalState = getInitialState();
        const obj = {
            1: payload.data
        };
        const expected = { ...originalState, cities: { ...originalState.cities, ...obj } };
        const actual = location(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });
});
