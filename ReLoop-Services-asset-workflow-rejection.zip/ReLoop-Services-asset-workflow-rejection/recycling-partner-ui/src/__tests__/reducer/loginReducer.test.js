import login from '../../store/reducer/loginReducer';

const getInitialState = () => ({});

const getPayload = () => ({
    userInfo: {
        bp_id: '1',
        bp_username: 'XYZ',
        bp_email_id: 'johndoe@everloop.com'
    },
    isLoggedIn: true
});

describe('Login Reducer', () => {
    it('returns the initial state', () => {
        const fakeAction = {
            type: undefined
        };
        const originalState = getInitialState();
        const expected = {};
        expect(login(originalState, fakeAction)).toEqual(expected);
    });

    it('sets userInfo when SET_USER_INFO action is received', () => {
        const payload = getPayload();
        const fakeAction = {
            type: 'SET_USER_INFO',
            payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, ...payload.userInfo, isLoggedIn: payload.isLoggedIn };
        const actual = login(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });
});
