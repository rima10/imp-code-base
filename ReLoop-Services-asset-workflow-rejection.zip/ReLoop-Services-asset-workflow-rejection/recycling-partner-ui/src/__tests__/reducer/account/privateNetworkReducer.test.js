import networkInfo from '../../../store/reducer/account/privateNetworkReducer';

const getInitialState = () => ({
    isLoading: false,
    errMsg: null,
    data: []
});

const getPayload = () => ({
    data: [
        {
            bp_nwk_id: '1',
            nwk_member: '2',
            nwk_owner: '3',
            nwk_member_business_partner: {
                bp_email_id: 'test@everloop.com',
                bp_username: 'test',
                bp_phone_number: '9876543210'
            }
        }
    ]
});

describe('Private Network Reducer', () => {
    it('returns the initial state', () => {
        const fakeAction = {
            type: undefined
        };
        const originalState = getInitialState();
        const expected = getInitialState();
        expect(networkInfo(originalState, fakeAction)).toEqual(expected);
    });

    it('sets isLoading to true when FETCH_BP_NETWORK_INFO_PENDING action is received', () => {
        const fakeAction = {
            type: 'FETCH_BP_NETWORK_INFO_PENDING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true, errMsg: null };
        const actual = networkInfo(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets isLoading to true when CREATE_BP_NETWORK_INFO_PENDING action is received', () => {
        const fakeAction = {
            type: 'CREATE_BP_NETWORK_INFO_PENDING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true, errMsg: null };
        const actual = networkInfo(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets isLoading to true when DELETE_BP_NETWORK_INFO_PENDING action is received', () => {
        const fakeAction = {
            type: 'DELETE_BP_NETWORK_INFO_PENDING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true, errMsg: null };
        const actual = networkInfo(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets networkInfo data when FETCH_BP_NETWORK_INFO_FULFILLED action is received', () => {
        const payload = getPayload();
        const fakeAction = {
            type: 'FETCH_BP_NETWORK_INFO_FULFILLED',
            payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: null, data: payload.data };
        const actual = networkInfo(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets errMsg when FETCH_BP_NETWORK_INFO_REJECTED action is received', () => {
        const payload = 'Something went wrong';
        const fakeAction = {
            type: 'FETCH_BP_NETWORK_INFO_REJECTED',
            payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: payload, data: [] };
        const actual = networkInfo(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets errMsg when CREATE_BP_NETWORK_INFO_REJECTED action is received', () => {
        const payload = 'Something went wrong';
        const fakeAction = {
            type: 'CREATE_BP_NETWORK_INFO_REJECTED',
            payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: payload };
        const actual = networkInfo(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets errMsg when DELETE_BP_NETWORK_INFO_REJECTED action is received', () => {
        const payload = 'Something went wrong';
        const fakeAction = {
            type: 'DELETE_BP_NETWORK_INFO_REJECTED',
            payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: payload };
        const actual = networkInfo(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });
});
