import certificatesReducer from '../../../store/reducer/account/certificatesReducer';

const getInitialState = () => ({
    isLoading: true,
    errMsg: null,
    data: []
});

const getPayload = () => ({
    data: [
        {
            certificateId: '10',
            certificateType: 'State population .copy elsx',
            validPeriod: '2027-01-31',
            authorizationNumber: '231312',
            issuedDate: '2021-01-01',
            recyclingCapacity: '123',
            businessPartnerId: '9',
            certificateName: 'State population .copy elsx',
            certificateStorageMeta: 'prnwk1_9_State population .copy elsx.xlsx'
        }
    ]
});

describe('Certificates Reducer', () => {
    it('returns the initial state', () => {
        const fakeAction = {
            type: undefined
        };
        const originalState = getInitialState();
        const expected = getInitialState();
        expect(certificatesReducer(originalState, fakeAction)).toEqual(expected);
    });

    // POST_CERTIFICATES action
    it('sets isLoading to true when POST_CERTIFICATES action is received', () => {
        const fakeAction = {
            type: 'POST_CERTIFICATES_PENDING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true, errMsg: null };
        const actual = certificatesReducer(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets certificates data with received payload when POST_CERTIFICATES action is fullfilled', () => {
        const payload = getPayload();
        const fakeAction = {
            type: 'POST_CERTIFICATES_FULFILLED',
            payload
        };
        const originalState = getInitialState();
        const expected = {
            ...originalState,
            isLoading: false,
            errMsg: null,
            data: [...originalState.data, ...payload.data]
        };
        const actual = certificatesReducer(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets error when POST_CERTIFICATES action is failed', () => {
        const payload = 'Something went wrong';
        const fakeAction = {
            type: 'POST_CERTIFICATES_REJECTED',
            payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: payload };
        const actual = certificatesReducer(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    // GET_CERTIFICATES action
    it('sets isLoading to true when GET_CERTIFICATES action is received', () => {
        const fakeAction = {
            type: 'GET_CERTIFICATES_PENDING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true, errMsg: null, data: [] };
        const actual = certificatesReducer(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets certificates data with received payload when GET_CERTIFICATES action is fullfilled', () => {
        const payload = getPayload();
        const fakeAction = {
            type: 'GET_CERTIFICATES_FULFILLED',
            payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: null, data: payload.data };
        const actual = certificatesReducer(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets error when GET_CERTIFICATES action is failed', () => {
        const payload = 'Something went wrong';
        const fakeAction = {
            type: 'GET_CERTIFICATES_REJECTED',
            payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: payload, data: [] };
        const actual = certificatesReducer(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    // DOWNLOAD CERTIFICATE action
    it('sets isLoading to true when DOWNLOAD_CERTIFICATE action is received', () => {
        const fakeAction = {
            type: 'DOWNLOAD_CERTIFICATE_PENDING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true, errMsg: null };
        const actual = certificatesReducer(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets isLoading to false when DOWNLOAD_CERTIFICATE action is fullfilled', () => {
        const payload = getPayload();
        const fakeAction = {
            type: 'DOWNLOAD_CERTIFICATE_FULFILLED',
            payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: null };
        const actual = certificatesReducer(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets error when DOWNLOAD_CERTIFICATE action is failed', () => {
        const payload = 'Something went wrong';
        const fakeAction = {
            type: 'DOWNLOAD_CERTIFICATE_REJECTED',
            payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: payload };
        const actual = certificatesReducer(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });
});
