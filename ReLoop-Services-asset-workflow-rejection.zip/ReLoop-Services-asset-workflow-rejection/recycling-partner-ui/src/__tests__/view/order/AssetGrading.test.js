import React from 'react';
import { act } from 'react-dom/test-utils';
import { render, fireEvent, cleanup } from '../../../utils/testUtils';
import { AssetGrading } from '../../../view/order/orderInformation/AssetGradingComponent';

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'), // use actual for all non-hook parts
    useParams: () => ({
        orderNumber: '2021022'
    })
}));

const state = {};
const orderItemsGradeList = [
    {
        accessoriesStatus: 'WORKING',
        assetNumber: 'RZ1F30LZCDP',
        createdByUserId: '9',
        createdDate: '2021-08-28T13:43:29.488Z',
        dataWipeStatus: 'ERASED',
        equipmentNumber: '50861403',
        grade: 'A',
        invoiceAmount: null,
        itemType: 'Mobile',
        lastModifiedDate: '2021-08-29T12:41:53.039Z',
        listPrice: '123',
        make: 'SAMSUNG',
        model: 'Thinkpad T240',
        orderId: '22',
        orderItemId: '67',
        orderItemQuoteId: '230',
        orderQuoteId: '8',
        recycleFinalQty: null,
        recycleItemUnit: null,
        recyclePricePerUnit: null,
        reportStatus: '1',
        serviceCost: '13.45'
    }
];

const orderQuote = {
    quoteId: '6',
    orderId: '20',
    totalPrice: '2001',
    currency: null,
    quoteStatus: 'Accepted',
    onsiteScheduledTime: null,
    quoteComments: '[rsannsa nndasd',
    assetGradeComments: 'sdadsd sdfqafdas',
    createdByUserId: '9',
    updatedByUserId: '9',
    recyclePricePerKg: null,
    createdDate: '2021-08-23T06:33:24.135Z',
    lastModifiedDate: '2021-08-25T08:08:16.280Z'
};
describe('Asset grading component for RP', () => {
    let props;
    beforeEach(() => {
        props = {
            startGetOrderItemsGradeList: jest.fn().mockImplementation(() => Promise.resolve(orderItemsGradeList)),
            startGetOrderQuoteDetails: jest.fn().mockImplementation(() => Promise.resolve(orderQuote)),
            startSaveAssetGradeList: jest.fn().mockImplementation(() => Promise.resolve()),
            startUpdateAssetGradeComments: jest.fn().mockImplementation(() => Promise.resolve()),
            startSubmitAssetGrading: jest.fn().mockImplementation(() => Promise.resolve()),
            orderList: [
                {
                    order_id: '22',
                    order_no: '2021022',
                    quoteId: '8',
                    quote_status: 'Accepted',
                    currentSequence: 4
                }
            ],
            orderHeaderData: {}
        };
    });
    afterEach(cleanup);
    it('Should render asset grade list in edit mode', () => {
        state.order = {
            orderList: {
                data: [
                    {
                        order_id: '22',
                        order_no: '2021022',
                        quoteId: '8',
                        quote_status: 'Accepted',
                        currentSequence: 4
                    }
                ]
            },
            orderHeaderData: { data: {} }
        };
        const { container } = render(<AssetGrading {...props} />, {
            preloadedState: state
        });
        expect(container.querySelector(`#EditBtn`)).toBeInTheDocument();
        expect(container.querySelector(`#SaveCommentsBtn`)).toBeInTheDocument();
    });

    it('Should not allow to submit, when in edit mode but not filled all required fields', async () => {
        state.order = {
            orderList: {
                data: [
                    {
                        order_id: '22',
                        order_no: '2021022',
                        quoteId: '8',
                        quote_status: 'Accepted',
                        currentSequence: 4
                    }
                ]
            },
            orderHeaderData: { data: {} }
        };
        let renderResult;
        act(() => {
            renderResult = render(<AssetGrading {...props} />, {
                preloadedState: state
            });
        });
        const { container, getByText } = renderResult;
        const editBtn = container.querySelector(`#EditBtn`);
        expect(editBtn).toBeInTheDocument();
        fireEvent.click(editBtn);

        fireEvent.click(container.querySelector(`#SubmitBtn`));
        expect(getByText('Please fill all the columns before submission')).toBeInTheDocument();
    });

    it('Should render asset grade list in view mode', () => {
        state.order = {
            orderList: {
                data: [
                    {
                        order_id: '22',
                        order_no: '2021022',
                        quoteId: '8',
                        quote_status: 'Accepted',
                        currentSequence: 5
                    }
                ]
            },
            orderHeaderData: { data: {} }
        };
        const { container } = render(<AssetGrading {...props} />, {
            preloadedState: state
        });
        expect(container.querySelector(`#EditBtn`)).toBeNull();
        expect(container.querySelector(`#SaveCommentsBtn`)).toBeNull();
    });
});
