import { validateContactNumber, validateIsEmpty } from './common';

const validateInput = (value, field, fieldConfig) => {
    if (field === 'vehicleType') {
        return validateIsEmpty(value, field);
    }
    if (field === 'vehicleNumber') {
        return validateIsEmpty(value, field);
    }
    if (field === 'driverName') {
        return validateIsEmpty(value, field);
    }
    if (field === 'recyclerContactNumber') {
        return validateContactNumber(value, fieldConfig.required);
    }
    return { isValid: true, errorMessage: '' };
};

export default validateInput;
