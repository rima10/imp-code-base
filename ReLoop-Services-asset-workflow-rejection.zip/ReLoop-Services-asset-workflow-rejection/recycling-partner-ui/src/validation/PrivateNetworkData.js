import { validateEmail, validateContactNumber, validateIsEmpty } from './common';

const validateInput = (value, field, fieldConfig) => {
    if (field === 'phoneNumber') {
        return validateContactNumber(value, fieldConfig.required);
    }
    if (field === 'emailAddress') {
        return validateEmail(value);
    }
    if (field === 'companyName') {
        return validateIsEmpty(value, field);
    }
    return { isValid: true, errorMessage: '' };
};

export default validateInput;
