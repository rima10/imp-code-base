import {
    validateCIN,
    validateContactNumber,
    validateGST,
    validateIsEmpty,
    validatePAN,
    validatePincode
} from './common';

const validateInput = (value, field, fieldConfig) => {
    if (field === 'businessName') {
        return validateIsEmpty(value, field);
    }
    if (field === 'gstin') {
        return validateGST(value);
    }
    if (field === 'phoneNumber') {
        return validateContactNumber(value, fieldConfig.required);
    }
    if (field === 'pan') {
        return validatePAN(value);
    }
    if (field === 'cin') {
        return validateCIN(value);
    }
    if (field === 'address') {
        return validateIsEmpty(value, field);
    }
    if (field === 'pincode') {
        return validatePincode(value, fieldConfig.required);
    }
    return { isValid: true, errorMessage: '' };
};

export default validateInput;
