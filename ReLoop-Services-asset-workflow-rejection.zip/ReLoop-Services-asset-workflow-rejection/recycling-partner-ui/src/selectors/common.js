export const getUserInfo = (state) => state.userInfo;

export const isLoadingData = (state) => state.isLoading;

export const getToastData = (state) => state.toast;

export const getStatesInfo = (state) => state.location.states;

export const getCitiesInfo = (state) => state.location.cities;

export const getBusinessInfoState = (state) => state.account.businessInfo.data;

export const isBusinessInfoLoading = (state) => state.account.businessInfo.isLoading;

export const getNetworkInfoState = (state) => state.account.networkInfo.data;

export const isNetworkInfoLoading = (state) => state.account.networkInfo.isLoading;

export const getServiceLocationState = (state) => state.account.serviceLocation.data;

export const isServiceLocationLoading = (state) => state.account.serviceLocation.isLoading;

export const getCertificatesState = (state) => state.account.certificates.data;

export const isCertificatesInfoLoading = (state) => state.account.certificates.isLoading;

export const getOrderList = (state) => state.order.orderList.data;

export const isOrderListLoading = (state) => state.order.orderList.isLoading;

export const getOrderHeaderDataState = (state) => state.order.orderHeaderData.data;

export const isOrderHeaderLoading = (state) => state.order.orderHeaderData.isLoading;

export const getConsolidatedOrderItemsState = (state) => state.order.consolidatedOrderItems.data;

export const getOnsiteVisitDetailsState = (state) => state.order.onsiteVisitData.data;

export const isSubmitFirstLevelQuoteLoading = (state) => state.order.orderEvents.isLoading;

export const isAcceptLogisticsScheduleLoading = (state) => state.order.orderEvents.isLoading;

export const getOrderDocInfoState = (state) => state.order.orderDocDetails.data;

export const getOrderId = (state) => state.order.orderHeaderData.data.orderId;

export const getOrderNo = (state) => state.order.orderHeaderData.data.orderNo;

export const getRpName = (state) => state.userInfo.bp_username;

export const getGpName = (state) => state.order.orderHeaderData.data.bpUserName;

export const getOrderCurrentSequenceState = (state) => state.order.orderHeaderData.data.currentSequence;

export const getRecycleOrderItemsState = (state) => state.order.recycleOrderItems.data;

export const isRecycleOrderItemsLoading = (state) => state.order.recycleOrderItems.isLoading;

export const getOrderDocLoading = (state) => state.order.orderDocDetails.isLoading;

export const getRecycleConsolidatedOrderItemsState = (state) => state.order.recycleConsolidatedOrderItems.data;

export const isRecycleConsolidatedOrderItemsLoading = (state) => state.order.recycleConsolidatedOrderItems.isLoading;

export const getLogisticsDataState = (state) => state.order.logisticsData.data;

export const isLogisticsDataLoading = (state) => state.order.logisticsData.isLoading;

export const getNotificationData = (state) => state.notification;
