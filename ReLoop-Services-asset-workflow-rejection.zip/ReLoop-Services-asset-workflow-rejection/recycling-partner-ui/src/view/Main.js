import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Route, Switch, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import { spacing } from '@ui5/webcomponents-react-base';
import PrivateRoute from './login/PrivateRoute';
import LoginSuccess from './login/loginSuccess';
import Header from './header/Header';
import NavBar from './home/NavBar';
import Home from './home/Home';
import ErrorComponent from './common/Error';
import MessageBar from './common/MessageBar';
import NetworkInfoView from './account/NetworkInfoView';
import ServiceLocationView from './account/ServiceLocationView';
import CertificatesInfoView from './account/CertificatesInfoView';
import BusinessInfo from './account/BusinessInfoRouter';
import OrderRouter from './order/OrderRouter';
import { getUserInfo, getToastData } from '../selectors/common';

const Main = ({ userInfo, toast }) => {
    const [isCollapsed, setIsCollapsed] = useState(false);
    const isInitialSetupDone = userInfo.isBusinessDataPresent;
    const handleSideNavCollapse = () => {
        const sidebar = document.querySelector('.sidebar');
        const mainContent = document.querySelector('.main-content');
        sidebar.classList.toggle('sidebar_small');
        mainContent.classList.toggle('main-content_large');
        setIsCollapsed(!isCollapsed);
    };
    return (
        <div className="grid-container">
            <Header
                userName={userInfo.bp_username}
                handleSideNavCollapse={handleSideNavCollapse}
                isInitialSetupDone={isInitialSetupDone}
            />
            {isInitialSetupDone && (
                <div className="sidebar">
                    <NavBar isCollapsed={isCollapsed} />
                </div>
            )}
            <div
                className={isInitialSetupDone ? 'main-content' : 'main-content_initial'}
                style={{
                    marginTop: '60px',
                    ...spacing.sapUiLargeMarginBeginEnd,
                    ...spacing.sapUiLargeMarginBottom
                }}
            >
                {toast.show && <MessageBar message={toast.message} type={toast.status} />}
                {!isInitialSetupDone && <Redirect to="/initialSetup" />}
                <Switch>
                    <Route path="/loginSuccessful">
                        <LoginSuccess />
                    </Route>
                    <PrivateRoute exact path="/account/businessInfo" component={BusinessInfo} />
                    <PrivateRoute exact path="/account/privateNetworkInfo" component={NetworkInfoView} check />
                    <PrivateRoute exact path="/account/serviceLocationInfo" component={ServiceLocationView} />
                    <PrivateRoute exact path="/account/certificatesInfo" component={CertificatesInfoView} />
                    <PrivateRoute path="/order" component={OrderRouter} />
                    <PrivateRoute exact path="/initialSetup" component={Home} />
                    <PrivateRoute exact path="/" component={OrderRouter} />
                    <PrivateRoute exact path="/404" component={() => <ErrorComponent text="Page Not Found" />} />
                    <Redirect from="/" to="/404" />
                </Switch>
            </div>
        </div>
    );
};

const mapStateToProps = (state) => ({
    userInfo: getUserInfo(state),
    toast: getToastData(state)
});

Main.propTypes = {
    userInfo: PropTypes.object,
    toast: PropTypes.object
};

export default connect(mapStateToProps)(Main);
