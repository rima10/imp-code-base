import React, { useEffect, useState, useRef } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import {
    Label,
    Title,
    Toolbar,
    Grid,
    FlexBox,
    ObjectStatus,
    Icon,
    Dialog,
    FileUploader,
    Input,
    Text,
    DatePicker,
    Button
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import moment from 'moment';
import mime from 'mime';
import bg from '../../asset/images/background-image.png';
import { getCertificates, downloadCertificate, saveCertificates } from '../../store/action/account';
import { getCertificatesState, isCertificatesInfoLoading } from '../../selectors/common';
import { certificateTypes } from '../../data/certificates';
import LoadingIndicator from '../common/Loading';

const CertificatesInfoView = ({
    startGetCertificates,
    startDownloadCertificate,
    startPostCertificates,
    certificates,
    isLoading,
    certificateTypes
}) => {
    const [viewData, setViewData] = useState([]);

    const initializeViewData = (certificates) => {
        const mandatoryItems = [];
        const otherItems = [];
        certificates.forEach((certItem) => {
            const certTypeItem = certificateTypes.find((item) => item.value === certItem.certificateType);
            if (certTypeItem && certTypeItem.required) {
                mandatoryItems.push(certItem);
            } else {
                otherItems.push(certItem);
            }
        });

        const data = [];
        data.push({
            title: 'Mandatory Certificates',
            required: true,
            certificates: mandatoryItems,
            certificateTypes: certificateTypes.filter((item) => item.required)
        });
        data.push({
            title: 'Additional / Optional Certificates',
            required: false,
            certificates: otherItems,
            certificateTypes: certificateTypes.filter((item) => !item.required)
        });
        setViewData(data);
    };

    useEffect(() => {
        startGetCertificates();
    }, []);

    useEffect(() => {
        initializeViewData(certificates);
    }, [certificates.length]);

    const isCertificateValid = (certificateItem) => moment().diff(moment(certificateItem.validPeriod)) < 0;

    const onViewCertificate = (certificateId) => {
        // const certItem = certificates.find((item) => item.certificateId === certificateId);
        startDownloadCertificate(certificateId).then((response) => {
            const responseBlob = new Blob([response.value.data], { type: response.value.headers['content-type'] });
            const url = window.URL.createObjectURL(responseBlob);
            window.open(url, '_blank');
        });
    };

    const onDownloadCertificate = (certificateId) => {
        const certItem = certificates.find((item) => item.certificateId === certificateId);
        startDownloadCertificate(certificateId).then((response) => {
            const responseBlob = new Blob([response.value.data]);
            const url = window.URL.createObjectURL(responseBlob);
            const a = document.createElement('a');
            const filename = `${certItem.certificateName}.${mime.getExtension(response.value.headers['content-type'])}`;
            a.href = url;
            a.target = '_blank';
            a.download = filename;
            a.click();
        });
    };

    const otherCertificateFormSpec = {
        headerText: 'Additional / Optional Certificate',
        certificateType: {
            value: '',
            valueState: 'None',
            valueStateMessage: ''
        },
        certificateName: {
            value: '',
            valueState: 'None',
            valueStateMessage: ''
        },
        certificateFile: {
            value: {
                name: ''
            },
            valueState: 'None',
            valueStateMessage: ''
        },
        validPeriod: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            transform: (value) => moment(value, 'DD-MM-YYYY').format('YYYY-MM-DD')
        }
    };
    const getInitialFormFieldsCopy = () => {
        const copyObject = {};
        Object.keys(otherCertificateFormSpec).forEach((field) => {
            if (typeof otherCertificateFormSpec[field] === 'object') {
                copyObject[field] = { ...otherCertificateFormSpec[field] };
            } else {
                copyObject[field] = otherCertificateFormSpec[field];
            }
        });
        return copyObject;
    };
    const [newCertificateItem, setNewCertificateItem] = useState(getInitialFormFieldsCopy());
    const addNewCertificateDialogRef = useRef(null);
    const onAddNewCertificate = (certificateCategory) => {
        const certType = certificateCategory.certificateTypes[0];
        const newCertItem = getInitialFormFieldsCopy();
        newCertItem.certificateType.value = certType.value;
        setNewCertificateItem(newCertItem);
        addNewCertificateDialogRef.current.show();
    };
    const onInputChange = (event, fieldName, value, valid = true) => {
        const tempFormFields = { ...newCertificateItem };
        tempFormFields[fieldName].value = value;
        if (!valid) {
            tempFormFields[fieldName].valueState = 'Error';
        } else {
            tempFormFields[fieldName].valueState = 'None';
            tempFormFields[fieldName].valueStateMessage = '';
        }
        if (value === undefined && fieldName === 'certificateFile') {
            tempFormFields[fieldName].value = {
                name: ''
            };
        }
        setNewCertificateItem(tempFormFields);
    };

    const onSubmitNewCertificate = () => {
        const fileform = new FormData();
        const certificateDetails = [];
        let isValidPayload = true;
        const newCertificateItemCopy = { ...newCertificateItem };
        const newCertificateItemPayload = {};

        fileform.append('certificateFile', newCertificateItemCopy.certificateFile.value);
        const certTypeItem = certificateTypes.find(
            (item) => item.value === newCertificateItemCopy.certificateType.value
        );
        if (!certTypeItem) {
            isValidPayload = false;
            newCertificateItemCopy.certificateType.valueState = 'Error';
            newCertificateItemCopy.certificateType.valueStateMessage = <div>Field is required</div>;
        } else {
            certTypeItem.visibleInputFields.forEach((fieldName) => {
                if (!newCertificateItemCopy[fieldName].value) {
                    isValidPayload = false;
                    newCertificateItemCopy[fieldName].valueState = 'Error';
                    newCertificateItemCopy[fieldName].valueStateMessage = <div>Field is required</div>;
                } else if (newCertificateItemCopy[fieldName].valueState !== 'None') {
                    isValidPayload = false;
                } else {
                    newCertificateItemPayload[fieldName] = newCertificateItemCopy[fieldName].transform
                        ? newCertificateItemCopy[fieldName].transform(newCertificateItemCopy[fieldName].value)
                        : newCertificateItemCopy[fieldName].value;
                }
                if (fieldName === 'certificateFile') {
                    if (!newCertificateItemCopy[fieldName].value.name) {
                        newCertificateItemCopy[fieldName].valueState = 'Error';
                        newCertificateItemCopy[fieldName].valueStateMessage = <div>Field is required</div>;
                    }
                }
            });
            if (!newCertificateItemPayload.certificateName) {
                newCertificateItemPayload.certificateName = certTypeItem.text;
            }
            // eslint-disable-next-line prefer-reflect
            delete newCertificateItemPayload.certificateFile;
            certificateDetails.push(newCertificateItemPayload);
        }
        if (isValidPayload) {
            // finally append the certificateDetails of all rows as a stringified json
            fileform.append('certificateDetails', JSON.stringify(certificateDetails));
            // post certificates expects array
            const forms = [fileform];
            startPostCertificates(forms).then((response) => {
                addNewCertificateDialogRef.current.close();
            });
        } else {
            setNewCertificateItem(newCertificateItemCopy);
        }
    };

    return (
        <>
            {isLoading && <LoadingIndicator />}
            <FlexBox alignItems="Center" direction="Column" justifyContent="SpaceBetween">
                <div style={{ backgroundImage: `url(${bg})`, width: '100%', height: '270px', textAlign: 'center' }}>
                    <Title
                        style={{
                            fontSize: 'x-large',
                            textAlign: 'center',
                            marginTop: '80px',
                            color: '#000000'
                        }}
                    >
                        <b>Certificates</b>
                    </Title>
                    <Label
                        wrappingType="Normal"
                        style={{
                            fontSize: 'large',
                            textAlign: 'center',
                            marginTop: '20px',
                            color: '#000000'
                        }}
                    >
                        Hеre you can upload all the mandatory certificates to verify your profile. If you have
                        additional ones, please add them here as well.
                    </Label>
                </div>
            </FlexBox>
            {viewData.map((viewItem, index) => (
                <div key={`viewItem${index}`}>
                    <Toolbar toolbarStyle="Clear">
                        <Title>{viewItem.title}</Title>
                    </Toolbar>

                    <Grid style={{ margin: '20px' }}>
                        {viewItem.certificates.map((certItem, certIndex) => (
                            <div key={`viewItem.certItem.${certItem.certificateId}`} className="docCard">
                                <FlexBox
                                    direction="Column"
                                    justifyContent="Start"
                                    displayInline
                                    style={{ height: '80%' }}
                                    children={
                                        <>
                                            <Title wrappingType="Normal">{certItem.certificateName}</Title>
                                            <ObjectStatus
                                                style={{ fontSize: '1rem', ...spacing.sapUiMediumMarginTop }}
                                                icon={
                                                    <Icon
                                                        name={isCertificateValid(certItem) ? 'sys-enter-2' : 'alert'}
                                                    />
                                                }
                                                state={isCertificateValid(certItem) ? 'Success' : 'Warning'}
                                            >
                                                {isCertificateValid(certItem) ? 'Valid' : 'Expired'}
                                            </ObjectStatus>
                                            <div style={{ ...spacing.sapUiSmallMarginTop }}>
                                                <Text>
                                                    Expiry Date <br />
                                                    {moment(certItem.validPeriod).format('DD-MM-YYYY')}
                                                </Text>
                                            </div>
                                            <div
                                                style={{
                                                    bottom: 0,
                                                    right: 0,
                                                    width: '100%',
                                                    position: 'absolute',
                                                    margin: '10px',
                                                    border: 'none'
                                                }}
                                            >
                                                <Button
                                                    icon="download"
                                                    className="align-right"
                                                    design="Transparent"
                                                    onClick={(e) => onDownloadCertificate(certItem.certificateId)}
                                                />
                                                <Button
                                                    icon="show"
                                                    className="align-right"
                                                    design="Transparent"
                                                    onClick={(e) => onViewCertificate(certItem.certificateId)}
                                                />
                                            </div>
                                        </>
                                    }
                                />
                            </div>
                        ))}
                        {!viewItem.required && (
                            <div key={`viewItem.${index}.addnew`} className="docCard">
                                <FlexBox
                                    alignItems="Center"
                                    justifyContent="Center"
                                    style={{ height: '80%' }}
                                    children={
                                        <>
                                            <Button
                                                icon="add"
                                                design="Transparent"
                                                style={{ fontSize: '5rem' }}
                                                onClick={(e) => onAddNewCertificate(viewItem)}
                                            />
                                        </>
                                    }
                                />
                            </div>
                        )}
                    </Grid>
                </div>
            ))}
            <Dialog
                ref={addNewCertificateDialogRef}
                headerText={newCertificateItem.headerText}
                footer={
                    <div style={{ bottom: 0, right: 0, width: '100%', margin: '10px', border: 'none' }}>
                        <Button
                            style={spacing.sapUiTinyMargin}
                            design="Emphasized"
                            className="align-right"
                            disabled={isLoading}
                            onClick={onSubmitNewCertificate}
                        >
                            Upload Certificate
                        </Button>
                        <Button
                            style={spacing.sapUiTinyMargin}
                            className="align-right"
                            onClick={(e) => addNewCertificateDialogRef.current.close()}
                        >
                            Close
                        </Button>
                    </div>
                }
                style={{
                    width: '40%'
                }}
            >
                {isLoading && <LoadingIndicator />}
                <Grid style={{ margin: '1rem' }}>
                    <div data-layout-span="XL12 L12 M12 S12">
                        <Label
                            required
                            style={{
                                fontSize: 'larger',
                                display: 'block'
                            }}
                        >
                            Upload Certificate
                        </Label>
                        <FileUploader
                            required
                            id="certificateFile"
                            name="certificateFile"
                            value={newCertificateItem.certificateFile.value.name}
                            valueState={newCertificateItem.certificateFile.valueState}
                            valueStateMessage={newCertificateItem.certificateFile.valueStateMessage}
                            onChange={(e) => onInputChange(e, e.target.name, e.target.files[0])}
                            style={{
                                width: '100%'
                            }}
                        >
                            <Button icon="upload" design="Transparent" />
                        </FileUploader>
                    </div>
                    <div data-layout-span="XL12 L12 M12 S12">
                        <Label
                            required
                            style={{
                                fontSize: 'larger',
                                display: 'block'
                            }}
                        >
                            Certificate Name
                        </Label>
                        <Input
                            type="Text"
                            name="certificateName"
                            value={newCertificateItem.certificateName.value}
                            valueState={newCertificateItem.certificateName.valueState}
                            valueStateMessage={newCertificateItem.certificateName.valueStateMessage}
                            onChange={(e) => onInputChange(e, e.target.name, e.target.attributes.value.value)}
                            style={{
                                width: '100%'
                            }}
                        />
                    </div>
                    <div data-layout-span="XL12 L12 M12 S12">
                        <Label
                            required
                            style={{
                                fontSize: 'larger',
                                display: 'block'
                            }}
                        >
                            Valid Period
                        </Label>
                        <DatePicker
                            name="validPeriod"
                            minDate={moment().format('DD-MM-YYYY')}
                            value={newCertificateItem.validPeriod.value}
                            valueState={newCertificateItem.validPeriod.valueState}
                            valueStateMessage={newCertificateItem.validPeriod.valueStateMessage}
                            onChange={(e) => onInputChange(e, e.target.name, e.detail.value, e.detail.valid)}
                            primaryCalendarType="Gregorian"
                            style={{
                                width: '100%'
                            }}
                            formatPattern="dd-MM-yyyy"
                            placeholder="DD-MM-YYYY"
                        />
                    </div>
                </Grid>
            </Dialog>
        </>
    );
};

const mapStateToProps = (state) => ({
    certificates: getCertificatesState(state),
    isLoading: isCertificatesInfoLoading(state),
    certificateTypes
});

const mapDispatchToProps = (dispatch) => ({
    startGetCertificates: () => dispatch(getCertificates()),
    startDownloadCertificate: (certificateId) => dispatch(downloadCertificate(certificateId)),
    startPostCertificates: (payload) => dispatch(saveCertificates(payload))
});

CertificatesInfoView.propTypes = {
    startGetCertificates: PropTypes.func.isRequired,
    startDownloadCertificate: PropTypes.func.isRequired,
    startPostCertificates: PropTypes.func.isRequired,
    certificates: PropTypes.array,
    isLoading: PropTypes.bool,
    certificateTypes: PropTypes.array
};

CertificatesInfoView.defaultProps = {
    certificates: []
};

export default connect(mapStateToProps, mapDispatchToProps)(CertificatesInfoView);
