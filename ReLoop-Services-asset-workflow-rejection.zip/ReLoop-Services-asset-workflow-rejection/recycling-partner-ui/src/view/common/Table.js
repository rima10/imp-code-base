import React from 'react';
import {
    Label,
    Button,
    Toolbar,
    Input,
    Table,
    TableColumn,
    ToolbarSpacer,
    TableRow,
    TableCell,
    Text,
    Select,
    Option,
    CheckBox,
    MultiComboBox,
    MultiComboBoxItem,
    TextArea,
    Title,
    Loader
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';

/**
 *
 * @param {columnOrder} is to follow the order of columns rendering as passed in columns array: so columns should be object array
 *
 */
const AccountTable = ({
    rows = [],
    columns = [],
    buttons = [],
    text,
    isLoading,
    onInputChange,
    columnOrder,
    height
}) => {
    const getTableStyle = () => {
        const style = { border: '1px solid #888888', overflowX: 'auto' };
        if (height) {
            style.height = height;
        }
        return style;
    };
    const getCell = (cell, rowNumber, field, columnDef = {}) => {
        switch (cell.type) {
            case 'text':
                return (
                    <Text
                        className={columnDef.viewFieldClassNames ? columnDef.viewFieldClassNames : 'tableCellText'}
                        tooltip={cell.value}
                        style={columnDef.style ? { ...columnDef.style, ...cell.style } : {}}
                    >
                        {cell.value}
                    </Text>
                );
            case 'input':
                return (
                    <Input
                        type={cell.dataType ? cell.dataType : 'Text'}
                        id={field + rowNumber}
                        style={columnDef.style ? columnDef.style : {}}
                        value={cell.value}
                        valueState={cell.valueState}
                        valueStateMessage={cell.valueStateMessage}
                        onInput={(e) =>
                            columnDef.onInputChange
                                ? columnDef.onInputChange(rowNumber, field, e.target.attributes.value.value)
                                : onInputChange(rowNumber, field, e)
                        }
                    />
                );
            case 'select':
                return (
                    <Select
                        id={field + rowNumber}
                        style={columnDef.style ? columnDef.style : {}}
                        valueState={cell.valueState}
                        valueStateMessage={cell.valueStateMessage}
                        onChange={(e) =>
                            columnDef.onInputChange
                                ? columnDef.onInputChange(rowNumber, field, e.detail.selectedOption.dataset.id)
                                : onInputChange(rowNumber, field, e)
                        }
                    >
                        <Option id="-1" value="-1">
                            Select a {columnDef.heading}
                        </Option>
                        {columnDef.options &&
                            columnDef.options.map((option, idx) => (
                                <Option
                                    key={`${field}|${rowNumber}|${option.value}|${idx}`}
                                    data-id={option.value}
                                    selected={option.value === cell.value}
                                >
                                    {option.text}
                                </Option>
                            ))}
                    </Select>
                );
            case 'multiComboBox':
                return (
                    <MultiComboBox
                        id={field + rowNumber}
                        // value={option[cell.property.value]}
                        valueState={cell.valueState}
                        valueStateMessage={cell.valueStateMessage}
                        onSelectionChange={(e) =>
                            columnDef.onInputChange
                                ? columnDef.onInputChange(rowNumber, field, e.detail.items)
                                : onInputChange(rowNumber, field, e)
                        }
                        placeholder={`Select ${cell.property.name}`}
                    >
                        <MultiComboBoxItem id="-1" value="-1" text={`All ${cell.property.name}`} />
                        {cell.options.map((option) => (
                            <MultiComboBoxItem
                                key={option[cell.property.id]}
                                id={option[cell.property.id]}
                                selected={option[cell.property.value] === cell.value.name}
                                text={option[cell.property.value]}
                                value={option[cell.property.value]}
                            />
                        ))}
                    </MultiComboBox>
                );
            case 'checkbox':
                return (
                    <CheckBox
                        id={field + rowNumber}
                        onChange={(e) =>
                            columnDef.onInputChange
                                ? columnDef.onInputChange(rowNumber, field, e)
                                : onInputChange(rowNumber, field, e)
                        }
                        style={{ zoom: '0.7' }}
                        disabled={cell.readonly}
                        checked={cell.value}
                    />
                );
            case 'textarea':
                return (
                    <TextArea
                        id={field + rowNumber}
                        style={columnDef.style ? columnDef.style : {}}
                        growing
                        growingMaxLines={5}
                        value={cell.value}
                        onInput={(e) =>
                            columnDef.onInputChange
                                ? columnDef.onInputChange(rowNumber, field, e.target.attributes.value.value)
                                : onInputChange(rowNumber, field, e)
                        }
                    />
                );
            default:
                return null;
        }
    };

    const getRowCells = (row, rowIndex) => {
        if (!columnOrder) {
            return Object.keys(row).map((cell, id) => (
                <TableCell style={{ verticalAlign: 'middle', width: '5rem' }} key={id}>
                    {getCell(row[cell], rowIndex, cell)}
                </TableCell>
            ));
        }
        return columns.map((colItem, colIndex) => (
            <TableCell style={{ ...colItem.style, verticalAlign: 'middle' }} key={colIndex}>
                {getCell(row[colItem.key], rowIndex, colItem.key, colItem)}
            </TableCell>
        ));
    };
    const getColumns = () => {
        if (!columnOrder) {
            return columns.map((column, idx) => (
                <TableColumn key={idx} style={{ width: '5rem', border: '1px' }}>
                    <Label style={{ fontSize: 'var(--sapFontSize)' }}>{column}</Label>
                </TableColumn>
            ));
        }
        return columns.map((column, idx) => (
            <TableColumn key={idx}>
                <Label style={{ ...column.style, fontSize: 'var(--sapFontSize)' }}>{column.heading}</Label>
            </TableColumn>
        ));
    };
    const renderFunction = () => (
        <div style={{ width: '100%' }}>
            <Toolbar style={{ ...spacing.sapUiLargeMarginTop, fontSize: '1.1rem' }}>
                <Title style={{ fontWeight: 'bold' }}>{text}</Title>
                <ToolbarSpacer />
                <div>
                    {buttons.map((button, idx) => (
                        <span key={button.name}>
                            {!button.hide && (
                                <Button
                                    id={idx}
                                    onClick={button.onClick}
                                    icon={button.icon}
                                    style={{ marginLeft: '10px' }}
                                    disabled={button.disabled}
                                    design={button.design ? button.design : ''}
                                >
                                    {button.name}
                                </Button>
                            )}
                        </span>
                    ))}
                </div>
            </Toolbar>
            {isLoading && <Loader />}
            <Table
                style={getTableStyle()}
                showNoData
                stickyColumnHeader={!!height}
                noDataText="No data available"
                columns={getColumns()}
            >
                {rows.map((row, idx) => (
                    <TableRow key={idx}>{getRowCells(row, idx)}</TableRow>
                ))}
            </Table>
        </div>
    );
    return renderFunction();
};

export default AccountTable;
