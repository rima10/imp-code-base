import React from 'react';
// eslint-disable-next-line no-unused-vars
const { REACT_APP_USERPOOLBASEURI, REACT_APP_CLIENTID, REACT_APP_CALLBACKURI } = process.env;
// eslint-disable-next-line max-len
const COGNITO_REDIRECT = `${REACT_APP_USERPOOLBASEURI}/login?client_id=${REACT_APP_CLIENTID}&response_type=code&scope=aws.cognito.signin.user.admin+email+openid+phone&redirect_uri=${REACT_APP_CALLBACKURI}`;
class CognitoRedirect extends React.Component {
    componentDidMount() {
        window.location.href = `${COGNITO_REDIRECT}`;
    }

    render() {
        return <></>;
    }
}

export default CognitoRedirect;
