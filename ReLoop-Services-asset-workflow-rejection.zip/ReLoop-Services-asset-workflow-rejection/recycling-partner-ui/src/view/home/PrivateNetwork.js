import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Button, Grid, Input, Title, Label, FlexBox, Icon, Loader } from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import { connect } from 'react-redux';
import { useHistory } from 'react-router-dom';
import validateInput from '../../validation/PrivateNetworkData';
import { registerBPNetworkInfo } from '../../store/action/account';
import { isNetworkInfoLoading } from '../../selectors/common';
import { camelCaseToSentence } from '../../utils/formatter';
import { getUserData } from '../../store/action/taskAction';
import { showMessage } from '../../store/action/toast';

export const PrivateNetworkStep = ({ startRegisterBPNetworkInfo, isLoading, startGetUserData, startShowMessage }) => {
    const history = useHistory();
    const [inputBox, setInputBox] = useState([
        {
            companyName: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                required: true
            },
            contactName: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                required: false
            },
            emailAddress: {
                value: '',
                valueState: 'None',
                valueStateMessage: '',
                required: true
            }
        }
    ]);

    const onSave = () => {
        let isValid = true;
        const tempInputBox = [...inputBox];
        if (!tempInputBox.length) {
            isValid = false;
            startShowMessage({
                message: 'Add Private Network to continue.',
                status: 'Negative'
            });
        } else {
            tempInputBox.forEach((input, idx) => {
                Object.keys(input).forEach((field) => {
                    // check to find whether value is empty for required fields
                    if (tempInputBox[idx][field].required && tempInputBox[idx][field].value === '') {
                        const fieldName = camelCaseToSentence(field);
                        tempInputBox[idx][field].valueState = 'Error';
                        tempInputBox[idx][field].valueStateMessage = <span>{fieldName} is required</span>;
                        isValid = false;
                    }
                    // check to find whether any field has error state
                    if (tempInputBox[idx][field].valueState === 'Error') {
                        isValid = false;
                    }
                });
            });
        }
        if (isValid) {
            const payload = { pvtNwkMembers: [] };
            inputBox?.forEach((input) => {
                payload.pvtNwkMembers.push({
                    emailId: input.emailAddress.value,
                    username: input.companyName.value,
                    contactName: input.contactName.value
                });
            });
            startRegisterBPNetworkInfo(payload).then(() => {
                startGetUserData()
                    .then(() => history.push('/account/businessInfo'))
                    .catch(() => console.log('Something went wrong!'));
            });
        } else {
            setInputBox(tempInputBox);
        }
    };

    const onSkip = () => {
        startGetUserData()
            .then(() => history.push('/account/businessInfo'))
            .catch(() => console.log('Something went wrong!'));
    };

    const onInputChange = (event) => {
        const tempInputBox = [...inputBox];
        const { id } = event.target;
        const split = id.split('-');
        const field = split[0];
        const idx = split[1];
        let { value } = event.target;
        if (field === 'emailAddress') {
            value = value.toLowerCase();
        }
        const { isValid, errorMessage } = validateInput(value, field, tempInputBox[idx][field]);
        tempInputBox[idx][field].value = value;
        tempInputBox[idx][field].valueStateMessage = <span>{errorMessage}</span>;
        if (isValid) {
            tempInputBox[idx][field].valueState = 'None';
        } else {
            tempInputBox[idx][field].valueState = 'Error';
        }
        setInputBox(tempInputBox);
    };

    const onDeleteClick = (index) => {
        let tempInputBox = [...inputBox];
        tempInputBox = tempInputBox.filter((value, idx) => idx !== index);
        setInputBox(tempInputBox);
    };

    return (
        <>
            <FlexBox alignItems="Center" direction="Column">
                {isLoading && <Loader />}
                <Title style={{ fontSize: 'larger', marginTop: '2rem' }}>
                    Set your Private Network by adding all the vendors you are currently working with.
                </Title>
                <Title style={{ fontSize: 'larger', marginTop: '0.5rem' }}>
                    This step could be skipped and set up later under{' '}
                    <b>Menu &gt; Account Management &gt; Private Network.</b>
                </Title>
            </FlexBox>
            <Grid style={{ margin: '20px' }}>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label required showColon style={{ fontSize: 'larger', marginTop: '2rem' }}>
                        Company Name
                    </Label>
                </div>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label showColon style={{ fontSize: 'larger', marginTop: '2rem' }}>
                        Contact Name
                    </Label>
                </div>
                <div data-layout-span="XL4 L4 M4 S4">
                    <Label required showColon style={{ fontSize: 'larger', marginTop: '2rem' }}>
                        Email Address
                    </Label>
                </div>
                {inputBox?.map((inputElements, index) =>
                    Object.keys(inputElements)?.map((inputElement, idx) => (
                        <div key={idx} data-layout-span="XL4 L4 M4 S4">
                            <Input
                                id={`${inputElement}-${index}`}
                                value={inputElements[inputElement].value}
                                valueState={inputElements[inputElement].valueState}
                                valueStateMessage={inputElements[inputElement].valueStateMessage}
                                onInput={onInputChange}
                            />
                            {idx === Object.keys(inputElements).length - 1 ? (
                                <Icon
                                    id={`delete-${index}`}
                                    name="delete"
                                    onClick={() => onDeleteClick(index)}
                                    tooltip="Delete Row"
                                    style={{
                                        ...spacing.sapUiTinyMarginBegin,
                                        width: '1.5rem',
                                        cursor: 'pointer'
                                    }}
                                />
                            ) : null}
                        </div>
                    ))
                )}
            </Grid>
            <Button
                design="Transparent"
                style={{ color: 'blue', marginLeft: '15px' }}
                onClick={() => {
                    const tempInputBox = [...inputBox];
                    tempInputBox.push({
                        companyName: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            required: true
                        },
                        contactName: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            required: false
                        },
                        emailAddress: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: '',
                            required: true
                        }
                    });
                    setInputBox(tempInputBox);
                }}
            >
                + Add Vendor
            </Button>
            <Grid style={{ ...spacing.sapUiMediumMarginTop }}>
                <div data-layout-indent="XL8 L8 M8 S8" data-layout-span="XL4 L4 M4 S4">
                    <Button style={{ ...spacing.sapUiSmallMarginEnd }} onClick={() => onSkip()}>
                        Skip
                    </Button>
                    <Button onClick={() => onSave()} design="Emphasized">
                        Save &amp; Go Next
                    </Button>
                </div>
            </Grid>
        </>
    );
};

const mapStateToProps = (state) => ({
    isLoading: isNetworkInfoLoading(state)
});

const mapDispatchToProps = (dispatch) => ({
    startRegisterBPNetworkInfo: async (payload) => dispatch(registerBPNetworkInfo(payload)),
    startGetUserData: async () => dispatch(getUserData()),
    startShowMessage: (payload) => dispatch(showMessage(payload))
});

PrivateNetworkStep.propTypes = {
    startRegisterBPNetworkInfo: PropTypes.func.isRequired,
    isLoading: PropTypes.bool,
    startGetUserData: PropTypes.func.isRequired,
    startShowMessage: PropTypes.func.isRequired
};

export default connect(mapStateToProps, mapDispatchToProps)(PrivateNetworkStep);
