import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import {
    Button,
    Select,
    Option,
    Grid,
    Title,
    Label,
    FlexBox,
    MultiComboBox,
    MultiComboBoxItem,
    Icon,
    Toolbar,
    Switch,
    Loader
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import { showMessage } from '../../store/action/toast';
import { createServiceLocation } from '../../store/action/account';
import { isServiceLocationLoading, getStatesInfo, getCitiesInfo } from '../../selectors/common';
import { getStates, getCities } from '../../store/action/location';
import { camelCaseToSentence } from '../../utils/formatter';
import { isEmpty } from '../../validation/common';

const ServiceLocation = ({
    onNextClick,
    startCreateServiceLocation,
    isLoading,
    states,
    startShowMessage,
    cities,
    startGetStates,
    startGetCities
}) => {
    // Checks if Across PAN India is selected
    const [isAllState, setIsAllState] = useState(false);
    const [inputBox, setInputBox] = useState([
        {
            state: {
                value: {},
                valueState: 'None',
                valueStateMessage: '',
                options: states
            },
            cities: {
                value: [],
                valueState: 'None',
                valueStateMessage: '',
                options: [],
                isAllSelected: false
            }
        }
    ]);

    useEffect(() => {
        startGetStates();
    }, []);

    useEffect(() => {
        const tempRows = [...inputBox];
        tempRows.forEach((row, idx) => {
            const { stateId } = row.state.value;
            if (cities[stateId]) {
                const cityList = cities[stateId];
                tempRows[idx].cities.options = cityList;
            }
        });
        setInputBox(tempRows);
    }, [cities]);

    useEffect(() => {
        const tempRows = [...inputBox];
        tempRows.forEach((row, idx) => {
            tempRows[idx].state.options = states;
        });
        setInputBox(tempRows);
    }, [states]);

    const onSave = () => {
        let isValid = true;
        const tempInputBox = [...inputBox];
        if (isAllState) {
            isValid = true;
        } else if (!tempInputBox.length) {
            isValid = false;
            startShowMessage({
                message: `Add Service Location data to continue.`,
                status: 'Negative'
            });
        } else {
            tempInputBox.forEach((input, idx) => {
                Object.keys(input).forEach((field) => {
                    // check to find whether value is empty for required fields
                    if (isEmpty(tempInputBox[idx][field].value)) {
                        const fieldName = camelCaseToSentence(field);
                        tempInputBox[idx][field].valueState = 'Error';
                        tempInputBox[idx][field].valueStateMessage = <span>{fieldName} is required</span>;
                        isValid = false;
                    }
                    // check to find whether any field has error state
                    if (tempInputBox[idx][field].valueState === 'Error') {
                        isValid = false;
                    }
                });
            });
        }
        if (isValid) {
            const payload = { countryId: '1' };
            if (isAllState) {
                payload.isAllStateSelected = isAllState;
            } else {
                payload.serviceLocations = [];
                inputBox.forEach((row) => {
                    const isAllCitySelected = row.cities.isAllSelected;
                    const cityList = [];
                    if (!isAllCitySelected) {
                        row.cities.value.forEach((city) => {
                            cityList.push({
                                cityId: city.city_id,
                                cityName: city.city_name
                            });
                        });
                    }
                    payload.serviceLocations.push({
                        state: row.state.value.stateId,
                        stateName: row.state.value.stateName,
                        isAllCitySelected,
                        city: cityList
                    });
                });
            }
            startCreateServiceLocation(payload).then(() => onNextClick('3'));
        } else {
            setInputBox(tempInputBox);
        }
    };

    // function to check if a city is selected or not
    const isCitySelected = (cityId) =>
        inputBox?.some((row) => row.cities.value?.some((cityObj) => cityObj.city_id === cityId));

    const onInputChange = (event) => {
        const tempRows = [...inputBox];
        const { id } = event.target;
        const split = id.split('-');
        const field = split[0];
        const idx = split[1];
        if (field === 'state') {
            const stateName = event.detail.selectedOption.attributes.value.value;
            const stateId = event.detail.selectedOption.attributes.id.value;
            tempRows[idx][field].value.stateName = stateName;
            tempRows[idx][field].value.stateId = stateId;
            tempRows[idx][field].valueState = 'None';
            tempRows[idx][field].valueStateMessage = <span />;
            // Empty the cities entry since state has changed
            tempRows[idx].cities.value = [];
            tempRows[idx].cities.isAllSelected = false;
            startGetCities(stateId);
        }
        if (field === 'cities') {
            // isAllCity checks if All Cities is selected from UI
            // let isAllCity = event.detail.items.some((element) => element.attributes.id.value === '-1');
            let isAllCity = false;
            const selectedCities = [];
            event.detail.items.forEach((selectedItem) => {
                const id = selectedItem.attributes.id.value;
                const { value } = selectedItem.attributes.value;
                if (id === '-1') {
                    isAllCity = true;
                } else {
                    selectedCities.push({ city_id: id, city_name: value });
                }
            });
            // All Cities Option is true and Other city is deselceted
            if (tempRows[idx][field].isAllSelected && selectedCities.length < tempRows[idx][field].options.length) {
                tempRows[idx][field].isAllSelected = false;
                isAllCity = false;
            }
            tempRows[idx][field].value = selectedCities;
            tempRows[idx][field].valueState = 'None';
            tempRows[idx][field].valueStateMessage = <span />;
            // All Cities Option was unselected
            if (!isAllCity && tempRows[idx][field].isAllSelected) {
                tempRows[idx][field].isAllSelected = false;
                tempRows[idx][field].value = [];
            } else if (isAllCity) {
                // All Cities Option was selected
                tempRows[idx][field].isAllSelected = true;
                tempRows[idx][field].value = tempRows[idx][field].options;
            }
        }
        setInputBox(tempRows);
    };

    const onDeleteClick = (index) => {
        let tempInputBox = [...inputBox];
        tempInputBox = tempInputBox?.filter((value, idx) => idx !== index);
        setInputBox(tempInputBox);
    };

    // function to check if a state is selected or not
    const isStateSelected = (stateId, currentRowStateId) =>
        inputBox?.some((row) => row.state.value.stateId === stateId && currentRowStateId !== stateId);

    return (
        <>
            <FlexBox alignItems="Center" direction="Column">
                {isLoading && <Loader />}
                <Title style={{ fontSize: 'larger', marginTop: '2rem' }}>
                    Add any additional locations you are providing your services at.
                </Title>
            </FlexBox>
            <Grid style={{ margin: '20px' }}>
                <div data-layout-span="XL11 L11 M11 S11" data-layout-indent="XL1 L1 M1 S1">
                    <Toolbar style={{ ...spacing.sapUiMediumMarginTop }} toolbarStyle="Clear">
                        <Label>Across PAN India</Label>
                        <Switch
                            id="isAllStateSwitch"
                            style={{ zoom: '0.7' }}
                            checked={isAllState}
                            onChange={() => setIsAllState(!isAllState)}
                        />
                    </Toolbar>
                </div>
                <div data-layout-span="XL4 L4 M4 S4" data-layout-indent="XL1 L1 M1 S1">
                    <Label required showColon style={{ fontSize: 'larger', marginTop: '2rem' }}>
                        State
                    </Label>
                </div>
                <div data-layout-span="XL7 L7 M7 S7">
                    <Label required showColon style={{ fontSize: 'larger', marginTop: '2rem' }}>
                        City
                    </Label>
                </div>
                {inputBox.map((inputElements, index) =>
                    Object.keys(inputElements).map((inputElement, idx) => {
                        // Odd elements are for state and even elements are for city
                        if ((idx + 1) % 2 !== 0) {
                            return (
                                <div key={idx} data-layout-span="XL4 L4 M4 S4" data-layout-indent="XL1 L1 M1 S1">
                                    <Select
                                        id={`${inputElement}-${index}`}
                                        valueState={inputElements[inputElement].valueState}
                                        valueStateMessage={inputElements[inputElement].valueStateMessage}
                                        onChange={onInputChange}
                                        style={{ width: '80%' }}
                                        disabled={isAllState}
                                    >
                                        <Option id="-1" value="-1">
                                            Select a State
                                        </Option>
                                        {inputElements[inputElement]?.options?.map((option) => (
                                            <Option
                                                key={option.state_id}
                                                id={option.state_id}
                                                value={option.state_name}
                                                disabled={isStateSelected(
                                                    option.state_id,
                                                    inputElements[inputElement].value.stateId
                                                )}
                                                selected={
                                                    option.state_name === inputElements[inputElement].value.stateName
                                                }
                                            >
                                                {option.state_name}
                                            </Option>
                                        ))}
                                    </Select>
                                </div>
                            );
                        }
                        return (
                            <div key={idx} data-layout-span="XL7 L7 M7 S7">
                                <MultiComboBox
                                    id={`${inputElement}-${index}`}
                                    valueState={inputElements[inputElement].valueState}
                                    valueStateMessage={inputElements[inputElement].valueStateMessage}
                                    onSelectionChange={onInputChange}
                                    placeholder="Select Cities"
                                    style={{ width: '80%' }}
                                    disabled={isAllState}
                                >
                                    {inputElements[inputElement].options.length && (
                                        <MultiComboBoxItem
                                            id="-1"
                                            value="-1"
                                            text="All Cities"
                                            selected={inputElements[inputElement].isAllSelected}
                                        />
                                    )}
                                    {inputElements[inputElement].options.map((option) => (
                                        <MultiComboBoxItem
                                            key={option.city_id}
                                            id={option.city_id}
                                            selected={isCitySelected(option.city_id)}
                                            text={option.city_name}
                                            value={option.city_name}
                                        />
                                    ))}
                                </MultiComboBox>
                                <Icon
                                    id={`delete-${index}`}
                                    name="delete"
                                    onClick={() => onDeleteClick(index)}
                                    tooltip="Delete Row"
                                    style={{
                                        ...spacing.sapUiTinyMarginBegin,
                                        width: '1.5rem',
                                        cursor: 'pointer'
                                    }}
                                />
                            </div>
                        );
                    })
                )}
                <div data-layout-span="XL11 L11 M11 S11" data-layout-indent="XL1 L1 M1 S1">
                    <Button
                        design="Transparent"
                        style={{ color: 'blue' }}
                        disabled={isAllState}
                        onClick={() => {
                            const tempInputBox = [...inputBox];
                            tempInputBox.push({
                                state: {
                                    value: {},
                                    valueState: 'None',
                                    valueStateMessage: '',
                                    options: states
                                },
                                cities: {
                                    value: [],
                                    valueState: 'None',
                                    valueStateMessage: '',
                                    options: [],
                                    isAllSelected: false
                                }
                            });
                            setInputBox(tempInputBox);
                        }}
                    >
                        + Add Another
                    </Button>
                </div>
                <div data-layout-span="XL12 L12 M12 S12">
                    <Button
                        onClick={() => onSave()}
                        design="Emphasized"
                        style={{
                            float: 'right',
                            marginRight: '8%'
                        }}
                    >
                        Save &amp; Go Next
                    </Button>
                </div>
            </Grid>
        </>
    );
};

const mapStateToProps = (state) => ({
    isLoading: isServiceLocationLoading(state),
    states: getStatesInfo(state),
    cities: getCitiesInfo(state)
});

const mapDispatchToProps = (dispatch) => ({
    startCreateServiceLocation: async (payload) => dispatch(createServiceLocation(payload)),
    startGetStates: () => dispatch(getStates()),
    startGetCities: (stateId) => dispatch(getCities(stateId)),
    startShowMessage: (payload) => dispatch(showMessage(payload))
});

ServiceLocation.propTypes = {
    startCreateServiceLocation: PropTypes.func.isRequired,
    startGetStates: PropTypes.func.isRequired,
    startGetCities: PropTypes.func.isRequired,
    onNextClick: PropTypes.func.isRequired,
    isLoading: PropTypes.bool,
    states: PropTypes.array,
    cities: PropTypes.object,
    startShowMessage: PropTypes.func.isRequired
};

export default connect(mapStateToProps, mapDispatchToProps)(ServiceLocation);
