import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { SideNavigation, SideNavigationItem, SideNavigationSubItem } from '@ui5/webcomponents-react';
import { withRouter } from 'react-router-dom';
import { getUserInfo } from '../../selectors/common';
import { isEmpty } from '../../validation/common';
import PrivacyStatement from './PrivacyStatement';

class NavBar extends Component {
    constructor(props) {
        super(props);
        this.myRef = React.createRef();
        this.state = {
            activePath: '/',
            accountItems: [
                {
                    path: '/account/businessInfo' /* path is used as id to check which NavItem is active basically */,
                    name: 'Business Information',
                    // eslint-disable-next-line max-len
                    key: 'accountKey1' /* Key is required, else console throws error. Does this please you Mr. Browser?! */,
                    icon: 'business-card'
                },
                {
                    path: '/account/serviceLocationInfo',
                    name: 'Service Locations',
                    key: 'accountKey2',
                    icon: 'functional-location'
                },
                {
                    path: '/account/certificatesInfo',
                    name: 'Certificates',
                    key: 'accountKey3',
                    icon: 'badge'
                }
            ],
            OrderManagement: [
                {
                    path: '/order',
                    name: 'Orders List',
                    key: 'orderKey1',
                    icon: 'order-status'
                }
            ]
        };
    }

    componentDidMount() {
        if (isEmpty(this.props.userInfo.isPartOfPvtNwk) || this.props.userInfo.isPartOfPvtNwk === false) {
            this.setState({
                accountItems: [
                    ...this.state.accountItems,
                    {
                        path: '/account/privateNetworkInfo',
                        name: 'Private Network',
                        key: 'accountKey4',
                        icon: 'cancel-share'
                    }
                ]
            });
        }
    }

    onSelectionChange = (event) => {
        this.setState({ activePath: event.detail.item.getAttribute('path') });
        const path = event.detail.item.getAttribute('path');
        this.props.history.push(`${path}`);
    };

    render() {
        const { accountItems, activePath, OrderManagement } = this.state;
        return (
            <>
                <SideNavigation
                    style={{ position: 'fixed', height: '-webkit-fill-available', marginTop: '44px' }}
                    slot=""
                    onSelectionChange={this.onSelectionChange}
                    fixedItems={
                        <>
                            <SideNavigationItem
                                icon="compare"
                                text="Privacy Statement"
                                onClick={() => this.myRef.current.show()}
                                path="#"
                            />
                            <SideNavigationItem
                                icon="chain-link"
                                text="EverLoop Website"
                                onClick={() => window.open('https://everloopbysap.webflow.io/', '_blank')}
                                path="#"
                            />
                        </>
                    }
                    collapsed={this.props.isCollapsed}
                >
                    <SideNavigationItem
                        wholeItemToggleable
                        path="#"
                        text="Account Management"
                        icon="sap-icon://account"
                    >
                        {accountItems.map((item) => (
                            /* Return however many NavItems in array to be rendered */
                            <SideNavigationSubItem
                                id={item.key}
                                path={item.path}
                                text={item.name}
                                active={item.path === activePath}
                                key={item.key}
                                icon={item.icon}
                            />
                        ))}
                    </SideNavigationItem>
                    <SideNavigationItem
                        wholeItemToggleable
                        path="#"
                        text="Order Management"
                        icon="sap-icon://sales-order-item"
                    >
                        {OrderManagement.map((item) => (
                            /* Return however many NavItems in array to be rendered */
                            <SideNavigationSubItem
                                id={item.key}
                                path={item.path}
                                text={item.name}
                                active={item.path === activePath}
                                key={item.key}
                                icon={item.icon}
                            />
                        ))}
                    </SideNavigationItem>
                </SideNavigation>
                <PrivacyStatement ref={this.myRef} />
            </>
        );
    }
}

NavBar.propTypes = {
    isCollapsed: PropTypes.bool,
    history: PropTypes.object,
    userInfo: PropTypes.object
};

const mapStateToProps = (state) => ({
    userInfo: getUserInfo(state)
});

export default withRouter(connect(mapStateToProps)(NavBar));
