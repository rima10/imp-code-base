import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import {
    Grid,
    Button,
    Select,
    Option,
    Title,
    Input,
    FlexBox,
    Label,
    FileUploader,
    DatePicker
} from '@ui5/webcomponents-react';
import moment from 'moment';
import { useHistory } from 'react-router-dom';
import { saveCertificates } from '../../store/action/account';
import { certificateTypes } from '../../data/certificates';
import { isCertificatesInfoLoading, getUserInfo } from '../../selectors/common';
import LoadingIndicator from '../common/Loading';
import { getUserData } from '../../store/action/taskAction';
import { isEmpty } from '../../validation/common';

const UploadCerificate = ({
    onNextClick,
    startPostCertificates,
    certificateTypes,
    isLoading,
    startGetUserData,
    userInfo
}) => {
    const history = useHistory();
    const initialFormFieldsState = {
        certificateType: {
            value: '',
            valueState: 'None',
            valueStateMessage: ''
        },
        certificateName: {
            value: '',
            valueState: 'None',
            valueStateMessage: ''
        },
        certificateFile: {
            value: {
                name: ''
            },
            valueState: 'None',
            valueStateMessage: ''
        },
        validPeriod: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            transform: (value) => moment(value, 'DD-MM-YYYY').format('YYYY-MM-DD')
        },
        authorizationNumber: {
            value: '',
            valueState: 'None',
            valueStateMessage: ''
        },
        recyclingCapacity: {
            value: '',
            valueState: 'None',
            valueStateMessage: ''
        },
        issuedDate: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            transform: (value) => moment(value, 'DD-MM-YYYY').format('YYYY-MM-DD')
        }
    };
    const [certificateFormFields, setFormFieldState] = useState([]);
    const [selectedCertTypes, setSelectedCertTypes] = useState({});
    const updateSelectedCertTypes = (formFieldState) => {
        const tempSelectedCertTypes = {};
        formFieldState.forEach((item, index) => {
            if (item.certificateType.value) {
                tempSelectedCertTypes[item.certificateType.value] = {
                    currentIndex: index
                };
            }
        });
        setSelectedCertTypes(tempSelectedCertTypes);
    };
    const showInputFieldsForCertificateType = (forms, formItem, currentCertificateType) => {
        const certTypeItem = certificateTypes.find((item) => item.value === currentCertificateType);
        if (certTypeItem) {
            Object.keys(formItem).forEach((certItemField) => {
                if (certTypeItem.visibleInputFields.includes(certItemField)) {
                    formItem[certItemField].show = true;
                } else {
                    formItem[certItemField].show = false;
                    formItem[certItemField].value = '';
                }
            });
        }
        updateSelectedCertTypes(forms);
    };
    const onInputChange = (index, fieldName, value, valid = true) => {
        const tempFormFields = [...certificateFormFields];
        tempFormFields[index][fieldName].value = value;
        if (!valid) {
            tempFormFields[index][fieldName].valueState = 'Error';
        } else {
            tempFormFields[index][fieldName].valueState = 'None';
            tempFormFields[index][fieldName].valueStateMessage = '';
        }
        // on certificate type change
        if (fieldName === 'certificateType') {
            showInputFieldsForCertificateType(tempFormFields, tempFormFields[index], value);
        }
        if (value === undefined && fieldName === 'certificateFile') {
            tempFormFields[index][fieldName].value = {
                name: ''
            };
        }
        setFormFieldState(tempFormFields);
    };

    const getInitialFormFieldsCopy = () => {
        const copyObject = {};
        Object.keys(initialFormFieldsState).forEach((field) => {
            copyObject[field] = { ...initialFormFieldsState[field] };
        });
        return copyObject;
    };
    const initMandatoryCertificateForm = () => {
        const forms = [];
        certificateTypes.forEach((typeItem) => {
            if (typeItem.required) {
                const form = getInitialFormFieldsCopy();
                form.certificateType.value = typeItem.value;
                form.certificateType.required = true;
                forms.push(form);
                showInputFieldsForCertificateType(forms, form, typeItem.value);
            }
        });
        return forms;
    };
    useEffect(() => {
        setFormFieldState([...initMandatoryCertificateForm()]);
    }, []);

    const submitCertificate = () => {
        // aims to issue multiple api calls based on number of certificate forms
        const fileForms = [];
        let isValidPayload = true;
        const certificateFormFieldsPayload = [...certificateFormFields];

        certificateFormFieldsPayload.forEach((certItem) => {
            const fileform = new FormData();
            const certificateDetails = [];
            fileform.append('certificateFile', certItem.certificateFile.value);
            const certItemPayload = {};
            const certTypeItem = certificateTypes.find((item) => item.value === certItem.certificateType.value);
            if (!certTypeItem) {
                isValidPayload = false;
                certItem.certificateType.valueState = 'Error';
                certItem.certificateType.valueStateMessage = <div>Field is required</div>;
            } else {
                certTypeItem.visibleInputFields.forEach((fieldName) => {
                    if (!certItem[fieldName].value) {
                        isValidPayload = false;
                        certItem[fieldName].valueState = 'Error';
                        certItem[fieldName].valueStateMessage = <div>Field is required</div>;
                    } else if (certItem[fieldName].valueState !== 'None') {
                        isValidPayload = false;
                    } else {
                        certItemPayload[fieldName] = certItem[fieldName].transform
                            ? certItem[fieldName].transform(certItem[fieldName].value)
                            : certItem[fieldName].value;
                    }
                    if (fieldName === 'certificateFile') {
                        if (!certItem[fieldName].value.name) {
                            certItem[fieldName].valueState = 'Error';
                            certItem[fieldName].valueStateMessage = <div>Field is required</div>;
                        }
                    }
                });
                if (!certItemPayload.certificateName) {
                    certItemPayload.certificateName = certTypeItem.text;
                }
                // eslint-disable-next-line prefer-reflect
                delete certItemPayload.certificateFile;
                certificateDetails.push(certItemPayload);
                fileform.append('certificateDetails', JSON.stringify(certificateDetails));
                fileForms.push(fileform);
            }
        });

        if (isValidPayload) {
            // finally append the certificateDetails of all rows as a stringified json
            startPostCertificates(fileForms).then(() => {
                if (isEmpty(userInfo.isPartOfPvtNwk) || userInfo.isPartOfPvtNwk === false) {
                    onNextClick('4');
                } else {
                    startGetUserData()
                        .then(() => history.push('/account/businessInfo'))
                        .catch(() => console.log('Something went wrong!'));
                }
            });
        } else {
            setFormFieldState(certificateFormFieldsPayload);
        }
    };

    const onDeleteCertificateItem = (index) => {
        const tempFormFields = [...certificateFormFields];
        if (index !== -1 && tempFormFields.length !== 1) {
            tempFormFields.splice(index, 1);
            setFormFieldState(tempFormFields);
            // reform the temp selected certificateType object
            updateSelectedCertTypes(tempFormFields);
        }
    };

    const isDeleteAllowed = (currentCertificateItem) => {
        let isAllowed = true;
        if (currentCertificateItem.certificateType.value) {
            const selectedCertType = certificateTypes.find(
                (type) => type.value === currentCertificateItem.certificateType.value
            );
            if (selectedCertType && selectedCertType.required) {
                isAllowed = false;
            }
        }
        return isAllowed;
    };

    return (
        <>
            {isLoading && <LoadingIndicator />}
            <FlexBox alignItems="Center" direction="Column">
                <Title style={{ fontSize: 'larger', marginTop: '2rem', textAlign: 'justify' }}>
                    In order to be onboarded please provide the certificates needed for verifying your recycling /
                    refurbishing status.
                </Title>
            </FlexBox>
            {certificateFormFields.map((certItem, index) => (
                <Grid
                    key={index}
                    style={{
                        margin: '1rem'
                    }}
                >
                    <div key={`delete${index}`} data-layout-span="XL12 L12 M12 S12">
                        {isDeleteAllowed(certItem) && (
                            <Button
                                data-testid={`delete${index}`}
                                id={`delete${index}`}
                                style={{
                                    float: 'right',
                                    marginTop: '1rem'
                                }}
                                design="Emphasized"
                                onClick={() => onDeleteCertificateItem(index)}
                            >
                                Delete
                            </Button>
                        )}
                    </div>
                    <div key={`type${index}`} data-layout-span="XL6 L6 M12 S12">
                        <Label
                            required
                            style={{
                                fontSize: 'larger',
                                marginTop: '2rem',
                                display: 'block'
                            }}
                        >
                            Certificate Type
                        </Label>
                        <Select
                            data-testid={`certificateType${index}`}
                            id={`certificateType${index}`}
                            value={certItem.certificateType.value}
                            valueState={certItem.certificateType.valueState}
                            valueStateMessage={certItem.certificateType.valueStateMessage}
                            onChange={(e) =>
                                onInputChange(index, 'certificateType', e.detail.selectedOption.dataset.id)
                            }
                            style={{
                                width: '100%'
                            }}
                            disabled={certItem.certificateType.required}
                        >
                            <Option key="" data-id="">
                                Select Certificate Type
                            </Option>
                            {certificateTypes.map((item) => (
                                <Option
                                    key={item.value}
                                    data-id={item.value}
                                    selected={item.value === certItem.certificateType.value}
                                    disabled={
                                        selectedCertTypes[item.value] &&
                                        selectedCertTypes[item.value].currentIndex !== index &&
                                        item.value !== '3'
                                    }
                                >
                                    {item.text}
                                </Option>
                            ))}
                        </Select>
                    </div>
                    <div key={`file${index}`} data-layout-span="XL3 L3 M12 S12">
                        <Label
                            required
                            style={{
                                fontSize: 'larger',
                                marginTop: '2rem',
                                display: 'block'
                            }}
                        >
                            Upload Certificate
                        </Label>
                        <FileUploader
                            required
                            id={`certificateFile${index}`}
                            name="certificateFile"
                            value={certItem.certificateFile.value.name}
                            valueState={certItem.certificateFile.valueState}
                            valueStateMessage={certItem.certificateFile.valueStateMessage}
                            onChange={(e) => onInputChange(index, e.target.name, e.target.files[0])}
                            style={{
                                width: '100%'
                            }}
                        >
                            <Button icon="upload" design="Transparent" />
                        </FileUploader>
                    </div>
                    <div key={`validPeriod${index}`} data-layout-span="XL3 L3 M12 S12">
                        <Label
                            required
                            style={{
                                fontSize: 'larger',
                                marginTop: '2rem',
                                display: 'block'
                            }}
                        >
                            Valid Period
                        </Label>
                        <DatePicker
                            id={`validPeriod${index}`}
                            name="validPeriod"
                            minDate={moment().format('DD-MM-YYYY')}
                            value={certItem.validPeriod.value}
                            valueState={certItem.validPeriod.valueState}
                            valueStateMessage={certItem.validPeriod.valueStateMessage}
                            onChange={(e) => onInputChange(index, e.target.name, e.detail.value, e.detail.valid)}
                            primaryCalendarType="Gregorian"
                            style={{
                                width: '100%'
                            }}
                            formatPattern="dd-MM-yyyy"
                            placeholder="DD-MM-YYYY"
                        />
                    </div>
                    {certItem.certificateName.show && (
                        <div key={`name${index}`} data-layout-span="XL6 L6 M12 S12">
                            <Label
                                required
                                style={{
                                    fontSize: 'larger',
                                    marginTop: '2rem',
                                    display: 'block'
                                }}
                            >
                                Certificate Name
                            </Label>
                            <Input
                                id={`certificateName${index}`}
                                type="Text"
                                name="certificateName"
                                value={certItem.certificateName.value}
                                valueState={certItem.certificateName.valueState}
                                valueStateMessage={certItem.certificateName.valueStateMessage}
                                onChange={(e) => onInputChange(index, e.target.name, e.target.attributes.value.value)}
                                style={{
                                    width: '100%'
                                }}
                            />
                        </div>
                    )}
                    {certItem.authorizationNumber.show && (
                        <div key={`autno${index}`} data-layout-span="XL4 L4 M12 S12">
                            <Label
                                required
                                style={{
                                    fontSize: 'larger',
                                    marginTop: '2rem',
                                    display: 'block'
                                }}
                            >
                                Authorization Number
                            </Label>
                            <Input
                                data-testid={`authorizationNumber${index}`}
                                id={`authorizationNumber${index}`}
                                type="Text"
                                name="authorizationNumber"
                                value={certItem.authorizationNumber.value}
                                valueState={certItem.authorizationNumber.valueState}
                                valueStateMessage={certItem.authorizationNumber.valueStateMessage}
                                onChange={(e) => onInputChange(index, e.target.name, e.target.attributes.value.value)}
                                style={{
                                    width: '100%'
                                }}
                            />
                        </div>
                    )}
                    {certItem.recyclingCapacity.show && (
                        <div key={`rcyunit${index}`} data-layout-span="XL4 L4 M12 S12">
                            <Label
                                required
                                style={{
                                    fontSize: 'larger',
                                    marginTop: '2rem',
                                    display: 'block'
                                }}
                            >
                                Rec. Unit Capacity
                            </Label>
                            <Input
                                id={`recyclingCapacity${index}`}
                                type="Number"
                                name="recyclingCapacity"
                                value={certItem.recyclingCapacity.value}
                                valueState={certItem.recyclingCapacity.valueState}
                                valueStateMessage={certItem.recyclingCapacity.valueStateMessage}
                                onChange={(e) => onInputChange(index, e.target.name, e.target.attributes.value.value)}
                                style={{
                                    width: '100%'
                                }}
                            />
                        </div>
                    )}
                    {certItem.issuedDate.show && (
                        <div key={`issueddate${index}`} data-layout-span="XL4 L4 M12 S12">
                            <Label
                                required
                                style={{
                                    fontSize: 'larger',
                                    marginTop: '2rem',
                                    display: 'block'
                                }}
                            >
                                Date of Issue
                            </Label>
                            <DatePicker
                                id={`issuedDate${index}`}
                                name="issuedDate"
                                maxDate={moment().format('DD-MM-YYYY')}
                                value={certItem.issuedDate.value}
                                valueState={certItem.issuedDate.valueState}
                                valueStateMessage={certItem.issuedDate.valueStateMessage}
                                onChange={(e) => onInputChange(index, e.target.name, e.detail.value, e.detail.valid)}
                                primaryCalendarType="Gregorian"
                                style={{
                                    width: '100%'
                                }}
                                formatPattern="dd-MM-yyyy"
                                placeholder="DD-MM-YYYY"
                            />
                        </div>
                    )}
                    <br />
                    <hr data-layout-span="XL12 L12 M12 S12" />
                </Grid>
            ))}
            <Button
                data-testid="addbutton"
                design="Transparent"
                style={{ color: 'blue' }}
                onClick={() => {
                    const tempInputBox = [...certificateFormFields];
                    tempInputBox.push(getInitialFormFieldsCopy());
                    setFormFieldState(tempInputBox);
                }}
            >
                + Add Another
            </Button>

            <Button
                style={{
                    float: 'right',
                    marginTop: '2rem'
                }}
                design="Emphasized"
                onClick={submitCertificate}
            >
                Save &amp; Go Next
            </Button>
        </>
    );
};

const mapStateToProps = (state) => ({
    certificateTypes,
    isLoading: isCertificatesInfoLoading(state),
    userInfo: getUserInfo(state)
});

const mapDispatchToProps = (dispatch) => ({
    startPostCertificates: (fileForms) => dispatch(saveCertificates(fileForms)),
    startGetUserData: async () => dispatch(getUserData())
});

UploadCerificate.propTypes = {
    onNextClick: PropTypes.func.isRequired,
    startPostCertificates: PropTypes.func.isRequired,
    certificateTypes: PropTypes.array,
    isLoading: PropTypes.bool,
    startGetUserData: PropTypes.func.isRequired,
    userInfo: PropTypes.object
};

export default connect(mapStateToProps, mapDispatchToProps)(UploadCerificate);
