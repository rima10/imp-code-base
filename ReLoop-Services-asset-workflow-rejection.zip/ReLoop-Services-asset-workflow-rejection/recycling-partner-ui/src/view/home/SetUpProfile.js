import React from 'react';
import PropTypes from 'prop-types';
import { Title, Button, Label, FlexBox } from '@ui5/webcomponents-react';
import bg from '../../asset/images/background-image.png';

const SetupProfile = ({ toggleHidden }) => (
    <FlexBox alignItems="Center" style={{ backgroundImage: `url(${bg})`, height: '270px' }} direction="Column">
        <Title
            style={{
                fontSize: 'x-large',
                textAlign: 'center',
                marginTop: '60px',
                color: '#000000'
            }}
        >
            <b>Welcome to EverLoop!</b>
        </Title>
        <Label
            wrappingType="Normal"
            style={{
                fontSize: 'large',
                textAlign: 'center',
                marginTop: '20px',
                color: '#000000'
            }}
        >
            Welcome to EverLoop! The platform for environment friendly disposal of e-waste. In order to use the platform
            and
        </Label>
        <br />
        <Label
            wrappingType="Normal"
            style={{
                fontSize: 'large',
                textAlign: 'center',
                color: '#000000'
            }}
        >
            be able to submit quotes, you have to verify your business account first.
        </Label>
        <Button
            design="Emphasized"
            onClick={toggleHidden}
            style={{
                marginTop: '25px'
            }}
        >
            Setup Profile
        </Button>
    </FlexBox>
);

SetupProfile.propTypes = {
    toggleHidden: PropTypes.func.isRequired
};

export default SetupProfile;
