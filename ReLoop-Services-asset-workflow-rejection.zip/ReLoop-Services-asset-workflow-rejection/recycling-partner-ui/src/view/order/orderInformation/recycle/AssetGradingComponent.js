import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import {
    Button,
    Toolbar,
    ToolbarSpacer,
    Bar,
    TextArea,
    Label,
    Panel,
    Title,
    Table,
    TableColumn,
    TableCell,
    TableRow,
    Text,
    Input
} from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import { useParams, useHistory } from 'react-router-dom';
import {
    getOrderHeaderDataState,
    getOrderList,
    isRecycleConsolidatedOrderItemsLoading,
    getRecycleConsolidatedOrderItemsState
} from '../../../../selectors/common';
import { getRecycleConsolidatedOrderItemsInfo, submitRecycleFinalQuote } from '../../../../store/action/order';
import LoadingIndicator from '../../../common/Loading';
import { validateIsEmpty } from '../../../../validation/common';
import { camelCaseToSentence } from '../../../../utils/formatter';

export const AssetGrading = ({
    startGetRecycleConsolidatedOrderItemsInfo,
    recycleConsolidatedOrderData,
    orderList,
    orderHeaderData,
    isLoading,
    startSubmitRecycleFinalQuote
}) => {
    const { orderNumber } = useParams();
    const [isFinalQuoteSubmitted, setIsFinalQuoteSubmitted] = useState(false);
    const [assetGradeComments, setAssetGradeComments] = useState('');
    const [isEditMode, setEditMode] = useState(0);
    const [isDataFilled, setIsDataFilled] = useState(false);
    const [rows, setRows] = useState([]);
    const history = useHistory();

    const getRowsFromOrderInfo = () => {
        let existingRows = [...rows];
        existingRows = [];
        if (recycleConsolidatedOrderData?.orderQuoteItems && !recycleConsolidatedOrderData.orderQuoteItems.length) {
            setRows([]);
        } else {
            recycleConsolidatedOrderData?.orderQuoteItems?.map((orderQuoteItem) => {
                existingRows.push({
                    orderQuoteItemId: {
                        value: orderQuoteItem.orderQuoteItemId,
                        type: 'text'
                    },
                    orderItem: {
                        value: orderQuoteItem.orderItem,
                        type: 'text'
                    },
                    itemUnit: {
                        value: orderQuoteItem.itemUnit,
                        type: 'text'
                    },
                    finalQuantity: {
                        value: orderQuoteItem?.finalQty ?? '',
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'input'
                    },
                    pricePerUnit: {
                        value: orderQuoteItem?.pricePerUnit ?? '',
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'input'
                    }
                });
            });
            setRows(existingRows);
        }
    };

    useEffect(() => {
        if (orderList && orderList.length > 0) {
            const order = orderList.find((order) => order.order_no === orderNumber);
            const id = order.order_id;
            startGetRecycleConsolidatedOrderItemsInfo(id);
        }
    }, [orderList]);

    useEffect(() => {
        if (recycleConsolidatedOrderData?.isFinalQuoteSubmitted) {
            setIsFinalQuoteSubmitted(recycleConsolidatedOrderData.isFinalQuoteSubmitted);
        }
        getRowsFromOrderInfo();
    }, [recycleConsolidatedOrderData]);

    const isValidData = () => {
        const existingRows = [...rows];
        let isValid = true;
        existingRows.forEach((input, idx) => {
            Object.keys(input).forEach((field) => {
                // check to find whether value is empty for required fields
                if (existingRows[idx][field].type === 'input' && existingRows[idx][field].value === '') {
                    const fieldName = camelCaseToSentence(field);
                    existingRows[idx][field].valueState = 'Error';
                    existingRows[idx][field].valueStateMessage = <span>{fieldName} is required</span>;
                    isValid = false;
                }
                // check to find whether any field has error state
                if (existingRows[idx][field].valueState === 'Error') {
                    isValid = false;
                }
            });
        });
        if (!isValid) {
            setIsDataFilled(false);
        } else {
            setIsDataFilled(true);
        }
    };

    const onCommentsChange = (value) => {
        setAssetGradeComments(value);
    };

    const submitAssetGrading = () => {
        const orderItemQuotes = [];
        rows.forEach((row) => {
            orderItemQuotes.push({
                orderQuoteItemsId: row.orderQuoteItemId.value,
                finalQty: row.finalQuantity.value,
                pricePerUnit: row.pricePerUnit.value
            });
        });
        const payload = {
            orderItemQuotes,
            quoteComments: assetGradeComments,
            quoteId: recycleConsolidatedOrderData.quoteId
        };
        startSubmitRecycleFinalQuote(orderHeaderData.orderId, payload).then(() => history.push('/order'));
    };

    const onInputChange = (rowIndex, field, event) => {
        const tempRows = [...rows];
        const idx = rowIndex;
        const { isValid, errorMessage } = validateIsEmpty(event.target.value, field);
        tempRows[idx][field].value = event.target.value;
        tempRows[idx][field].valueStateMessage = <span>{errorMessage}</span>;
        if (isValid) {
            tempRows[idx][field].valueState = 'None';
        } else {
            tempRows[idx][field].valueState = 'Error';
        }
        isValidData();
        setRows(tempRows);
    };

    if (isLoading) {
        return <LoadingIndicator />;
    }
    return (
        <Panel
            style={{ padding: '1rem 0rem' }}
            header={
                <Toolbar>
                    <Title level="H4">List of Verified Assets ({orderHeaderData.itemsCount})</Title>
                    <ToolbarSpacer />
                    <Button
                        style={{ marginLeft: '10px' }}
                        design={isEditMode ? 'Emphasized' : 'Default'}
                        disabled={orderHeaderData.currentSequence > 5 || isFinalQuoteSubmitted}
                        onClick={() => {
                            if (isEditMode === 0) {
                                setEditMode(1);
                            } else {
                                setEditMode(0);
                            }
                        }}
                    >
                        {isEditMode ? 'Save' : 'Edit'}
                    </Button>
                </Toolbar>
            }
        >
            <Table
                columns={
                    <>
                        <TableColumn>
                            <Label>Order Item</Label>
                        </TableColumn>
                        <TableColumn popinText="Item Unit">
                            <Label>Item Unit</Label>
                        </TableColumn>
                        <TableColumn popinText="Item Unit">
                            <Label>Final Quantity</Label>
                        </TableColumn>
                        <TableColumn popinText="Item Unit">
                            <Label>Price / Unit</Label>
                        </TableColumn>
                    </>
                }
            >
                {rows?.map((item, index) => (
                    <TableRow key={index}>
                        <TableCell>
                            <Text>{item.orderItem.value}</Text>
                        </TableCell>
                        <TableCell>
                            <Text>{item.itemUnit.value}</Text>
                        </TableCell>
                        <TableCell>
                            {isEditMode ? (
                                <Input
                                    type="Number"
                                    id={`finalQuantity${index}`}
                                    style={{ height: '20%' }}
                                    value={item.finalQuantity.value}
                                    valueState={item.finalQuantity.valueState}
                                    valueStateMessage={item.finalQuantity.valueStateMessage}
                                    onInput={(e) => onInputChange(index, 'finalQuantity', e)}
                                />
                            ) : (
                                <Text id={`finalQuantity${index}`}> {item.finalQuantity.value}</Text>
                            )}
                        </TableCell>
                        <TableCell>
                            {isEditMode ? (
                                <Input
                                    type="Number"
                                    id={`pricePerUnit${index}`}
                                    style={{ height: '20%' }}
                                    value={item.pricePerUnit.value}
                                    valueState={item.pricePerUnit.valueState}
                                    valueStateMessage={item.pricePerUnit.valueStateMessage}
                                    onInput={(e) => onInputChange(index, 'pricePerUnit', e)}
                                />
                            ) : (
                                <Text id={`pricePerUnit${index}`}> {item.pricePerUnit.value}</Text>
                            )}
                        </TableCell>
                    </TableRow>
                ))}
            </Table>
            <div style={{ width: '100%', marginTop: '2rem' }}>
                <Toolbar>
                    <Label style={{ fontSize: '1rem', fontWeight: 'bold' }}>Additional Comments</Label>
                </Toolbar>
                {isFinalQuoteSubmitted ? (
                    <TextArea value={recycleConsolidatedOrderData.quoteComments} disabled />
                ) : (
                    <TextArea
                        value={assetGradeComments}
                        onInput={(e) => onCommentsChange(e.target.attributes.value.value)}
                    />
                )}
            </div>
            <Bar
                design="FloatingFooter"
                style={{ marginTop: '30px', width: '100%', boxShadow: 'none' }}
                endContent={
                    <Button
                        id="SubmitBtn"
                        design="Emphasized"
                        disabled={!isDataFilled || orderHeaderData.currentSequence > 5}
                        onClick={submitAssetGrading}
                    >
                        Submit Asset Verification
                    </Button>
                }
            />
        </Panel>
    );
};

AssetGrading.propTypes = {
    orderList: PropTypes.array,
    orderHeaderData: PropTypes.object,
    startGetRecycleConsolidatedOrderItemsInfo: PropTypes.func.isRequired,
    getOrderList: PropTypes.array,
    isLoading: PropTypes.bool,
    recycleConsolidatedOrderData: PropTypes.object,
    startSubmitRecycleFinalQuote: PropTypes.func.isRequired
};

const mapStateToProps = (state) => ({
    orderList: getOrderList(state),
    orderHeaderData: getOrderHeaderDataState(state),
    isLoading: isRecycleConsolidatedOrderItemsLoading(state),
    recycleConsolidatedOrderData: getRecycleConsolidatedOrderItemsState(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetRecycleConsolidatedOrderItemsInfo: (orderId) => dispatch(getRecycleConsolidatedOrderItemsInfo(orderId)),
    startSubmitRecycleFinalQuote: (orderId, payload) => dispatch(submitRecycleFinalQuote(orderId, payload))
});

export default connect(mapStateToProps, mapDispatchToProps)(AssetGrading);
