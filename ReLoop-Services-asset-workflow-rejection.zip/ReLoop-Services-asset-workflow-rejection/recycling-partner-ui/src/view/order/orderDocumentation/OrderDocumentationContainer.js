import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Text, Title, Grid } from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import DocumentCard from './DocumentCard';
import {
    getOrderDocuments,
    downloadDocument,
    generateForm6Document,
    uploadDocument,
    generateForm2Document
} from '../../../store/action/order';
import {
    getOrderDocInfoState,
    getOrderId,
    getOrderNo,
    getRpName,
    getGpName,
    getOrderHeaderDataState
} from '../../../selectors/common';
import LoadingIndicator from '../../common/Loading';

const OrderDocumentationContainer = ({
    orderId,
    startGenerateForm6Document,
    startGenerateForm2Document,
    startGetOrderDocumentsInfo,
    startUploadOrderDocument,
    orderDocInfo = [],
    rpName,
    gpName,
    orderNo,
    startDownloadOrderDocument,
    orderHeaderData
}) => {
    useEffect(() => {
        if (orderId) {
            startGetOrderDocumentsInfo(orderId);
        }
    }, []);
    const [documents, setDocuments] = useState([]);
    const recyclerDocs = [
        'Data Destruction Certificate',
        'Form 2',
        'Form 6',
        'Service Invoice',
        'Recycling Certificate'
    ];
    const [Generatedocuments, setGenerateDocuments] = useState([]);
    const [isLoading, setLoading] = useState(false);
    const openDialog = (ref) => {
        ref.current.show();
    };

    const onGenerateForm6 = (payload) => {
        setLoading(true);
        payload.orderNo = orderNo;
        startGenerateForm6Document(orderId, payload)
            .then((response) => {
                setLoading(false);
                const responseBlob = new Blob([response.data]);
                const url = window.URL.createObjectURL(responseBlob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `Form_6_${payload.orderNo}.pdf`;
                a.click();
            })
            .catch(() => {
                setLoading(false);
            });
    };

    const onGenerateForm2 = (payload) => {
        setLoading(true);
        payload.orderNo = orderNo;
        startGenerateForm2Document(orderId, payload)
            .then((response) => {
                setLoading(false);
                const responseBlob = new Blob([response.data]);
                const url = window.URL.createObjectURL(responseBlob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `Form_2_${payload.orderNo}.pdf`;
                a.click();
            })
            .catch(() => {
                setLoading(false);
            });
    };

    const onUpload = (payload) => {
        setLoading(true);
        const formdata = new FormData();
        for (const [key, value] of Object.entries(payload)) {
            if (key === 'document') {
                for (const pair of value.entries()) {
                    formdata.append(pair[0], pair[1]);
                }
            }
            formdata.append(`${key}`, `${value}`);
        }
        formdata.append('orderNo', orderNo);
        startUploadOrderDocument(orderId, formdata)
            .then(() => {
                setLoading(false);
            })
            .catch(() => {
                setLoading(false);
            });
    };

    const onDownload = (key) => {
        setLoading(true);
        startDownloadOrderDocument(orderId, key)
            .then((response) => {
                setLoading(false);
                const responseBlob = new Blob([response.data]);
                const url = window.URL.createObjectURL(responseBlob);
                const a = document.createElement('a');
                a.href = url;
                a.download = key;
                a.click();
            })
            .catch(() => {
                setLoading(false);
            });
    };

    const formatDocuments = (orderDocs = []) => {
        const gpDocs = [];
        const rpDocs = [];
        orderDocs.map((orderDoc) => {
            if (orderDoc.docName === 'other') {
                orderDoc.order_docs.map((otherDoc) => {
                    const otherDocument = {
                        title: otherDoc.documentText,
                        status: 'Created',
                        date: otherDoc.lastModifiedDate,
                        key: otherDoc.storageKey,
                        createdBy: otherDoc.createdBy?.bpUserName,
                        type: 'other',
                        openDialog,
                        onDownload
                    };
                    if (otherDocument.createdBy === rpName) {
                        rpDocs.push(otherDocument);
                    } else gpDocs.push(otherDocument);
                });
            } else {
                const doc = {};
                doc.title = orderDoc.docName;
                if (orderDoc.order_docs && orderDoc.order_docs.length) {
                    doc.status = 'Created';
                    doc.date = orderDoc.order_docs[0].lastModifiedDate;
                    doc.key = orderDoc.order_docs[0].storageKey;
                    doc.createdBy = orderDoc.order_docs[0].createdBy?.bpUserName;
                } else {
                    doc.status = 'Pending';
                    doc.date = null;
                }
                doc.onGenerate = openDialog;
                doc.openDialog = openDialog;
                doc.onDownload = onDownload;
                if (recyclerDocs.includes(orderDoc.docName)) {
                    rpDocs.push(doc);
                } else gpDocs.push(doc);
            }
        });
        setDocuments(gpDocs);
        setGenerateDocuments(rpDocs);
    };
    useEffect(() => {
        if (orderDocInfo && orderDocInfo.length) {
            formatDocuments(orderDocInfo);
        }
    }, [orderDocInfo]);

    if (orderHeaderData.currentSequence <= 4) {
        return <Title>You can see the Documents once Quote is Accepted</Title>;
    }
    return (
        <>
            {isLoading && <LoadingIndicator />}
            <Title level="H3" style={{ ...spacing.sapUiMediumMarginTopBottom }}>
                From {rpName}
            </Title>
            <Text>Here you can upload, generate and store the files of the following documents.</Text>
            <Grid style={{ marginTop: '20px' }}>
                {Generatedocuments?.map((document, index) => {
                    const { title, status, date, onDownload, onGenerate, openDialog, key, createdBy, type } = document;
                    return (
                        <DocumentCard
                            key={`rpdoc_${index}`}
                            title={title}
                            status={status}
                            date={date}
                            createdBy={createdBy}
                            onDownload={onDownload}
                            onUpload={onUpload}
                            openDialog={openDialog}
                            onGenerate={onGenerate}
                            docKey={key}
                            type={type}
                            onGenerateForm6={onGenerateForm6}
                            onGenerateForm2={onGenerateForm2}
                        />
                    );
                })}
                <DocumentCard
                    title="Add Document"
                    openUploadDialog={onUpload}
                    openDialog={openDialog}
                    onUpload={onUpload}
                    newDoc
                />
            </Grid>
            <Title level="H3" style={{ ...spacing.sapUiMediumMarginTopBottom }}>
                From {gpName}
            </Title>
            <Text>These are the documents your green partner provided for you. You can review and download them.</Text>
            <Grid style={{ marginTop: '20px' }}>
                {documents?.map((document, index) => {
                    const { title, status, date, onDownload, onGenerate, openDialog, key, createdBy } = document;
                    if (
                        (title !== 'Asset Grading' && title !== 'Delivery Challan') ||
                        orderHeaderData.processType === 'Refurbish'
                    ) {
                        return (
                            <DocumentCard
                                key={`gpdoc_${index}`}
                                title={title}
                                status={status}
                                date={date}
                                createdBy={createdBy}
                                openDialog={openDialog}
                                onDownload={onDownload}
                                onGenerate={onGenerate}
                                onUpload={onUpload}
                                docKey={key}
                                noUplaod
                                onGenerateForm6={onGenerateForm6}
                                onGenerateForm2={onGenerateForm2}
                            />
                        );
                    }
                })}
            </Grid>
        </>
    );
};

const mapStateToProps = (state) => ({
    orderDocInfo: getOrderDocInfoState(state),
    orderId: getOrderId(state),
    orderNo: getOrderNo(state),
    gpName: getGpName(state),
    rpName: getRpName(state),
    orderHeaderData: getOrderHeaderDataState(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetOrderDocumentsInfo: (orderId) => dispatch(getOrderDocuments(orderId)),
    startDownloadOrderDocument: (orderId, key) => dispatch(downloadDocument(orderId, key)),
    startUploadOrderDocument: (orderId, payload) => dispatch(uploadDocument(orderId, payload)),
    startGenerateForm6Document: (orderId, payload) => dispatch(generateForm6Document(orderId, payload)),
    startGenerateForm2Document: (orderId, payload) => dispatch(generateForm2Document(orderId, payload))
});

OrderDocumentationContainer.propTypes = {
    orderHeaderData: PropTypes.object,
    orderId: PropTypes.string,
    startGenerateForm6Document: PropTypes.func.isRequired,
    startGenerateForm2Document: PropTypes.func.isRequired,
    startGetOrderDocumentsInfo: PropTypes.func.isRequired,
    startUploadOrderDocument: PropTypes.func.isRequired,
    orderDocInfo: PropTypes.array,
    rpName: PropTypes.string,
    gpName: PropTypes.string,
    orderNo: PropTypes.string,
    startDownloadOrderDocument: PropTypes.func.isRequired
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderDocumentationContainer);
