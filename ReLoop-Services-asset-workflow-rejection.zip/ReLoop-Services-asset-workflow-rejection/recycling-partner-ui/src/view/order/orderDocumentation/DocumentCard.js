import React, { useState, useRef } from 'react';
import PropTypes from 'prop-types';
import { FlexBox, Title, Button, ObjectStatus, Text, Icon, Form, FormItem, Input } from '@ui5/webcomponents-react';
import GenerateDocDialog from './GenerateDocDialog';
import UploadDocDialog from './UploadDocDialog';

const DocumentCard = ({
    title,
    status,
    date,
    onDownload,
    onGenerate,
    onUpload,
    openDialog,
    docKey,
    onGenerateForm6,
    onGenerateForm2,
    newDoc,
    createdBy,
    noUplaod,
    type
}) => {
    const [payloadData, setPayloadData] = useState({});
    const [genType, setGenType] = useState('');
    const rpDocsToGenerate = ['Form 6', 'Form 2'];
    const getStatusData = (isIcon, status) => {
        let result = '';
        switch (status) {
            case 'Created':
                result = isIcon ? 'accept' : 'Success';
                break;
            case 'Pending':
                result = isIcon ? 'pending' : 'Warning';
                break;
            default:
                result = isIcon ? 'pending' : 'Warning';
                break;
        }
        return result;
    };
    const dialogRef = useRef(null);
    const uploadDialogRef = useRef(null);
    const onCancel = () => {
        dialogRef.current.close();
        uploadDialogRef.current.close();
    };

    const onSubmit = () => {
        dialogRef.current.close();
        uploadDialogRef.current.close();
        const updatedPayloadData = { ...payloadData };
        if (genType === 'form6') {
            onGenerateForm6(updatedPayloadData);
        } else {
            onGenerateForm2(updatedPayloadData);
        }
    };
    const onInputChange = (event) => {
        const { name, value } = event.target;
        const updatedData = { ...payloadData };
        updatedData[name] = value;
        setPayloadData(updatedData);
    };

    const onUpload2 = (payload) => {
        uploadDialogRef.current.close();
        onUpload(payload);
    };

    const onDownloadClick = (docKey, title) => {
        onDownload(docKey);
    };

    const onGenerateClick = (docKey, title) => {
        if (title === 'Form 6') {
            setGenType('form6');
            onGenerate(dialogRef, docKey);
        } else if (title === 'Form 2') {
            setGenType('form2');
            onGenerate(dialogRef, docKey);
        } else onGenerate(null, docKey);
    };
    const onUploadClick = (docKey, title) => {
        openDialog(uploadDialogRef);
    };

    const getComponents = (type) => {
        if (type === 'form2') {
            return (
                <>
                    <Form>
                        <FormItem label="Weight of E-waste (KG)">
                            <Input name="weight" onChange={onInputChange} />
                        </FormItem>
                    </Form>
                </>
            );
        }
        return (
            <>
                <Form>
                    <FormItem label="Invoice Number">
                        <Input name="invoiceNo" onChange={onInputChange} />
                    </FormItem>
                    <FormItem label="Weight of E-waste (KG)">
                        <Input name="weight" onChange={onInputChange} />
                    </FormItem>
                </Form>
            </>
        );
    };
    return (
        <div className="docCard">
            <FlexBox
                direction="Column"
                justifyContent="SpaceBetween"
                displayInline
                style={{ height: '100%', width: '100%' }}
                children={
                    <>
                        <Title wrap>{title}</Title>
                        {newDoc ? (
                            <Icon
                                name="add"
                                interactive
                                onClick={() => {
                                    onUploadClick(docKey, title);
                                }}
                                style={{ height: '8rem', width: '4rem', margin: '0 auto', color: 'rgb(8, 84, 160)' }}
                            />
                        ) : (
                            <>
                                <ObjectStatus
                                    icon={<Icon name={getStatusData(true, status)} />}
                                    state={getStatusData(false, status)}
                                    style={{ fontSize: '1rem' }}
                                >
                                    {status}
                                </ObjectStatus>
                                {status !== 'Pending' && (
                                    <Text style={{ fontSize: '1rem' }}>
                                        {`Created on: ${new Date(date).toDateString()}`}
                                    </Text>
                                )}
                                <FlexBox direction="Row" justifyContent="End">
                                    {!noUplaod && !rpDocsToGenerate.includes(title) && (
                                        <Button
                                            icon="upload"
                                            tooltip="Upload Document"
                                            onClick={() => {
                                                onUploadClick(docKey, title, type);
                                            }}
                                            style={{
                                                bottom: 0,
                                                border: 'none'
                                            }}
                                        />
                                    )}
                                    {rpDocsToGenerate.includes(title) && (
                                        <Button
                                            icon="create-entry-time"
                                            tooltip="Generate Document"
                                            onClick={() => {
                                                onGenerateClick(docKey, title);
                                            }}
                                            style={{
                                                bottom: 0,
                                                border: 'none'
                                            }}
                                        />
                                    )}
                                    {status !== 'Pending' && (
                                        <Button
                                            icon="download"
                                            tooltip="Download Document"
                                            onClick={() => {
                                                onDownloadClick(docKey, title);
                                            }}
                                            style={{
                                                bottom: 0,
                                                border: 'none'
                                            }}
                                        />
                                    )}
                                </FlexBox>
                            </>
                        )}
                    </>
                }
            />
            <GenerateDocDialog
                ref={dialogRef}
                onCancel={onCancel}
                onSubmit={onSubmit}
                onInputChange={onInputChange}
                headerText={`Generate Document:${title}`}
                components={getComponents(genType)}
            />
            <UploadDocDialog
                ref={uploadDialogRef}
                onCancel={onCancel}
                onSubmit={onSubmit}
                onUpload2={onUpload2}
                onUpload={onUpload}
                onInputChange={onInputChange}
                headerText={title}
                newDoc={newDoc}
                type={type}
            />
        </div>
    );
};

DocumentCard.propTypes = {
    title: PropTypes.string,
    status: PropTypes.string,
    date: PropTypes.string,
    onDownload: PropTypes.func.isRequired,
    onGenerate: PropTypes.func.isRequired,
    onUpload: PropTypes.func.isRequired,
    openDialog: PropTypes.func.isRequired,
    docKey: PropTypes.string,
    onGenerateForm6: PropTypes.func.isRequired,
    onGenerateForm2: PropTypes.func.isRequired,
    newDoc: PropTypes.string,
    createdBy: PropTypes.string,
    noUplaod: PropTypes.bool,
    type: PropTypes.string
};

export default DocumentCard;
