import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { Panel, Label, List, CustomListItem, FlexBox, Bar, Text, Icon } from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { getOrderList } from '../../store/action/order';
import { spacing } from '@ui5/webcomponents-react-base';
import { isOrderListLoading } from '../../selectors/common';
import LoadingIndicator from '../common/Loading';

const OrderList = ({ orderList, isLoading, startGetOrderList }) => {
    useEffect(() => {
        startGetOrderList();
    }, []);

    const history = useHistory();
    const onSelectionChange = (orderNumber) => {
        history.push(`/order/${orderNumber}`);
    };
    const uniqueStatus = [
        {
            status: ['New']
        },
        {
            status: ['In Progress', 'Accepted', 'Waiting', 'In Review', 'Temporarily Accepted']
        },
        {
            status: ['Completed', 'Rejected']
        }
    ];
    const getDataWithSpecificStatus = (status) => {
        const list = orderList.filter((order) => status.includes(order.quote_status));
        return list.sort((a, b) => (b.order_no.localeCompare(a.order_no)
            && (new Date(b.lastModifiedDate) - new Date(a.lastModifiedDate))
        ));
    };

    const getOrderTypeName = (orderType) => {
        if (orderType === '1') {
            return 'Refurbish';
        }
        return 'Recycle';
    };

    const orderTypeFontColor = {
        1: '#0065c5',
        2: '#107e3e'
    };

    if (isLoading) {
        return <LoadingIndicator />;
    }
    return (
        <>
            <Label style={{ fontSize: '1.3rem', fontWeight: 'Bold', marginTop: '15px', marginBottom: '20px' }}>
                Order List
            </Label>
            {uniqueStatus.map((item, index) => {
                const data = getDataWithSpecificStatus(item.status);
                return (
                    <Panel
                        headerText={`${item.status[0]} Orders (${data.length})`}
                        key={index}
                        style={{ overflow: 'hidden' }}
                    >
                        <List
                            noDataText={`No ${item.status[0]} Orders`}
                            mode="SingleSelect"
                            separators="None"
                            growing="Scroll"
                            onSelectionChange={(e) => onSelectionChange(e.detail.selectedItems[0].dataset.id)}
                        >
                            {data.map((order, idx) => (
                                <CustomListItem
                                    data-id={order.order_no}
                                    key={`List${idx}`}
                                    style={{
                                        height: '5rem'
                                    }}
                                >
                                    <Bar
                                        className="active-hover"
                                        style={{
                                            height: '5rem'
                                        }}
                                        endContent={
                                            <div>
                                                <br />
                                                <Icon name="slim-arrow-right" />
                                            </div>
                                        }
                                        startContent={
                                            <FlexBox>
                                                <Icon name="order-status" tooltip="Order" />
                                                <div style={spacing.sapUiTinyMarginBeginEnd}>
                                                    <div>
                                                        <Text>{order.order_no}</Text>
                                                        <div style={spacing.sapUiTinyMarginTop}>
                                                            <span>
                                                                <strong
                                                                    style={{
                                                                        color: orderTypeFontColor[order?.orderType]
                                                                    }}
                                                                >
                                                                    {getOrderTypeName(order?.orderType)}
                                                                </strong>
                                                                &nbsp;|&nbsp;
                                                                <strong>{order.created_by}</strong>
                                                                &nbsp;|&nbsp;Received Date:{' '}
                                                                {order.created_date.substring(0, 10)}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </FlexBox>
                                        }
                                    />
                                </CustomListItem>
                            ))}
                        </List>
                    </Panel>
                );
            })}
        </>
    );
};

OrderList.propTypes = {
    orderList: PropTypes.array,
    isLoading: PropTypes.bool,
    startGetOrderList: PropTypes.func
};

OrderList.defaultProps = {
    orderList: []
};
const mapStateToProps = (state) => ({
    orderList: state.order.orderList.data,
    isLoading: isOrderListLoading(state)
});
const mapDispatchToProps = (dispatch) => ({
    startGetOrderList: () => dispatch(getOrderList())
});
export default connect(mapStateToProps, mapDispatchToProps)(OrderList);
