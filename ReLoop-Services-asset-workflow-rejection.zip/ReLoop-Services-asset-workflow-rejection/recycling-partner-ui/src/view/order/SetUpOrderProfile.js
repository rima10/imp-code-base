import React from 'react';
import PropTypes from 'prop-types';
import { Title, Button, Label, FlexBox } from '@ui5/webcomponents-react';
import bg from '../../asset/images/background-image.png';

const SetupOrderProfile = ({ toggleHidden }) => (
    <FlexBox alignItems="Center" style={{ backgroundImage: `url(${bg})`, height: '270px' }} direction="Column">
        <Title
            style={{
                fontSize: 'x-large',
                textAlign: 'center',
                marginTop: '60px',
                color: '#000000'
            }}
        >
            <b>Welcome to EverLoop!</b>
        </Title>
        <Label
            wrappingType="Normal"
            style={{
                fontSize: 'large',
                textAlign: 'center',
                marginTop: '20px',
                color: '#000000'
            }}
        >
            Your workflow was already set up. You can now proceed further and review the orders received from your
            partners.
        </Label>
        <br />
        <Button
            design="Emphasized"
            onClick={toggleHidden}
            style={{
                marginTop: '25px'
            }}
        >
            View My orders
        </Button>
    </FlexBox>
);

SetupOrderProfile.propTypes = {
    toggleHidden: PropTypes.func.isRequired
};

export default SetupOrderProfile;
