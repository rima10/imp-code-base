const camelCaseToSentence = (value) => {
    value = value.trim();
    const temp = value.replace(/([A-Z])/g, ' $1');
    const sentence = temp.charAt(0).toUpperCase() + temp.slice(1);
    return sentence;
};

export { camelCaseToSentence };
