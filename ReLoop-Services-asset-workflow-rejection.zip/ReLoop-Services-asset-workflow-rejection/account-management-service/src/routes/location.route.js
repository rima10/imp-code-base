const router = require('express').Router();
const locController = require('../controllers/loc.controller');

/*
  @desc router configuartion for /api/user/location endpoint
*/

module.exports = (app) => {
  /**
 * @swagger
 * /api/user/loc/address:
 *   post:
 *    description:  Endpoint to create address location data
 *    tags:
 *      - Location
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              addresses:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    countryName:
 *                      type: string
 *                      description: Country Name
 *                      example: India
 *                    stateName:
 *                      type: string
 *                      description: State name.
 *                      example: Delhi
 *                    cityName:
 *                      type: string
 *                      description: City name.
 *                      example: New Delhi
 */
  router.post('/address', locController.createAddresses);

  /**
 * @swagger
 * /api/user/loc/country:
 *   post:
 *    description:  Endpoint to create country data
 *    tags:
 *      - Location
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *              $ref: '#/components/schemas/Country'
 */
  router.post('/country', locController.createCountries);

  /**
 * @swagger
 * /api/user/loc/state:
 *   post:
 *    description:  Endpoint to create state data
 *    tags:
 *      - Location
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *              $ref: '#/components/schemas/State'
 */
  router.post('/state', locController.createStates);

  /**
 * @swagger
 * /api/user/loc/city:
 *   post:
 *    description:  Endpoint to create city data
 *    tags:
 *      - Location
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *              $ref: '#/components/schemas/City'
 */
  router.post('/city', locController.createCities);

  /**
 * @swagger
 * /api/user/loc/country:
 *   get:
 *    description:  Endpoint to get list of countries
 *    tags:
 *      - Location
 *    responses:
 *       200:
 *         description: A list of countries.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Country'
 */
  router.get('/country', locController.getCountryList);

  /**
 * @swagger
 * /api/user/loc/country/{countryId}:
 *   get:
 *    description:  Endpoint to get list of countries
 *    tags:
 *      - Location
 *    parameters:
 *       - name: countryId
 *         description: id of the country
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: Details of the country.
 *         content:
 *           application/json:
 *             schema:
 *              type: object
 *              items:
 *                $ref: '#/components/schemas/Country'
 */
  router.get('/country/:countryId', locController.getCountry);

  /**
 * @swagger
 * /api/user/loc/getStateList:
 *   get:
 *    description:  Endpoint to get list of state
 *    tags:
 *      - Location
 *    responses:
 *       200:
 *         description: A list of states.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/State'
 */
  router.get('/state', locController.getStateList);

  /**
 * @swagger
 * /api/user/loc/state/country/{countryId}:
 *   get:
 *    description:  Endpoint to get list of state by country
 *    tags:
 *      - Location
 *    parameters:
 *       - name: countryId
 *         description: id of the country
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: list of states by the country.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/State'
 */
  router.get('/state/country/:countryId', locController.getStatesbyCountry);

  /**
 * @swagger
 * /api/user/loc/state/{stateId}:
 *   get:
 *    description:  Endpoint to get state
 *    tags:
 *      - Location
 *    parameters:
 *       - name: stateId
 *         description: id of the state
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: state object.
 *         content:
 *           application/json:
 *             schema:
 *              type: object
 *              items:
 *                $ref: '#/components/schemas/State'
 */
  router.get('/state/:stateId', locController.getState);

  /**
 * @swagger
 * /api/user/loc/city:
 *   get:
 *    description:  Endpoint to get list of city
 *    tags:
 *      - Location
 *    responses:
 *       200:
 *         description: A list of cities.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/City'
 */
  router.get('/city', locController.getCityList);

  /**
 * @swagger
 * /api/user/loc/city/state/{stateId}:
 *   get:
 *    description:  Endpoint to get list of cities by state
 *    tags:
 *      - Location
 *    parameters:
 *       - name: stateId
 *         description: id of the state
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: list of cities by state.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/city'
 */
  router.get('/city/state/:stateId', locController.getCitiesByState);

  /**
 * @swagger
 * /api/user/loc/city/{cityId}:
 *   get:
 *    description:  Endpoint to get city
 *    tags:
 *      - Location
 *    parameters:
 *       - name: cityId
 *         description: id of the state
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: city object
 *         content:
 *           application/json:
 *             schema:
 *              type: object
 *              items:
 *                $ref: '#/components/schemas/city'
 */
  router.get('/city/:cityId', locController.getCity);
  app.use('/api/user/loc', router);
};
