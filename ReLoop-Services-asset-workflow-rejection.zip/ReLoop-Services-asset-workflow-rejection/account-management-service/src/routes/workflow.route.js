const router = require('express').Router();
const workflowController = require('../controllers/workflow.controller');
const authUtil = require('../utils/auth.util');

module.exports = (app) => {
  /**
 * @swagger
 * /api/user/workflow/:
 *   post:
 *    description:  Endpoint to create workflow data
 *    tags:
 *      - Workflow
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *              type: object
 *              required:
 *              properties:
 *                  processStageSequence:
 *                      type: number
 *                      description: process stage sequence number
 *                      example: 1
 *                  processStageName:
 *                      type: string
 *                      description: process stage name.
 *                      example: Initial
 *                  processTypeId:
 *                      type: string
 *                      description: recycling or refurbishing process id.
 *                      example: admin
 *                  approvers:
 *                      type: array
 *                      description: list of approvers.
 *                      items:
 *                          type: object
 *                          properties:
 *                              approverId:
 *                                  type: string
 *                                  description: approver id
 *                                  example: 1
 *                              approverSequence:
 *                                  type: number
 *                                  description: approver sequence in workflow
 *                                  example: 1
 *
 */
  router.post('/',
    [authUtil.validateMiddleware, authUtil.isGpUser],
    workflowController.addWorkflow);

  /**
 * @swagger
 * /api/user/workflow/:
 *   get:
 *    description:  Endpoint to update approver data
 *    tags:
 *      - Workflow
 *    responses:
 *       200:
 *         description: A list of user's workflows.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Workflow'
 */
  router.get('/',
    [authUtil.validateMiddleware, authUtil.isGpUser],
    workflowController.getWorkflows);
  /**
 * @swagger
 * /api/user/workflow/{workflowId}/{processTypeId}:
 *   delete:
 *    description:  Endpoint to delete business partner workflow
 *    tags:
 *      - Workflow
 *    parameters:
 *       - name: workflowId
 *         description: id of the workflow
 *         in: path
 *         required: true
 *         type: number
 *       - name: workflowId
 *         description: id of the process
 *         in: path
 *         required: true
 *         type: number
 *    responses:
 *       201:
 *         description: workflow deleted successfully.
 */
  router.delete('/:workflowId/:processTypeId',
    [authUtil.validateMiddleware, authUtil.isGpUser],
    workflowController.deleteWorkflow);

  /**
 * @swagger
 * /api/user/workflow/approver:
 *   delete:
 *    description:  Endpoint to delete business partner workflow approver
 *    tags:
 *      - Workflow
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: number
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              processTypeId:
 *                type: string
 *                description: processTypeId
 *                example: 1
 *              workflowApprovers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    workflowApproverId:
 *                      type: string
 *                      description: workflow approver id
 *                      example: 1
 *    responses:
 *       201:
 *         description: workflow approvers deleted
 */
  router.delete('/approver',
    [authUtil.validateMiddleware, authUtil.isGpUser],
    workflowController.deleteWorkflowApprovers);

  app.use('/api/user/workflow', router);
};
