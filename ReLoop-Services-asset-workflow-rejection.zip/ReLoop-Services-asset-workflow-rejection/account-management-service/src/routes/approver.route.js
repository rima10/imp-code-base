const router = require('express').Router();
const approverController = require('../controllers/approver.controller');
const authUtil = require('../utils/auth.util');

module.exports = (app) => {
  /**
 * @swagger
 * /api/user/approver/:
 *   post:
 *    description:  Endpoint to create approver data
 *    tags:
 *      - Approver
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              approvers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    approverEmailId:
 *                      type: string
 *                      description: approver email id
 *                      example: fake@email.com
 *                    approverName:
 *                      type: string
 *                      description: approver name.
 *                      example: Raj
 *                    approverRole:
 *                      type: string
 *                      description: approver role.
 *                      example: admin
 */
  router.post('/',
    [authUtil.validateMiddleware, authUtil.isGpUser],
    approverController.addApprovers);

  /**
 * @swagger
 * /api/user/approver/:
 *   get:
 *    description:  Endpoint to get list of GP approvers
 *    tags:
 *      - Approver
 *    responses:
 *       200:
 *         description: List of approvers.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Approver'
 */
  router.get('/',
    [authUtil.validateMiddleware, authUtil.isGpUser],
    approverController.getApprovers);

  /**
 * @swagger
 * /api/user/approver/{approverId}:
 *   delete:
 *    description:  Endpoint to delete GP approver by approver id
 *    tags:
 *      - Approver
 *    parameters:
 *       - name: approverId
 *         description: id of the approver
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       201:
 *         description: List of approvers.
 *         content:
 *           application/json:
 */
  router.delete('/:approverId',
    [authUtil.validateMiddleware, authUtil.isGpUser],
    approverController.deleteApproverById);

  /**
 * @swagger
 * /api/user/approver/:
 *   delete:
 *    description:  Endpoint to delete GP approver
 *    tags:
 *      - Approver
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              approvers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    approverId:
 *                      type: string
 *                      description: approver user id
 *                      example: 1
 *    responses:
 *       201:
 *         description: List of approvers.
 *         content:
 *           application/json:
 */
  router.delete('/',
    [authUtil.validateMiddleware, authUtil.isGpUser],
    approverController.deleteApprovers);

  /**
 * @swagger
 * /api/user/approver/:
 *   patch:
 *    description:  Endpoint to update approver data
 *    tags:
 *      - Approver
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              approvers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    approverEmailId:
 *                      type: string
 *                      description: approver email id
 *                      example: fake@email.com
 *                    approverName:
 *                      type: string
 *                      description: approver name.
 *                      example: Raj
 *                    approverRole:
 *                      type: string
 *                      description: approver role.
 *                      example: admin
 */
  router.patch('/',
    [authUtil.validateMiddleware, authUtil.isGpUser],
    approverController.updateApprovers);
  app.use('/api/user/approver', router);
};
