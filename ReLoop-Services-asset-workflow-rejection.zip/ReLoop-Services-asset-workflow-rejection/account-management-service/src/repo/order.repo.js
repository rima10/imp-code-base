const models = require('../models/index');

exports.getOngoingOrdersForUser = async (userId, processTypeId, options = {}) => {
  if (!options.projection) {
    options.projection = [];
  }
  const promise = models.order.findAll({
    where: { created_by: userId, order_position: 'In Progress', order_type: processTypeId },
    attributes: models.order.attributesAliasesHelper(options.projection),
  });
  return promise;
};
