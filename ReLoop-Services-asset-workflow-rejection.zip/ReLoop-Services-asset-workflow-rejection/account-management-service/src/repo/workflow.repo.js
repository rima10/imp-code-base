const { Op } = require('sequelize');
const models = require('../models/index');

exports.getAllWorkflowsForUser = async (userId) => {
  const promise = models.workflow
    .findAll({
      where:
        { bp_id: userId },
      attributes: ['workflow_id', 'process_stage_name', 'process_stage_sequence', 'process_type_id'],
      include: [{
        model: models.workflow_approver,
        as: 'workflow_approvers',
        attributes: ['approver_sequence', 'workflow_approver_id'],
        include: {
          model: models.approver,
          as: 'approver',
          attributes: ['approver_id', 'approver_email_id', 'approver_name', 'approver_role']
        },
      }],
    });
  return promise;
};

/*
  @desc helper function to create workflow
  @param Object - workflowData
  @param Array - approvers
  @return Oject - newWorkflow
*/
exports.createWorkflow = async (userId, workflowData, approvers) => {
  let workflow;
  const {
    processStageSequence, processTypeId,
  } = workflowData;
  const existingWorkflow = await models.workflow.findOne(
    {
      where: {
        process_type_id: processTypeId,
        process_stage_sequence: processStageSequence,
        bp_id: userId,
      },
      attributes: ['workflow_id'],
    },
  );
  if (existingWorkflow) {
    workflow = existingWorkflow;
  } else {
    const workflowDataCopy = { ...workflowData };
    workflowDataCopy.bpUserId = userId;

    const workflowDataCopy2 = models.workflow.attributesAliasesHelper(workflowDataCopy, {
      allowNewFields: false, method: 'in',
    });
    workflow = await models.workflow.create(workflowDataCopy2);
  }
  await Promise.all(approvers.map(async (approver) => {
    const { approverId, approverSequence } = approver;
    await models.workflow_approver.create({
      approver_id: approverId,
      approver_sequence: approverSequence,
      workflow_id: workflow.workflow_id,
    });
  }));
  return workflow;
};

exports.deleteWorkflow = async (userId, workflowId) => models.workflow.destroy({
  where: { bp_id: userId, workflow_id: workflowId },
});

exports.deleteWorkflowApprovers = async (workflowApprovers) => {
  await Promise.all(workflowApprovers.map(async (approver) => {
    const { workflowApproverId } = approver;
    // eslint-disable-next-line max-len
    const workflowApprover = await models.workflow_approver.findOne({
      where: { workflow_approver_id: workflowApproverId },
    });
    await workflowApprover.destroy();
    await models.workflow_approver.update({
      approver_sequence: models.sequelize.literal(('cast(approver_sequence as integer) - 1')),
    }, {
      where: {
        workflow_id: workflowApprover.dataValues.workflow_id,
        approver_sequence: { [Op.gte]: workflowApprover.dataValues.approver_sequence },
      },
    });
  }));
};
