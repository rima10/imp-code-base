const Models = require('../models/index');
const utilFunctions = require('../utils/commonFunctions.util');

exports.createAddress = async (address) => {
  let country; let state; let city;
  if (address.countryName) {
    country = await Models.country.findOne({ where: { country_name: address.countryName } });
    if (!country) {
      country = await Models.country.create({ country_name: address.countryName });
    }
  }
  if (address.stateName) {
    state = await Models.state.findOne({ where: { state_name: address.stateName } });
    if (!state) {
      state = await Models.state.create({
        state_name: address.stateName,
        country_id: country.country_id,
      });
    }
  }
  if (address.cityName) {
    city = await Models.city.findOne({ where: { city_name: address.cityName } });
    if (!city) {
      city = await Models.city.create({ city_name: address.cityName, state_id: state.state_id });
    }
  }
  return {
    country, state, city,
  };
};

exports.createCountry = async (country) => Models.country.create(utilFunctions.camelCaseToUnderScore(country));

exports.createCountry = async (state) => Models.state.create(utilFunctions.camelCaseToUnderScore(state));

exports.createCity = async (city) => Models.city.create(utilFunctions.camelCaseToUnderScore(city));

exports.getAllCountries = async () => Models.country.findAll();

exports.getCountryById = async (countryId) => Models.country.findOne({
  where: {
    country_id: countryId,
  },
});

exports.getAllStates = async () => Models.state.findAll();

exports.getStatesbyCountry = async (countryId) => Models.state.findAll({
  where: { country_id: countryId },
  order: [
    ['state_name', 'ASC'],
  ],
});

exports.getStateById = async (stateId) => Models.state.findOne({ where: { state_id: stateId } });

exports.getAllCities = async () => Models.city.findAll();

exports.getCitiesByState = async (stateId) => Models.city.findAll({
  where: { state_id: stateId },
  order: [
    ['city_name', 'ASC'],
  ],
});

exports.getCityById = async (cityId) => Models.city.findOne({ where: { city_id: cityId } });
