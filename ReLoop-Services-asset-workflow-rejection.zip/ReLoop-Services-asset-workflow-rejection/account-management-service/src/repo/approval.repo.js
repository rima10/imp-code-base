const Models = require('../models/index');
const authUtil = require('../utils/auth.util');
const ErrorTypes = require('../constants/error');
/*
  @desc helper function to create approvers
  @desc approver user created in cognito
  @param Object - approverData
  @return Oject - newApprover
*/
async function createApprover(approverData) {
  const cognitoUserData = {
    Username: approverData.approver_email_id,
    UserPoolId: process.env.COGNITO_USER_POOL_ID,
    TemporaryPassword: 'Welcome@12345', // To be removed , just for test data creation
  };
  const congitoUserGroupData = {
    GroupName: authUtil.ROLES.GP_APPORVER,
    UserPoolId: process.env.COGNITO_USER_POOL_ID,
  };
  const cognitoUser = await authUtil.createCognitouser(cognitoUserData, congitoUserGroupData);
  const approver = { ...approverData };
  approver.approver_userid = cognitoUser;
  const newApprover = await Models.approver.create(approver);
  return newApprover;
}

const removeApprover = async (userId, approverId) => {
  const existingApprover = await Models.approver.findOne({ where: { approver_id: approverId } });
  if (!existingApprover) {
    const err = new Error('Approver does not exist');
    err.type = ErrorTypes.RES_NOT_FOUND;
    return Promise.reject(err);
  }
  const cognitoUserData = {
    Username: existingApprover.approver_email_id,
    UserPoolId: process.env.COGNITO_USER_POOL_ID,
  };
  await authUtil.deleteCognitouser(cognitoUserData);
  await Models.approver.destroy({ where: { bp_id: userId, approver_id: approverId } });
  return Promise.resolve(true);
};
exports.removeApprover = removeApprover;

exports.deleteManyApprovers = async (userId, approvers) => {
  const existingOrderStatus = await Models.order.findAll({
    where: { created_by: userId, order_position: 'In Progress' },
    attributes: [['order_position', 'orderPosition']],
  });
  if (existingOrderStatus.length !== 0) {
    const err = new Error('Approver cannot be deleted as being used in ongoing orders');
    err.type = ErrorTypes.NOT_ALLOWED_ACTION;
    throw err;
  }
  return Promise.all(approvers.map(async (approver) => {
    const { approverId } = approver;
    return removeApprover(userId, approverId);
  }));
};

exports.createManyApprovers = async (userId, approvers) => {
  await Promise.all(approvers.map(async (approver) => {
    let { approverEmailId, approverName, approverRole } = approver;
    approverEmailId = approverEmailId.toString().toLowerCase().trim();
    approverName = approverName.toString().trim();
    approverRole = approverRole.toString().trim();
    // eslint-disable-next-line max-len
    const existingApprover = await Models.approver.findAll({ where: { approver_email_id: approverEmailId } });
    if (existingApprover.length > 0) {
      const err = new Error('Approver already exist');
      err.type = ErrorTypes.NOT_ALLOWED_REDO;
      throw err;
    }
    await createApprover({
      approver_email_id: approverEmailId,
      approver_name: approverName,
      bp_id: userId,
      approver_role: approverRole,
    });
  }));
};

exports.getAllApproversForUser = async (userId) => {
  const promise = Models.approver.findAll({
    where: { bp_id: userId },
    attributes: ['approver_id', 'approver_email_id', 'approver_name', 'approver_role']
  });
  return promise;
};

exports.updateManyApprovers = async (userId, approvers) => {
  await Promise.all(approvers.map(async (approver) => {
    const { approverEmailId, approverName, approverRole } = approver;
    const existingApprover = await Models.approver.findOne({
      where: { bp_id: userId, approver_email_id: approverEmailId },
    });
    if (existingApprover) {
      existingApprover.update({
        approver_name: approverName,
        approver_role: approverRole,
      });
    } else {
      await createApprover({
        approver_email_id: approverEmailId,
        approver_name: approverName,
        bp_id: userId,
        approver_role: approverRole,
      });
    }
  }));
};
