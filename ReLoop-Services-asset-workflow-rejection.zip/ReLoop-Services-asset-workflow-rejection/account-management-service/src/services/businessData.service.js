const UserRepo = require('../repo/user.repo');

/*
  @desc service to get user data
*/
exports.getUserBusinessData = async (userId) => {
  try {
    const user = await UserRepo.getBusinessData(userId);
    return Promise.resolve(user);
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to update business partner data
*/
exports.updateUserBusinessData = async (userId, payload) => {
  try {
    await UserRepo.updateUserBusinessData(userId, payload);
    const userData = await UserRepo.getBusinessData(userId);
    return Promise.resolve(userData);
  } catch (error) {
    return Promise.reject(error);
  }
};
