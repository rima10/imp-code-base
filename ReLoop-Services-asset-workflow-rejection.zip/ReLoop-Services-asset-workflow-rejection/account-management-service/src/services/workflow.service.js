const ErrorTypes = require('../constants/error');
const WorkflowRepo = require('../repo/workflow.repo');
const OrderRepo = require('../repo/order.repo');

exports.getWorkflows = async (userId) => WorkflowRepo.getAllWorkflowsForUser(userId);

/*
  @desc service function to add workflow
*/
exports.addWorkflow = async (userId, workflow) => {
  try {
    const {
      processTypeId, approvers,
    } = workflow;

    const existingOrderStatus = await OrderRepo.getOngoingOrdersForUser(userId, processTypeId);
    if (existingOrderStatus.length !== 0) {
      const err = new Error('Workflow cannot be added as being used in ongoing orders');
      err.type = ErrorTypes.NOT_ALLOWED_ACTION;
      throw err;
    }

    await WorkflowRepo.createWorkflow(userId, workflow, approvers);

    const workflows = await WorkflowRepo.getAllWorkflowsForUser(userId);
    return Promise.resolve(workflows);
  } catch (error) {
    return Promise.reject(error);
  }
};

exports.deleteWorkflow = async (userId, workflowId, processTypeId) => {
  const existingOrderStatus = await OrderRepo.getOngoingOrdersForUser(userId, processTypeId);
  if (existingOrderStatus.length !== 0) {
    const err = new Error('Workflow cannot be deleted as being used in ongoing orders');
    err.type = ErrorTypes.NOT_ALLOWED_ACTION;
    throw err;
  }
  await WorkflowRepo.deleteWorkflow(userId, workflowId);

  const workflows = await WorkflowRepo.getAllWorkflowsForUser(userId);
  return workflows;
};

exports.deleteWorkflowApprovers = async (userId, processTypeId, workflowApprovers) => {
  const existingOrderStatus = await OrderRepo.getOngoingOrdersForUser(userId, processTypeId);
  if (existingOrderStatus.length !== 0) {
    const err = new Error('Approver cannot be deleted as being used in ongoing orders');
    err.type = ErrorTypes.NOT_ALLOWED_ACTION;
    throw err;
  }

  await WorkflowRepo.deleteWorkflowApprovers(workflowApprovers);

  const workflows = await WorkflowRepo.getAllWorkflowsForUser(userId);
  return workflows;
};
