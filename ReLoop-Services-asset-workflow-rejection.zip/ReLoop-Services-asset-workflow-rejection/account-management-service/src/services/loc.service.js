const LocationRepo = require('../repo/location.repo');
/*
  @desc service function to create addresses
  @desc loop over address list and create address
  @desc check if country/state/city exists, if not create new
*/
exports.createAddresses = async function (addresses) {
  return Promise.all(addresses.map(async (address) => LocationRepo.createAddress(address)));
};

/*
  @desc service function to create country
  @desc loop over country list and create country
*/
exports.createCountries = async function (countries) {
  return Promise.all(countries.map(async (country) => LocationRepo.createCountry(country)));
};

/*
  @desc service function to create state
  @desc loop over state list and create state
*/
exports.createStates = async function (states) {
  return Promise.all(states.map(async (state) => LocationRepo.createState(state)));
};

/*
  @desc service function to create city
  @desc loop over city list and create city
*/
exports.createCities = async function (cities) {
  return Promise.all(cities.map(async (city) => LocationRepo.createCity(city)));
};

/*
  @desc service function to get country list
*/
exports.getCountryList = async function () {
  return LocationRepo.getAllCountries();
};

/*
  @desc service function to get country
*/
exports.getCountry = async function (countryId) {
  return LocationRepo.getCountryById(countryId);
};

/*
  @desc service function to get state list
*/
exports.getStateList = async function () {
  return LocationRepo.getAllStates();
};

/*
  @desc service function to get state by country
*/
exports.getStatesbyCountry = async function (countryId) {
  return LocationRepo.getStatesbyCountry(countryId);
};

/*
  @desc service function to get state
*/
exports.getState = async function (stateId) {
  return LocationRepo.getStateById(stateId);
};

/*
  @desc service function to get city list
*/
exports.getCityList = async function () {
  return LocationRepo.getAllCities();
};

/*
  @desc service function to get city by state
*/
exports.getCitiesByState = async function (stateId) {
  return LocationRepo.getCitiesByState(stateId);
};

/*
  @desc service function to get city
*/
exports.getCity = async function (cityId) {
  return LocationRepo.getCityById(cityId);
};
