const UserRepo = require('../repo/user.repo');

/*
  @desc service function to create service location for a recycler
*/
exports.addServicableLocations = async (userId, details) => UserRepo.saveServicableLocations(userId, details);

/*
  @desc service function to get servicable Location of a recycler
*/
exports.getRecyclerServicableLocation = async (userId) => UserRepo.getServicableLocationsForUser(userId);

/*
  @desc service function to delete service location
*/
exports.deleteServicableLocations = async (userId, details) => {
  await UserRepo.deleteServicableLocations(userId, details);
  return UserRepo.getServicableLocationsForUser(userId);
};
