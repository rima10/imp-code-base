const UserRepo = require('../repo/user.repo');

/*
  @desc service function to create user private network
  @desc check if pvt network user exist, if not create cognito user aswell
*/
exports.createUserPrivateNtw = async (userId, bpType, pvtNwkMembers) => {
  try {
    await UserRepo.createPrivateNetworkUsers(userId, bpType, pvtNwkMembers);
    const userPrivateNtws = await UserRepo.getPrivateNetworks(userId);
    return Promise.resolve(userPrivateNtws);
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to get private network
*/
exports.getUserPrivateNtw = async (userId) => {
  try {
    const userPrivateNtws = await UserRepo.getPrivateNetworks(userId);
    return Promise.resolve(userPrivateNtws);
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to update private network
*/
exports.updateUserPrivateNtw = async (userId, pvtNwkMembers) => {
  try {
    await UserRepo.updatePrivateNetworkMembers(userId, pvtNwkMembers);
    const userPrivateNtws = await UserRepo.getPrivateNetworks(userId);
    return Promise.resolve(userPrivateNtws);
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to update private network
*/
exports.deleteUserPrivateNtw = async (userId, pvtNetworks) => {
  try {
    await UserRepo.deletePrivateNetworkMembers(userId, pvtNetworks);
    const userPrivateNtws = await UserRepo.getPrivateNetworks(userId);
    return Promise.resolve(userPrivateNtws);
  } catch (error) {
    return Promise.reject(error);
  }
};
