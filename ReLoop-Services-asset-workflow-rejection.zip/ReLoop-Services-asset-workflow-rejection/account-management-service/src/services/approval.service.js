const ApprovalRepo = require('../repo/approval.repo');

/*
  @desc service function to add approvers
  @desc loop over approvers list and create approvers
*/
exports.addApprovers = async (userId, approvers) => {
  await ApprovalRepo.createManyApprovers(userId, approvers);
  return ApprovalRepo.getAllApproversForUser(userId);
};

/*
  @desc service function to get approvers
*/
exports.getApprovers = async (bpId) => ApprovalRepo.getAllApproversForUser(bpId);

/*
  @desc service function to delete one approver by id
*/
exports.deleteApproverById = async (userId, approverId) => {
  await ApprovalRepo.removeApprover(userId, approverId);
  return ApprovalRepo.getAllApproversForUser(userId);
};

/*
  @desc service function to delete approvers
*/
exports.deleteApprovers = async (userId, approvers) => {
  try {
    await ApprovalRepo.deleteManyApprovers(userId, approvers);
    return ApprovalRepo.getAllApproversForUser(userId);
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to update approvers
  @desc loop over approvers list and update approvers
*/
exports.updateApprovers = async (userId, approvers) => {
  try {
    await ApprovalRepo.updateManyApprovers(userId, approvers);
    return ApprovalRepo.getAllApproversForUser(userId);
  } catch (error) {
    return Promise.reject(error);
  }
};
