/* eslint-disable max-len */
/* eslint-disable no-param-reassign */
const Models = require('../models/index');
const s3UtilFunctions = require('../utils/s3.util');
const UserRepo = require('../repo/user.repo');

function formUserCertificateObjects(userCertificates, userData) {
  const { username, userId } = userData;
  return userCertificates.map((certItem) => {
    const fileNamewithExt = certItem.certificateFile.originalname;
    const fileExt = fileNamewithExt.substr(fileNamewithExt.lastIndexOf('.') + 1);
    const uniqueFilename = `${username}_${userId}_${certItem.certificateName}.${fileExt}`;
    return { certificateFile: certItem.certificateFile, uniqueFilename };
  });
}
const uploadCertificatesToS3 = async (certificates) => {
  const uploadedFileKeys = await Promise.all(certificates.map(async (file) => s3UtilFunctions.pushFileToS3(file.certificateFile, file.uniqueFilename)));
  return uploadedFileKeys;
};

/*
  @desc service function to save certificate details of user
  @desc also uploads the certificate file into s3
*/
exports.saveUserCertificates = async (userId, userCertificates) => {
  try {
    const queryOptions = {
      projection: ['userId', 'username'],
    };
    const userData = await UserRepo.getUserById(userId, queryOptions);

    const certificateFiles = formUserCertificateObjects(userCertificates, userData);
    const uploadedFileKeys = await uploadCertificatesToS3(certificateFiles);

    userCertificates.forEach((certItem, index) => {
      certItem.certificateStorageMeta = uploadedFileKeys[index];
    });

    const certificates = await UserRepo.createCertificates(userCertificates);
    return Promise.resolve(certificates);
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to get all certificate details of an user
*/
exports.getAllCertificatesForUser = async (userId) => UserRepo.getAllCertificatesForUser(userId);

/*
  @desc service function to read uploaded file from s3
*/
exports.downloadUserCertificateById = async (userId, certId) => {
  try {
    const certificate = await UserRepo.getCertificateById(userId, certId);
    const { certificateStorageMeta } = certificate;
    const result = await s3UtilFunctions.downloadFile(certificateStorageMeta);
    const { stream, data } = result;
    return Promise.resolve({ stream, data, filename: certificateStorageMeta });
  } catch (error) {
    return Promise.reject(error);
  }
};
