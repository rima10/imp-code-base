const Sequelize = require('sequelize');

const attributesMap = [
  ['bpNwkId', 'bp_nwk_id'],
  ['memberUserId', 'nwk_member'],
  ['ownerUserId', 'nwk_owner'],
  ['archive', 'archive'],
  ['createdDate', 'created_date'],
  ['lastModifiedDate', 'last_modified_date'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

/**
 * @swagger
 *  components:
 *    schemas:
 *      PrivateNetwork:
 *        type: object
 *        required:
 *        properties:
 *          bp_nwk_id:
 *            type: string
 *          nwk_member:
 *            type: string
 *          nwk_owner:
 *            type: string
 *        example:
 *           bp_nwk_id: 1
 *           nwk_member: 2
 *           nwk_owner: 3
 */
module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('bp_private_nwk', {
    bp_nwk_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    nwk_member: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    nwk_owner: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    archive: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
  }, {
    sequelize,
    tableName: 'bp_private_nwk',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'bp_private_nwk_pkey',
        unique: true,
        fields: [
          { name: 'bp_nwk_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.business_partner, { as: 'nwk_owner_business_partner', foreignKey: 'nwk_owner' });
    model.belongsTo(models.business_partner, { as: 'nwk_member_business_partner', foreignKey: 'nwk_member' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
