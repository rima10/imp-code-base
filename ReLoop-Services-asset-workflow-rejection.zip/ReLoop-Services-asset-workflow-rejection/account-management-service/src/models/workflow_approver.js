const attributesMap = [
  ['workflowApproverId', 'workflow_approver_id'],
  ['workflowId', 'workflow_id'],
  ['approverId', 'approver_id'],
  ['approverSequence', 'approver_sequence'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('workflow_approver', {
    workflow_approver_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    workflow_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'workflow',
        key: 'workflow_id',
      },
    },
    approver_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'approver',
        key: 'approver_id',
      },
    },
    approver_sequence: {
      type: DataTypes.DECIMAL,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'workflow_approver',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'workflow_approver_pkey',
        unique: true,
        fields: [
          { name: 'workflow_approver_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.approver, { as: 'approver', foreignKey: 'approver_id' });
    model.belongsTo(models.workflow, { as: 'workflow', foreignKey: 'workflow_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
