/* eslint-disable no-param-reassign */
const fs = require('fs');
const path = require('path');
const Sequelize = require('sequelize');

const basename = path.basename(__filename);
const env = process.env.NODE_ENV || 'development';
const config = require(`${__dirname}/../config/config.js`)[env];
const db = {};

let sequelize;
if (config.use_env_variable) {
  sequelize = new Sequelize(process.env[config.use_env_variable], config);
} else {
  sequelize = new Sequelize(config.database, config.username, config.password, config);
}
/*
  @desc attributesAliasesHelper:
  this function helps to transform service attributes into db column attributes and vice versa
  service attributes: key name that is used in service layers, for ex: greenPartnerId
  db column attributes: column name that is kept in db, for ex: gp_id

  this attributesAliasesHelper will transform the fields using maps defined specific to the model
  sample input: specification
  can be array:
    [] - will return all the fields mentioned in the specific model's attributesMap
    ['greenPartnerId'] - will return [['gp_id', 'greenPartnerId']]
  can be an object:
    { greenPartnerId: 123 } - will return { gp_id: 123 }

  NOTE: this attributesAliasesHelper must be called only with the context (this)
  of any model with attributesMap in it attached.
*/
// eslint-disable-next-line no-underscore-dangle
function jsonObjectHelper(obj, options) {
  const transMap = options.method === 'in' ? this.serviceToDbMap : this.dbToServiceMap;
  const convertedSpec = {};
  Object.keys(obj).forEach((alias) => {
    if (transMap.has(alias)) {
      convertedSpec[transMap.get(alias)] = obj[alias];
    } else if (options.allowNewFields) {
      convertedSpec[alias] = obj[alias];
    }
  });
  return convertedSpec;
}
function attributesAliasesHelper(specification, options = { allowNewFields: true, method: 'in' }) {
  if (!options.method) {
    options.method = 'in';
  }
  if (!Object.keys(options).includes('allowNewFields')) {
    options.allowNewFields = true;
  }
  let transMap = options.method === 'in' ? this.serviceToDbMap : this.dbToServiceMap;
  if (Array.isArray(specification)) {
    if (!specification || !specification.length) {
      transMap = this.dbToServiceMap;
      return Array.from(transMap, (keyvaluePair) => (keyvaluePair));
    }
    const aliases = [];
    specification.forEach((alias) => {
      if (Array.isArray(alias)) {
        aliases.push(alias);
      } else if (typeof alias === 'object') {
        aliases.push(jsonObjectHelper.call(this, alias, options));
      } else if (typeof alias === 'string') {
        transMap = this.serviceToDbMap;

        if (transMap.has(alias)) {
          aliases.push([transMap.get(alias), alias]);
        } else if (options.allowNewFields) {
          aliases.push([alias, alias]);
        }
      }
    });

    return aliases;
  }

  // specification is a json object directly
  return jsonObjectHelper.call(this, specification, options);
}

fs
  .readdirSync(__dirname)
  .filter((file) => (file.indexOf('.') !== 0) && (file !== basename) && (file.slice(-3) === '.js'))
  .forEach((file) => {
    const model = require(path.join(__dirname, file))(sequelize, Sequelize.DataTypes);
    db[model.name] = model;
  });

Object.keys(db).forEach((modelName) => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
  db[modelName].attributesAliasesHelper = attributesAliasesHelper;
});

db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;
