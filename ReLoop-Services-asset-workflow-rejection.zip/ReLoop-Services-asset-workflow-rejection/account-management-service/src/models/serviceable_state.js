const attributesMap = [
  ['servicableLocationStateId', 'serv_loc_state_id'],
  ['servicableLocationId', 'serv_loc_id'],
  ['stateId', 'state_id'],
  ['stateName', 'state_name'],
  ['isAllCity', 'is_all_city'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('serviceable_state', {
    serv_loc_state_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    serv_loc_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'serviceable_location',
        key: 'serv_loc_id',
      },
    },
    state_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'state',
        key: 'state_id',
      },
    },
    state_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    is_all_city: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'serviceable_state',
    schema: 'address',
    timestamps: false,
    indexes: [
      {
        name: 'serviceable_state_pkey',
        unique: true,
        fields: [
          { name: 'serv_loc_state_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.serviceable_location, { as: 'serv_loc', foreignKey: 'serv_loc_id' });
    model.hasMany(models.serviceable_city, { as: 'serviceable_cities', foreignKey: 'serv_loc_state_id' });
    model.belongsTo(models.state, { as: 'state', foreignKey: 'state_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
