const Sequelize = require('sequelize');

const attributesMap = [
  ['notificationId', 'notification_id'],
  ['notificationBody', 'notification_body'],
  ['notificationText', 'notification_text'],
  ['createdDate', 'created_date'],
  ['lastModifiedDate', 'last_modified_date'],
  ['eventId', 'event_id'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('notification', {
    notification_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    notification_body: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    notification_text: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    event_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'event',
        key: 'event_id',
      },
    },
  }, {
    sequelize,
    tableName: 'notification',
    schema: 'notification',
    timestamps: false,
    indexes: [
      {
        name: 'notification_mapping_pkey',
        unique: true,
        fields: [
          { name: 'notification_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.event, { as: 'event', foreignKey: 'event_id' });
    model.hasMany(models.bp_notification, { as: 'bp_notifications', foreignKey: 'notification_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
