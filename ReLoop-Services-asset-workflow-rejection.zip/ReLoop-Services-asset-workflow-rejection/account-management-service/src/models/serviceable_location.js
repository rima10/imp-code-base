const attributesMap = [
  ['servicableLocationId', 'serv_loc_id'],
  ['bpUserId', 'rcy_id'],
  ['countryId', 'country_id'],
  ['isAllState', 'is_all_state'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

/**
 * @swagger
 *  components:
 *    schemas:
 *      ServiceableLocation:
 *        type: object
 *        required:
 *        properties:
 *          serv_loc_id:
 *            type: string
 *          is_all_state:
 *            type: string
 *          country_id:
 *            type: string
 *        example:
 *           serv_loc_id: 1
 *           is_all_state: true
 *           country_id: 1
 */
module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('serviceable_location', {
    serv_loc_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    rcy_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    country_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'country',
        key: 'country_id',
      },
    },
    is_all_state: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'serviceable_location',
    schema: 'address',
    timestamps: false,
    indexes: [
      {
        name: 'serviceable_location_pkey',
        unique: true,
        fields: [
          { name: 'serv_loc_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.business_partner, { as: 'rcy', foreignKey: 'rcy_id' });
    model.belongsTo(models.country, { as: 'country', foreignKey: 'country_id' });
    model.hasMany(models.serviceable_state, { as: 'serviceable_states', foreignKey: 'serv_loc_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
