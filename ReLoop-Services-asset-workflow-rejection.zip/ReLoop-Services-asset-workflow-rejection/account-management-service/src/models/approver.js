const attributesMap = [
  ['approverId', 'approver_id'],
  ['approverUserId', 'approver_userid'],
  ['approverEmailId', 'approver_email_id'],
  ['approverName', 'approver_name'],
  ['approverRole', 'approver_role'],
  ['bpUserId', 'bp_id'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

/**
 * @swagger
 *  components:
 *    schemas:
 *      Approver:
 *        type: object
 *        required:
 *        properties:
 *          approver_id:
 *            type: string
 *          approver_userid:
 *            type: string
 *          approver_email_id:
 *            type: string
 *          approver_name:
 *            type: string
 *          approver_role:
 *            type: string
 *          bp_id:
 *            type: string
 *        example:
 *           approver_id: 1
 *           approver_userid: 2
 *           approver_email_id: fake@email.com
 *           approver_name: approver
 *           approver_role: admin
 *           bp_id: 1
 */

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('approver', {
    approver_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    approver_userid: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: 'approver_approver_userid_key',
    },
    approver_email_id: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: 'approver_approver_email_id_key',
    },
    approver_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    approver_role: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    bp_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
  }, {
    sequelize,
    tableName: 'approver',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'approver_approver_email_id_key',
        unique: true,
        fields: [
          { name: 'approver_email_id' },
        ],
      },
      {
        name: 'approver_approver_userid_key',
        unique: true,
        fields: [
          { name: 'approver_userid' },
        ],
      },
      {
        name: 'approver_pkey',
        unique: true,
        fields: [
          { name: 'approver_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.hasMany(models.bp_notification, { as: 'bp_notifications', foreignKey: 'approver_id' });
    model.hasMany(models.workflow_approver, { as: 'workflow_approvers', foreignKey: 'approver_id' });
    model.belongsTo(models.business_partner, { as: 'bp', foreignKey: 'bp_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
