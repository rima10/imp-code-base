const Sequelize = require('sequelize');

const attributesMap = [
  ['bpNotificationId', 'bp_notification_id'],
  ['bpUserId', 'bp_id'],
  ['approverUserId', 'approver_id'],
  ['notificationId', 'notification_id'],
  ['isRead', 'is_read'],
  ['createdDate', 'created_date'],
  ['lastModifiedDate', 'last_modified_date'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('bp_notification', {
    bp_notification_id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
    },
    bp_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    approver_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'approver',
        key: 'approver_id',
      },
    },
    notification_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'notification',
        key: 'notification_id',
      },
    },
    is_read: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
  }, {
    sequelize,
    tableName: 'bp_notification',
    schema: 'notification',
    timestamps: false,
    indexes: [
      {
        name: 'bp_notification_pkey',
        unique: true,
        fields: [
          { name: 'bp_notification_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.approver, { as: 'approver', foreignKey: 'approver_id' });
    model.belongsTo(models.business_partner, { as: 'bp', foreignKey: 'bp_id' });
    model.belongsTo(models.notification, { as: 'notification', foreignKey: 'notification_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
