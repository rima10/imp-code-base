const Sequelize = require('sequelize');

const attributesMap = [
  ['orderId', 'order_id'],
  ['orderNumber', 'order_no'],
  ['additionalInfo', 'order_sub_text'],
  ['categoryId', 'category'],
  ['subCategoryId', 'sub_category'],
  ['processTypeId', 'order_type'],
  ['createdDate', 'created_date'],
  ['lastModifiedDate', 'last_modified_date'],
  ['createdByUserId', 'created_by'],
  ['updatedByUserId', 'updated_by'],
  ['preferredPickUpTime', 'preferred_pick_up_time'],
  ['isVerificationRequired', 'is_verification_reqd'],
  ['orderNetwork', 'order_network'],
  ['pictureStorageKey', 'picture_loc'],
  ['submissionDeadline', 'submission_deadline'],
  ['orderPosition', 'order_position'],
  ['currentSequence', 'current_sequence'],
  ['logisticsScheduledTime', 'logistics_scheduled_time'],
  ['vehicleType', 'vehicle_type'],
  ['vehicleNumber', 'vehicle_licence_no'],
  ['driverName', 'driver_name'],
  ['logisticProvider', 'logistic_provider'],
  ['recyclerContactName', 'recycler_contact_name'],
  ['recyclerContactNumber', 'recycler_contact_number'],
  ['totalWeight', 'total_weight'],
  ['recycleAssetType', 'recycle_asset_type'],
  ['logisticSpocName', 'logistic_spoc_name'],
  ['logisticSpocContactNumber', 'logistic_spoc_number'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

/**
 * @swagger
 *  components:
 *    schemas:
 *      Order:
 *        type: object
 *        required:
 *        properties:
 *          order_id:
 *            type: string
 *          order_no:
 *            type: string
 *          order_sub_text:
 *            type: string
 *          category:
 *            type: string
 *          sub_category:
 *            type: string
 *          order_type:
 *            type: string
 *          created_date:
 *            type: date
 *          last_modified_date:
 *            type: date
 *          created_by:
 *            type: string
 *          updated_by:
 *            type: string
 *          submission_deadline:
 *            type: date
 *          preferred_pick_up_time:
 *            type: date
 *          is_verification_reqd:
 *            type: string
 *          order_network:
 *            type: string
 *          picture_loc:
 *            type: string
 *          logistics_scheduled_time:
 *            type: date
 *          vehicle_type:
 *            type: string
 *          vehicle_licence_no:
 *            type: string
 *          driver_name:
 *            type: string
 *          logistic_provider:
 *            type: string
 *          recycler_contact_name:
 *            type: string
 *          recycler_contact_number:
 *            type: string
 *          order_Items:
 *            type: array
 *            items:
 *              $ref: '#/components/schemas/OrderItem'
 *        example:
 *           orderId: 1
 *           orderNumber: SAP2021001
 *           orderAdditionalInfo: additional information
 *           category: 1
 *           subCategory: 1
 *           orderType: 1
 *           created_date: 2021-06-14 15:23:59.171827+05:30
 *           last_modified_date: 2021-06-14 15:23:59.171827+05:30
 *           createdBy: 12
 *           updatedBy: 12
 *           submissionDeadline: 2021-07-01 17:22:23+05:30
 *           preferred_pick_up_time: 2021-07-09 17:22:23+05:30
 *           is_verification_reqd: true
 *           orderLocation: address
 *           orderNetwork: Private
 *           pictureLoc: s3.com
 *           logisticsScheduledTime: 2021-10-09 17:22:23+05:30
 *           vehicleType: AMT (Semi Trailer)
 *           vehicleNumber: HR26DQ5551
 *           driverName: John Doe
 *           logisticProvider: XYZ Ltd
 *           recyclerContactName: Alen
 *           recyclerContactNumber: 9876543210
 *           orderItems:
 *            id: 1
 *            orderId: 2
 *            equipmentNumber: dfg456
 *            assetNumber: 2345abc
 *            categoryNumber: Mobile Telephone
 *            make: SAMSUNG
 *            description: SAMSUNG Galaxy
 *            created_date: 2021-06-14T15:52:02.030Z
 *            last_modified_date: 2021-06-14T15:52:02.030Z
 *            createdBy: 12
 *            updatedBy: 12
 *            buildingLocation: BLR04
 *            manufactureSerial: ACY0056
 *            bondStatus: debonded
 *            model: Thinkpad T240
 *            ageInYear: 13
 *            purchaseYear: 2010 and Older
 */

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('order', {
    order_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_no: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: 'order_order_no_key',
    },
    order_sub_text: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    category: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'category',
        key: 'category_id',
      },
    },
    sub_category: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'sub_category',
        key: 'sub_category_id',
      },
    },
    order_type: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'process_type',
        key: 'process_type_id',
      },
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    created_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    updated_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    preferred_pick_up_time: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    is_verification_reqd: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    order_network: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    picture_loc: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    submission_deadline: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    order_position: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    current_sequence: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    logistics_scheduled_time: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    vehicle_type: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    vehicle_licence_no: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    driver_name: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    logistic_provider: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    recycler_contact_name: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    recycler_contact_number: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    total_weight: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    recycle_asset_type: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    logistic_spoc_name: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    logistic_spoc_number: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'order',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'order_order_no_key',
        unique: true,
        fields: [
          { name: 'order_no' },
        ],
      },
      {
        name: 'order_pkey',
        unique: true,
        fields: [
          { name: 'order_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.business_partner, { as: 'businessPartner', foreignKey: 'created_by' });
    model.belongsTo(models.business_partner, { as: 'updated_by_business_partner', foreignKey: 'updated_by' });
    model.hasMany(models.order_invited_business_partner, { as: 'order_invited_business_partners', foreignKey: 'order_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
