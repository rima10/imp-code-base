const attributesMap = [
  ['roleMapId', 'map_id'],
  ['bpUserId', 'bp_id'],
  ['roleId', 'role_id'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('role_bp_mapping', {
    map_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    bp_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    role_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'role',
        key: 'role_id',
      },
    },
  }, {
    sequelize,
    tableName: 'role_bp_mapping',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'role_bp_mapping_pkey',
        unique: true,
        fields: [
          { name: 'map_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.business_partner, { as: 'bp', foreignKey: 'bp_id' });
    model.belongsTo(models.role, { as: 'role', foreignKey: 'role_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
