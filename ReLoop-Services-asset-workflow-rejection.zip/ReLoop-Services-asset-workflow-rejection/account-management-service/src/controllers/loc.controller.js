const locService = require('../services/loc.service');

/*
  @desc controller function to create addresses
*/
exports.createAddresses = async function (req, res, next) {
  try {
    const { addresses } = req.body;
    await locService.createAddresses(addresses);
    res.send(200);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to create country
*/
exports.createCountries = async function (req, res, next) {
  try {
    const { countries } = req.body;
    await locService.createCountries(countries);
    res.send(200);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to create states
*/
exports.createStates = async function (req, res, next) {
  try {
    const { states } = req.body;
    await locService.createStates(states);
    res.send(200);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to create city
*/
exports.createCities = async function (req, res, next) {
  try {
    const { cities } = req.body;
    await locService.createCities(cities);
    res.send(200);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get country list
*/
exports.getCountryList = async function (req, res, next) {
  try {
    const countries = await locService.getCountryList();
    res.json(countries);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get country
*/
exports.getCountry = async function (req, res, next) {
  try {
    const { countryId } = req.params;
    const country = await locService.getCountry(countryId);
    res.json(country);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get state list
*/
exports.getStateList = async function (req, res, next) {
  try {
    const states = await locService.getStateList();
    res.json(states);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get state by country
*/
exports.getStatesbyCountry = async function (req, res, next) {
  try {
    const { countryId } = req.params;
    const states = await locService.getStatesbyCountry(countryId);
    res.json(states);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get state
*/
exports.getState = async function (req, res, next) {
  try {
    const { stateId } = req.params;
    const state = await locService.getState(stateId);
    res.json(state);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get city list
*/
exports.getCityList = async function (req, res, next) {
  try {
    const cities = await locService.getCityList();
    res.json(cities);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get city by state
*/
exports.getCitiesByState = async function (req, res, next) {
  try {
    const { stateId } = req.params;
    const cities = await locService.getCitiesByState(stateId);
    res.json(cities);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get city
*/
exports.getCity = async function (req, res, next) {
  try {
    const { cityId } = req.params;
    const city = await locService.getCity(cityId);
    res.json(city);
  } catch (error) {
    next(error);
  }
};
