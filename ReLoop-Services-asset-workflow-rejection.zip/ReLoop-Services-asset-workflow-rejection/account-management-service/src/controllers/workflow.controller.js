const workflowService = require('../services/workflow.service');

/*
  @desc controller function to add workflow
*/
exports.addWorkflow = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const workflow = req.body;
    const response = await workflowService.addWorkflow(userId, workflow);
    res.status(201).json(response);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get workflows
*/
exports.getWorkflows = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const workflows = await workflowService.getWorkflows(userId);
    res.status(200).json(workflows);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to delete workflow
*/
exports.deleteWorkflow = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { workflowId, processTypeId } = req.params;
    const response = await workflowService.deleteWorkflow(userId, workflowId, processTypeId);
    res.status(200).json(response);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to delete workflow approvers
*/
exports.deleteWorkflowApprovers = async (req, res, next) => {
  try {
    const { userId } = req.userInfo;
    const { workflowApprovers, processTypeId } = req.body;
    const response = await workflowService.deleteWorkflowApprovers(userId, processTypeId, workflowApprovers);
    res.status(200).json(response);
  } catch (error) {
    next(error);
  }
};
