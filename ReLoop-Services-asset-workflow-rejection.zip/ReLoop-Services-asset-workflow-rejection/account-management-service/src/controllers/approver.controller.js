const approvalService = require('../services/approval.service');

/*
  @desc controller function to add approvers
*/
exports.addApprovers = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;
    const { approvers } = req.body;
    const response = await approvalService.addApprovers(userId, approvers);
    res.status(201).json(response);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get approvers
*/
exports.getApprovers = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;
    const approvers = await approvalService.getApprovers(userId);
    res.json(approvers);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to delete approvers
*/
exports.deleteApproverById = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;
    const { approverId } = req.params;
    const approvers = await approvalService.deleteApproverById(userId, approverId);
    res.status(201).json(approvers);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to delete approvers
*/
exports.deleteApprovers = async function (req, res, next) {
  try {
    const { userId } = req.userInfo;
    const { approvers } = req.body;
    const response = await approvalService.deleteApprovers(userId, approvers);
    res.status(200).json(response);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to update approvers
*/
exports.updateApprovers = async function (req, res, next) {
  try {
    const { approvers } = req.body;
    const { userId } = req.userInfo;
    const response = await approvalService.updateApprovers(userId, approvers);
    res.status(200).json(response);
  } catch (error) {
    next(error);
  }
};
