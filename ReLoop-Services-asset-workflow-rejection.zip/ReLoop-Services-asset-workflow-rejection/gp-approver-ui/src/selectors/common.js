export const getUserInfoState = (state) => state.userInfo;

export const getToastState = (state) => state.toast;

export const isLoadingState = (state) => state.isLoading;

export const getNotificationsState = (state) => state.notification.data;

export const isNotificationLoadingState = (state) => state.notification.isLoading;

export const getOrderInfoState = (state) => state.orderInfo.data;

export const getOrderItemQuotationState = (state) => state.orderItemQuote.data;

export const getOrderListState = (state) => state.orderList.data;

export const isOrderListLoading = (state) => state.orderList.isLoading;

export const getOrderQuotationState = (state) => state.orderQuote.data;
