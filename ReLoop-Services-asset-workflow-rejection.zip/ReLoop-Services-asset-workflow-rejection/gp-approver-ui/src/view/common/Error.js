import React from 'react';
import PropTypes from 'prop-types';
import { Label, Button, ShellBar } from '@ui5/webcomponents-react';
import { useHistory } from 'react-router-dom';
import logo from '../../../public/favicon.ico';

const ErrorComponent = ({ text, redirect }) => {
    const history = useHistory();
    const onLogin = () => {
        history.push('/login');
    };

    return (
        <>
            {redirect && (
                <ShellBar
                    logo={<img alt="EverLoop Logo" src={logo} />}
                    primaryTitle="EverLoop by SAP"
                    style={{ position: 'fixed', top: '0', zIndex: '1000' }}
                />
            )}
            <Label style={{ position: 'fixed', zIndex: 100, top: '50%', left: '44%', fontSize: '2rem' }}>{text}</Label>
            {redirect && (
                <Button
                    design="Emphasized"
                    style={{
                        position: 'fixed',
                        zIndex: 100,
                        top: '60%',
                        left: '48%',
                        width: '100px',
                        height: '42px',
                        fontSize: '1.5rem'
                    }}
                    onClick={onLogin}
                >
                    Login
                </Button>
            )}
        </>
    );
};

ErrorComponent.propTypes = {
    text: PropTypes.string,
    redirect: PropTypes.bool
};

ErrorComponent.defaultProps = {
    text: 'Something went wrong, please refresh the page'
};

export default ErrorComponent;
