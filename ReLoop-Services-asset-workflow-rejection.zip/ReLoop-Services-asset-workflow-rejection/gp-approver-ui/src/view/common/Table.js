import React from 'react';
import {
    Label,
    Button,
    Toolbar,
    Input,
    Table,
    TableColumn,
    ToolbarSpacer,
    TableRow,
    TableCell,
    Text,
    Select,
    Option,
    Title,
    TableGrowingMode
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport';

const AccountTable = ({ rows = [], columns = [], buttons = [], edit = false, text, lazyLoading, height }) => {
    const getCell = (cell) => {
        switch (cell.type) {
            case 'text':
                return (
                    <Text className="tableCellText" tooltip={cell.value} style={{ ...spacing.sapUiTinyMarginBeginEnd }}>
                        {cell.value}
                    </Text>
                );
            case 'input':
                return (
                    <Input
                        key={cell.name}
                        name={cell.name}
                        onChange={(e) => {
                            cell.onInputChange(e);
                        }}
                    />
                );
            case 'select':
                return (
                    <Select
                        onChange={(e) => {
                            cell.onInputChange(e);
                        }}
                    >
                        {cell?.options?.map((item) => (
                            <Option
                                key={item.approver_id}
                                id={item.approver_id}
                                name={item.approver_name}
                                value={item.approver_role}
                            >
                                {item.approver_role}
                            </Option>
                        ))}
                    </Select>
                );
            default:
                return null;
        }
    };

    const getStyleForTable = () => {
        const style = {
            border: '1px solid #888888',
            overflowX: 'auto'
        };
        if (height) {
            style.height = height;
        }
        return style;
    };

    const renderFunction = () => (
        <div>
            <Toolbar style={spacing.sapUiMediumMarginTop}>
                <Title>{text}</Title>
                <ToolbarSpacer />
                <div>
                    {buttons.map((button) => (
                        <Button key={button.name} onClick={button.onClick} icon={button.icon}>
                            {button.name}
                        </Button>
                    ))}
                </div>
            </Toolbar>
            <Table
                onLoadMore={lazyLoading}
                growing={lazyLoading ? TableGrowingMode.Scroll : TableGrowingMode.None}
                noDataText="No data available"
                stickyColumnHeader={!!height}
                columns={columns?.map((column, idx) => (
                    <TableColumn key={idx} style={{ width: '33rem' }}>
                        <Label>{column}</Label>
                    </TableColumn>
                ))}
                style={getStyleForTable()}
            >
                {rows?.map((row, idx) => (
                    <TableRow key={idx}>
                        {row.map((cell, id) => (
                            <TableCell key={id}>{getCell(cell)}</TableCell>
                        ))}
                    </TableRow>
                ))}
            </Table>
        </div>
    );
    return renderFunction();
};

export default AccountTable;
