import React, { useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import {
    ShellBar,
    Avatar,
    Popover,
    Button,
    Bar,
    NotificationListItem,
    List,
    Label,
    Text,
    FlexBox
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import { useHistory } from 'react-router-dom';
import logo from '../../../public/favicon.ico';
import { logout } from '../../store/action/taskAction';
import { getNotifications, readNotification } from '../../store/action/notification';
import { getNotificationsState, isNotificationLoadingState } from '../../selectors/common';

const Header = ({
    notificationList,
    startGetNotificationsInfo,
    startReadNotification,
    userName,
    imageSrc,
    startLogout,
    isLoading
}) => {
    const popoverRef = useRef(null);
    const signoutRef = useRef(null);
    const history = useHistory();

    const onNotificationsClick = (e) => {
        popoverRef.current.showAt(e.detail.targetRef);
    };

    const onAvatarClick = (e) => {
        signoutRef.current.showAt(e.detail.targetRef);
    };

    const onPopoverClose = () => {
        popoverRef.current.close();
    };

    const onLogout = () => {
        onPopoverClose();
        startLogout();
        history.push('/logout');
    };

    useEffect(() => {
        startGetNotificationsInfo();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleLogoClick = () => {
        history.push('/');
    };

    const getNotificationAge = (notificationTime) => {
        const startDate = new Date(notificationTime);
        const endDate = new Date();
        const difference = endDate.getTime() - startDate.getTime();
        const daysDifference = Math.floor(difference / 1000 / 60 / 60 / 24);
        if (daysDifference) return `${daysDifference} Days Ago`;

        const hoursDifference = Math.floor(difference / 1000 / 60 / 60);
        if (hoursDifference) return `${hoursDifference} Hours Ago`;

        const minutesDifference = Math.floor(difference / 1000 / 60);
        if (minutesDifference) return `${minutesDifference} Minutes Ago`;
        return 'Just Now';
    };

    const onNotificationRead = (event) => {
        const bpNotificationId = event.currentTarget.getAttribute('data-id');
        startReadNotification(bpNotificationId);
    };

    const getNotificationStyle = (isRead) => {
        if (!isRead) return { background: 'aliceblue' };
        return {};
    };

    const renderAvatar = () => {
        if (imageSrc) {
            return <Avatar size="XS" imageFitType="Contain" image={imageSrc} />;
        }
        if (userName) {
            const initials = userName
                .split(' ')
                .slice(0, 2)
                .map((word) => word.charAt(0))
                .join('');
            return <Avatar size="XS" initials={initials} />;
        }
        return <Avatar icon="employee" size="XS" />;
    };

    return (
        <>
            <ShellBar
                logo={<img alt="EverLoop Logo" src={logo} />}
                primaryTitle="EverLoop by SAP"
                profile={renderAvatar()}
                showNotifications
                notificationsCount={notificationList.length}
                onNotificationsClick={onNotificationsClick}
                onProfileClick={onAvatarClick}
                onLogoClick={handleLogoClick}
            />
            <Popover
                headerText="Notifications"
                footer={
                    <Bar
                        style={{ background: 'var(--sapShellColor)' }}
                        endContent={<Button onClick={onPopoverClose}>Close</Button>}
                    />
                }
                placementType="Bottom"
                horizontalAlign="Center"
                ref={popoverRef}
            >
                <>
                    <List noDataText="No new notifications" busy={isLoading}>
                        {notificationList?.map((notification) => {
                            const notificationItem = notification.notification;
                            return (
                                <NotificationListItem
                                    key={notification.bpNotificationId}
                                    style={getNotificationStyle(notification.isRead)}
                                    data-id={notification.bpNotificationId}
                                    footnotes={<Label>{getNotificationAge(notificationItem.createdDate)}</Label>}
                                    titleText={notificationItem.notificationBody}
                                    showClose={!notification.isRead}
                                    onClose={onNotificationRead}
                                >
                                    {notificationItem.notificationText}
                                </NotificationListItem>
                            );
                        })}
                    </List>
                </>
            </Popover>
            <Popover placementType="Bottom" horizontalAlign="Center" ref={signoutRef}>
                <FlexBox
                    style={spacing.sapUiSmallMargin}
                    direction="Column"
                    justifyContent="SpaceBetween"
                    alignItems="Start"
                >
                    <Text>{userName}</Text>
                    <Button
                        disabled
                        style={{ ...spacing.sapUiTinyMargin, fontSize: '0.8rem', border: 'none' }}
                        icon="action-settings"
                        design="Transparent"
                    >
                        Settings
                    </Button>
                    <Button
                        style={{ ...spacing.sapUiTinyMargin, fontSize: '0.8rem', border: 'none' }}
                        icon="log"
                        onClick={onLogout}
                    >
                        Sign Out
                    </Button>
                </FlexBox>
            </Popover>
        </>
    );
};

const mapStateToProps = (state) => ({
    notificationList: getNotificationsState(state),
    isLoading: isNotificationLoadingState(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetNotificationsInfo: async () => dispatch(getNotifications()),
    startReadNotification: async (bpNotificationId) => dispatch(readNotification(bpNotificationId)),
    startLogout: async () => dispatch(logout())
});

Header.propTypes = {
    notificationList: PropTypes.array,
    startGetNotificationsInfo: PropTypes.func.isRequired,
    startReadNotification: PropTypes.func.isRequired,
    userName: PropTypes.string,
    imageSrc: PropTypes.string,
    startLogout: PropTypes.func.isRequired,
    isLoading: PropTypes.bool
};

Header.defaultProps = {
    notificationList: []
};

export default connect(mapStateToProps, mapDispatchToProps)(Header);
