import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FlexibleColumnLayout, List, StandardListItem } from '@ui5/webcomponents-react';
import { getOrderList } from '../../store/action/order';
import OrderDetails from './OrderDetails';
import { getOrderListState, isOrderListLoading } from '../../selectors/common';
import StatusColor from '../../asset/constants/statusColor';

const getInfoState = (approverStatus) => {
    let infoState = StatusColor.None;
    switch (approverStatus) {
        case 'Pending':
            infoState = StatusColor.Warning;
            break;
        case 'Approved':
            infoState = StatusColor.Success;
            break;
        case 'Rejected':
            infoState = StatusColor.Error;
            break;
        default:
            infoState = StatusColor.None;
    }
    return infoState;
};

const OrderFCL = ({ orderList, startGetOrdersInfo, isLoading }) => {
    const [layout, setLayout] = useState('OneColumn');
    const [selectedOrder, setSelectedOrder] = useState({});

    useEffect(() => {
        startGetOrdersInfo();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onSelectionChange = (event) => {
        const [orderNumber, orderWorkflowApprId] = event.detail.selectedItems[0].accessibleName.split('|');
        const order = orderList.find(
            (orderItem) => orderItem.orderNo === orderNumber
                && orderItem.orderWorkflowApproverId === orderWorkflowApprId
        );
        setSelectedOrder(order);
        setLayout('TwoColumnsMidExpanded');
    };

    return (
        <>
            <FlexibleColumnLayout
                midColumn={<OrderDetails orderWorkflow={selectedOrder} />}
                startColumn={
                    <List
                        headerText="Order List"
                        noDataText="No order data present"
                        onSelectionChange={(e) => onSelectionChange(e)}
                        mode="SingleSelect"
                        busy={isLoading}
                    >
                        {orderList?.map((order, idx) => (
                            <StandardListItem
                                key={`${order.orderNo}|${order.orderWorkflowApproverId}`}
                                accessibleName={`${order.orderNo}|${order.orderWorkflowApproverId}`}
                                additionalText={order.status.toUpperCase()}
                                additionalTextState={getInfoState(order.status)}
                                description={`Current Status : ${order.processStageName}`}
                            >
                                {order.orderNo}
                            </StandardListItem>
                        ))}
                    </List>
                }
                layout={layout}
                style={{ height: '100vh' }}
            />
        </>
    );
};

OrderFCL.propTypes = {
    startGetOrdersInfo: PropTypes.func.isRequired,
    orderList: PropTypes.array,
    isLoading: PropTypes.bool
};

OrderFCL.defaultProps = {
    orderList: []
};

const mapStateToProps = (state) => ({
    orderList: getOrderListState(state),
    isLoading: isOrderListLoading(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetOrdersInfo: async () => dispatch(getOrderList())
});

export default connect(mapStateToProps, mapDispatchToProps)(OrderFCL);
