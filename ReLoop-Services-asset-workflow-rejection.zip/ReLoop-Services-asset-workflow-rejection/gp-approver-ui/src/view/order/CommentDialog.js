import React from 'react';
import PropTypes from 'prop-types';
import { spacing } from '@ui5/webcomponents-react-base';
import { Button, Form, FormItem, TextArea, Dialog } from '@ui5/webcomponents-react';

const CommentDialog = React.forwardRef(({ onSubmit, onCancel, onCommentChange, btnText }, ref) => (
    <Dialog
        ref={ref}
        footer={
            <div style={spacing.sapUiSmallMargin}>
                <Button style={spacing.sapUiTinyMargin} onClick={onCancel}>
                    Close
                </Button>
                <Button style={spacing.sapUiTinyMargin} onClick={onSubmit}>
                    {btnText}
                </Button>
            </div>
        }
        headerText="Add Comments"
    >
        <Form>
            <FormItem label="Comments">
                <TextArea onChange={onCommentChange} />
            </FormItem>
        </Form>
    </Dialog>
));

CommentDialog.propTypes = {
    onSubmit: PropTypes.func.isRequired,
    onCancel: PropTypes.func.isRequired,
    onCommentChange: PropTypes.func.isRequired,
    btnText: PropTypes.string
};

CommentDialog.displayName = 'CommentDialog';

export default CommentDialog;
