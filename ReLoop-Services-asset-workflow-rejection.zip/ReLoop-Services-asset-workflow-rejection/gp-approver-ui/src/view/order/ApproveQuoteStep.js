import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Bar, Label } from '@ui5/webcomponents-react';
import AccountTable from '../common/Table';
import { getOrderItemLevelQuote } from '../../store/action/quotation';
import { getOrderInfoState, getOrderItemQuotationState } from '../../selectors/common';
import { isEmpty } from '../../validation/common';

const ApproveFinalQuote = ({ startGetItemQuote, orderItemQuotation, orderType, orderInfo }) => {
    const [assetRows, setAssetRows] = useState([]);
    const assetColumns = [
        'Equipment No.',
        'Asset No.',
        'Grade',
        'Blancco',
        'Report status',
        'List price',
        'To be invoiced',
        'service cost'
    ];

    const recycleAssetColumns = ['Item', 'Final Quantity', 'Unit', 'Price per Unit (INR)', 'Total Price (INR)'];

    const [totalRow, setTotalRows] = useState({ invoiceAmount: 0, serviceCost: 0 });
    const calculateTotalAmount = (assetGradeListRows, field1, field2) => {
        const totalRowCopy = { ...totalRow };
        totalRowCopy[field1] = 0;
        if (field2) {
            totalRowCopy[field2] = 0;
        }
        assetGradeListRows.forEach((item) => {
            totalRowCopy[field1] += item[field1] ? Number(item[field1]) : 0;
            if (field2) {
                totalRowCopy[field2] += item[field2] ? Number(item[field2]) : 0;
            }
        });
        if (field1) {
            totalRowCopy[field1] = Math.round(totalRowCopy[field1] * 100) / 100;
        }
        if (field2) {
            totalRowCopy[field2] = Math.round(totalRowCopy[field2] * 100) / 100;
        }
        setTotalRows(totalRowCopy);
    };

    const getOrderItemQuoteDetails = () => {
        const newRows = [];
        if (orderType === '1') {
            orderItemQuotation.orderQuoteItems.map((orderItem) => {
                const row = [];
                row.push({ name: assetColumns[0], value: orderItem.equipmentNumber, type: 'text' });
                row.push({ name: assetColumns[1], value: orderItem.assetNumber, type: 'text' });
                row.push({ name: assetColumns[2], value: orderItem.grade, type: 'text' });
                row.push({ name: assetColumns[3], value: orderItem.dataWipeStatus, type: 'text' });
                row.push({ name: assetColumns[4], value: orderItem.reportStatus, type: 'text' });
                row.push({ name: assetColumns[5], value: orderItem.listPrice, type: 'text' });
                row.push({ name: assetColumns[7], value: orderItem.invoiceAmount, type: 'text' });
                row.push({ name: assetColumns[6], value: orderItem.serviceCost, type: 'text' });
                newRows.push(row);
            });
        } else {
            orderItemQuotation.orderQuoteItems.map((orderItem) => {
                const row = [];
                row.push({ name: assetColumns[0], value: orderItem.item, type: 'text' });
                row.push({ name: assetColumns[1], value: orderItem.finalQty, type: 'text' });
                row.push({ name: assetColumns[2], value: orderItem.unit, type: 'text' });
                row.push({ name: assetColumns[3], value: orderItem.pricePerUnit, type: 'text' });
                row.push({ name: assetColumns[4], value: orderItem.totalPrice, type: 'text' });
                newRows.push(row);
            });
        }
        return newRows;
    };

    const getColumns = () => (orderType === '1' ? assetColumns : recycleAssetColumns);

    useEffect(() => {
        if (!isEmpty(orderItemQuotation)) {
            const tempAssetRows = getOrderItemQuoteDetails();
            calculateTotalAmount(orderItemQuotation.orderQuoteItems, 'invoiceAmount', 'serviceCost');
            setAssetRows(tempAssetRows);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [orderItemQuotation]);

    useEffect(() => {
        if (!isEmpty(orderInfo)) {
            const { orderId, acceptedOrderQuote } = orderInfo;
            if (orderId && acceptedOrderQuote) {
                startGetItemQuote(orderInfo?.orderId, orderInfo?.acceptedOrderQuote?.quoteId, orderType);
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [orderInfo]);

    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <AccountTable columns={getColumns()} edit={false} text="Asset List" rows={assetRows} />
            {
                orderType === '1' &&
                <>
                    <Bar
                        startContent={
                            <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                                Total value to be Invoiced (exclude tax)
                            </Label>
                        }
                        endContent={
                            <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                                {totalRow && totalRow.invoiceAmount} INR
                            </Label>
                        }
                        style={{ background: '#f2f2f2' }}
                    />
                    <Bar
                        startContent={
                            <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>Total service costs (exclude tax) </Label>
                        }
                        endContent={
                            <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                                {totalRow && totalRow.serviceCost} INR
                            </Label>
                        }
                        style={{ background: '#f2f2f2' }}
                    />
                </>
            }

        </div>
    );
};

const mapStateToProps = (state) => ({
    orderItemQuotation: getOrderItemQuotationState(state),
    orderInfo: getOrderInfoState(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetItemQuote: (orderId, quoteId, orderType) => dispatch(getOrderItemLevelQuote(orderId, quoteId, orderType))
});

ApproveFinalQuote.propTypes = {
    startGetItemQuote: PropTypes.func.isRequired,
    orderItemQuotation: PropTypes.object,
    orderType: PropTypes.string,
    orderInfo: PropTypes.object
};

export default connect(mapStateToProps, mapDispatchToProps)(ApproveFinalQuote);
