import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import { getAccessToken } from '../../store/action/taskAction';
import LoadingIndicator from '../common/Loading';
import ErrorComponent from '../common/Error';
import { getUserInfoState, isLoadingState } from '../../selectors/common';

const LoginSuccess = ({ userInfo, isLoading, startGetAccessToken }) => {
    useEffect(() => {
        startGetAccessToken();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    if (isLoading) {
        return <LoadingIndicator />;
    }
    return userInfo.isLoggedIn ? <Redirect to="/" /> : <ErrorComponent text="Login Failed" redirect />;
};

const mapStateToProps = (state) => ({
    isLoading: isLoadingState(state),
    userInfo: getUserInfoState(state)
});

const mapDispatchToProps = (dispatch) => ({
    startGetAccessToken: () => dispatch(getAccessToken())
});

LoginSuccess.propTypes = {
    userInfo: PropTypes.object,
    isLoading: PropTypes.bool,
    startGetAccessToken: PropTypes.func.isRequired
};

LoginSuccess.defaultProps = {
    isLoading: true
};

export default connect(mapStateToProps, mapDispatchToProps)(LoginSuccess);
