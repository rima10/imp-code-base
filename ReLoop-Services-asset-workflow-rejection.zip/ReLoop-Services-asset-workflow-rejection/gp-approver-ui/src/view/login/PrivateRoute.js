import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Route } from 'react-router-dom';
import CognitoRedirect from './CognitoRedirect';
import { validateUser } from '../../store/action/taskAction';
import LoadingIndicator from '../common/Loading';
import { getUserInfoState, isLoadingState } from '../../selectors/common';

const PrivateRoute = ({ component: Component, path, isLoading, startValidateUser, userInfo = {}, ...rest }) => {
    useEffect(() => {
        startValidateUser();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const redirect = <CognitoRedirect />;
    const routeComponent = (props) => {
        if (isLoading) return <LoadingIndicator />;
        return userInfo.isLoggedIn ? <Component {...props} userInfo={userInfo} /> : redirect;
    };
    return <Route path={path} {...rest} render={(props) => routeComponent(props)} />;
};

const mapStateToProps = (state) => ({
    isLoading: isLoadingState(state),
    userInfo: getUserInfoState(state)
});

const mapDispatchToProps = (dispatch) => ({
    startValidateUser: () => dispatch(validateUser())
});

PrivateRoute.propTypes = {
    component: PropTypes.elementType,
    path: PropTypes.string,
    startValidateUser: PropTypes.func.isRequired,
    isLoading: PropTypes.bool,
    userInfo: PropTypes.object
};

export default connect(mapStateToProps, mapDispatchToProps)(PrivateRoute);
