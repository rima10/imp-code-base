import React, { useEffect } from 'react';

const { REACT_APP_USERPOOLBASEURI, REACT_APP_CLIENTID, REACT_APP_CALLBACKURI } = process.env;
const COGNITO_REDIRECT = `${REACT_APP_USERPOOLBASEURI}/login?
client_id=${REACT_APP_CLIENTID}&response_type=code&scope=phone+email+openid&redirect_uri=${REACT_APP_CALLBACKURI}`;

const CognitoRedirect = () => {
    useEffect(() => {
        window.location.href = `${COGNITO_REDIRECT}`;
    }, []);

    return <></>;
};

export default CognitoRedirect;
