import React from 'react';
import { Grid, FlexBox, Link } from '@ui5/webcomponents-react';

const infos = [
    {
        label: 'Copyright',
        href: 'https://facebook.com'
    },
    {
        label: 'Privacy',
        href: 'https://facebook.com'
    },
    {
        label: 'Legal Disclosure',
        href: 'https://facebook.com'
    }
];

export default function Footer() {
    return (
        <Grid item xs={12} md={6} lg={4}>
            <FlexBox display="flex" justifyContent="center">
                <div>
                    {infos.map((info) => (
                        <Link key={info.href} href={info.href}>
                            {info.label}
                        </Link>
                    ))}
                </div>
            </FlexBox>
        </Grid>
    );
}
