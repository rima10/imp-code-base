import React from 'react';
import PropTypes from 'prop-types';
import { Route, Switch, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import PrivateRoute from './login/PrivateRoute';
import LoginSuccess from './login/loginSuccess';
import Header from './header/Header';
import ErrorComponent from './common/Error';
import MessageBar from './common/MessageBar';
import OrderFCL from './order/OrderFCL';
import { getToastState, getUserInfoState } from '../selectors/common';

const Main = ({ userInfo, toast }) => (
    <div>
        <Header userName={userInfo.approverName} />
        <div>
            {toast.show && <MessageBar message={toast.message} type={toast.status} />}
            <Switch>
                <Route path="/loginSuccessful">
                    <LoginSuccess />
                </Route>
                <PrivateRoute exact path="/" component={OrderFCL} />
                <PrivateRoute exact path="/404" component={() => <ErrorComponent text="Page Not Found" />} />
                <Redirect from="/" to="/404" />
            </Switch>
        </div>
    </div>
);

const mapStateToProps = (state) => ({
    toast: getToastState(state),
    userInfo: getUserInfoState(state)
});

Main.propTypes = {
    toast: PropTypes.object,
    userInfo: PropTypes.object
};

export default connect(mapStateToProps)(Main);
