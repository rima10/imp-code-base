import { createStore, applyMiddleware, combineReducers } from 'redux';
import thunk from 'redux-thunk';
import { composeWithDevTools } from 'redux-devtools-extension';
import promise from 'redux-promise-middleware';
import userInfo from './reducer/loginReducer';
import notification from './reducer/notificationReducer';
import isLoading from './reducer/loadingReducer';
import toast from './reducer/messageReducer';
import orderList from './reducer/orderListReducer';
import orderInfo from './reducer/orderInfoReducer';
import orderQuote from './reducer/orderQuoteReducer';
import orderItemQuote from './reducer/orderItemQuoteReducer';

const reducers = {
    userInfo,
    notification,
    isLoading,
    toast,
    orderList,
    orderInfo,
    orderQuote,
    orderItemQuote
};

const rootReducer = combineReducers(reducers);

export const store = createStore(rootReducer, composeWithDevTools(applyMiddleware(...[thunk, promise])));
