export const SET_USER_INFO = 'SET_USER_INFO';
export const setUserInfo = (userInfo, isLoggedIn, csrf) => ({
    type: SET_USER_INFO,
    payload: { userInfo, isLoggedIn, csrf }
});

export const SET_LOAD_IN_PROGRESS = 'SET_LOAD_IN_PROGRESS';
export const loadInProgress = () => ({
    type: SET_LOAD_IN_PROGRESS
});

export const SET_LOAD_COMPLETED = 'SET_LOAD_COMPLETED';
export const loadCompleted = () => ({
    type: SET_LOAD_COMPLETED
});

export const SET_CSRF = 'SET_CSRF';
export const setCsrf = (csrf) => ({
    type: SET_CSRF,
    payload: csrf
});

// Action Type to show message toast
export const SHOW_MSG_TOASTER = 'SHOW_MSG_TOASTER';

// Action Type to hide message toast
export const HIDE_MSG_TOASTER = 'HIDE_MSG_TOASTER';

// Action Type to fetch list of orders
export const FETCH_ORDER_LIST = 'FETCH_ORDER_LIST';

// Action Type to fetch order info
export const FETCH_ORDER_INFO = 'FETCH_ORDER_INFO';

// Action Type to approve request
export const APPROVE_REQUEST = 'APPROVE_REQUEST';

// Action Type to reject request
export const REJECT_REQUEST = 'REJECT_REQUEST';

// Action Type to reject quote
export const REJECT_QUOTE = 'REJECT_QUOTE';

// Action Type to accept quote
export const TEMPORARY_ACCEPT_QUOTE = 'TEMPORARY_ACCEPT_QUOTE';

// Action Type to fetch notifications
export const FETCH_NOTIFICATIONS = 'FETCH_NOTIFICATIONS';

// Action Type to read a notification
export const READ_NOTIFICATION = 'READ_NOTIFICATION';

// Action Type to fetch order quotation
export const FETCH_ORDER_QUOTATION = 'FETCH_ORDER_QUOTATION';

// Action Type to fetch item level quote for recycle order
export const FETCH_RECYCYLE_ITEM_LEVEL_QUOTE = 'FETCH_RECYCYLE_ITEM_LEVEL_QUOTE';

// Action Type to fetch item level quote for refurbish order
export const FETCH_REFURBISH_ITEM_LEVEL_QUOTE = 'FETCH_REFURBISH_ITEM_LEVEL_QUOTE';
