import { ActionType } from 'redux-promise-middleware';
import { FETCH_ORDER_LIST, APPROVE_REQUEST, REJECT_REQUEST } from '../actionType';

const initialState = {
    isLoading: false,
    errMsg: null,
    data: []
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_ORDER_LIST}_${ActionType.Pending}`:
        case `${APPROVE_REQUEST}_${ActionType.Pending}`:
        case `${REJECT_REQUEST}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${FETCH_ORDER_LIST}_${ActionType.Fulfilled}`:
        case `${APPROVE_REQUEST}_${ActionType.Fulfilled}`:
        case `${REJECT_REQUEST}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: payload.data };

        case `${FETCH_ORDER_LIST}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: [] };

        default:
            return state;
    }
};
