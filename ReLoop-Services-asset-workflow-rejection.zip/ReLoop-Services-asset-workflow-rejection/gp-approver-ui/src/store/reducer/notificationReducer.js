import { ActionType } from 'redux-promise-middleware';
import { FETCH_NOTIFICATIONS, READ_NOTIFICATION } from '../actionType';

const initialState = {
    isLoading: false,
    errMsg: null,
    data: []
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_NOTIFICATIONS}_${ActionType.Pending}`:
        case `${READ_NOTIFICATION}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${FETCH_NOTIFICATIONS}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: payload.data };

        case `${FETCH_NOTIFICATIONS}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: [] };

        default:
            return state;
    }
};
