import { ActionType } from 'redux-promise-middleware';
import { FETCH_RECYCYLE_ITEM_LEVEL_QUOTE, FETCH_REFURBISH_ITEM_LEVEL_QUOTE } from '../actionType';

const initialState = {
    isLoading: false,
    errMsg: null,
    data: {}
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_RECYCYLE_ITEM_LEVEL_QUOTE}_${ActionType.Pending}`:
        case `${FETCH_REFURBISH_ITEM_LEVEL_QUOTE}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${FETCH_RECYCYLE_ITEM_LEVEL_QUOTE}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: payload.data };

        case `${FETCH_REFURBISH_ITEM_LEVEL_QUOTE}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: { orderQuoteItems: payload.data } };

        case `${FETCH_RECYCYLE_ITEM_LEVEL_QUOTE}_${ActionType.Rejected}`:
        case `${FETCH_REFURBISH_ITEM_LEVEL_QUOTE}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: {} };

        default:
            return state;
    }
};
