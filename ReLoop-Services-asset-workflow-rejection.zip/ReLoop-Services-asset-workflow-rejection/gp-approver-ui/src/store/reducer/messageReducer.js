import { ActionType } from 'redux-promise-middleware';
import {
    SHOW_MSG_TOASTER,
    HIDE_MSG_TOASTER,
    FETCH_ORDER_LIST,
    FETCH_ORDER_INFO,
    APPROVE_REQUEST,
    REJECT_REQUEST,
    TEMPORARY_ACCEPT_QUOTE,
    REJECT_QUOTE,
    FETCH_NOTIFICATIONS,
    READ_NOTIFICATION,
    FETCH_ORDER_QUOTATION,
    FETCH_RECYCYLE_ITEM_LEVEL_QUOTE,
    FETCH_REFURBISH_ITEM_LEVEL_QUOTE
} from '../actionType';
import StatusColor from '../../asset/constants/statusColor';

const initialState = {
    show: false,
    status: StatusColor.Information,
    message: ''
};

const messageToaster = (state = initialState, action) => {
    const { type, payload } = action;

    switch (type) {
        case SHOW_MSG_TOASTER: {
            return {
                ...state,
                message: payload.message,
                status: payload.status,
                show: true
            };
        }

        case HIDE_MSG_TOASTER: {
            return {
                ...initialState
            };
        }

        case `${FETCH_ORDER_LIST}_${ActionType.Rejected}`:
        case `${FETCH_ORDER_INFO}_${ActionType.Rejected}`:
        case `${APPROVE_REQUEST}_${ActionType.Rejected}`:
        case `${REJECT_REQUEST}_${ActionType.Rejected}`:
        case `${TEMPORARY_ACCEPT_QUOTE}_${ActionType.Rejected}`:
        case `${REJECT_QUOTE}_${ActionType.Rejected}`:
        case `${FETCH_NOTIFICATIONS}_${ActionType.Rejected}`:
        case `${READ_NOTIFICATION}_${ActionType.Rejected}`:
        case `${FETCH_ORDER_QUOTATION}_${ActionType.Rejected}`:
        case `${FETCH_RECYCYLE_ITEM_LEVEL_QUOTE}_${ActionType.Rejected}`:
        case `${FETCH_REFURBISH_ITEM_LEVEL_QUOTE}_${ActionType.Rejected}`: {
            return {
                ...state,
                // optional chaining checks
                message: payload?.response?.data?.error?.message ?? 'Something went wrong',
                status: StatusColor.Negative,
                show: true
            };
        }

        default: {
            return state;
        }
    }
};

export default messageToaster;
