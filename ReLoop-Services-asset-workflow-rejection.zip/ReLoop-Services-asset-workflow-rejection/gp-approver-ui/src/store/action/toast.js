import { SHOW_MSG_TOASTER, HIDE_MSG_TOASTER } from '../actionType';
import StatusColor from '../../asset/constants/statusColor';

export const showMessage = (messagePayload) => ({
    type: SHOW_MSG_TOASTER,
    payload: messagePayload
});

export const showErrorMessage = (message) => ({
    type: SHOW_MSG_TOASTER,
    payload: {
        message: message || 'Something went wrong!',
        status: StatusColor.Negative
    }
});

export const hideToast = () => ({
    type: HIDE_MSG_TOASTER
});
