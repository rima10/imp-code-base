import { FETCH_NOTIFICATIONS, READ_NOTIFICATION } from '../actionType';
import http from '../../utils/httpService';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

export const getNotifications = () => async (dispatch) => {
    dispatch({
        type: FETCH_NOTIFICATIONS,
        payload: http.get(`${API_BASE_URL}notification/getApproverNotifications?$skip=0&top=5`, {
            withCredentials: true
        })
    });
};

export const readNotification = (bpNotificationId) => async (dispatch) => {
    await dispatch({
        type: READ_NOTIFICATION,
        payload: http.post(
            `${API_BASE_URL}notification/readNotification/${bpNotificationId}`,
            {},
            {
                withCredentials: true
            }
        )
    });
    dispatch(getNotifications());
};
