const Information = 'Information';
const Positive = 'Positive';
const Negative = 'Negative';
const Warning = 'Warning';
const Success = 'Success';
const Error = 'Error';
const None = 'None';

export default {
    Information,
    Positive,
    Negative,
    Warning,
    Success,
    Error,
    None
};
