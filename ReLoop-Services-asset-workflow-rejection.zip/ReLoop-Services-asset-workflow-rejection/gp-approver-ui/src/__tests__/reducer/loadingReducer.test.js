import isLoading from '../../store/reducer/loadingReducer';

const getInitialState = () => ({ state: true });

describe('Loading Reducer', () => {
    it('returns the initial state', () => {
        const fakeAction = {
            type: undefined
        };
        const originalState = getInitialState();
        const expected = { state: true };
        expect(isLoading(originalState, fakeAction)).toEqual(expected);
    });

    it('sets Loading to true when SET_LOAD_IN_PROGRESS action is received', () => {
        const fakeAction = {
            type: 'SET_LOAD_IN_PROGRESS'
        };
        const originalState = getInitialState();
        const expected = true;
        const actual = isLoading(originalState, fakeAction);
        expect(actual).toBe(expected);
    });

    it('sets Loading to false when SET_LOAD_COMPLETED action is received', () => {
        const fakeAction = {
            type: 'SET_LOAD_COMPLETED'
        };
        const originalState = getInitialState();
        const expected = false;
        const actual = isLoading(originalState, fakeAction);
        expect(actual).toBe(expected);
    });
});
