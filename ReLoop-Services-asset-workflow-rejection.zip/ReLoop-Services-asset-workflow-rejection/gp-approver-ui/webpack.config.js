const path = require('path');
const HWP = require('html-webpack-plugin');
const webpack = require('webpack');
const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
const dotenv = require('dotenv').config({ path: __dirname + '/.env' });

module.exports = {
    mode: 'development',
    entry: path.join(__dirname, '/src/index.js'),
    devtool: 'inline-source-map',
    output: {
        filename: 'build.js',
        path: path.join(__dirname, '/dist')
    },
    devServer: {
        historyApiFallback: true,
        hot: true,
        headers: {
            'X-Frame-Options': 'SAMEORIGIN'
        }
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: ['babel-loader', 'eslint-loader']
            },
            {
                test: /\.js|\.jsx$/,
                include: [path.resolve(__dirname, 'node_modules/react-jss/src')],
                exclude: /(node_modules|bower_components)/,

                use: ['babel-loader', 'eslint-loader']
            },
            {
                test: /\.css$/,
                use: ['style-loader', 'css-loader']
            },
            {
                test: /\.(ico|svg|jpg|gif|png)$/,
                use: ['file-loader']
            }
        ]
    },
    plugins: [
        new webpack.DefinePlugin({
            'process.env': JSON.stringify(process.env)
        }),
        new HWP({
            favicon: 'public/favicon.ico',
            template: path.join(__dirname, '/src/index.html')
        }),
        new BundleAnalyzerPlugin({
            analyzerPort: 9002
        })
    ]
};
