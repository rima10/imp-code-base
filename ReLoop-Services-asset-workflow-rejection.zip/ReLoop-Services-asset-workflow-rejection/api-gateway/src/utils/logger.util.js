const winston = require('winston');
const morgan = require('morgan');
const dotenv = require('dotenv');
const CloudWatchTransport = require('winston-aws-cloudwatch');

dotenv.config();

const winstonTransports = [];
if (process.env.NODE_ENV === 'development') {
  winstonTransports.push(new winston.transports.File({
    filename: 'logs/app.log',
  }));
  winstonTransports.push(new winston.transports.Console());
} else {
  const awsCouldWatchInstance = new CloudWatchTransport({
    logGroupName: process.env.CW_LOG_GROUP,
    logStreamName: process.env.CW_LOG_STREAM,
    createLogGroup: true,
    createLogStream: true,
    submissionInterval: 2000,
    submissionRetryCount: 1,
    batchSize: 20,
    awsConfig: {
      accessKeyId: process.env.CW_ACCESS_KEY_ID,
      secretAccessKey: process.env.CW_SECRET_ACCESS_KEY,
      region: process.env.CW_REGION,
    },
    formatLog(item) {
      return JSON.stringify({ level: item.level, message: item.message, ...item.meta });
    },
  });
  winstonTransports.push(awsCouldWatchInstance);
}

// instantiate a new Winston Logger
const logger = winston.createLogger({
  transports: winstonTransports,
  exitOnError: false, // do not exit on handled exceptions
  format: winston.format.combine(
    winston.format.errors({ stack: true }), // <-- use errors format
    winston.format.timestamp(),
    winston.format.prettyPrint(),
  ),
});

// create a stream object with a 'write' function that will be used by `morgan`
logger.stream = {
  write(message) {
    logger.info(message);
  },
};

const morganLogger = morgan((tokens, req, res) => [
  `Request Id: ${req.id}`,
  `ip: ${req.socket.remoteAddress}`,
  req.protocol,
  tokens.method(req, res),
  tokens.url(req, res),
  `User Id: ${req.userInfo ? req.userInfo['cognito:username'] : ''}`,
  tokens.status(req, res),
  tokens.res(req, res, 'content-length'), '-',
  tokens['response-time'](req, res), 'ms',
].join(' '), { stream: logger.stream });

module.exports = morganLogger;
