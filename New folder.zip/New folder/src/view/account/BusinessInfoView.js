import React, { useEffect, useState } from 'react';
import { connect } from "react-redux";
import { Grid, Label, Title, Button, BusyIndicator } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import bg from '../../asset/images/background-image.png';
import { spacing } from "@ui5/webcomponents-react-base";
import "@ui5/webcomponents/dist/features/InputElementsFormSupport.js";
import { getBusinessInfo } from '../../store/action/taskAction';

const BusinessInfoView = ({ startGetBusinessInfo, businessInfo = {}, onEditClick }) => {
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        startGetBusinessInfo();
    }, []);
    useEffect(() => {
        if (businessInfo && businessInfo.industryType && businessInfo.industryType.length) {
            setLoading(false);
        }
    }, [businessInfo.industryType]);

    const { industryType, gstNumber, cin, pan, bpPhoneNumber, companyCode, location = {} } = businessInfo;
    return (
        <BusyIndicator active={loading} size="Medium" >
            <div style={{ display: 'flex', flexDirection: 'column' }}>
                <div style={{ backgroundImage: `url(${bg})`, width: "100%", height: "270px", textAlign: "center" }}>
                    <Title style={{
                        fontSize: "x-large",
                        textAlign: "center",
                        marginTop: "80px",
                        color: "#000000"
                    }}><b> Business Information </b></Title>
                    <Label wrap style={{
                        fontSize: "x-large",
                        textAlign: "center",
                        marginTop: "20px",
                        color: "#000000"
                    }}> Please add all the additional data needed to complete your Business Profile</Label>
                </div>

                <div style={spacing.sapUiLargeMarginBegin}>

                    <Grid defaultSpan="XL1 L1 M1 S1">

                        <div >
                            <Label className="formLabel">Industry Type </Label>
                            <Label className="formLabel">GSTIN</Label>
                            <Label className="formLabel">CIN Number</Label>
                            <Label className="formLabel">PAN</Label>
                            <Label className="formLabel">Phone Number</Label>


                        </div>
                        <div >
                            <Label className="formLabel">:</Label>
                            <Label className="formLabel">:</Label>
                            <Label className="formLabel">:</Label>
                            <Label className="formLabel">:</Label>
                            <Label className="formLabel">:</Label>


                        </div>

                        <div style={{ width: "380px" }} >
                            <Label className="formLabel txtColor" > {industryType} </Label>
                            <Label className="formLabel txtColor" > {gstNumber} </Label>
                            <Label className="formLabel txtColor" > {cin} </Label>
                            <Label className="formLabel txtColor" > {pan} </Label>
                            <Label className="formLabel txtColor" > {bpPhoneNumber} </Label>


                        </div>
                        <div >
                            <Label className="formLabel">State</Label>
                            <Label className="formLabel">City</Label>
                            <Label className="formLabel">Pincode</Label>
                            <Label className="formLabel">Company Code</Label>
                            <Label className="formLabel">Address</Label>
                        </div>
                        <div >
                            <Label className="formLabel">:</Label>
                            <Label className="formLabel">:</Label>
                            <Label className="formLabel">:</Label>
                            <Label className="formLabel">:</Label>
                            <Label className="formLabel">:</Label>


                        </div>
                        <div style={{ width: "250px" }} >
                            <Label className="formLabel txtColor" >  {location.state}</Label>
                            <Label className="formLabel txtColor" > {location.city} </Label>
                            <Label className="formLabel txtColor" > {location.pincode} </Label>
                            <Label className="formLabel txtColor" >  {companyCode}</Label>
                            <Label className="formLabel txtColor" wrap> {location.locDetails} </Label>
                        </div>

                    </Grid>
                    <Button design="Emphasized" style={{
                        marginRight: "15rem",
                        marginTop: "1rem",
                        float: "right"
                    }} onClick={onEditClick}>Edit</Button>

                </div>
            </div>
        </BusyIndicator>
    );
};

const mapStateToProps = state => {
    return {
        businessInfo: state.account.businessInfo
    };
};

const mapDispatchToProps = dispatch => {
    return {
        startGetBusinessInfo: () => dispatch(getBusinessInfo())
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(BusinessInfoView);
