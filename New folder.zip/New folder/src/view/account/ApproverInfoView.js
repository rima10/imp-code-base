import React, { useState, useEffect, useRef } from 'react';
import { connect } from 'react-redux';
import { Label, Title, Toast } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport.js';
import bg from '../../asset/images/background-image.png';
import AccountTable from '../common/Table';
import { EMAIL_REGEX } from '../../asset/constants/constant';
import { getApproverInfoState, isApproverInfoLoading } from '../../selectors/common';
import {
    getApproverInfo,
    registerBPApproverInfo,
    deleteBPApproverInfo
} from '../../store/action/taskAction';

const ApproverInfoView = ({
    startGetApproverInfo,
    startRegisterBPApproverInfo,
    approverInfo = [],
    isLoading,
    startDeleteBPApproverInfo
}) => {
    const [rows, setRows] = useState([]);
    const toast = useRef();
    const [errorMessage, setErrorMessage] = useState('');
    const [selectedRow, setSelectedRow] = useState([]);
    const [newApprovers, setNewApprovers] = useState({});
    const stateRef = useRef();
    stateRef.current = selectedRow;
    const newAppRef = useRef({});
    newAppRef.current = newApprovers;

    const isRowSelected = (event, rowNumber) => {
        event.preventDefault();
        let row = stateRef.current;
        const index = row.indexOf(rowNumber);
        if (index > -1) {
            row.splice(index, 1);
        } else {
            row.push(rowNumber);
        }
        setSelectedRow(row);
    };
    const getRowsFromApproverInfo = (approverInfo) => {
        const newRows = [];
        if (Object.keys(approverInfo).length !== 0) {
            approverInfo.map((approver) => {
                const row = [
                    {
                        type: 'checkbox',
                        onInputChange: isRowSelected,
                        disabled: false
                    }
                ];
                const keys = Object.keys(approver);
                keys.map((key) => {
                    if (['approver_email_id', 'approver_name', 'approver_role'].includes(key)) {
                        row.push({
                            name: key,
                            value: approver[key],
                            type: 'text'
                        });
                    }
                });
                newRows.push(row);
            });
        }
        return newRows;
    };

    const updateApproverList = (approverInfo) => {
        const newRows = getRowsFromApproverInfo(approverInfo);
        setRows(newRows);
    };

    useEffect(() => {
        startGetApproverInfo();
    }, []);

    useEffect(() => {
        updateApproverList(approverInfo);
    }, [approverInfo.length]);

    const saveApproverInfo = async (event) => {
        event.preventDefault();
        const payload = { approvers: [] };
        const approvers = newAppRef.current;
        for (const key in approvers) {
            const approver = approvers[key];
            if (!EMAIL_REGEX.test(approver.email)) {
                setErrorMessage("Please enter valid Email Address");
                toast.current.show();
                return;
            }
            payload.approvers.push({
                approverEmailId: approver.email,
                approverName: approver.name,
                approverRole: approver.role
            });
        }
        startRegisterBPApproverInfo(payload);
        setNewApprovers({});
    };

    const inputChange = (event) => {
        const { slot } = event.currentTarget.parentElement.parentElement;
        const { name, value } = event.target;
        const { current } = newAppRef;
        const approvers = { ...current };
        if (approvers[slot]) approvers[slot][name] = value;
        else {
            approvers[slot] = {};
            approvers[slot][name] = value;
        }
        setNewApprovers(approvers);
    };


    const onAddRowClick = () => {
        const row = [];
        row.push({
            type: 'checkbox',
            onInputChange: isRowSelected,
            disabled: true
        });
        row.push({ name: 'email', value: 'email', type: 'input', valueState: 'None', onInputChange: inputChange });
        row.push({ name: 'name', value: 'name', type: 'input', valueState: 'None', onInputChange: inputChange });
        row.push({ name: 'role', value: 'role', type: 'input', valueState: 'None', onInputChange: inputChange });
        const existingRows = [...rows];
        existingRows.push(row);
        setRows(existingRows);
    };

    const onCancel = async (event) => {
        event.preventDefault();
        const newRows = getRowsFromApproverInfo(approverInfo);
        setRows(newRows);
    };

    const onDeleteClick = async (event) => {
        event.preventDefault();
        const rowsToDelete = stateRef.current;
        const payload = { approvers: [] };
        rowsToDelete.map((row) => {
            payload.approvers.push({
                approverId: approverInfo[row].approver_id
            });
        });
        startDeleteBPApproverInfo(payload);
        setSelectedRow([]);
    };

    const buttons = [
        {
            name: 'Save',
            icon: 'save',
            onClick: saveApproverInfo
        },
        {
            name: 'Cancel',
            icon: 'decline',
            onClick: onCancel
        },
        {
            name: 'Add',
            icon: 'add',
            onClick: onAddRowClick
        },
        {
            name: 'Delete',
            icon: 'delete',
            onClick: onDeleteClick
        }
    ];

    const columns = ['', 'Approver Email ID', 'Approver Name', 'Approver Role'];

    return (
        <div style={{ display: "flex", flexDirection: "column" }}>
            <div style={{ backgroundImage: `url(${bg})`, width: "100%", height: "270px", textAlign: "center" }}>
                <Title style={{
                    fontSize: "x-large",
                    textAlign: "center",
                    marginTop: "80px",
                    color: "#000000"
                }}><b> Approver Information</b></Title>
                <Label wrap style={{
                    fontSize: "x-large",
                    textAlign: "center",
                    marginTop: "20px",
                    color: "#000000"
                }}> In case you want to create an Approval Workflow please add data about your approver team
                </Label>

            </div>

            <AccountTable
                selectedRow={selectedRow}
                isLoading={isLoading}
                buttons={buttons}
                columns={columns}
                rows={rows}
                edit={false}
            />
            <Toast ref={toast}>{errorMessage}</Toast>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        approverInfo: getApproverInfoState(state),
        isLoading: isApproverInfoLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetApproverInfo: async () => dispatch(getApproverInfo()),
        startRegisterBPApproverInfo: (payload) => dispatch(registerBPApproverInfo(payload)),
        startDeleteBPApproverInfo: (payload) => dispatch(deleteBPApproverInfo(payload))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(ApproverInfoView);
