import React, { useEffect, useState, useRef } from 'react';
import { connect } from 'react-redux';
import { Label, Title, Toast } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from '@ui5/webcomponents-react-base';
import bg from '../../asset/images/background-image.png';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport.js';
import AccountTable from '../common/Table';
import { EMAIL_REGEX } from '../../asset/constants/constant';
import {
    getNetworkInfo,
    registerBPNetworkInfo,
    deleteBPNetworkInfo
} from '../../store/action/taskAction';
import {
    getNetworkInfoState,
    isApproverInfoLoading
} from '../../selectors/common';

const NetworkInfoView = ({
    startGetNetworkInfo,
    startRegisterBPNetworkInfo,
    networkInfo = [],
    isLoading,
    startDeleteBPNetworkInfo
}) => {
    const [rows, setRows] = useState([]);
    const [selectedRow, setSelectedRow] = useState([]);
    const [newNetworks, setNewNetworks] = useState({});
    const [errorMessage, setErrorMessage] = useState("");
    const toast = useRef();
    const stateRef = useRef();
    stateRef.current = selectedRow;
    const newNetRef = useRef({});
    newNetRef.current = newNetworks;

    const isRowSelected = async (event, rowNumber) => {
        event.preventDefault();
        let row = stateRef.current;
        const index = row.indexOf(rowNumber);
        if (index > -1) {
            row.splice(index, 1);
        } else {
            row.push(rowNumber);
        }
        setSelectedRow(row);
    };
    const getRowsFromNetworkInfo = (networkInfo) => {
        const newRows = [];
        // can be simply networkInfo.length
        if (Object.keys(networkInfo).length !== 0) {
            networkInfo.map((network) => {
                const row = [
                    {
                        type: 'checkbox',
                        onInputChange: isRowSelected,
                        disabled: false
                    }
                ];
                const keys = Object.keys(network.rcy);
                keys.map((key) => {
                    if (['bp_email_id', 'bp_phone_number', 'bp_username'].includes(key)) {
                        row.push({
                            name: key,
                            value: network.rcy[key],
                            type: 'text'
                        });
                    }
                });
                newRows.push(row);
            });
        }
        return newRows;
    };

    const updateNetworkList = (networkInfo) => {
        const newRows = getRowsFromNetworkInfo(networkInfo);
        setRows(newRows);
    };

    useEffect(() => {
        startGetNetworkInfo();
    }, []);

    useEffect(() => {
        updateNetworkList(networkInfo);
    }, [networkInfo.length]);

    const saveNetworkInfo = async (event) => {
        event.preventDefault();
        const payload = { pvtRecyclers: [] };
        const networks = newNetRef.current;
        for (const key in networks) {
            const network = networks[key];
            if (!EMAIL_REGEX.test(network.email)) {
                setErrorMessage("Please enter valid Email Address");
                toast.current.show();
                return;
            }
            payload.pvtRecyclers.push({
                emailId: network.email,
                username: network.name,
                phoneNumber: network.number
            });
        }
        startRegisterBPNetworkInfo(payload);
        setNewNetworks({});
    };

    const inputChange = (event) => {
        const { slot } = event.currentTarget.parentElement.parentElement;
        const { name, value } = event.target;
        const { current } = newNetRef;
        const networks = { ...current };
        if (networks[slot]) networks[slot][name] = value;
        else {
            networks[slot] = {};
            networks[slot][name] = value;
        }
        setNewNetworks(networks);
    };


    const onAddRowClick = () => {
        const row = [];
        row.push({
            type: 'checkbox',
            onInputChange: isRowSelected,
            disabled: true
        });
        row.push({ name: 'email', value: 'email', type: 'input', onInputChange: inputChange });
        row.push({ name: 'name', value: 'name', type: 'input', onInputChange: inputChange });
        row.push({ name: 'number', value: 'number', type: 'input', onInputChange: inputChange });
        const existingRows = [...rows];
        existingRows.push(row);
        setRows(existingRows);
    };

    const onCancel = async (event) => {
        event.preventDefault();
        const newRows = getRowsFromNetworkInfo(networkInfo);
        setRows(newRows);
    };

    const onDeleteClick = async (event) => {
        event.preventDefault();
        const rowsToDelete = stateRef.current;
        const payload = { pvtNetworks: [] };
        rowsToDelete.map((row) => {
            payload.pvtNetworks.push({
                recyclerId: networkInfo[row].rcy_id,
                networkId: networkInfo[row].bp_nwk_id
            });
        });
        startDeleteBPNetworkInfo(payload);
        setSelectedRow([]);
    };

    const buttons = [
        {
            name: 'Save',
            icon: 'save',
            onClick: saveNetworkInfo
        },
        {
            name: 'Cancel',
            icon: 'decline',
            onClick: onCancel
        },
        {
            name: 'Add',
            icon: 'add',
            onClick: onAddRowClick
        },
        {
            name: 'Delete',
            icon: 'delete',
            onClick: onDeleteClick
        }
    ];

    const columns = ['', 'Email ID', 'Name', 'Contact Number'];

    // if (isLoading) {
    //     return <LoadingIndicator />;
    // }
    return (
        <div style={{ display: 'flex', flexDirection: 'column', ...spacing.sapUiMediumMargin }}>

            <div style={{ backgroundImage: `url(${bg})`, width: "100%", height: "270px", textAlign: "center" }}>
                <Title style={{
                    fontSize: "x-large",
                    textAlign: "center",
                    marginTop: "80px",
                    color: "#000000"
                }}><b> Private Network</b></Title>
                <Label wrap style={{
                    fontSize: "x-large",
                    textAlign: "center",
                    marginTop: "20px",
                    color: "#000000"
                }}>For Refurbishing requests only: Set your Private Network adding all the
                 vendors you are currently working with</Label>

            </div>

            <AccountTable
                selectedRow={selectedRow}
                isLoading={isLoading}
                buttons={buttons}
                columns={columns}
                rows={rows}
                edit={false}
            />
            <Toast ref={toast}>{errorMessage}</Toast>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        networkInfo: getNetworkInfoState(state),
        isLoading: isApproverInfoLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetNetworkInfo: () => dispatch(getNetworkInfo()),
        startRegisterBPNetworkInfo: (payload) => dispatch(registerBPNetworkInfo(payload)),
        startDeleteBPNetworkInfo: (payload) => dispatch(deleteBPNetworkInfo(payload))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(NetworkInfoView);
