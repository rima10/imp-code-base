import React, { useEffect, useState, useRef } from 'react';
import { connect } from 'react-redux';
import { Button } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from '@ui5/webcomponents-react-base';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport.js';
import AccountTable from '../common/Table';
import {
    getWorkflowsInfo,
    registerBPWorkflowInfo,
    deleteBPWorkflowInfo,
    deleteBPWorkflowApproverInfo
} from '../../store/action/taskAction';
import { getApproverInfoState, isApproverInfoLoading } from '../../selectors/common';

const Workflow = ({
    processStageSequence,
    processStageName,
    processTypeId,
    approvers = [],
    approverInfo = [],
    workflowId,
    startRegisterBPWorkflowInfo,
    startGetWorkflowInfo,
    showTable,
    startDeleteBPWorkflowInfo,
    startDeleteBPWorkflowApproverInfo,
    isLoading
}) => {
    const [rows, setRows] = useState([]);
    const [table, setTable] = useState(showTable);
    const [selectedRow, setSelectedRow] = useState([]);
    const stateRef = useRef();
    stateRef.current = selectedRow;
    const [newApprovers, setNewApprovers] = useState({
        processStageSequence,
        processStageName,
        processTypeId,
        approvers: {}
    });
    const newAppRef = useRef({});
    newAppRef.current = newApprovers.approvers;

    const newRowRef = useRef({});
    newRowRef.current = rows;

    const isRowSelected = (event, rowNumber) => {
        event.preventDefault();
        let row = stateRef.current;
        const index = row.indexOf(rowNumber);
        if (index > -1) {
            row.splice(index, 1);
        } else {
            row.push(rowNumber);
        }
        setSelectedRow(row);
    };
    const getRowsFromApprovers = (approvers) => {
        const newRows = [];
        if (approvers.length !== 0) {
            approvers.map((app) => {
                const row = [
                    {
                        type: 'checkbox',
                        onInputChange: isRowSelected,
                        disabled: false
                    }
                ];
                const { approver } = app;
                row.push({
                    name: 'approver_sequence',
                    value: app.approver_sequence,
                    type: 'text'
                });
                row.push({
                    name: 'approver_role',
                    value: approver.approver_role,
                    type: 'text'
                });
                row.push({
                    name: 'approver_name',
                    value: approver.approver_name,
                    type: 'text'
                });
                newRows.push(row);
            });
        }
        return newRows;
    };

    useEffect(() => {
        startGetWorkflowInfo();
    }, []);

    useEffect(() => {
        const rows = getRowsFromApprovers(approvers);
        setRows(rows);
    }, [approvers.length]);

    const saveWorkflowInfo = async (event) => {
        event.preventDefault();
        const payload = { ...newApprovers };
        const approvers = newAppRef.current;
        const approversPayload = [];
        for (const key in approvers) {
            const approver = approvers[key];
            approversPayload.push(approver);
        }
        payload.approvers = approversPayload;
        startRegisterBPWorkflowInfo(payload);
        setNewApprovers({ processStageSequence,
            processStageName,
            processTypeId, approvers: [] });
    };

    const inputChange = (event) => {
        const { slot } = event.currentTarget.parentElement.parentElement;
        let name = '';
        let value = '';
        if (event.detail) {
            name = 'approverId';
            value = event.detail.selectedOption.attributes.id.value;
            const approverName = event.detail.selectedOption.attributes.name.value;
            const { current } = newRowRef;
            const updatedRows = [...current];
            updatedRows[Number(slot.substr(-1)) - 1][3].value = approverName;
            setRows(updatedRows);
        } else {
            name = event.target.name;
            value = event.target.value;
        }
        const { current } = newAppRef;
        const approvers = { ...current };
        if (approvers[slot]) approvers[slot][name] = value;
        else {
            approvers[slot] = {};
            approvers[slot][name] = value;
        }
        setNewApprovers({ ...newApprovers, approvers });
        name = "approverSequence";
        value = rows.length + 1;
        if (approvers[slot]) approvers[slot][name] = value;
        else {
            approvers[slot] = {};
            approvers[slot][name] = value;
        }
        setNewApprovers({ ...newApprovers, approvers });
    };


    const onAddRowClick = () => {
        const row = [];
        row.push({
            type: 'checkbox',
            onInputChange: isRowSelected,
            disabled: true
        });
        row.push({
            name: 'approverSequence',
            value: `${rows.length + 1}`,
            type: 'text'
        });
        row.push({
            name: 'role',
            value: 'name',
            type: 'select',
            options: approverInfo,
            onInputChange: inputChange
        });
        row.push({ name: 'name', value: '-', type: 'text' });
        const { current } = newRowRef;
        const existingRows = [...current];
        existingRows.push(row);
        setRows(existingRows);
    };

    const onCancel = async (event) => {
        event.preventDefault();
        const newRows = getRowsFromApprovers(approvers);
        setRows(newRows);
    };

    const onAddWorkflow = (stepId) => {
        setTable(true);
        // showTable = true
        onAddRowClick();
    };

    const onDeleteWorklow = (event) => {
        event.preventDefault();
        setTable(false);
        //showTable = false;
        const payload = workflowId;
        startDeleteBPWorkflowInfo(payload);
    };

    const onDeleteClick = async (event) => {
        event.preventDefault();
        const rowsToDelete = stateRef.current;
        const payload = { workflowApprovers: [] };
        rowsToDelete.map((row) => {
            payload.workflowApprovers.push({
                workflowApproverId: approvers[row].workflow_approver_id
            });
        });
        startDeleteBPWorkflowApproverInfo(payload);
        setSelectedRow([]);
    };

    const buttons = [
        {
            name: 'Save',
            icon: 'save',
            onClick: saveWorkflowInfo
        },
        {
            name: 'Cancel',
            icon: 'decline',
            onClick: onCancel
        },
        {
            name: 'Add',
            icon: 'add',
            onClick: onAddRowClick
        },
        {
            name: 'Delete',
            icon: 'delete',
            onClick: onDeleteClick
        }
    ];

    const columns = ['', 'Approver Sequence', 'Approver Role', 'Approver Name'];

    return (
        <div style={{ display: 'flex', ...spacing.sapUiMediumMargin }}>
            {/* Label is currently getting overlapped by Delete Button :( */}

            <>
                {showTable || table ? (
                    <>
                        <Button
                            design="Negative"
                            icon="delete"
                            style={{ position: 'absolute', right: '4.5%' }}
                            onClick={(e) => onDeleteWorklow(e)}
                        >
                            Delete Workflow
                        </Button>
                        <AccountTable
                            selectedRow={selectedRow}
                            isLoading={isLoading}
                            buttons={buttons}
                            columns={columns}
                            rows={rows}
                            edit={false}
                        />
                    </>
                ) : (
                    <Button
                        data-layout-span="XL3"
                        id="add_workflow"
                        onClick={() => onAddWorkflow()}
                        design="Emphasized"
                        style={{ position: 'absolute' }}
                        width="20%"
                    >
                        Add Workflow
                    </Button>
                )}
            </>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        approverInfo: getApproverInfoState(state),
        isLoading: isApproverInfoLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetWorkflowInfo: (payload) => dispatch(getWorkflowsInfo(payload)),
        startRegisterBPWorkflowInfo: (payload) => dispatch(registerBPWorkflowInfo(payload)),
        startDeleteBPWorkflowInfo: (payload) => dispatch(deleteBPWorkflowInfo(payload)),
        startDeleteBPWorkflowApproverInfo: (payload) =>
            dispatch(deleteBPWorkflowApproverInfo(payload))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(Workflow);
