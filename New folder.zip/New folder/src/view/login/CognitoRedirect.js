import React from 'react';
const COGNITO_REDIRECT = "https://reloop.auth.ap-south-1.amazoncognito.com/login?client_id=6rmm4etrdd625j9da87qkuvpn5&response_type=code&scope=aws.cognito.signin.user.admin+email+openid+phone&redirect_uri=http://localhost:3001/loginSuccessful";

class CognitoRedirect extends React.Component {
    componentDidMount () {
        window.location.href = `${COGNITO_REDIRECT}`;
    }

    render () {
        return (<></>);
    }
}

export default CognitoRedirect;
