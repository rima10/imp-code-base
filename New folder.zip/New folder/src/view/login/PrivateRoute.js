import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import CognitoRedirect from './CognitoRedirect';
import { validateUser } from '../../store/action/taskAction';
import { Route } from "react-router-dom";
import LoadingIndicator from '../common/Loading';

const PrivateRoute = ({ component: Component, path, isLoading, startValidateUser, userInfo = {}, ...rest }) => {
    useEffect(() => {
        startValidateUser();
    }, []);
    const redirect = <CognitoRedirect/>;
    const routeComponent = (props) => {
        if (isLoading) return <LoadingIndicator />;
        else {
            return (userInfo.isLoggedIn ? <Component {...props} userInfo={userInfo}/> : redirect);
        }
    };
    return <Route path={path} {...rest} render={props => routeComponent(props)}/>;
};

const mapStateToProps = state => {
    return {
        isLoading: state.isLoading,
        userInfo: state.userInfo
    };
};

const mapDispatchToProps = dispatch => {
    return {
        startValidateUser: () => dispatch(validateUser())
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(PrivateRoute);
