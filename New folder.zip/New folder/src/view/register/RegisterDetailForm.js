import React, { Component } from 'react';
//import { formatPhoneNumber, isValidEmail } from '../../../../utils';
import { Label, Input, Select, Option, Button, CheckBox, Card } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from "@ui5/webcomponents-react-base";
export class RegisterDetailForm extends Component {
    constructor (props) {
        super(props);
        this.state = {
            businessPartner: {

                businessName: '',
                telephone: '',
                network: '',
                email: '',
                password: '',
                acceptService: false

            },
            validForm: false,
            submitted: false
        };
    }
  submitForm = async (event) => {
      this.setState({ submitted: true });
      //this.props.dispatch(ActionCreators.formSubmittionStatus(true));
      //const businessPartner = this.state.businessPartner;
      event.preventDefault();
  }
  checkboxChange = (event) => {
      const { name, checked } = event.target;
      const businessPartner = this.state.businessPartner;
      businessPartner[name] = checked;
      this.setState({ businessPartner });
  }
  inputChange = (event) => {
      const { name, value } = event.target;
      const businessPartner = this.state.businessPartner;
      businessPartner[name] = value;
      this.setState({ businessPartner });
  }
  render () {
      const { businessName, telephone, network, acceptService } = this.state.businessPartner;
      //const { submitted } = this.state;
      return (
          <div style={{ display: 'flex', justifyContent: 'center' }}>
              <Card
                  style={{ width: "900px", height: "700px", ...spacing.sapUiContentPadding }}
                  heading ="Register"
              >

                  <div style={{ display: 'flex', justifyContent: 'center' }}>
                      <Label className="col-sm-2 col-form-label">Name</Label>
                      <div className="col-sm-3 mb-2">
                          <Input type="text" value={businessName} name="businessName" placeholder="Business Name" required onChange={(e) => { this.inputChange(e);}}/>

                      </div>
                      <div className="col-sm-4" />
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'center' }}>
                      <Label for="telephone" className="col-sm-2 col-form-label">Phone Number</Label>
                      <div className="col-sm-6 mb-2">
                          <Input type="text" pattern="[0-9]" maxLength="14" name="telephone" value={telephone} required placeholder="Phone Number" onChange={(e) => { this.inputChange(e);}}/>

                      </div>
                      <div className="col-sm-4" />
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'center' }}>
                      <Label for="network" className="col-sm-2 col-form-label">Network</Label>
                      <div className="col-sm-6 mb-2">
                          <Select className="custom-select" name="network" value={network} id="inlineFormCustomSelect" onChange={(e) => { this.inputChange(e);}}>
                              <Option>
    Public
                              </Option>
                              <Option>
    Private
                              </Option>
                              <Option>
   Hubrid
                              </Option>
                          </Select>
                      </div>
                      <div className="col-sm-4" />
                  </div>
                  <div className="row">
                      <div className="col-sm-2" />
                      <div className="col-sm-6 mb-2">
                          <CheckBox for="acceptService" checked={acceptService} name="acceptService" text="I agree to the terms and services" id="acceptService" style={{ margin: '10px' }} onChange={this.checkboxChange} />
                      </div>
                      <div className="col-sm-4" />
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'center' }}>
                      <div className="col-sm-5 mb-2" />
                      <div className="col-sm-4">
                          <Button design="Emphasized" onClick={this.submitForm}>Submit</Button>
                      </div>
                      <div className="col-sm-3" />
                  </div>

              </Card>
          </div>
      );
  }
}


export default RegisterDetailForm;
