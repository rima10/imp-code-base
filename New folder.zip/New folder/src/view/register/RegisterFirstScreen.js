import React from "react";
import { Button, FlexBox, Form, FormItem, Input, Text, FormGroup, Card } from '@ui5/webcomponents-react';
import { spacing } from "@ui5/webcomponents-react-base";
import signIn from "../../asset/images/sign.png";
import { useHistory } from "react-router-dom";
export function RegisterFirstScreen (props) {
    let history = useHistory();
    function handleClick () {
        history.push("/register");
    }
    return (
        <div style={{ display: 'flex', justifyContent: 'center' }}>
            <Card
                style={{ width: "900px", ...spacing.sapUiContentPadding }}
                heading="Register"
            >
                <FlexBox
                    alignItems="Start"
                    justifyContent="Center" >
                    <div style={spacing.sapUiLargeMarginTop}>
                        <Text style={{ fontWeight: 'bold', fontSize: 'large' }} >Let's start creating your Business account</Text>
                        <Form>
                            <FormGroup>
                                <FormItem label="Enter the work email you'd like to use for your account">
                                    <Input />
                                </FormItem>
                            </FormGroup>
                            <FormItem>
                                <Button design="Emphasized" onClick={handleClick}>Get Started</Button>
                            </FormItem>
                        </Form>
                    </div>
                    <div style={spacing.sapUiMediumMarginBegin}>
                        <img src={signIn} style={{ width: "450px", maxHeight: "100%" }} />
                    </div>
                </FlexBox>
            </Card>
        </div>
    );
}
