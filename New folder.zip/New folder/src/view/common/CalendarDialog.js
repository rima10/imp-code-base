import React, { useState } from 'react';
import PropTypes from 'prop-types';
import {
    Button,
    Dialog,
    FlexBox,
    Calendar,
    Label,
    Input,
    DurationPicker,
    Select,
    Option
} from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from '@ui5/webcomponents-react-base';

const CalendarDialog = React.forwardRef(({ onCancel, onSubmit, headerText, showEstHours }, ref) => {
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');
    const [hour, setHour] = useState('');

    const onDateSelect = (event) => {
        event.preventDefault();
        setDate(event.detail.values[0]);
    };

    const onTimeSelect = (event) => {
        event.preventDefault();
        setTime(event.detail.value);
    };

    const onEstimatedHoursSelect = (event) => {
        event.preventDefault();
        setHour(event.detail.selectedOption.textContent);
    };

    return (
        <Dialog
            ref={ref}
            footer={
                <div>
                    <Button style={spacing.sapUiTinyMargin} onClick={() => onSubmit(date, time, hour)}>
                        Submit
                    </Button>
                    <Button style={spacing.sapUiTinyMargin} onClick={onCancel}>
                        Close
                    </Button>
                </div>
            }
            headerText={headerText}
        >
            <FlexBox justifyContent="SpaceBetween">
                <Calendar
                    onSelectedDatesChange={onDateSelect}
                    primaryCalendarType="Gregorian"
                    selectionMode="Single"
                    format-pattern="yyyy-MM-dd"
                />
                <FlexBox style={spacing.sapUiSmallMargin} justifyContent="Center" direction="Column">
                    <Label style={spacing.sapUiSmallMarginTopBottom}>Date</Label>
                    <Input readonly placeholder="Date" value={date} />
                    <Label style={spacing.sapUiSmallMarginTopBottom}>Time</Label>
                    <DurationPicker onChange={onTimeSelect} />
                    {showEstHours && (
                        <>
                            <Label style={spacing.sapUiSmallMarginTopBottom}>Estimated Hours</Label>
                            <Select onChange={onEstimatedHoursSelect}>
                                <Option>1 hour</Option>
                                <Option>2 hours</Option>
                                <Option>3 hours</Option>
                                <Option>4 hours</Option>
                                <Option>5 hours</Option>
                                <Option>6 hours</Option>
                            </Select>
                        </>
                    )}
                </FlexBox>
            </FlexBox>
        </Dialog>
    );
});

CalendarDialog.propTypes = {
    onCancel: PropTypes.func,
    onSubmit: PropTypes.func,
    headerText: PropTypes.string,
    showEstHours: PropTypes.bool
};

CalendarDialog.defaultProps = {
    showEstHours: true
};

export default CalendarDialog;
