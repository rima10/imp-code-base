import React from 'react';
import PropTypes from 'prop-types';
import { Wizard, WizardStep, Button } from '@ui5/webcomponents-react';
import Workflow from '../account/Workflow';

const WorkflowWizard = ({ steps, processTypeId, onNextClick }) => {
    return (
        <Wizard style={{ height: "400px", overflow: "hidden" }}>
            {Object.keys(steps).map((idx) => {
                return (
                    <WizardStep
                        branching
                        heading={steps[idx].name}
                        selected={steps[idx].selected}
                        disabled={steps[idx].disabled}
                        key={idx}
                    >
                        <Workflow
                            approvers={steps[idx].approvers}
                            processTypeId={processTypeId}
                            processStageName={steps[idx].name}
                            processStageSequence={idx} showTable={steps[idx].showTable}
                            workflowId={steps[idx].workflowId}/>
                        <Button
                            onClick={() => onNextClick(idx)}
                            design="Emphasized"
                            style={{ float: "right", marginRight: "2rem" }}
                        >Next
                        </Button>

                    </WizardStep>
                );
            })}
        </Wizard>
    );
};

WorkflowWizard.propTypes = {
    steps: PropTypes.object,
    processTypeId: PropTypes.oneOf(['1', '2']),
    onNextClick: PropTypes.func
};

WorkflowWizard.defaultProps = {
    steps: {}
};

export default WorkflowWizard;
