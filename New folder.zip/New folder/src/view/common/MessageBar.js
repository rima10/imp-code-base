import React from 'react';
import PropTypes from 'prop-types';
import { MessageStrip } from '@ui5/webcomponents-react';

const MessageBar = ({ message, type }) => {
    const closeMessageBar = () => {
        document.querySelectorAll('ui5-messagestrip').forEach((messageStrip) => {
            messageStrip.parentNode.removeChild(messageStrip);
        });
    };

    // const [delay, setDelay] = useState(0)
    // type === "Negative" ? setDelay(10000) : setDelay(5000)
    // setTimeout(() => {
    //     closeMessageBar();
    // }, delay);

    return (
        <MessageStrip
            onClose={closeMessageBar}
            style={{
                position: 'fixed',
                bottom: '0',
                width: '50%',
                padding: '20px',
                left: '45%',
                zIndex: 110
            }}
            type={type}
        >
            {message}
        </MessageStrip>
    );
};

MessageBar.propTypes = {
    message: PropTypes.string,
    type: PropTypes.oneOf(['Negative', 'Positive', 'Information', 'Warning'])
};

MessageBar.defaultProps = {
    message: 'Something went wrong, please try again',
    type: 'Negative'
};

export default MessageBar;
