/* eslint-disable max-len */
import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { connect } from "react-redux";
import { useHistory } from "react-router-dom";
import { FileUploader, Button, Label, Text, Toolbar, Form, FormItem, TextArea, Option, Select, DateTimePicker, Bar, FormGroup, Input } from '@ui5/webcomponents-react';
import { spacing } from "@ui5/webcomponents-react-base";
import '../../asset/style/style.css';
import AccountTable from '../common/Table';
import CommentDialog from '../common/Dialog';
import { updateOrderInfo, getWorkflowsInfo, readExcelInfo, updateDraftOrderInfo, downloadFile, getOrderType, getCategory, getSubCategory, getBusinessInfo } from '../../store/action/taskAction';
import { clearPreviewOrderItems } from '../../store/action/type';

const OrderCreationForm = ({ businessInfo, startGetOrderType, startGetCategory, startGetSubCategory, startUpdateOrderInfo, startUpdateDraftOrderInfo, startGetWorkflowInfo, startReadExcelInfo, startGetBusinessInfo, orderInfo, workflowsInfo, previewOrderItemInfo, orderTypes, categories, subcategories, startClearPreviewOrderItems }) => {
    const columns = ['Approver Sequence', 'Approver Role', 'Approver Name'];
    const assetColumns = ['Equipment No.', 'Asset No.', 'Location', 'Bond Status', 'Category', 'Make', 'Model', 'Manuf. Serial No.', 'Age in Years', 'Purchase Year', 'Description'];
    const [rows, setRows] = useState([]);
    const [orderPayload, setOrderPayload] = useState({ orderType: '1', category: '1', subcategory: '1', network: 'Private' });
    const [assetRows, setAssetRows] = useState([]);
    let history = useHistory();
    const [assetTableVisible, setAssetTableVisible] = useState(false);
    const dialogRef = useRef(null);
    const getWorkflowDetails = (workflowsInfo) => {
        const newRows = [];
        const workflowApprover = [];
        if (workflowsInfo.length !== 0) {
            workflowApprover.push(workflowsInfo[0].workflow_approvers);
            workflowApprover[0].map(index => {
                const row = [];
                row.push({ name: 'approver_sequence', value: index.approver_sequence, type: 'text' });
                row.push({ name: 'approver_role', value: index.approver.approver_email_id, type: 'text' });
                row.push({ name: 'approver_name', value: index.approver.approver_name, type: 'text' });
                newRows.push(row);
            });
            return newRows;
        }
    };
    const getOrderItemDetails = (previewOrderItemInfo) => {
        const newRows = [];
        previewOrderItemInfo.map(index => {
            const row = [];
            row.push({ name: 'Equipment No.', value: index.A, type: 'text' });
            row.push({ name: 'Asset No.', value: index.B, type: 'text' });
            row.push({ name: 'Location', value: index.E, type: 'text' });
            row.push({ name: 'Bond Status', value: index.F, type: 'text' });
            row.push({ name: 'Category', value: index.G, type: 'text' });
            row.push({ name: 'Make', value: index.H, type: 'text' });
            row.push({ name: 'Model', value: index.I, type: 'text' });
            row.push({ name: 'Manuf. Serial No.', value: index.J, type: 'text' });
            row.push({ name: 'Age in Years', value: index.K, type: 'text' });
            row.push({ name: 'Purchase Year', value: index.L, type: 'text' });
            row.push({ name: 'Description', value: index.M, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };
    useEffect(() => {
        startGetBusinessInfo();
        startGetOrderType();
        startGetCategory();
        startGetSubCategory();
        startGetWorkflowInfo();
    }, []);
    useEffect(() => {
        const rows = getWorkflowDetails(workflowsInfo);
        setRows(rows);
    }, [workflowsInfo.length]);
    useEffect(() => {
        if (previewOrderItemInfo.length !== 0) {
            const assetRows = getOrderItemDetails(previewOrderItemInfo.slice(1));
            setAssetRows(assetRows);
        }
    }, [previewOrderItemInfo.length]);
    const onSelectChange = (e) => {
        const updatedPayload = { ...orderPayload };
        updatedPayload[e.target.name] = e.detail.selectedOption.value;
        setOrderPayload(updatedPayload);
    };
    const onSelectCatChange = (e) => {
        const updatedPayload = { ...orderPayload };
        updatedPayload[e.target.name] = e.target.value;
        setOrderPayload(updatedPayload);
    };
    const inputChange = (event) => {
        const { name, value } = event.target;
        const updatedPayload = { ...orderPayload };
        updatedPayload[name] = value;
        setOrderPayload(updatedPayload);
    };
    const onFileChangeHandler = (event) => {
        const fileform = new FormData();
        fileform.append(event.target.name, event.target.files[0]);
        const updatedPayload = { ...orderPayload };
        updatedPayload[event.target.name] = fileform;
        setOrderPayload(updatedPayload);
        if (event.target.name === 'assetExcel') {
            startReadExcelInfo(fileform);
            setAssetTableVisible(true);
        }
    };
    const onDeleteClick = async (event) => {
        setAssetTableVisible(false);
    };
    const onDownloadBtnClick = () => {
        downloadFile("Assetlist_Template.xlsx");
    };
    const onCancel = () => {
        dialogRef.current.close();
    };
    const onSubmit = (event, draftVal) => {
        event.preventDefault();
        const formdata = new FormData();
        for (const [key, value] of Object.entries(orderPayload)) {
            if (key === 'assetExcel' || key === 'picture') {
                for (var pair of value.entries()) {
                    formdata.append(pair[0], pair[1]);
                }
            }
            formdata.append(`${key}`, `${value}`);
        }
        formdata.append('processStageSequence', '1');
        orderInfo = formdata;
        dialogRef.current.close();
        startClearPreviewOrderItems();
        history.push("/order/previousOrder");
        if (draftVal === 'draft') {
            startUpdateDraftOrderInfo(orderInfo);
        } else {
            startUpdateOrderInfo(orderInfo);
        }
    };
    const onSendAssetListClick = () => {
        dialogRef.current.open();
    };
    const { orderType, category, subcategory, network, submissionDeadline, additionalInfo, assetExcel, picture, orderLocCity } = orderInfo;
    const buttons = [{
        name: 'Delete',
        icon: 'delete',
        onClick: onDeleteClick
    }
    ];
    return (
        <div >
            <Label
                style={{ fontSize: '1.3rem', fontWeight: 'Bold', marginBottom: '20px' }}
            >
                Order Creation
            </Label>
            <Toolbar style={spacing.sapUiTinyMargin}
            >
                <Label style={{ fontSize: '1rem', fontWeight: 'bold' }}>
                    Order Details
                </Label>
            </Toolbar>
            <Form columnsL={2}
                columnsM={2}
                columnsS={2}
                labelSpanM={5}

                style={spacing.sapUiLargeMarginBottom}>
                <FormGroup>
                    <FormItem label={<Label required>This request is for</Label>}>
                        <Select style={spacing.sapUiTinyMargin} name="orderType" value = {orderType} onChange={(e) => { onSelectChange(e); }}>
                            { orderTypes.map((index) =>
                                (<Option selected={index.processTypeId === '1'} key={index.processTypeId} disabled={index.processTypeId !== '1'}
                                    value={index.processTypeId}>{index.processTypeName}</Option>))}
                        </Select>
                    </FormItem>
                    <FormItem label={<Label required>Category</Label>}>
                        <Select style={spacing.sapUiTinyMargin} name="category" value = {category} onChange={(e) => { onSelectCatChange(e); }}>
                            { categories.map((index) =>
                                (<Option selected={index.categoryId === '1'} key={index.categoryId} disabled={index.categoryId !== '1'}
                                    value={index.categoryId}>{index.categoryName}</Option>))}
                        </Select>
                    </FormItem>
                    <FormItem label={<Label required>Subcategory</Label>}>
                        <Select style={spacing.sapUiTinyMargin} name="subcategory" value={subcategory} onChange={(e) => { onSelectCatChange(e); }}>
                            { subcategories.map((index) =>
                                (<Option selected={index.subcategoryId === '1'} key={index.subcategoryId} disabled={index.subcategoryId !== '1'}
                                    value={index.subcategoryId}>{index.subcategoryName}</Option>))}
                        </Select>
                    </FormItem>
                    <FormItem label={<Label required wrap>Quote Submission Deadline</Label>}>
                        <DateTimePicker style={spacing.sapUiTinyMargin} name="submissionDeadline" value={submissionDeadline} onChange={(e) => { inputChange(e); }} />
                    </FormItem>
                    <FormItem label="City" required>
                        <Select style={spacing.sapUiTinyMargin} name="orderLocCity" value={orderLocCity} onChange={(e) => { onSelectChange(e); }} disabled>
                            <Option selected>
                                {businessInfo.location !== undefined ? businessInfo.location.city : ''}
                            </Option>
                        </Select>
                    </FormItem>
                </FormGroup>
                <FormGroup>
                    <FormItem>
                        <Label />
                    </FormItem>
                    <FormItem label={<Label required>Private/Public Network</Label>}>
                        <Select style={spacing.sapUiTinyMargin} name="network" value={network} onChange={(e) => { onSelectChange(e); }}>
                            <Option selected value="Private">
                                Private
                            </Option>
                            <Option value="Public" disabled>
                                Public
                            </Option>
                        </Select>
                    </FormItem>
                    <FormItem label={<Label >Additional Information</Label>}>
                        <TextArea
                            rows={3}
                            style={{
                                width: '210px',
                                margin: '0.5rem'
                            }}
                            name="additionalInfo"
                            value={additionalInfo}
                            onChange={(e) => { inputChange(e); }}
                        />
                    </FormItem>
                    <FormItem label={<Label >Picture</Label>}>
                        <FileUploader style={spacing.sapUiTinyMargin} name="picture" value={picture} onChange={onFileChangeHandler}>
                            <Button design="emphasized" icon="upload" />
                        </FileUploader>
                    </FormItem>
                    <FormItem label="Company Code">
                        <Input style={spacing.sapUiTinyMargin} name="companyCode" readonly value ={businessInfo.companyCode}>{businessInfo.companyCode}</Input>
                    </FormItem>
                </FormGroup>
            </Form>

            {assetTableVisible === true ? <AccountTable columns={assetColumns} edit={false} text="Asset List" rows={assetRows} buttons={buttons}/> :
                <div>
                    <Toolbar>
                        <Label style={{ fontSize: '1rem', fontWeight: 'bold' }}>
                            Asset List
                        </Label>
                    </Toolbar>
                    <div style={{ display: "flex", flexDirection: "column", ...spacing.sapUiLargeMargin }}>
                        <Text>1. Please download an Excel template and fill the given columns with your matching asset data.</Text>
                        <Button data-layout-span="XL3" design = "Emphasized" icon="download" style={{ position: "absolute", ...spacing.sapUiMediumMargin }} width="20%" onClick={onDownloadBtnClick} >Download Excel Template</Button>
                    </div>
                    <div style={spacing.sapUiLargeMargin}>
                        <Text style={spacing.sapUiMediumMarginTop}>2. Then upload the Excel file here in order to prepare the internal approval from your colleagues.</Text>
                        <Bar style ={spacing.sapUiMediumMargin} middleContent= {
                            <FileUploader name="assetExcel" hideInput value={assetExcel} onChange={onFileChangeHandler}>
                                <Button design="Emphasized" style={spacing.sapUiMediumMargin}>
                                    Upload file
                                </Button>
                            </FileUploader>} />
                    </div>
                </div>}
            <AccountTable columns={columns} edit={false} text="Internal Approval Workflow (Asset List)" rows={rows}/>
            <div style={spacing.sapUiTinyMargin}>
                <Button style= {{ float: "right", ...spacing.sapUiMediumMarginBegin }}
                    onClick={() => onSendAssetListClick()}
                    design="Emphasized"
                >Send Asset List for Internal Approval</Button>
                <Button style= {{ float: "right" }}
                    onClick={(e) => { onSubmit(e, 'draft'); }}
                    design="Emphasized"
                >Save as Draft</Button>
                <CommentDialog ref={dialogRef} onCancel={onCancel} onSubmit={onSubmit} headerText="Send Asset List for internal approval"/>
            </div>
        </div>
    );
};
const mapStateToProps = state => {
    return {
        businessInfo: state.account.businessInfo,
        workflowsInfo: state.account.workflows,
        orderTypes: state.order.orderType,
        categories: state.order.category,
        subcategories: state.order.subcategory,
        previewOrderItemInfo: state.order.previewOrderItemInfo
    };
};

const mapDispatchToProps = dispatch => {
    return {
        startGetOrderType: () => dispatch(getOrderType()),
        startGetCategory: () => dispatch(getCategory()),
        startGetSubCategory: () => dispatch(getSubCategory()),
        startGetWorkflowInfo: () => dispatch(getWorkflowsInfo()),
        startUpdateOrderInfo: (payload) => dispatch(updateOrderInfo(payload)),
        startUpdateDraftOrderInfo: (payload) => dispatch(updateDraftOrderInfo(payload)),
        startReadExcelInfo: (payload) => dispatch(readExcelInfo(payload)),
        startGetBusinessInfo: () => dispatch(getBusinessInfo()),
        startClearPreviewOrderItems: () => dispatch(clearPreviewOrderItems())
    };
};

OrderCreationForm.propTypes = {
    businessInfo: PropTypes.object,
    orderInfo: PropTypes.object,
    workflowsInfo: PropTypes.array,
    previewOrderItemInfo: PropTypes.array,
    orderTypes: PropTypes.array,
    categories: PropTypes.array,
    subcategories: PropTypes.array,
    startGetOrderType: PropTypes.func,
    startGetCategory: PropTypes.func,
    startGetSubCategory: PropTypes.func,
    startUpdateOrderInfo: PropTypes.func,
    startUpdateDraftOrderInfo: PropTypes.func,
    startGetWorkflowInfo: PropTypes.func,
    startReadExcelInfo: PropTypes.func,
    startGetBusinessInfo: PropTypes.func,
    startClearPreviewOrderItems: PropTypes.func
};

OrderCreationForm.defaultProps = {
    businessInfo: {},
    orderInfo: {},
    workflowsInfo: [],
    previewOrderItemInfo: [],
    orderTypes: [],
    categories: [],
    subcategories: []
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderCreationForm);
