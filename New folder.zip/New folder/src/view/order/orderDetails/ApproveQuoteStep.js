import React, { useRef, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import AccountTable from '../../common/Table';
import { Button, Toolbar, ToolbarSpacer } from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import {
    getApprover,
    getOrderItemLevelQuote,
    scheduleLogistics
} from '../../../store/action/order';
import CalendarDialog from '../../common/CalendarDialog';

const ApproveFinalQuote = ({
    approver,
    startGetApprover,
    orderItemQuotation,
    orderId,
    orderType,
    onSiteVisitDetails,
    startGetItemQuote,
    startScheduleLogistics
}) => {
    const dialogRef = useRef(null);
    const [recyclerInfoRows, setRecyclerInfoRows] = useState([]);
    const [assetRows, setAssetRows] = useState([]);
    const [approverRows, setApproverRows] = useState([]);
    const selectedRecyclerInfoColumns = ['Selected Recycler Company', 'Total Price'];
    const assetColumns = [
        'Equipment No.',
        'Location',
        'Bond Status',
        'Item Type',
        'Make',
        'Model',
        'Age in Years',
        'Description',
        'Grade',
        'Blancco',
        'Report status',
        'List price',
        'Service cost',
        'To be invoiced'
    ];

    const approverColumns = ['Approver Role', 'Approver Name', 'Status'];
    const getVisitDetails = (onSiteVisitDetails) => {
        const newRows = [];
        const row = [];
        row.push({
            name: selectedRecyclerInfoColumns[0],
            value: onSiteVisitDetails.createdByBP.recyclerName,
            type: 'text'
        });
        row.push({
            name: selectedRecyclerInfoColumns[1],
            value: onSiteVisitDetails.totalPrice,
            type: 'text'
        });
        newRows.push(row);
        return newRows;
    };

    useEffect(() => {
        if (Object.keys(onSiteVisitDetails).length !== 0) {
            const row = getVisitDetails(onSiteVisitDetails);
            setRecyclerInfoRows(row);
        }
    }, [onSiteVisitDetails]);
    const getOrderItemQuoteDetails = (orderItemQuotation) => {
        const newRows = [];
        orderItemQuotation.map((index) => {
            const row = [];
            const orderItem = index.order_item;
            row.push({ name: assetColumns[0], value: orderItem.equipmentNumber, type: 'text' });
            row.push({ name: assetColumns[2], value: orderItem.buildingLoc, type: 'text' });
            row.push({ name: assetColumns[3], value: orderItem.bondStatus, type: 'text' });
            row.push({ name: assetColumns[4], value: orderItem.itemType, type: 'text' });
            row.push({ name: assetColumns[5], value: orderItem.make, type: 'text' });
            row.push({ name: assetColumns[6], value: orderItem.model, type: 'text' });
            row.push({ name: assetColumns[8], value: orderItem.ageInYear, type: 'text' });
            row.push({ name: assetColumns[10], value: orderItem.description, type: 'text' });
            row.push({ name: assetColumns[11], value: index.grade, type: 'text' });
            row.push({ name: assetColumns[12], value: index.blancco, type: 'text' });
            row.push({ name: assetColumns[13], value: index.reportStatus, type: 'text' });
            row.push({ name: assetColumns[14], value: index.listPrice, type: 'text' });
            row.push({ name: assetColumns[15], value: index.serviceCost, type: 'text' });
            row.push({ name: assetColumns[16], value: index.toBeInvoiced, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };
    const getApproverDetails = (approvers) => {
        const newRows = [];
        approvers.map((approver) => {
            const row = [];
            row.push({ name: approverColumns[0], value: approver.approverRole, type: 'text' });
            row.push({ name: approverColumns[1], value: approver.approverName, type: 'text' });
            row.push({ name: approverColumns[2], value: approver.status, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };
    useEffect(() => {
        startGetApprover(orderId, '1', '5');
        startGetItemQuote(orderId);
    }, []);

    useEffect(() => {
        if (approver.length !== 0) {
            const row = getApproverDetails(approver);
            setApproverRows(row);
        }
    }, [approver.length]);
    useEffect(() => {
        if (orderItemQuotation) {
            const assetRows = getOrderItemQuoteDetails(orderItemQuotation);
            setAssetRows(assetRows);
        }
    }, [orderItemQuotation]);
    const onCancel = () => {
        dialogRef.current.close();
    };
    const onSubmit = (date, time, hours) => {
        let formattedDate = new Date(`${date} ${time} UTC`);
        formattedDate = formattedDate.toISOString();
        const payload = {
            scheduledLogisticDate: formattedDate,
            estimatedTime: hours
        };
        startScheduleLogistics(orderId, payload);
        dialogRef.current.close();
    };
    const onScheduleClick = () => {
        dialogRef.current.open();
    };

    const renderButton = () => {
        if (approver === []) {
            return (
                <>
                    {' '}
                    <Toolbar toolbarStyle="Clear">
                        <ToolbarSpacer />
                        <Button design="Emphasized" onClick={onScheduleClick}>
                            Schedule Pick up date
                        </Button>
                    </Toolbar>
                </>
            );
        } else {
            let isAllApproved = approver.filter((x) => x.status === 'approved').length === approver.length;
            return (
                <>
                    {' '}
                    <Toolbar toolbarStyle="Clear">
                        <ToolbarSpacer />
                        {isAllApproved ? (
                            <Button
                                design="Emphasized"
                                onClick={onScheduleClick}
                            >
                                Schedule Pick up date
                            </Button>
                        ) : (
                            <Button
                                design="Emphasized"
                            >
                                Send Quote for Internal Approval
                            </Button>
                        )}
                    </Toolbar>
                </>
            );
        }
    };

    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <AccountTable
                columns={selectedRecyclerInfoColumns}
                edit={false}
                text="Selected Recycler"
                rows={recyclerInfoRows}
            />
            <AccountTable columns={assetColumns} edit={false} text="Asset List" rows={assetRows} />
            <AccountTable
                columns={approverColumns}
                edit={false}
                text="Workflow Approver"
                rows={approverRows}
            />
            {renderButton()}
            <CalendarDialog
                ref={dialogRef}
                onCancel={onCancel}
                onSubmit={onSubmit}
                headerText="Schedule Pickup Date for your Assets"
                showEstHours={false}
            />
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        approver: state.order.approver['5'],
        orderItemQuotation: state.order.orderItemQuotation,
        onSiteVisitDetails: state.order.onSiteVisitDetails
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetApprover: (orderId, processType, sequenceNo) =>
            dispatch(getApprover(orderId, processType, sequenceNo)),
        startGetItemQuote: (orderId) => dispatch(getOrderItemLevelQuote(orderId)),
        startScheduleLogistics: (orderId, quoteId, payload) =>
            dispatch(scheduleLogistics(orderId, quoteId, payload))
    };
};

ApproveFinalQuote.propTypes = {
    approver: PropTypes.array,
    startGetApprover: PropTypes.func,
    startGetItemQuote: PropTypes.func,
    startScheduleLogistics: PropTypes.func,
    orderId: PropTypes.string,
    orderType: PropTypes.string,
    onSiteVisitDetails: PropTypes.object,
    orderItemQuotation: PropTypes.array,
};

export default connect(mapStateToProps, mapDispatchToProps)(ApproveFinalQuote);
