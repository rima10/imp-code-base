import React, { useRef, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { AnalyticalTable, Button, ObjectStatus, Toolbar, ToolbarSpacer, Label, Text } from '@ui5/webcomponents-react';
import CalendarDialog from '../../common/CalendarDialog';
import AccountTable from '../../common/Table';
import { acceptQuote, rejectQuote, temporaryAcceptQuote, getApprover } from '../../../store/action/order';
import { connect } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { showMessage } from '../../../store/action/type';

const QuoteSelection = ({
    currentSequence,
    approver,
    orderId,
    orderType,
    orderQuotation,
    startGetApprover,
    startTemporaryAcceptQuote,
    startRejectQuote,
    startAcceptQuote,
    startShowMessage
}) => {
    const dialogRef = useRef(null);
    const history = useHistory();
    const [approverRows, setApproverRows] = useState([]);
    const approverColumns = ['Sequence', 'Approver Role', 'Approver Name', 'Approval Status'];

    const getApproverDetails = (approvers) => {
        const newRows = [];
        approvers.sort(function (a, b) {
            return a.approverSequence - b.approverSequence;
        });
        approvers.map((approver) => {
            const row = [];
            row.push({ name: approverColumns[0], value: approver.approverSequence, type: 'text' });
            row.push({ name: approverColumns[1], value: approver.approverRole, type: 'text' });
            row.push({ name: approverColumns[2], value: approver.approverName, type: 'text' });
            row.push({ name: approverColumns[3], value: approver.status, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };

    useEffect(() => {
        if (approver.length !== 0) {
            const row = getApproverDetails(approver);
            setApproverRows(row);
        }
    }, [approver]);

    useEffect(() => {
        startGetApprover(orderId, '1', '3');
    }, []);

    const onCancel = () => {
        dialogRef.current.close();
    };

    const onSubmit = (date, time, hours) => {
        let formattedDate = new Date(`${date} ${time} UTC`);
        formattedDate = formattedDate.toISOString();
        const payload = {
            scheduledOnsiteDate: formattedDate,
            estimatedTime: hours
        };
        startAcceptQuote(orderId, payload);
        dialogRef.current.close();
        startShowMessage({
            message: `A confirmation about the selected Quote has been sent to the recycler`,
            status: 'Positive'
        });
        history.push('/order/previousOrder');
    };

    const onAcceptClick = () => {
        dialogRef.current.open();
    };

    const getValueState = (value) => {
        if (value === 'In Review') {
            return 'Warning';
        }
        if (value === 'Accepted' || value === 'Temporarily Accepted') {
            return 'Success';
        }
        if (value === 'Rejected') {
            return 'Error';
        }
        return 'Information';
    };

    const isAcceptDisabled = () => {
        let isDisabled = false;
        if (parseInt(currentSequence, 10) > 3) {
            return true;
        } else if (approver.length !== 0) {
            isDisabled = approver.filter((x) => x.status === 'approved').length !== approver.length;
            return isDisabled;
        } else {
            return false;
        }
    };

    const onAcceptQuote = (quoteId) => {
        startTemporaryAcceptQuote(orderId, quoteId);
    };

    const onRejectQuote = (quoteId) => {
        startRejectQuote(orderId, quoteId);
    };

    const renderButton = (value) => {
        if (value) {
            let status = orderQuotation.quotesData.find((quote) => quote.quoteId === value).quoteStatus;
            if (status === 'Accepted' || status === 'Temporarily Accepted') {
                return (
                    <>
                        <Button onClick={() => onRejectQuote(value)} design="Negative">
                            Reject Quote
                        </Button>
                    </>
                );
            } else {
                if (
                    orderQuotation.quotesOverallStatus === 'Accepted' ||
                    orderQuotation.quotesOverallStatus === 'Temporarily Accepted'
                ) {
                    return <Button disabled>Accept Quote</Button>;
                }
                return (
                    <Button onClick={() => onAcceptQuote(value)} disabled={false}>
                        Accept Quote
                    </Button>
                );
            }
        }
        return null;
    };

    const renderName = (value) => {
        if (typeof value === 'object' && value !== null) {
            return (
                <Text>
                    {value.name} ({value.count})
                </Text>
            );
        }
        return <Text>{value}</Text>;
    };

    const renderPrice = (instance) => {
        const rowProps = instance.row.getRowProps();
        const rowKeyArr = rowProps.key.split('.');
        let price = instance.cell.value;
        if (price && rowKeyArr.length > 1) {
            return (<><Text>{price}</Text>
                <Text style={{ fontStyle: 'italic', fontSize: '1rem', margin: '2px' }}> / unit</Text></>);
        }
        return <Text>{price}</Text>;
    };

    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <Label style={{ fontSize: '1rem', fontWeight: 'bold', marginBottom: '10px' }}>Quotes From Recyclers</Label>
            <AnalyticalTable
                columns={[
                    {
                        Header: 'Recycler Company',
                        accessor: 'name',
                        Cell: (instance) => renderName(instance.cell.value)
                    },
                    {
                        Header: 'Price (INR)',
                        accessor: 'totalPrice',
                        Cell: (instance) => renderPrice(instance)
                    },
                    {
                        Header: 'Status',
                        accessor: 'quoteStatus',
                        Cell: (instance) => {
                            return (
                                <ObjectStatus state={getValueState(instance.cell.value)}>
                                    {instance.cell.value}
                                </ObjectStatus>
                            );
                        }
                    },
                    {
                        Header: 'Action',
                        accessor: 'quoteId',
                        Cell: (instance) => renderButton(instance.cell.value)
                    }
                ]}
                data={orderQuotation.quotesData}
                isTreeTable
                minRows={1}
                subRowsKey="data"
            />
            <AccountTable
                columns={approverColumns}
                edit={false}
                text="Internal Approval Workflow (Pricing)"
                rows={approverRows}
            />
            <Toolbar toolbarStyle="Clear">
                <ToolbarSpacer />
                <Button design="Emphasized" disabled={isAcceptDisabled()} onClick={onAcceptClick}>
                    Accept Quote
                </Button>
            </Toolbar>
            <CalendarDialog
                ref={dialogRef}
                onCancel={onCancel}
                onSubmit={onSubmit}
                headerText="Schedule Onsite Visit"
            />
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        approver: state.order.approver['3'],
        orderItemQuotation: state.order.orderItemQuotation
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startAcceptQuote: (orderId, quoteId, payload) => dispatch(acceptQuote(orderId, quoteId, payload)),
        startRejectQuote: (orderId, quoteId) => dispatch(rejectQuote(orderId, quoteId)),
        startTemporaryAcceptQuote: (orderId, quoteId) => dispatch(temporaryAcceptQuote(orderId, quoteId)),
        startGetApprover: (orderId, processType, sequenceNo) => dispatch(getApprover(orderId, processType, sequenceNo)),
        startShowMessage: (payload) => dispatch(showMessage(payload))
    };
};

QuoteSelection.propTypes = {
    orderQuotation: PropTypes.object,
    currentSequence: PropTypes.string,
    approver: PropTypes.array,
    orderId: PropTypes.string,
    orderType: PropTypes.string,
    startGetApprover: PropTypes.func,
    startTemporaryAcceptQuote: PropTypes.func,
    startRejectQuote: PropTypes.func,
    startAcceptQuote: PropTypes.func,
    startShowMessage: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(QuoteSelection);
