import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { getOnsiteVisitDetails } from '../../../store/action/order';
import { getOnsiteDetails, isOnsiteLoading } from '../../../selectors/common';
import AccountTable from '../../common/Table';

const ScheduleOnsiteVisit = ({ isLoading, startGetOnsiteVisitDetails, onSiteDetails, orderId }) => {
    useEffect(() => {
        startGetOnsiteVisitDetails(orderId);
    }, []);
    const [rows, setRows] = useState([]);
    const columns = ['Selected Recycler Company', 'Scheduled Time', 'Status', 'Total Price'];

    const getVisitDetails = (onSiteDetails) => {
        const newRows = [];
        const row = [];
        row.push({ name: columns[0], value: onSiteDetails.createdByBP.recyclerName, type: 'text' });
        row.push({ name: columns[1], value: onSiteDetails.onsiteScheduledTime, type: 'text' });
        row.push({ name: columns[2], value: onSiteDetails.quoteStatus, type: 'text' });
        row.push({ name: columns[3], value: onSiteDetails.totalPrice, type: 'text' });
        newRows.push(row);
        return newRows;
    };

    useEffect(() => {
        if (onSiteDetails && !Object.keys(onSiteDetails).length === 0) {
            const row = getVisitDetails(onSiteDetails);
            setRows(row);
        }
    }, [onSiteDetails]);

    if (isLoading) {
        return null;
    } else {
        return (
            <div style={{ height: '100%', margin: '10px' }}>
                <AccountTable columns={columns} edit={false} text="Selected Recycler" rows={rows} />
            </div>
        );
    }
};

const mapStateToProps = (state) => {
    return {
        onSiteDetails: getOnsiteDetails(state),
        isLoading: isOnsiteLoading(state),
        orderItemQuotation: state.order.orderItemQuotation
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetOnsiteVisitDetails: (orderId) => dispatch(getOnsiteVisitDetails(orderId))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(ScheduleOnsiteVisit);
