import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import OrderWizard from './OrderWizard';
import { connect } from 'react-redux';
import { setMoveToNextStep } from '../../../store/action/order';

const OrderDetailsContainer = ({
    orderId,
    consolidatedOrderItemInfo,
    orderItemInfo,
    orderQuotation,
    startSetMoveToNextStep
}) => {
    const [steps, setSteps] = useState({});

    const onNextStep = (stepNumber) => {
        startSetMoveToNextStep(orderId, stepNumber + 1);
    };

    useEffect(() => {
        const defaultSteps = {
            1: {
                name: 'Order Creation',
                selected: true,
                disabled: false,
                showTable: false
            },
            2: {
                name: 'Quote Submission',
                selected: false,
                disabled: parseInt(orderItemInfo.currentSequence, 10) < 2,
                showTable: false
            },
            3: {
                name: 'Quotation Selection',
                selected: false,
                disabled: parseInt(orderItemInfo.currentSequence, 10) < 3,
                showTable: false
            },
            4: {
                name: 'Schedule Onsite Visit',
                selected: false,
                disabled: parseInt(orderItemInfo.currentSequence, 10) < 4,
                showTable: false
            },
            5: {
                name: 'Approve Final Quote',
                selected: false,
                disabled: parseInt(orderItemInfo.currentSequence, 10) < 5,
                showTable: false
            },
            6: {
                name: 'Logistics',
                selected: false,
                disabled: parseInt(orderItemInfo.currentSequence, 10) < 6,
                showTable: false
            }
        };
        setSteps(defaultSteps);
    }, [orderItemInfo]);

    return (
        <OrderWizard
            steps={steps}
            onNextStep={onNextStep}
            orderId={orderId}
            consolidatedOrderItemInfo={consolidatedOrderItemInfo}
            orderItemInfo={orderItemInfo}
            orderQuotation={orderQuotation}
        />
    );
};

const mapStateToProps = (state) => {
    return {
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startSetMoveToNextStep: (orderId, stepNumber) => dispatch(setMoveToNextStep(orderId, stepNumber))
    };
};

OrderDetailsContainer.propTypes = {
    orderId: PropTypes.string,
    orderItemInfo: PropTypes.object,
    consolidatedOrderItemInfo: PropTypes.object,
    orderQuotation: PropTypes.object,
    startSetMoveToNextStep: PropTypes.func,
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderDetailsContainer);
