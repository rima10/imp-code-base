
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { BusyIndicator, Label, Form, FormGroup, FormItem, Text } from '@ui5/webcomponents-react';
import { spacing } from "@ui5/webcomponents-react-base";

const Logistics = ({ orderItemInfo }) => {
    const [loading, setLoading] = useState(true);
    useEffect(() => {
    }, []);
    useEffect(() => {
        if (orderItemInfo && orderItemInfo.logisticsScheduledTime) {
            setLoading(false);
        }
    }, [orderItemInfo.logisticsScheduledTime]);

    const getDate = (logisticsScheduledTime) => {
        if (logisticsScheduledTime !== null && logisticsScheduledTime !== undefined) {
            const logisticsScheduledDate = new Date(logisticsScheduledTime).toDateString();
            return logisticsScheduledDate;
        }
    };

    const getTime = (logisticsScheduledTime) => {
        if (logisticsScheduledTime !== null && logisticsScheduledTime !== undefined) {
            const logisticsScheduledDate = new Date(logisticsScheduledTime);
            let hours = logisticsScheduledDate.getUTCHours();
            let minutes = logisticsScheduledDate.getUTCMinutes();
            let seconds = logisticsScheduledDate.getUTCSeconds();
            let meridian;
            if (hours.toString().length === 1) {
                hours = `0${hours.toString()}`;
            }
            if (minutes.toString().length === 1) {
                minutes = `0${minutes.toString()}`;
            }
            if (seconds.toString().length === 1) {
                seconds = `0${seconds.toString()}`;
            }
            if (hours > 11) {
                hours -= 12;
                meridian = 'PM';
                return `${hours}:${minutes}:${seconds} PM`;
            } else meridian = 'AM';
            return `${hours}:${minutes}:${seconds} ${meridian}`;
        }
    };
    return (
        <BusyIndicator active={loading} size="Medium" >
            <div style={spacing.sapUiMediumMargin}>
                <Label
                    style={{ fontSize: '1rem', fontWeight: 'Bold' }}
                    tooltip=""
                >
                Logistic Details
                </Label>
                <div style={spacing.sapUiLargeMargin}>
                    <Form columnsL={2}
                        columnsM={2}
                        columnsS={2}
                        labelSpanM={5}

                        style={spacing.sapUiLargeMarginBottom}>
                        <FormGroup>
                            <FormItem label="Date">
                                <Text > {getDate(orderItemInfo.logisticsScheduledTime)} </Text>
                            </FormItem>
                            <FormItem label="Time">
                                <Text > {getTime(orderItemInfo.logisticsScheduledTime)} </Text>
                            </FormItem>
                        </FormGroup>
                        <FormGroup >
                            <FormItem label="Vehicle Type">
                                <Text > {orderItemInfo.vehicleType}</Text>
                            </FormItem>
                            <FormItem label="Vehicle Number">
                                <Text >{orderItemInfo.vehicleNumber}</Text>
                            </FormItem>
                        </FormGroup>
                    </Form>
                </div>
            </div>
        </BusyIndicator>
    );
};

const mapStateToProps = (state) => {
    return {
        orderItemInfo: state.order.orderItemInfo
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
    };
};

Logistics.propTypes = {
    orderItemInfo: PropTypes.object
};

export default connect(mapStateToProps, mapDispatchToProps)(Logistics);
