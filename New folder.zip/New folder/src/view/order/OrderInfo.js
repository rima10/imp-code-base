import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { TabContainer, Tab, Breadcrumbs, Link, Title } from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import { useHistory } from 'react-router-dom';
import {
    getOrderItemInfoState,
    getConsolidatedOrderItemInfoState,
    getOrderQuotationState,
    isOrderItemInfoLoading,
    isConsolidatedOrderItemInfoLoading,
    isOrderQuotationLoading
} from '../../selectors/common';
import { getOrderItemInfo, getConsolidatedOrderItemInfo, getOrderQuotation } from '../../store/action/order';
import OrderDetailsContainer from './orderDetails/Container';
import DocumentContainer from './documentDetails/documentContainer';
import LoadingIndicator from '../common/Loading';

const applyCSS = async () => {
    // Set timeout is used to trigger async job which will be invoked after the components is rendered.
    setTimeout(() => {
        const shadowDOM = document.querySelector('ui5-tabcontainer').shadowRoot;
        const style = document.createElement('style');
        style.innerHTML = '.ui5-tc__headerList { justify-content: space-around !important}';
        shadowDOM.appendChild(style);
        const fontStyle = document.createElement('style');
        fontStyle.innerHTML = '.ui5-tab-strip-item { font-size: var(--sapFontSize) !important;}';
        shadowDOM.appendChild(fontStyle);
    }, 0);
};

const OrderInfo = ({
    orderId,
    startGetOrderItemInfo,
    startGetConsolidatedOrderItemInfo,
    orderItemInfo,
    consolidatedOrderItemInfo,
    orderQuotation,
    startGetOrderQuotation,
    isOrderItemInfoLoading,
    isConsolidatedOrderItemInfoLoading,
    isOrderQuotationLoading
}) => {
    const history = useHistory();

    const onBreadCrumbClick = () => {
        history.push('/order/previousOrder');
    };

    useEffect(() => {
        startGetOrderItemInfo(orderId);
        startGetConsolidatedOrderItemInfo(orderId);
        startGetOrderQuotation(orderId);
    }, []);

    useEffect(() => {
        if (!(isOrderItemInfoLoading || isConsolidatedOrderItemInfoLoading || isOrderQuotationLoading)) {
            applyCSS();
        }
    }, [isOrderItemInfoLoading, isConsolidatedOrderItemInfoLoading, isOrderQuotationLoading]);

    if (isOrderItemInfoLoading || isConsolidatedOrderItemInfoLoading || isOrderQuotationLoading) {
        return <LoadingIndicator />;
    } else {
        return (
            <>
                <Breadcrumbs
                    style={{ ...spacing.sapUiMediumMarginTopBottom }}
                    currentLocationText={orderItemInfo.orderNumber}
                >
                    <Link onClick={onBreadCrumbClick}>Previous Order</Link>
                </Breadcrumbs>
                <Title style={spacing.sapUiMediumMarginBottom}>{`Order ${orderItemInfo.orderNumber}`}</Title>
                <TabContainer fixed>
                    <Tab icon="form" selected text="Order Details">
                        <OrderDetailsContainer
                            orderId={orderId}
                            consolidatedOrderItemInfo={consolidatedOrderItemInfo}
                            orderItemInfo={orderItemInfo}
                            orderQuotation={orderQuotation}
                        />
                    </Tab>
                    <Tab icon="documents" text="Order Documents">
                        <DocumentContainer orderId={orderId} orderNo={orderItemInfo.orderNumber} />
                    </Tab>
                    <Tab icon="clinical-tast-tracker" text="Order Tracking" disabled>
                        Content Tab 3
                    </Tab>
                </TabContainer>
            </>
        );
    }
};

const mapStateToProps = (state) => {
    return {
        orderItemInfo: getOrderItemInfoState(state),
        consolidatedOrderItemInfo: getConsolidatedOrderItemInfoState(state),
        orderQuotation: getOrderQuotationState(state),
        isOrderItemInfoLoading: isOrderItemInfoLoading(state),
        isConsolidatedOrderItemInfoLoading: isConsolidatedOrderItemInfoLoading(state),
        isOrderQuotationLoading: isOrderQuotationLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetOrderItemInfo: (orderId) => dispatch(getOrderItemInfo(orderId)),
        startGetConsolidatedOrderItemInfo: (orderId) => dispatch(getConsolidatedOrderItemInfo(orderId)),
        startGetOrderQuotation: (orderId) => dispatch(getOrderQuotation(orderId))
    };
};

OrderInfo.propTypes = {
    orderId: PropTypes.string,
    orderItemInfo: PropTypes.object,
    consolidatedOrderItemInfo: PropTypes.object,
    orderQuotation: PropTypes.object,
    startGetOrderItemInfo: PropTypes.func,
    startGetConsolidatedOrderItemInfo: PropTypes.func,
    startGetOrderQuotation: PropTypes.func,
    isOrderItemInfoLoading: PropTypes.bool,
    isConsolidatedOrderItemInfoLoading: PropTypes.bool,
    isOrderQuotationLoading: PropTypes.bool
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderInfo);
