import React from 'react';
import {
    Form, Button, FormItem, Dialog, Label, Select, Option, FileUploader
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';

const documentTypes = ["Invoice", "Gate Pass", "Data destruction certificates", "E-way bill"];
const UploadDocDialog = React.forwardRef(({ onCancel, headerText, onSelectDocChange, onSubmit, onFileSelect }, ref) => {
    return (<Dialog
        className=""
        ref={ref}
        footer={<div style={spacing.sapUiSmallMargin}>
            <Button style={spacing.sapUiTinyMargin} onClick={onCancel}>Close</Button>
            <Button style={spacing.sapUiTinyMargin} onClick={onSubmit}>Upload</Button></div>}
        headerText={headerText}
        style={{ width: "20%" }}
    >
        <div style={{ display: "flex", justifyContent: "center" }}>
            <Form >
                <FormItem label={<Label required>Document Type</Label>}>
                    <Select name="documentType" onChange={(e) => { onSelectDocChange(e); }}>
                        <Option key={-1}
                        >Select Document Type</Option>
                        { documentTypes.map((docType, i) =>
                            (<Option key={i}
                                value={i + 4}>{docType}</Option>))}
                    </Select>
                </FormItem>
                <FormItem label={<Label >Document</Label>}>
                    <FileUploader name="document" onChange={onFileSelect} >
                        <Button design="emphasized" icon="upload" />
                    </FileUploader>
                </FormItem>
            </Form>
        </div>
    </Dialog>);
});
export default UploadDocDialog;
