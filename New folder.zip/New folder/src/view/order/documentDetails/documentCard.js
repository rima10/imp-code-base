import React, { useState, useRef } from 'react';
import { FlexBox, Title, Button, ObjectStatus, Text, Icon, Form, FormItem, Input } from '@ui5/webcomponents-react';
import GenerateDocDialog from './generateDocDialog';

const documentCard = ({ title, status, date, onDownload, docKey, onGenerateDC, onGenerateForm6 }) => {
    const [payloadData, setPayloadData] = useState({ gst: '18', hsnCode: '8471' });
    const [genType, setGenType] = useState('');
    const getStatusData = (isIcon, status) => {
        let result = '';
        switch (status) {
            case 'Created':
                result = isIcon ? "accept" : "Success";
                break;
            case 'Pending':
                result = isIcon ? "pending" : "Warning";
                break;
            default:
                result = isIcon ? "pending" : "Warning";
                break;
        }
        return result;
    };
    const dialogRef = useRef(null);
    const onCancel = () => {
        dialogRef.current.close();
    };

    const onSubmit = () => {
        dialogRef.current.close();
        const updatedPayloadData = { ...payloadData };
        if (genType === 'form6') {
            Reflect.deleteProperty(updatedPayloadData, 'gst');
            Reflect.deleteProperty(updatedPayloadData, 'hsnCode');
            onGenerateForm6(updatedPayloadData);
        } else onGenerateDC(updatedPayloadData);
    };
    const onInputChange = (event) => {
        const { name, value } = event.target;
        const updatedDcData = { ...payloadData };
        updatedDcData[name] = value;
        setPayloadData(updatedDcData);
    };

    const onDownloadClick = (docKey, title) => {
        if (title === 'Delivery Challan') {
            setGenType('dc');
            onDownload(dialogRef, docKey);
        } else if (title === 'Form 6') {
            setGenType('form6');
            onDownload(dialogRef, docKey);
        } else onDownload(dialogRef, docKey);
    };

    const getComponents = (type) => {
        if (type === 'dc') {
            return (<><Form>
                <FormItem label="Delivery Challan Number">
                    <Input name="dcNo" onChange={onInputChange}/>
                </FormItem>
                <FormItem label="HSN Code for goods">
                    <Input name="hsnCode" value="8471" onChange={onInputChange}/>
                </FormItem>
                <FormItem label="GST (%)">
                    <Input name="gst" value="18" onChange={onInputChange}/>
                </FormItem>
            </Form></>);
        } else {
            return (<><Form>
                <FormItem label="Invoice Number">
                    <Input name="invoiceNo" onChange={onInputChange}/>
                </FormItem>
                <FormItem label="Weight of E-waste (KG)">
                    <Input name="weight" onChange={onInputChange}/>
                </FormItem>
            </Form></>);
        }
    };
    return (<div
        className="docCard">
        <FlexBox direction="Column" justifyContent="SpaceBetween" displayInline
            style={{ height: "80%" }}
            children={<>
                <Title>{title}</Title>
                <ObjectStatus icon={<Icon name={getStatusData(true, status)}/>}
                    state={getStatusData(false, status)} style={{ fontSize: "1rem" }}>{status}</ObjectStatus>
                {date != null ? <Text>{`created on: ${new Date(date).toDateString()}`}</Text> :
                    <Text />}
                <Button
                    icon="download"
                    onClick={() => {onDownloadClick(docKey, title);}}
                    disabled={(docKey === undefined && (title !== 'Delivery Challan' && title !== 'Form 6'))}
                    style={{ bottom: 0, right: 0, width: '20%', position: 'absolute', margin: '10px', border: 'none' }}
                />
            </>}/>
        <GenerateDocDialog ref={dialogRef} onCancel={onCancel} onSubmit={onSubmit}
            onInputChange={onInputChange}
            headerText={`Generate ${genType === 'dc' ? 'Delivery Challan' : 'Form 6'} Document`}
            components={getComponents(genType)}/>

    </div>);
};

export default documentCard;
