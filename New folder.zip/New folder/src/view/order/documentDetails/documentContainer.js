import React, { useState, useEffect, useRef } from 'react';
import { connect } from 'react-redux';
import { Grid, Title, Toolbar, Button, ToolbarSpacer } from '@ui5/webcomponents-react';
import DocumentCard from './documentCard';
import UploadDocDialog from './UploadDocDialog';
import { getOrderDocuments, uploadDocument, downloadDocument,
    generateDCDocument, generateForm6Document } from '../../../store/action/order';
import { getOrderDocInfoState } from '../../../selectors/common';
import LoadingIndicator from '../../common/Loading';


const DocumentContainer = ({ startGetOrderDocumentsInfo, startUploadOrderDocument, startGenerateForm6Document,
    startDownloadOrderDocument, startGenerateDCDocument, orderDocInfo, orderId, orderNo }) => {
    const [documents, setDocuments] = useState([]);
    const [uploadpayload, setUploadPayload] = useState({});
    const openDialog = (ref) => {
        ref.current.open();
    };

    const onDownload = (ref, key) => {
        startDownloadOrderDocument(key);
    };

    const onGenerateDC = (payload) => {
        payload.orderNo = orderNo;
        startGenerateDCDocument(orderId, payload);
    };

    const onGenerateForm6 = (payload) => {
        payload.orderNo = orderNo;
        startGenerateForm6Document(orderId, payload);
    };

    const formatDocuments = (orderDocs) => {
        const docs = [];
        orderDocs.map(orderDoc => {
            const doc = {};
            doc.title = orderDoc.docName;
            if (orderDoc.order_docs.length) {
                doc.status = 'Created';
                doc.date = orderDoc.order_docs[0].lastModifiedDate;
                doc.key = orderDoc.order_docs[0].storageKey;
            } else {
                doc.status = 'Pending';
                doc.date = null;
            }
            if (orderDoc.docName === 'Delivery Challan') doc.onDownload = openDialog;
            else if (orderDoc.docName === 'Form 6') doc.onDownload = openDialog;
            else doc.onDownload = onDownload;
            docs.push(doc);
        });
        return docs;
    };
    useEffect(() => {
        startGetOrderDocumentsInfo(orderId);
    }, []);
    useEffect(() => {
        const docs = formatDocuments(orderDocInfo.orderDocuments);
        setDocuments(docs);
    }, [JSON.stringify(orderDocInfo.orderDocuments)]);

    const dialogRef = useRef(null);

    const openUploadDialog = () => {
        dialogRef.current.open();
    };

    const onFileSelect = (event) => {
        const fileform = new FormData();
        fileform.append(event.target.name, event.target.files[0]);
        const updatedPayload = { ...uploadpayload };
        updatedPayload[event.target.name] = fileform;
        setUploadPayload(updatedPayload);
    };

    const onSelectDocChange = (e) => {
        const updatedPayload = { ...uploadpayload };
        updatedPayload.documentId = e.detail.selectedOption.value;
        setUploadPayload(updatedPayload);
    };

    const onUpload = (event) => {
        event.preventDefault();
        dialogRef.current.close();
        const formdata = new FormData();
        for (const [key, value] of Object.entries(uploadpayload)) {
            if (key === 'document') {
                for (var pair of value.entries()) {
                    formdata.append(pair[0], pair[1]);
                }
            }
            formdata.append(`${key}`, `${value}`);
        }
        formdata.append('orderNo', orderNo);
        startUploadOrderDocument(orderId, formdata);
    };

    const onCancel = () => {
        dialogRef.current.close();
    };
    if (orderDocInfo.isLoading) {
        return (<LoadingIndicator/>);
    } else {
        return (<>
            <Toolbar toolbarStyle="Clear">
                <Title>Documents</Title>
                <ToolbarSpacer />
                <Button style={{ float: 'right' }} design="Emphasized" onClick={openUploadDialog}>Upload</Button>
            </Toolbar>

            <Grid style={{ marginTop: '20px' }}>
                {documents.map(document => {
                    const { title, status, date, onDownload, key } = document;
                    return (<DocumentCard title={title} status={status} date={date} onDownload={onDownload} docKey={key}
                        onGenerateDC={onGenerateDC} onGenerateForm6={onGenerateForm6}/>);
                })}
            </Grid>
            <UploadDocDialog ref={dialogRef} onCancel={onCancel} onSubmit={onUpload} onFileSelect={onFileSelect}
                onSelectDocChange={onSelectDocChange} headerText="Upload Document"/>
        </>
        );
    }
};
const mapStateToProps = (state) => {
    return {
        orderDocInfo: getOrderDocInfoState(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetOrderDocumentsInfo: (orderId) => dispatch(getOrderDocuments(orderId)),
        startUploadOrderDocument: (orderId, payload) => dispatch(uploadDocument(orderId, payload)),
        startDownloadOrderDocument: (key) => dispatch(downloadDocument(key)),
        startGenerateDCDocument: (orderId, payload) => dispatch(generateDCDocument(orderId, payload)),
        startGenerateForm6Document: (orderId, payload) => dispatch(generateForm6Document(orderId, payload))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(DocumentContainer);

