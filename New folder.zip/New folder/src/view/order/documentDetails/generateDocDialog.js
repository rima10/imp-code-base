import React from 'react';
import {
    Button, Dialog
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';

const DCDialog = React.forwardRef(({ onCancel, onSubmit, headerText, onInputChange, components }, ref) => {
    return (<Dialog
        className=""
        ref={ref}
        footer={<div style={spacing.sapUiSmallMargin}>
            <Button style={spacing.sapUiTinyMargin} onClick={onCancel}>Close</Button>
            <Button style={spacing.sapUiTinyMargin} onClick={onSubmit}>Generate</Button></div>}
        headerText={headerText}
        style={{ width: "20%" }}
    >
        <div style={{ display: "flex", justifyContent: "center" }}>
            {components}
        </div>
    </Dialog>);
});
export default DCDialog;
