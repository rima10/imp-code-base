import React, { useState } from 'react';
import { Route, Switch, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import Home from './home/Home';
import BusinessInfo from './account/BusinessInfoRouter';
import PrivateRoute from './login/PrivateRoute';
import LoginSuccess from './login/loginSuccess';
import NetworkInfoView from './account/NetworkInfoView';
import ApproverInfoView from './account/ApproverInfoView';
import WorkflowInfo from './account/WorkflowInfo';
import Header from './header/Header';
import NavBar from './home/NavBar';
import { Grid } from '@ui5/webcomponents-react';
import ErrorComponent from './common/Error';
import MessageBar from './common/MessageBar';
import OrderComponent from './order/OrderComponent';

const Main = ({ userInfo, toast }) => {
    const [isCollapsed, setIsCollapsed] = useState(false);
    const handleSideNavCollapse = (e) => {
        setIsCollapsed(!isCollapsed);
    };
    let indent = 'XL1 L1 M1 S1';
    let span = 'XL10 L10 M10 S10';
    if (isCollapsed) {
        indent = 'XL0 L0 M0 S0';
        span = 'XL12 L12 M12 S12';
    }
    const getMargin = (isCollapsed) => isCollapsed ? { margin: "60px 70px" } : { margin: "60px 0px" };

    return (
        <div>
            <Header userName={userInfo.bp_username} handleSideNavCollapse={handleSideNavCollapse} />
            <Grid>
                <div data-layout-indent="XL0 L0 M0 S0" data-layout-span="XL1 L1 M1 S1">
                    <NavBar isCollapsed={isCollapsed} />
                </div>
                <div style={getMargin(isCollapsed)} data-layout-indent={indent} data-layout-span={span} >
                    {toast.show && <MessageBar message={toast.message} type={toast.status} />}
                    <Switch>
                        <Route path="/loginSuccessful">
                            <LoginSuccess />
                        </Route>
                        <PrivateRoute path="/order" component={OrderComponent} />
                        <PrivateRoute exact path="/account/businessInfo" component={BusinessInfo} />
                        <PrivateRoute exact path="/account/networkInfo" component={NetworkInfoView} />
                        <PrivateRoute exact path="/account/approverInfo" component={ApproverInfoView} />
                        <PrivateRoute exact path="/account/workflowInfo" component={WorkflowInfo} />
                        <PrivateRoute exact path="/dashboard" component={Home} />
                        <PrivateRoute exact path="/" component={Home} />
                        <PrivateRoute exact path="/404" component={() => <ErrorComponent text="Page Not Found" />} />
                        <Redirect from="/" to="/404" />
                    </Switch>
                </div>
            </Grid>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        userInfo: state.userInfo,
        toast: state.toast
    };
};

export default connect(mapStateToProps)(Main);
