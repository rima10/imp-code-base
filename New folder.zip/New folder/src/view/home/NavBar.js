import React, { Component } from 'react';
import { SideNavigation, SideNavigationItem, SideNavigationSubItem } from '@ui5/webcomponents-react';
import { withRouter } from 'react-router-dom';

class NavBar extends Component {
    constructor (props) {
        super(props);
        this.state = {
            activePath: '/',
            orderItems: [
                {
                    path: '/order/newOrder', /* path is used as id to check which NavItem is active basically */
                    name: 'New Order',
                    key: 'key1', /* Key is required, else console throws error. Does this please you Mr. Browser?! */
                    icon: 'create'
                },
                {
                    path: '/order/previousOrder',
                    name: 'Previous Order',
                    key: 'key2',
                    icon: 'present'
                }
            ],
            accountItems: [
                {
                    path: '/account/businessInfo', /* path is used as id to check which NavItem is active basically */
                    name: 'Business Information',
                    key: 'accountKey1', /* Key is required, else console throws error. Does this please you Mr. Browser?! */
                    icon: 'business-card'
                },
                {
                    path: '/account/networkInfo',
                    name: 'Private Network',
                    key: 'accountKey2',
                    icon: 'cancel-share'
                },
                {
                    path: '/account/approverInfo',
                    name: 'Approver Information',
                    key: 'accountKey3',
                    icon: 'customer-and-contacts'
                },
                {
                    path: '/account/workflowInfo',
                    name: 'Workflow Information',
                    key: 'accountKey4',
                    icon: 'add-activity'
                }
            ]
        };
    }
  onSelectionChange = (event) => {
      this.setState({ activePath: event.detail.item.getAttribute('path') });
      let path = event.detail.item.getAttribute('path');
      this.props.history.push(`${path}`);
  }
  render () {
      const { orderItems, accountItems, activePath } = this.state;
      return (
          <>
              <SideNavigation
                  style = {{ position: 'fixed', top: '0', marginTop: '44px', bottom: '0' }}
                  slot=""
                  onSelectionChange={this.onSelectionChange}
                  collapsed={this.props.isCollapsed}>
                  <SideNavigationItem path="#" text="Order Management" expanded icon="sap-icon://sales-order-item">
                      {orderItems.map((item) => (
                          /* Return however many NavItems in array to be rendered */
                          <SideNavigationSubItem id={item.key} path={item.path} text={item.name} active={item.path === activePath} key={item.key} icon={item.icon}/>
                      ))}
                  </SideNavigationItem>
                  <SideNavigationItem path="#" text="Account Management" icon="sap-icon://account">
                      {accountItems.map((item) => (
                          /* Return however many NavItems in array to be rendered */
                          <SideNavigationSubItem id={item.key} path={item.path} text={item.name} active={item.path === activePath} key={item.key} icon={item.icon}/>
                      ))}
                  </SideNavigationItem>
                  <SideNavigationItem path="/dashboard" disabled icon="sap-icon://business-objects-experience" text="Dashboard"/>
              </SideNavigation>
          </>
      );
  }
}

export default withRouter(NavBar);
