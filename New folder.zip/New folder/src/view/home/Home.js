import React, { Component } from 'react';
import { Card, Title, Button } from '@ui5/webcomponents-react';
class Home extends Component {
    constructor (props) {
        super(props);
        this.state = {
            isHidden: true
        };
    }

    toggleHidden () {
        this.setState({
            isHidden: !this.state.isHidden
        });
    }


    render () {
        return (

            <div style={{ display: "grid", flexDirection: "row" }} >

                <Card heading="Home"/>

                <div style={{ width: "100%", display: "flex", margin: "1rem" }}>
                    <Title ><b>Your Recycling Orders</b></Title>
                    <Button design="Emphasized" disabled style={{ right: "0", position: "absolute", marginRight: "4rem" }}>New Order</Button>
                </div>


            </div>


        );
    }
}

export default Home;
