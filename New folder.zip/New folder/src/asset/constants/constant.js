const GST_REGEX = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
const GST_MAXLENGTH = 15;
const PAN_REGEX = /(^([a-zA-Z]{5})([0-9]{4})([a-zA-Z]{1})$)/;
const EMAIL_REGEX = /^\S+@\S+\.\S+$/;
const PHONE_LENGTH = 10;
const COMPANYCODE_LENGTH = 10;

export {
    GST_REGEX,
    GST_MAXLENGTH,
    PAN_REGEX,
    EMAIL_REGEX,
    PHONE_LENGTH,
    COMPANYCODE_LENGTH
};
