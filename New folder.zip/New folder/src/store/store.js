import account from './reducer/accountReducer';
import userInfo from './reducer/loginReducer';
import isLoading from './reducer/loadingReducer';
import order from './reducer/orderReducer';
import messageToaster from './reducer/messageReducer';
import { createStore, applyMiddleware, combineReducers } from "redux";
import thunk from 'redux-thunk';
import { composeWithDevTools } from 'redux-devtools-extension';
import notification from './reducer/notificationReducer';
import documents from './reducer/documentsReducer';
const reducers = {
    account,
    userInfo,
    isLoading,
    order,
    toast: messageToaster,
    notification,
    documents
};
const rootReducer = combineReducers(reducers);
export const store = createStore(rootReducer, composeWithDevTools(applyMiddleware(thunk)));
