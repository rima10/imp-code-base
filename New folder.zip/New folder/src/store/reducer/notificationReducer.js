import { SET_NOTIFICATION_LIST_INFO, SET_NOTIFICATION_READ } from "../action/type";

export default (state = [], action) => {
    const { type, payload } = action;
    switch (type) {
        case SET_NOTIFICATION_LIST_INFO:
            return payload;
        case SET_NOTIFICATION_READ:
            const index = state.findIndex(notification => notification.bpNotificationId === payload.bpNotificationId);
            state[index] = payload;
            return state;
        default:
            return state;
    }
};
