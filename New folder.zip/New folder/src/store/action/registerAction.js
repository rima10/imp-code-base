//import { createStore, applyMiddleware } from "redux";
//import thunk from "redux-thunk";
/*import axios from "axios";
//const store = createStore(rootReducer, applyMiddleware(thunk));
export const registerBusinessPartner = (bpDetail) => {
    return (dispatch) => {
        const params = {
            bpDetail: bpDetail
        };
        axios.post('http://localhost:3000/api/order/createOrder', params).then((response) => {
            console.log(response);
            dispatch({
                type: 'REGISTER_BP',
                payload: response
            });
        })
            .catch(error => {
                console.log('error');
            });
    };
}; */
