import {
    orderInfoLoading,
    setOrderInfo,
    orderInfoFailed,
    orderItemInfoLoading,
    setOrderItemInfo,
    orderItemInfoFailed,
    consolidatedOrderItemInfoLoading,
    setConsolidatedOrderItemInfo,
    consolidatedOrderItemInfoFailed,
    orderQuotationLoading,
    setOrderQuotation,
    orderQuotationFailed,
    setOnsiteVisitDetails,
    onsiteVisitDetailsLoading,
    onsiteVisitDetailsFailed,
    // setTemporaryAcceptQuote,
    setOrderApprover,
    setOrderItemQuotation,
    setOrderDocuments,
    orderDocumentsLoading,
    orderDocumentsFailed,
    orderDocumentsLoaded
} from './type';
import http from '../../utils/httpService';
import { getErrorMessage } from '../../utils/errorMessage';

const API_BASE_URL = 'http://localhost:5000/api/';

export const getOrderInfo = () => async (dispatch, getState) => {
    try {
        dispatch(orderInfoLoading());
        const userId = getState().userInfo.bp_id;
        const response = await http.get(`${API_BASE_URL}order/getOrders/${userId}`, {
            withCredentials: true
        });
        dispatch(setOrderInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderInfoFailed(errorMessage));
    }
};

export const getOrderItemInfo = (orderId) => async (dispatch) => {
    try {
        dispatch(orderItemInfoLoading());
        const response = await http.get(`${API_BASE_URL}order/getOrderByOrderId/${orderId}`, {
            withCredentials: true
        });
        dispatch(setOrderItemInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderItemInfoFailed(errorMessage));
    }
};

export const getConsolidatedOrderItemInfo = (orderId) => async (dispatch) => {
    try {
        dispatch(consolidatedOrderItemInfoLoading());
        const response = await http.get(`${API_BASE_URL}order/getConsolidatedOrderData/${orderId}`, {
            withCredentials: true
        });
        dispatch(setConsolidatedOrderItemInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(consolidatedOrderItemInfoFailed(errorMessage));
    }
};

export const getOrderQuotation = (orderId) => async (dispatch) => {
    try {
        dispatch(orderQuotationLoading());
        const response = await http.get(`${API_BASE_URL}order/quotation/getOrderFirstLevelQuotes/${orderId}`, {
            withCredentials: true
        });
        dispatch(setOrderQuotation(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderQuotationFailed(errorMessage));
    }
};

export const temporaryAcceptQuote = (orderId, quoteId) => async (dispatch, getState) => {
    try {
        // dispatch(orderQuotationLoading());
        await http.post(`${API_BASE_URL}order/quotation/temporaryAcceptQuote/${orderId}/${quoteId}`, null, {
            withCredentials: true
        });
        // dispatch(setTemporaryAcceptQuote(response.data));
        await getOrderQuotation(orderId)(dispatch, getState);
    } catch (error) {
        getErrorMessage(error);
        // dispatch(orderQuotationFailed(errorMessage));
    }
};

export const rejectQuote = (orderId, quoteId) => async (dispatch) => {
    try {
        await http.post(`${API_BASE_URL}order/quotation/rejectQuote/${orderId}/${quoteId}`, {
            withCredentials: true
        });
        await getOrderQuotation(orderId)(dispatch);
    } catch (error) {
        getErrorMessage(error);
    }
};

export const setMoveToNextStep = (orderId, nextStage) => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.bp_id;
        await http.post(`${API_BASE_URL}order/moveOrderToNextStep/${userId}?orderId=${orderId}&nextStage=${nextStage}`, null, {
            withCredentials: true
        });
        await getOrderItemInfo(orderId)(dispatch, getState);
    } catch (error) {
        getErrorMessage(error);
    }
};

export const acceptQuote = (orderId, payload) => async (dispatch, getState) => {
    try {
        await http.post(`${API_BASE_URL}order/quotation/acceptQuote/${orderId}`, payload, {
            withCredentials: true
        });
        await getOrderQuotation(orderId)(dispatch, getState);
        await setMoveToNextStep(orderId, '4')(dispatch, getState);
        // dispatch(setOrderQuotation(response.data));
    } catch (error) {
        getErrorMessage(error);
    }
};

export const getApprover = (orderId, processType, sequenceNo) => async (dispatch) => {
    try {
        // dispatch(orderQuotationLoading());
        const response = await http.get(`${API_BASE_URL}order/getStageApprovalStatus/${orderId}?processType=${processType}&processStageSequence=${sequenceNo}`, {
            withCredentials: true
        });
        dispatch(setOrderApprover(response.data));
    } catch (error) {
        getErrorMessage(error);
    }
};

export const getOnsiteVisitDetails = (orderId) => async (dispatch) => {
    try {
        dispatch(onsiteVisitDetailsLoading());
        const response = await http.get(`${API_BASE_URL}order/quotation/getScheduledOnsiteVisitDetails/${orderId}`, {
            withCredentials: true
        });
        dispatch(setOnsiteVisitDetails(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(onsiteVisitDetailsFailed(errorMessage));
    }
};

export const getOrderItemLevelQuote = (orderId, processType, sequenceNo) => async (dispatch, getState) => {
    try {
        // dispatch(orderQuotationLoading());
        const response = await http.get(`${API_BASE_URL}order/quotation/getOrderItemLevelQuote/${orderId}`, {
            withCredentials: true
        });
        dispatch(setOrderItemQuotation(response.data));
    } catch (error) {
        getErrorMessage(error);
    }
};

export const getOrderDocuments = (orderId) => async (dispatch) => {
    try {
        dispatch(orderDocumentsLoading());
        const response = await http.get(`${API_BASE_URL}order/document/getOrderDocuments/${orderId}`, {
            withCredentials: true
        });
        dispatch(setOrderDocuments(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderDocumentsFailed(errorMessage));
    }
};

export const downloadDocument = (key) => async (dispatch) => {
    try {
        dispatch(orderDocumentsLoading());
        const response = await http.get(`${API_BASE_URL}order/document/downloadDocument/${key}`, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([response.data]);
        const url = window.URL.createObjectURL(responseBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = key;
        a.click();
        dispatch(orderDocumentsLoaded());
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderDocumentsFailed(errorMessage));
    }
};

export const uploadDocument = (orderId, payload) => async (dispatch) => {
    try {
        dispatch(orderDocumentsLoading());
        await http.post(`${API_BASE_URL}order/document/uploadDocument/${orderId}`, payload, {
            withCredentials: true
        });
        dispatch(getOrderDocuments(orderId)(dispatch));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderDocumentsFailed(errorMessage));
    }
};

export const generateDCDocument = (orderId, payload) => async (dispatch) => {
    try {
        dispatch(orderDocumentsLoading());
        const response = await http.post(`${API_BASE_URL}order/document/generateDC/${orderId}`, payload, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([response.data]);
        const url = window.URL.createObjectURL(responseBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Delivery_Challan_${payload.orderNo}.pdf`;
        a.click();
        dispatch(getOrderDocuments(orderId)(dispatch));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderDocumentsFailed(errorMessage));
    }
};

export const generateForm6Document = (orderId, payload) => async (dispatch) => {
    try {
        dispatch(orderDocumentsLoading());
        const response = await http.post(`${API_BASE_URL}order/document/generateForm6/${orderId}`, payload, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([response.data]);
        const url = window.URL.createObjectURL(responseBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Form_6_${payload.orderNo}.pdf`;
        a.click();
        dispatch(getOrderDocuments(orderId)(dispatch));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderDocumentsFailed(errorMessage));
    }
};

export const scheduleLogistics = (orderId, payload) => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.bp_id;
        payload.userId = userId;
        await http.post(`${API_BASE_URL}order/scheduleLogistics/${orderId}`, payload, {
            withCredentials: true
        });
        await setMoveToNextStep(orderId, '6')(dispatch, getState);
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderQuotationFailed(errorMessage));
    }
};

export const createOrderWorkflow = (payload) => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.bp_id;
        await http.post(`${API_BASE_URL}order/workflow/createOrderWorkflow/${userId}`, payload, {
            withCredentials: true
        });
        dispatch(getOrderItemInfo(payload.orderId)(dispatch));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(orderQuotationFailed(errorMessage));
    }
};
