import axios from 'axios';
export async function validate (accessToken) {
    try {
        let options = {
            method: "POST",
            withCredentials: true
        };
        if (accessToken) {
            options.headers = {
                authorization: 'Bearer ' + accessToken
            };
        }
        return new Promise((resolve, reject) => {
            axios('http://localhost:5000/api/auth/validate', options)
                .then(response => {
                    if (response.status === 401) reject(response.statusText);
                    else resolve(response);
                }).catch(error => reject(error));
        });
    } catch (error) {
        return false;
    }
}

export async function getToken () {
    let params = (new URL(document.location)).searchParams;
    let code = params.get("code");
    var details = {
        grant_type: "authorization_code",
        client_id: "6rmm4etrdd625j9da87qkuvpn5",
        code: code,
        redirect_uri: "http://localhost:3001/loginSuccessful"
    };
    var formBody = [];
    for (var property in details) {
        var encodedKey = encodeURIComponent(property);
        var encodedValue = encodeURIComponent(details[property]);
        formBody.push(encodedKey + "=" + encodedValue);
    }
    formBody = formBody.join("&");
    return new Promise((resolve, reject) => {
        fetch('https://reloop.auth.ap-south-1.amazoncognito.com/oauth2/token', {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
            },
            body: formBody
        })
            .then(response => response.json())
            .then(response => {
                resolve(response.id_token);
            }).catch(error => reject(error));
    });
}
