const { Kafka } = require('kafkajs');

const config = { clientId: 'account-management', brokers: ['localhost:29092'] };
// 1.Instantiating kafka
const kafka = new Kafka(config);
// 2.Creating Kafka Producer
const producer = kafka.producer();

exports.runProducer = async function (topic, message) {
  await producer.connect();
  await producer.send({
    topic,
    messages:
          [{ value: JSON.stringify(message) }],
  });
};
