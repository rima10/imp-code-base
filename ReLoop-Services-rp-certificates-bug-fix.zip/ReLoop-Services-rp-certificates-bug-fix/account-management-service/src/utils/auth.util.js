const AWS = require('aws-sdk');
const got = require('got');
const jwkToPem = require('jwk-to-pem');
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
const userService = require('../services/user.service');

exports.ROLES = {
  GP_USER: 'ReLoopGreenPartner',
  RP_USER: 'ReLoopRecyclerPartner',
  GP_APPORVER: 'ReLoopGPApprover',
};

dotenv.config();

const poolData = {
  UserPoolId: process.env.COGNITO_USER_POOL_ID,
  ClientId: process.env.COGNITO_CLIENT_ID,
};
const poolRegion = process.env.POOL_REGION;

AWS.config.update(
  {
    accessKeyId: process.env.COGNITO_ACCESS_ID,
    secretAccessKey: process.env.COGNITO_SECRET_KEY,
    region: process.env.POOL_REGION,
  },
);

const COGNITO_CLIENT = new AWS.CognitoIdentityServiceProvider({
  region: process.env.POOL_REGION,
});

/*
  @desc Fetch JSONWebKeys from cognito to validate the JWT token
  @desc JWKs is fetched dynamically everytime for security resons as well as it can change in future
  @return Object - pems
*/
async function fetchJwks() {
  const url = `https://cognito-idp.${poolRegion}.amazonaws.com/${poolData.UserPoolId}/.well-known/jwks.json`;
  const jwks = await got(url, { responseType: 'json' });
  const pems = {};
  const { keys } = jwks.body;
  for (let i = 0; i < keys.length; i += 1) {
    const keyId = keys[i].kid;
    const jwk = { kty: keys[i].kty, n: keys[i].n, e: keys[i].e };
    const pem = jwkToPem(jwk);
    pems[keyId] = pem;
  }
  return pems;
}

/*
  @desc validates JWT token with pems
  @param Object pems
  @param String token
  @return Object - pems
*/
async function validateJWT(pems, token) {
  try {
    const decodedJwt = jwt.decode(token, { complete: true });
    if (!decodedJwt) {
      throw new Error('not a valid JWT token');
    }
    const { kid } = decodedJwt.header;
    const pem = pems[kid];
    if (!pem) {
      throw new Error('not a valid JWT token');
    }
    await jwt.verify(token, pem);
    return decodedJwt;
  } catch (error) {
    throw new Error('not a valid JWT token');
  }
}

// returns an object with the cookies' name as keys
function getCookies(req) {
  // We extract the raw cookies from the request headers
  if (!req.headers.cookie) return req.headers.cookie;
  const rawCookies = req.headers.cookie.split('; ');
  const parsedCookies = {};
  rawCookies.forEach((rawCookie) => {
    const parsedCookie = rawCookie.split('=');
    const [key, val] = parsedCookie;
    parsedCookies[key] = val;
  });
  return parsedCookies;
}

const getCognitoUser = async (userData) => new Promise((resolve) => {
  const cognitoUserData = { ...userData };
  delete cognitoUserData.TemporaryPassword;
  COGNITO_CLIENT.adminGetUser(cognitoUserData, (error, data) => {
    if (error) resolve(false);
    else {
      resolve(data.Username);
    }
  });
});

const addUserToGroup = async (cognitoUserGroupData) => new Promise((resolve, reject) => {
  COGNITO_CLIENT.adminAddUserToGroup(cognitoUserGroupData, (err, groupData) => {
    if (err) reject(err);
    else resolve({ groupData });
  });
});

const createUser = async (userData) => new Promise((resolve, reject) => {
  COGNITO_CLIENT.adminCreateUser(userData, (error, data) => {
    if (error) reject(error);
    else {
      resolve(data.User.Username);
    }
  });
});

exports.createCognitouser = async function createCognitouser(userData, userGroupData) {
  let existingUser = await getCognitoUser(userData);
  if (!existingUser) {
    existingUser = await createUser(userData);
  }
  const cognitoUserGroupData = { ...userGroupData };
  cognitoUserGroupData.Username = existingUser;
  await addUserToGroup(cognitoUserGroupData);
  return existingUser;
};

exports.deleteCognitouser = async function deleteCognitouser(userData) {
  return new Promise((resolve, reject) => {
    COGNITO_CLIENT.adminDeleteUser(userData, (error, data) => {
      if (error) reject(error);
      else {
        resolve(data);
      }
    });
  });
};

/*
  @desc controller function to validate JWT token
  @desc JWKs is fetched dynamically everytime for security resons as well as it can change in future
*/
exports.validate = async function validate(req, res, next) {
  try {
    const pems = await fetchJwks();
    const token = req.headers.authorization;
    await validateJWT(pems, token);
    res.send(200);
    return;
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to validate JWT token
  @desc JWKs is fetched dynamically everytime for security resons as well as it can change in future
  @return Object - pems
*/
exports.validateMiddleware = async function validateMiddleware(req, res, next) {
  try {
    const pems = await fetchJwks();
    let { authorization } = req.headers;
    if (!authorization) authorization = getCookies(req).authorization;
    else {
      const [, token] = authorization.split(' ');
      authorization = token;
    }
    const decodedJWT = await validateJWT(pems, authorization);
    req.userInfo = decodedJWT.payload;
    next();
  } catch (error) {
    res.status(401).json({
      error: {
        message: 'Unauthorized',
      },
    });
    next(error);
  }
};

exports.isGpUser = function (req, res, next) {
  try {
    const groups = req.userInfo['cognito:groups'];
    if (!groups.includes(exports.ROLES.GP_USER)) {
      res.status(403).json({
        error: {
          message: 'Unauthorized',
        },
      });
    } else next();
  } catch (error) {
    next(error);
  }
};

exports.isUserAsset = async function (req, res, next) {
  try {
    const username = req.userInfo['cognito:username'];
    const userData = await userService.getUserDatabyCognito(username);
    if (req.params.userId && userData.bp_id !== req.params.userId) {
      res.status(403).json({
        error: {
          message: 'Unauthorized to access the data',
        },
      });
    } else if (req.params.recyclerId && userData.bp_id !== req.params.recyclerId) {
      res.status(403).json({
        error: {
          message: 'Unauthorized to access the data',
        },
      });
    } else next();
  } catch (error) {
    next(error);
  }
};

exports.isGpOrRp = (req, res, next) => {
  try {
    const groups = req.userInfo['cognito:groups'];
    if (!(groups.includes(exports.ROLES.RP_USER) || groups.includes(exports.ROLES.GP_USER))) {
      res.status(403).json({
        error: {
          message: 'Unauthorized',
        },
      });
    } else next();
  } catch (error) {
    next(error);
  }
};

exports.isRpUser = function (req, res, next) {
  try {
    const groups = req.userInfo['cognito:groups'];
    if (!groups.includes(exports.ROLES.RP_USER)) {
      res.status(403).json({
        error: {
          message: 'Unauthorized',
        },
      });
    } else next();
  } catch (error) {
    next(error);
  }
};
