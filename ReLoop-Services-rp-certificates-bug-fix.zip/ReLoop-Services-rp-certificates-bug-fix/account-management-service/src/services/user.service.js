const { DataTypes, Op } = require('sequelize');
const { sequelize } = require('../models/index');
const User = require('../models/business_partner')(sequelize, DataTypes);
const Role = require('../models/role_bp_mapping')(sequelize, DataTypes);
const Models = require('../models/init-models')(sequelize, DataTypes);
const ServiceableLocation = require('../models/serviceable_location')(sequelize, DataTypes);

async function createBpUser(payload) {
  const userData = {
    bp_userid: payload.bp_userid,
    bp_username: payload.bp_username,
    bp_email_id: payload.bp_email_id,
    archive: payload.archive,
  };
  const result = await User.create(userData);
  const roleId = payload.role_id;
  const bpId = result.dataValues.bp_id;
  const roleMapping = {
    bp_id: bpId,
    role_id: roleId,
  };
  await Role.create(roleMapping);
}

exports.getUserDatabyCognito = async function (cognitoId, bp) {
  let isBusinessDataPresent;
  const user = await User.findOne({
    where: {
      bp_userid: cognitoId,
      // Will be used when existing useer archive flag is set to false
      // [Op.not]: [{ archive: true }],
    },
    atrributes: ['bp_id', 'bp_username', 'bp_email_id', 'bp_phone_number', 'loc_id',
      'gst_number', 'industry_type', 'cin', 'pan', 'is_part_of_pvt_nwk'],
  });
  if (!user) throw new Error('Invalid or inactive user');
  const {
    bp_id, bp_username, bp_email_id, gst_number, bp_phone_number, industry_type, cin, pan,
    loc_id, is_part_of_pvt_nwk,
  } = user;
  if (bp === 'gp') {
    isBusinessDataPresent = (gst_number !== null && bp_phone_number !== null
      && industry_type !== null && cin !== null && pan !== null && loc_id !== null);
  } else if (bp === 'rp') {
    const certificateQuery = {
      bp_id,
      cert_name: {
        [Op.or]: ['State Pollution Control Board Authorization', 'Authorization under Hazardous & Other Wastes'],
      },
    };
    const serviceableLoc = await ServiceableLocation.findOne({ where: { rcy_id: bp_id }, attributes: [['serv_loc_id', 'servLocId']] });
    const certificates = await Models.certificate.findAll({ where: certificateQuery, attributes: ['cert_id'] });
    isBusinessDataPresent = (gst_number !== null && loc_id !== null
      && serviceableLoc !== null && bp_phone_number !== null
      && cin !== null && pan !== null && certificates.length >= 2);
  }
  const userData = {
    bp_id,
    bp_username,
    bp_email_id,
    isPartOfPvtNwk: is_part_of_pvt_nwk,
    isBusinessDataPresent,
    bpPhoneNumber: bp_phone_number,
  };
  return userData;
};

exports.getApproverDatabyCognito = async (cognitoId) => {
  const approver = await Models.approver.findOne({
    where: {
      approver_userid: cognitoId,
    },
    attributes: [['approver_id', 'approverId'],
      ['approver_role', 'approverRole'],
      ['approver_name', 'approverName'],
      ['approver_email_id', 'approverEmailId']],
  });
  return approver;
};
/*
  @desc service to create user data
*/
exports.register = async function (req) {
  const userData = req.body;
  userData.archive = false;
  await createBpUser(req.body);
};

/*
  @desc service function to get user data
*/
exports.getUserData = async (req, res, next) => {
  try {
    const { cognitoId } = req.params;
    const { approver, bp } = req.query;
    let userData = null;
    if (approver) userData = await exports.getApproverDatabyCognito(cognitoId);
    else userData = await exports.getUserDatabyCognito(cognitoId, bp);
    return userData;
  } catch (error) {
    res.status(401).json({
      message: error.message,
    });
    return next(error);
  }
};
