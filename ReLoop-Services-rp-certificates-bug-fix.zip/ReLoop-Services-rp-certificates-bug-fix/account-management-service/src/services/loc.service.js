const dataTypes = require('sequelize').DataTypes;
const { sequelize } = require('../models/index');
const Country = require('../models/country')(sequelize, dataTypes);
const State = require('../models/state')(sequelize, dataTypes);
const City = require('../models/city')(sequelize, dataTypes);
const utilFunctions = require('../utils/commonFunctions.util');

/*
  @desc service function to create addresses
  @desc loop over address list and create address
  @desc check if country/state/city exists, if not create new
*/
exports.createAddress = async function (req, res, next) {
  const { addresses } = req.body;
  // eslint-disable-next-line no-restricted-syntax
  for (const address of addresses) {
    // eslint-disable-next-line no-await-in-loop
    let country = await Country.findOne({ where: { country_name: address.countryName } });
    if (!country) {
      // eslint-disable-next-line no-await-in-loop
      await Country.create({ country_name: address.countryName });
    }
    // eslint-disable-next-line no-await-in-loop
    country = await Country.findOne({ where: { country_name: address.countryName } });
    // eslint-disable-next-line no-await-in-loop
    let state = await State.findOne({ where: { state_name: address.stateName } });
    if (!state) {
      // eslint-disable-next-line no-await-in-loop
      await State.create({ state_name: address.stateName, country_id: country.country_id });
    }
    // eslint-disable-next-line no-await-in-loop
    state = await State.findOne({ where: { state_name: address.stateName } });
    // eslint-disable-next-line no-await-in-loop
    const city = await City.findOne({ where: { city_name: address.cityName } });
    if (!city) {
      // eslint-disable-next-line no-await-in-loop
      await City.create({ city_name: address.cityName, state_id: state.state_id });
    }
  }
};

/*
  @desc service function to create country
  @desc loop over country list and create country
*/
exports.createCountry = async function (req, res, next) {
  const { countries } = req.body;
  await Promise.all(countries.map(async (country) => {
    Country.create(utilFunctions.camelCaseToUnderScore(country));
  }));
};

/*
  @desc service function to create state
  @desc loop over state list and create state
*/
exports.createState = async function (req, res, next) {
  const { states } = req.body;
  await Promise.all(states.map(async (state) => {
    Country.create(utilFunctions.camelCaseToUnderScore(state));
  }));
};

/*
  @desc service function to create city
  @desc loop over city list and create city
*/
exports.createCity = async function (req, res, next) {
  const { cities } = req.body;
  await Promise.all(cities.map(async (city) => {
    Country.create(utilFunctions.camelCaseToUnderScore(city));
  }));
};

/*
  @desc service function to get country list
*/
exports.getCountryList = async function (req, res, next) {
  try {
    const countries = await Country.findAll();
    return countries;
  } catch (error) {
    next(error);
  }
};

/*
  @desc service function to get country
*/
exports.getCountry = async function (req, res, next) {
  try {
    const country = await Country.getAll();
    return country;
  } catch (error) {
    next(error);
  }
};

/*
  @desc service function to get state list
*/
exports.getStateList = async function (req, res, next) {
  try {
    const states = await State.findAll();
    return states;
  } catch (error) {
    next(error);
  }
};

/*
  @desc service function to get state by country
*/
exports.getStatesbyCountry = async function (req, res, next) {
  try {
    const states = await State.findAll({
      where: { country_id: req.params.countryId },
      order: [
        ['state_name', 'ASC'],
      ],
    });
    return states;
  } catch (error) {
    next(error);
  }
};

/*
  @desc service function to get state
*/
exports.getState = async function (req, res, next) {
  try {
    const state = await State.findOne({ where: { state_id: req.params.stateId } });
    return state;
  } catch (error) {
    next(error);
  }
};

/*
  @desc service function to get city list
*/
exports.getCityList = async function (req, res, next) {
  try {
    const cities = await City.findAll();
    return cities;
  } catch (error) {
    next(error);
  }
};

/*
  @desc service function to get city by state
*/
exports.getCitiesByState = async function (req, res, next) {
  try {
    const cities = await City.findAll({
      where: { state_id: req.params.stateId },
      order: [
        ['city_name', 'ASC'],
      ],
    });
    return cities;
  } catch (error) {
    next(error);
  }
};

/*
  @desc service function to get city
*/
exports.getCity = async function (req, res, next) {
  try {
    // TODO
    const city = await City.find(req);
    return city;
  } catch (error) {
    next(error);
  }
};
