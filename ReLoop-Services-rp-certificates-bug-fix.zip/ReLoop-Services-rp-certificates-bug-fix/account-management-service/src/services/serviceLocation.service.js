const dataTypes = require('sequelize').DataTypes;
const { sequelize } = require('../models/index');
const ServiceableCity = require('../models/serviceable_city')(sequelize, dataTypes);
const ServiceableState = require('../models/serviceable_state')(sequelize, dataTypes);
const ServiceableLocation = require('../models/serviceable_location')(sequelize, dataTypes);
const Models = require('../models/init-models')(sequelize, dataTypes);

async function getServicableLocation(recyclerId) {
  const serviceableLocations = await Models.serviceable_location.findAll({
    where: { rcy_id: recyclerId },
    attributes: [['serv_loc_id', 'servLocId'], ['is_all_state', 'isAllState'], ['country_id', 'countryId']],
    include: [{
      model: Models.serviceable_state,
      attributes: [['state_id', 'stateId'], ['state_name', 'stateName'], ['is_all_city', 'isAllCity']],
      as: 'serviceable_states',
      include: [
        {
          model: Models.serviceable_city,
          attributes: [['city_id', 'cityId'], ['city_name', 'cityName']],
          as: 'serviceable_cities',
        }],
    }],
  });
  return serviceableLocations;
}
async function deleteServicableLocation(isAllState, existingServiceableLocation, statesDetail) {
  if (isAllState === true) {
    await Models.serviceable_location.update({ is_all_state: false },
      { where: { serv_loc_id: existingServiceableLocation.dataValues.servLocId } });
    await Models.serviceable_state.destroy(
      {
        where: {
          serv_loc_id: existingServiceableLocation.dataValues.servLocId,
        },
      },
    );
  } else {
    await Models.serviceable_state.destroy(
      {
        where: {
          state_id: statesDetail,
          serv_loc_id: existingServiceableLocation.dataValues.servLocId,
        },
      },
    );
  }
}
async function addRecyclerServicableLocation(serviceLocations, servLocId) {
  await Promise.all(serviceLocations.map(async (serviceLocation) => {
    const existingServiceableState = await ServiceableState.findOne({
      where: {
        serv_loc_id: servLocId,
        state_id: serviceLocation.state,
      },
      attributes: [['state_id', 'stateId']],
    });
    if (!existingServiceableState) {
      if (serviceLocation.isAllCitySelected) {
        await ServiceableState.create({
          serv_loc_id: servLocId,
          state_id: serviceLocation.state,
          state_name: serviceLocation.stateName,
          is_all_city: true,
        });
      } else {
        const serviceLocationCities = serviceLocation.city;
        const serviceableState = await ServiceableState.create({
          serv_loc_id: servLocId,
          state_id: serviceLocation.state,
          state_name: serviceLocation.stateName,
          is_all_city: false,
        });
        await Promise.all(serviceLocationCities.map(async (serviceLocationCity) => {
          await ServiceableCity.create({
            serv_loc_state_id: serviceableState.serv_loc_state_id,
            city_id: serviceLocationCity.cityId,
            city_name: serviceLocationCity.cityName,
          });
        }));
      }
    }
  }));
}

/*
  @desc service function to create service location for a recycler
*/
exports.addServicableLocation = async function (req) {
  const { recyclerId } = req.params;
  const { serviceLocations, isAllStateSelected, countryId } = req.body;
  const existingServiceableLocation = await ServiceableLocation.findOne({
    where: {
      rcy_id: recyclerId,
    },
    attributes: [['serv_loc_id', 'servLocId'], ['is_all_state', 'isAllState']],
  });

  if (isAllStateSelected) {
    if (!existingServiceableLocation) {
      await ServiceableLocation.create({
        rcy_id: recyclerId,
        country_id: countryId,
        is_all_state: true,
      });
    } else {
      await deleteServicableLocation(true, existingServiceableLocation);
      await ServiceableLocation.update({
        is_all_state: true,
      }, {
        where: {
          rcy_id: recyclerId,
          serv_loc_id: existingServiceableLocation.dataValues.servLocId,
        },
      });
    }
  } else {
    let servLocId;
    if (existingServiceableLocation) {
      servLocId = existingServiceableLocation.dataValues.servLocId;
      await ServiceableLocation.update({
        is_all_state: isAllStateSelected,
      }, {
        where: {
          rcy_id: recyclerId,
          serv_loc_id: servLocId,
        },
      });
      await addRecyclerServicableLocation(serviceLocations, servLocId);
    } else {
      const serviceableLocation = await ServiceableLocation.create({
        rcy_id: recyclerId,
        country_id: countryId,
        is_all_state: false,
      });
      servLocId = serviceableLocation.serv_loc_id;
      await addRecyclerServicableLocation(serviceLocations, servLocId);
    }
  }
};

/*
  @desc service function to get servicable Location of a recycler
*/
exports.getRecyclerServicableLocation = async (req, res, next) => {
  try {
    const { recyclerId } = req.params;
    const rcyServicableLocation = await getServicableLocation(recyclerId);
    return rcyServicableLocation;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to delete service location
*/
exports.deleteServiceableLocation = async (req, res, next) => {
  try {
    const { recyclerId } = req.params;
    const { statesDetail, isAllState } = req.body;
    const existingServiceableLocation = await ServiceableLocation.findOne({
      where: {
        rcy_id: recyclerId,
      },
      attributes: [['serv_loc_id', 'servLocId'], ['is_all_state', 'isAllState']],
    });
    await deleteServicableLocation(isAllState, existingServiceableLocation, statesDetail);
    const rcyServicableLocation = await getServicableLocation(recyclerId);
    return rcyServicableLocation;
  } catch (error) {
    return next(error);
  }
};
