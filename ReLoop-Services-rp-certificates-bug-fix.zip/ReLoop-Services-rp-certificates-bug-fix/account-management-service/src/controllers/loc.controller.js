const locService = require('../services/loc.service');

/*
  @desc controller function to create addresses
*/
exports.createAddress = async function (req, res, next) {
  try {
    await locService.createAddress(req, res, next);
    res.send(200);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to create country
*/
exports.createCountry = async function (req, res, next) {
  try {
    await locService.createCountry(req, res, next);
    res.send(200);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to create states
*/
exports.createState = async function (req, res, next) {
  try {
    await locService.createState(req, res, next);
    res.send(200);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to create city
*/
exports.createCity = async function (req, res, next) {
  try {
    await locService.createCity(req, res, next);
    res.send(200);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get country list
*/
exports.getCountryList = async function (req, res, next) {
  try {
    const countries = await locService.getCountryList(req, res, next);
    res.json(countries);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get country
*/
exports.getCountry = async function (req, res, next) {
  try {
    const country = await locService.getCountry(req, res, next);
    res.json(country);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get state list
*/
exports.getStateList = async function (req, res, next) {
  try {
    const states = await locService.getStateList(req, res, next);
    res.json(states);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get state by country
*/
exports.getStatesbyCountry = async function (req, res, next) {
  try {
    const states = await locService.getStatesbyCountry(req, res, next);
    res.json(states);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get state
*/
exports.getState = async function (req, res, next) {
  try {
    const state = await locService.getState(req, res, next);
    res.json(state);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get city list
*/
exports.getCityList = async function (req, res, next) {
  try {
    const cities = await locService.getCityList(req, res, next);
    res.json(cities);
  } catch (error) {
    next(error);
  }
};
/*
  @desc controller function to get city by state
*/
exports.getCitiesByState = async function (req, res, next) {
  try {
    const cities = await locService.getCitiesByState(req, res, next);
    res.json(cities);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get city
*/
exports.getCity = async function (req, res, next) {
  try {
    const city = await locService.getCity(req, res, next);
    res.json(city);
  } catch (error) {
    next(error);
  }
};
