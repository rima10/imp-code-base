exports.options = {
  definition: {
    openapi: '3.0.1',
    info: {
      title: 'ReLoop Account Management swagger API',
      version: '0.1.0',
      description:
          'ReLoop Account Management service documented with swagger',
    },
    host: 'localhost:5001',
    basePath: '/api/user',
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
        },
      },
    },
    security: [{
      bearerAuth: [],
    }],
  },

  apis: ['./src/models/**.js', './src/routes/**.route.js'],
};
