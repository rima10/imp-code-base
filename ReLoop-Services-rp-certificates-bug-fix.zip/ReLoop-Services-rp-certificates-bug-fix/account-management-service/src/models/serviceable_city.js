module.exports = function (sequelize, DataTypes) {
  return sequelize.define('serviceable_city', {
    serv_city_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    serv_loc_state_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'serviceable_state',
        key: 'serv_loc_state_id',
      },
    },
    city_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'city',
        key: 'city_id',
      },
    },
    city_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'serviceable_city',
    schema: 'address',
    timestamps: false,
    indexes: [
      {
        name: 'serviceable_city_pkey',
        unique: true,
        fields: [
          { name: 'serv_city_id' },
        ],
      },
    ],
  });
};
