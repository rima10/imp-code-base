const attributesMap = [
  ['certificateId', 'cert_id'],
  ['certificateType', 'cert_type'],
  ['certificateStorageMeta', 'cert_details'],
  ['certificateName', 'cert_name'],
  ['authorizationNumber', 'authorization_number'],
  ['recyclingCapacity', 'rcy_unit_capacity'],
  ['validPeriod', 'valid_period'],
  ['issuedDate', 'issued_date'],
  ['businessPartnerId', 'bp_id'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

/**
 * @swagger
 *  components:
 *    schemas:
 *      Certificate:
 *        type: object
 *        required:
 *        properties:
 *          cert_id:
 *            type: integer
 *          cert_type:
 *            type: string
 *          cert_details:
 *            type: string
 *          cert_name:
 *            type: string
 *          rcy_unit_capacity:
 *            type: integer
 *          valid_period:
 *            type: date
 *          issued_date:
 *            type: date
 *          bp_id:
 *            type: integer
 *        example:
 *           certificateId: 1
 *           certificateType: State Pollution Control Board Authorization
 *           certificateStorageMeta: PRNWK 1_9_State Pollution Control Board Authorization.txt
 *           certificateName: State Pollution Control Board Authorization
 *           authorizationNumber: 123asv
 *           recyclingCapacity: 100
 *           validPeriod: 2022-01-31
 *           issuedDate: 2019-01-31
 *           businessPartnerId: 9
 */
module.exports = function (sequelize, DataTypes) {
  const model = sequelize.define('certificate', {
    cert_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    cert_type: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    cert_details: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    authorization_number: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    rcy_unit_capacity: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    valid_period: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    issued_date: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    cert_name: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: 'cert_unique',
    },
    bp_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      unique: 'cert_unique',
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
  }, {
    sequelize,
    tableName: 'certificate',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'certificate_pkey',
        unique: true,
        fields: [
          { name: 'cert_id' },
        ],
      },
    ],
  });

  model.associate = (models) => {
    model.belongsTo(models.business_partner, { as: 'bp', foreignKey: 'bp_id' });
  };

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;
  return model;
};
