module.exports = function (sequelize, DataTypes) {
  return sequelize.define('role_bp_mapping', {
    map_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    bp_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'business_partner',
        key: 'bp_id',
      },
    },
    role_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'role',
        key: 'role_id',
      },
    },
  }, {
    sequelize,
    tableName: 'role_bp_mapping',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'role_bp_mapping_pkey',
        unique: true,
        fields: [
          { name: 'map_id' },
        ],
      },
    ],
  });
};
