var DataTypes = require("sequelize").DataTypes;
var _approver = require("./approver");
var _bp_notification = require("./bp_notification");
var _bp_private_nwk = require("./bp_private_nwk");
var _business_partner = require("./business_partner");
var _category = require("./category");
var _certificate = require("./certificate");
var _city = require("./city");
var _country = require("./country");
var _doc = require("./doc");
var _event = require("./event");
var _location = require("./location");
var _notification = require("./notification");
var _process_type = require("./process_type");
var _role = require("./role");
var _role_bp_mapping = require("./role_bp_mapping");
var _serviceable_city = require("./serviceable_city");
var _serviceable_location = require("./serviceable_location");
var _serviceable_state = require("./serviceable_state");
var _state = require("./state");
var _workflow = require("./workflow");
var _workflow_approver = require("./workflow_approver");

function initModels(sequelize) {
  var approver = _approver(sequelize, DataTypes);
  var bp_notification = _bp_notification(sequelize, DataTypes);
  var bp_private_nwk = _bp_private_nwk(sequelize, DataTypes);
  var business_partner = _business_partner(sequelize, DataTypes);
  var category = _category(sequelize, DataTypes);
  var certificate = _certificate(sequelize, DataTypes);
  var city = _city(sequelize, DataTypes);
  var country = _country(sequelize, DataTypes);
  var doc = _doc(sequelize, DataTypes);
  var event = _event(sequelize, DataTypes);
  var location = _location(sequelize, DataTypes);
  var notification = _notification(sequelize, DataTypes);
  var process_type = _process_type(sequelize, DataTypes);
  var role = _role(sequelize, DataTypes);
  var role_bp_mapping = _role_bp_mapping(sequelize, DataTypes);
  var serviceable_city = _serviceable_city(sequelize, DataTypes);
  var serviceable_location = _serviceable_location(sequelize, DataTypes);
  var serviceable_state = _serviceable_state(sequelize, DataTypes);
  var state = _state(sequelize, DataTypes);
  var workflow = _workflow(sequelize, DataTypes);
  var workflow_approver = _workflow_approver(sequelize, DataTypes);
  serviceable_location.belongsTo(business_partner, { as: "rcy", foreignKey: "rcy_id"});
  business_partner.hasMany(serviceable_location, { as: "serviceable_locations", foreignKey: "rcy_id"});
  location.belongsTo(city, { as: "city", foreignKey: "city_id"});
  city.hasMany(location, { as: "locations", foreignKey: "city_id"});
  serviceable_city.belongsTo(city, { as: "city", foreignKey: "city_id"});
  city.hasMany(serviceable_city, { as: "serviceable_cities", foreignKey: "city_id"});
  location.belongsTo(country, { as: "country", foreignKey: "country_id"});
  country.hasMany(location, { as: "locations", foreignKey: "country_id"});
  serviceable_location.belongsTo(country, { as: "country", foreignKey: "country_id"});
  country.hasMany(serviceable_location, { as: "serviceable_locations", foreignKey: "country_id"});
  state.belongsTo(country, { as: "country", foreignKey: "country_id"});
  country.hasMany(state, { as: "states", foreignKey: "country_id"});
  serviceable_state.belongsTo(serviceable_location, { as: "serv_loc", foreignKey: "serv_loc_id"});
  serviceable_location.hasMany(serviceable_state, { as: "serviceable_states", foreignKey: "serv_loc_id"});
  serviceable_city.belongsTo(serviceable_state, { as: "serv_loc_state", foreignKey: "serv_loc_state_id"});
  serviceable_state.hasMany(serviceable_city, { as: "serviceable_cities", foreignKey: "serv_loc_state_id"});
  city.belongsTo(state, { as: "state", foreignKey: "state_id"});
  state.hasMany(city, { as: "cities", foreignKey: "state_id"});
  location.belongsTo(state, { as: "state", foreignKey: "state_id"});
  state.hasMany(location, { as: "locations", foreignKey: "state_id"});
  serviceable_state.belongsTo(state, { as: "state", foreignKey: "state_id"});
  state.hasMany(serviceable_state, { as: "serviceable_states", foreignKey: "state_id"});
  bp_notification.belongsTo(approver, { as: "approver", foreignKey: "approver_id"});
  approver.hasMany(bp_notification, { as: "bp_notifications", foreignKey: "approver_id"});
  bp_notification.belongsTo(business_partner, { as: "bp", foreignKey: "bp_id"});
  business_partner.hasMany(bp_notification, { as: "bp_notifications", foreignKey: "bp_id"});
  notification.belongsTo(event, { as: "event", foreignKey: "event_id"});
  event.hasMany(notification, { as: "notifications", foreignKey: "event_id"});
  bp_notification.belongsTo(notification, { as: "notification", foreignKey: "notification_id"});
  notification.hasMany(bp_notification, { as: "bp_notifications", foreignKey: "notification_id"});
  workflow_approver.belongsTo(approver, { as: "approver", foreignKey: "approver_id"});
  approver.hasMany(workflow_approver, { as: "workflow_approvers", foreignKey: "approver_id"});
  approver.belongsTo(business_partner, { as: "bp", foreignKey: "bp_id"});
  business_partner.hasMany(approver, { as: "approvers", foreignKey: "bp_id"});
  bp_private_nwk.belongsTo(business_partner, { as: "nwk_owner_business_partner", foreignKey: "nwk_owner"});
  business_partner.hasMany(bp_private_nwk, { as: "bp_private_nwks", foreignKey: "nwk_owner"});
  bp_private_nwk.belongsTo(business_partner, { as: "nwk_member_business_partner", foreignKey: "nwk_member"});
  business_partner.hasMany(bp_private_nwk, { as: "nwk_member_bp_private_nwks", foreignKey: "nwk_member"});
  certificate.belongsTo(business_partner, { as: "bp", foreignKey: "bp_id"});
  business_partner.hasMany(certificate, { as: "certificates", foreignKey: "bp_id"});
  role_bp_mapping.belongsTo(business_partner, { as: "bp", foreignKey: "bp_id"});
  business_partner.hasMany(role_bp_mapping, { as: "role_bp_mappings", foreignKey: "bp_id"});
  workflow.belongsTo(business_partner, { as: "bp", foreignKey: "bp_id"});
  business_partner.hasMany(workflow, { as: "workflows", foreignKey: "bp_id"});
  business_partner.belongsTo(location, { as: "loc", foreignKey: "loc_id"});
  location.hasMany(business_partner, { as: "business_partners", foreignKey: "loc_id"});
  workflow.belongsTo(process_type, { as: "process_type", foreignKey: "process_type_id"});
  process_type.hasMany(workflow, { as: "workflows", foreignKey: "process_type_id"});
  role_bp_mapping.belongsTo(role, { as: "role", foreignKey: "role_id"});
  role.hasMany(role_bp_mapping, { as: "role_bp_mappings", foreignKey: "role_id"});
  workflow_approver.belongsTo(workflow, { as: "workflow", foreignKey: "workflow_id"});
  workflow.hasMany(workflow_approver, { as: "workflow_approvers", foreignKey: "workflow_id"});
  return {
    approver,
    bp_notification,
    bp_private_nwk,
    business_partner,
    category,
    certificate,
    city,
    country,
    doc,
    event,
    location,
    notification,
    process_type,
    role,
    role_bp_mapping,
    serviceable_city,
    serviceable_location,
    serviceable_state,
    state,
    workflow,
    workflow_approver,
  };
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;
