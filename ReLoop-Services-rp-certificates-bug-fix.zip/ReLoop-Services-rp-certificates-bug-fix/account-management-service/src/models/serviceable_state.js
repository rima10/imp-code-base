module.exports = function (sequelize, DataTypes) {
  return sequelize.define('serviceable_state', {
    serv_loc_state_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    serv_loc_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'serviceable_location',
        key: 'serv_loc_id',
      },
    },
    state_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'state',
        key: 'state_id',
      },
    },
    state_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    is_all_city: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
  }, {
    sequelize,
    tableName: 'serviceable_state',
    schema: 'address',
    timestamps: false,
    indexes: [
      {
        name: 'serviceable_state_pkey',
        unique: true,
        fields: [
          { name: 'serv_loc_state_id' },
        ],
      },
    ],
  });
};
