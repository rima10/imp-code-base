const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('bp_notification', {
    bp_notification_id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    bp_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'business_partner',
        key: 'bp_id'
      }
    },
    approver_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'approver',
        key: 'approver_id'
      }
    },
    notification_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'notification',
        key: 'notification_id'
      }
    },
    is_read: {
      type: DataTypes.BOOLEAN,
      allowNull: true
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP')
    }
  }, {
    sequelize,
    tableName: 'bp_notification',
    schema: 'notification',
    timestamps: false,
    indexes: [
      {
        name: "bp_notification_pkey",
        unique: true,
        fields: [
          { name: "bp_notification_id" },
        ]
      },
    ]
  });
};
