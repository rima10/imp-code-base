const router = require('express').Router();
const multer = require('multer');

const upload = multer();

const userController = require('../controllers/user.controller');
const validator = require('../utils/validate.util');
const authUtil = require('../utils/auth.util');

/*
  @desc router configuartion for /api/user endpoint
*/

module.exports = (app) => {
  /**
 * @swagger
 * /api/user/register:
 *   post:
 *    description:  Endpoint to register business partner
 *    tags:
 *      - Business Partner
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/User'
 *    responses:
 *      200:
 *        description: Successfully Registered Business Partner.
 */
  router.post('/register', validator.createUserValidations, validator.validate, userController.register);

  /**
 * @swagger
 * /api/user/update/{userId}:
 *   patch:
 *    description:  Endpoint to update business partner
 *    tags:
 *      - Business Partner
 *    parameters:
 *       - name: userId
 *         description: id of the business partner
 *         in: path
 *         required: true
 *         type: number
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/User'
 */
  router.patch('/update/:userId', [authUtil.validateMiddleware, authUtil.isGpOrRp, authUtil.isUserAsset], userController.updateUserBusinessData);

  /**
 * @swagger
 * /api/user/getBusinessInfo/{userId}:
 *   get:
 *    description:  Endpoint to update business partner
 *    tags:
 *      - Business Partner
 *    parameters:
 *       - name: userId
 *         description: id of the business partner
 *         in: path
 *         required: true
 *         type: number
 *    responses:
 *       200:
 *         description: A list of user's private networks.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/User'
 */
  router.get('/getBusinessInfo/:userId', [authUtil.validateMiddleware, authUtil.isGpOrRp, authUtil.isUserAsset], userController.getUserBusinessData);
  /**
 * @swagger
 * /api/user/createprivatenetwork/{userId}:
 *   post:
 *    description:  Endpoint to create business partner private network
 *    tags:
 *      - Private Network
 *    parameters:
 *       - name: userId
 *         description: id of the private network owner
 *         in: path
 *         required: true
 *         type: number
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              pvtNwkMembers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    emailId:
 *                      type: string
 *                      format: email
 *                      description: Email for the user, needs to be unique.
 *                      example: 0
 *                    username:
 *                      type: string
 *                      description: The Recycling partner user's name.
 *                      example: Cerebra
 */
  router.post('/createprivatenetwork/:userId', [authUtil.validateMiddleware, authUtil.isGpOrRp, authUtil.isUserAsset], userController.createUserPrivateNtw);
  /**
 * @swagger
 * /api/user/getprivatenetwork/{userId}:
 *   get:
 *    description:  Endpoint to get business partner private networks
 *    tags:
 *      - Private Network
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: number
 *    responses:
 *       200:
 *         description: A list of user's private networks.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/PrivateNetwork'
 */
  router.get('/getprivatenetwork/:userId', [authUtil.validateMiddleware, authUtil.isGpOrRp, authUtil.isUserAsset], userController.getUserPrivateNtw);

  /**
 * @swagger
 * /api/user/deleteprivatenetwork/{userId}:
 *   delete:
 *    description:  Endpoint to delete business partner private networks
 *    tags:
 *      - Private Network
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: number
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              pvtNetworks:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    recyclerId:
 *                      type: string
 *                      description: private recycler user id
 *                      example: 1
 *                    networkId:
 *                      type: string
 *                      description: private network id
 *                      example: 1
 *    responses:
 *       200:
 *         description: A list of user's private networks.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/PrivateNetwork'
 */
  router.delete('/deleteprivatenetwork/:userId', [authUtil.validateMiddleware, authUtil.isGpOrRp, authUtil.isUserAsset], userController.deleteUserPrivateNtw);

  /**
 * @swagger
 * /api/user/updateUserPrivateNetwork/{userId}:
 *   patch:
 *    description:  Endpoint to update business partner
 *    tags:
 *      - Private Network
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: number
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              pvtNwkMembers:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    emailId:
 *                      type: string
 *                      format: email
 *                      description: Email for the user, needs to be unique.
 *                      example: rpuser@domain.com
 *                    username:
 *                      type: string
 *                      description: The Recycling partner user's name.
 *                      example: Cerebra
 */
  router.patch('/updateUserPrivateNetwork/:userId', [authUtil.validateMiddleware, authUtil.isGpOrRp, authUtil.isUserAsset], userController.updateUserPrivateNtw);

  /**
 * @swagger
 * /api/user/{userId}/certificates:
 *   post:
 *    description:  Upload recycling partner's certificates to verify their business account
 *    tags:
 *      - RP Certificates
 *    parameters:
 *       - name: userId
 *         description: id of the user trying to upload certificates
 *         in: path
 *         required: true
 *         type: number
 *    requestBody:
 *      required: true
 *      content:
 *        multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *              certificateFile:
 *                type: array of files
 *                format: binary
 *              certificateDetails:
 *                type: array of object (json stringified)
 *                required: true
 *                properties:
 *                  certificateType:
 *                    type: string
 *                    description: Type of certificate
 *                  validPeriod:
 *                    type: date string
 *                    description: Effective valid period of the certificate
 *                    example: 2027-01-31 (YYYY-MM-DD)
 *                  authorizationNumber:
 *                    type: string
 *                    description: An unique certificate auth number
 *                    mandatory: false
 *                  issuedDate:
 *                    type: date string
 *                    description: Date of issue of Certificate
 *                    mandatory: false
 *                  recyclingCapacity:
 *                    type: integer
 *                    description: Units of recycling capacity
 *                    mandatory: false
 *                    example: 100
 *    responses:
 *       201:
 *         description: A list of RP user's newly created certificate details.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Certificate'
 */
  router.post('/:userId/certificates',
    upload.array('certificateFile'),
    [authUtil.validateMiddleware, authUtil.isUserAsset],
    userController.saveCertificates);

  /**
 * @swagger
 * /api/user/{userId}/certificates:
 *   get:
 *    description: to retrieve RP user's all certificate details
 *    tags:
 *      - RP Certificates
 *    parameters:
 *       - name: userId
 *         description: id of the user trying to upload certificates
 *         in: path
 *         required: true
 *         type: number
 *    responses:
 *       200:
 *         description: A list of RP user's certificate details uploaded.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                type: object
 *                $ref: '#/components/schemas/Certificate'
 */
  router.get('/:userId/certificates',
    [authUtil.validateMiddleware, authUtil.isUserAsset],
    userController.getAllCertificates);

  /**
 * @swagger
 * /api/user/{userId}/certificates/{certId}:
 *   get:
 *    description: to download certificate document by cert_id
 *    tags:
 *      - RP Certificates
 *    parameters:
 *       - name: userId
 *         description: id of the user trying to upload certificates
 *         in: path
 *         required: true
 *         type: number
 *       - name: certId
 *         description: id of the certificate row in db
 *         in: path
 *         required: true
 *         type: number
 *    responses:
 *       200:
 *         description: document downloaded.
 */
  router.get('/:userId/certificates/:certId',
    [authUtil.validateMiddleware, authUtil.isUserAsset],
    userController.downloadCertificate);

  /**
 * @swagger
 * /api/user/getUserData/{cognitoId}:
 *   get:
 *    description:  Endpoint to get user data with cognito id
 *    tags:
 *      - Business Partner
 *    parameters:
 *       - name: cognitoId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: string
 *
 */
  router.get('/getUserData/:cognitoId', userController.getUserData);

  /**
 * @swagger
 * /api/user/addServicableLocation/{recyclerId}:
 *   post:
 *    description:  Endpoint to add service location for a recycler partner
 *    tags:
 *      - Serviceable Location
 *    parameters:
 *       - name: recyclerId
 *         description: id of the recycler partner
 *         in: path
 *         required: true
 *         type: number
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              countryId:
 *                type: string
 *                description: Country Id
 *                example: 1
 *              isAllStateSelected:
 *                type: boolean
 *                description: flag to show if the service location is in all the states
 *                example: false
 *              serviceLocations:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    state:
 *                      type: string
 *                      description: state Id of the state
 *                      example: 2
 *                    stateName:
 *                      type: string
 *                      description: state Name of that state Id
 *                      example: Kashmir
 *                    isAllCitySelected:
 *                      type: boolean
 *                      description: flag to show if the service location is in all the cities
 *                      example: false
 *                    city:
 *                      type: array
 *                      items:
 *                        type: object
 *                        properties:
 *                          cityId:
 *                            type: string
 *                            description: city Id of the state
 *                            example: 2
 *                          cityName:
 *                            type: string
 *                            description: state Name of that state Id
 *                            example: Punch
 *    responses:
 *      200:
 *        description: Successfully added service location.
 */

  router.post('/addServicableLocation/:recyclerId', [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isUserAsset], userController.addServicableLocation);

  /**
 * @swagger
 * /api/user/getServicableLocation/{recyclerId}:
 *   get:
 *    description:  Endpoint to get service location for a recycler partner
 *    tags:
 *      - Serviceable Location
 *    parameters:
 *       - name: recyclerId
 *         description: id of the recycler partner
 *         in: path
 *         required: true
 *         type: number
 *    responses:
 *       200:
 *         description: A list of service location.
 *         content:
 *           application/json:
 *            schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/ServiceableLocation'
 */
  router.get('/getServicableLocation/:recyclerId', [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isUserAsset], userController.getRecyclerServicableLocation);

  /**
 * @swagger
 * /api/user/deleteServicableLocation/{recyclerId}:
 *   delete:
 *    description:  Endpoint to delete recycler partner's ServiceableLocation
 *    tags:
 *      -  Serviceable Location
 *    parameters:
 *       - name: recyclerId
 *         description: id of the recycler partner
 *         in: path
 *         required: true
 *         type: number
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              statesDetail:
 *                type: array
 *                items:
 *                  type: string
 *                  description: private recycler's state id
 *                  example: 1
 *    responses:
 *       200:
 *         description: A list of recycler's serviceable location.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/ServiceableLocation'
 */
  router.delete('/deleteServicableLocation/:recyclerId', [authUtil.validateMiddleware, authUtil.isRpUser, authUtil.isUserAsset], userController.deleteServiceableLocation);
  app.use('/api/user', router);
};
