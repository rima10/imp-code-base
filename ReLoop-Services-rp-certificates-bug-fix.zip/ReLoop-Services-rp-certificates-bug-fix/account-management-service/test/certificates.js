const path = require('path');
const chai = require('chai');
const chaiHttp = require('chai-http');

chai.use(chaiHttp);
const { assert } = chai; // we are using the "assert" style of Chai

// db related requires
const { business_partner, certificate } = require(path.resolve('src/models/index'));

const sinon = require('sinon');
var app, authUtil;
describe('RP Certificate APIs', function () {
    let testUser = {};
    before(async function () {
        const dbRes = await business_partner.findOne({});
        testUser = dbRes.dataValues;

        authUtil = require('../src/utils/auth.util');
        sinon.stub(authUtil, 'validateMiddleware')
            .callsFake(function (req, res, next) {
                return next();
            });
        sinon.stub(authUtil, 'isUserAsset')
            .callsFake(function (req, res, next) {
                return next();
            });
        app = require('../app');
    });
    after(async function () {
        await certificate.destroy({
            where: { bp_id: testUser.bp_id }
        });
    });
    it('should successfully save certificates for an RP user', function (done) {
        const url = `/api/user/${testUser.bp_id}/certificates`;
        chai.request(app)
            .post(url)
            .type('form')
            .attach('certificateFile', path.resolve('package.json'), 'package.json')
            .attach('certificateFile', path.resolve('package.json'), 'package.json')
            .attach('certificateFile', path.resolve('package.json'), 'package.json')
            .field('certificateDetails', JSON.stringify(certificates))
            .end((error, response) => {
                assert.isNull(error);
                assert.equal(response.statusCode, 201);
                if (response.body) {
                    response.body.forEach((item, index) => {
                        certificates[index].certificateId = item.certificateId;
                    });
                }
                done();
            });
    });
    it('should get all certificates for an RP user', (done) => {
        const url = `/api/user/${testUser.bp_id}/certificates`;
        chai.request(app)
            .get(url)
            .end((error, response) => {
                assert.isNull(error);
                assert.equal(response.statusCode, 200);
                assert.isAtLeast(response.body.length, 1);
                done();
            });
    });
    it('should get uploaded certificate file back from s3', (done) => {
        const url = `/api/user/${testUser.bp_id}/certificates/${certificates[0].certificateId}`;
        chai.request(app)
            .get(url)
            .end((error, response) => {
                assert.isNull(error);
                assert.equal(response.statusCode, 200);
                done();
            });
    });
});

const certificates = [{
    "certificateType": 1,
    "certificateName": "State Pollution Control Board Authorization",
    "validPeriod": "2025-12-31",
    "authorizationNumber": "123avas",
    "recyclingCapacity": 1500,
    "issuedDate": "2018-12-31",
}, {
    "certificateType": 2,
    "certificateName": "Authorization under Hazardous & Other Wastes",
    "validPeriod": "2025-12-31",
}, {
    "certificateType": 3,
    "certificateName": "Other certificate 1",
    "validPeriod": "2025-12-31",
}];