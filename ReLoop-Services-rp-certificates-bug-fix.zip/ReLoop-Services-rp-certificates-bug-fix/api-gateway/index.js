const express = require('express');
const dotenv = require('dotenv');
const https = require('https');
const fs = require('fs');
const app = require('./app');

dotenv.config();

const { PORT, NODE_ENV } = process.env;
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Run HTTP server for developement
if (NODE_ENV === 'development') {
  app.listen(PORT, () => {
    console.log(`App running on port ${PORT}.`);
  });
} else {
  // Run HTTPS server for production
  const options = {
    key: fs.readFileSync('./certs/key.pem'),
    cert: fs.readFileSync('./certs/cert.pem'),
  };

  const httpsServer = https.createServer(options, app);
  httpsServer.listen(443);
}
