const router = require('express').Router();
const dotenv = require('dotenv');
const proxy = require('../utils/proxy.util');

dotenv.config();

const { ALERT_NOTIFICATION_URL } = process.env;

/*
  @desc router for /api/notification endpoint
*/
module.exports = (app) => {
  router.all('/notification*', proxy.getCustomProxy(ALERT_NOTIFICATION_URL));
  app.use('/api', router);
};
