const router = require('express').Router();
const dotenv = require('dotenv');
const proxy = require('../utils/proxy.util');
const authUtil = require('../utils/auth.util');

dotenv.config();

const { ACCOUNT_MGT_URL } = process.env;

/*
  @desc router for /api/user endpoint
*/
module.exports = (app) => {
  router.all('/user*', authUtil.validateMiddleware, proxy.getCustomProxy(ACCOUNT_MGT_URL));
  app.use('/api', router);
};
