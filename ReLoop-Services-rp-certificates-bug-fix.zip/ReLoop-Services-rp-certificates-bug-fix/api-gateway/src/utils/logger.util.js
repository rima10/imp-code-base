const winston = require('winston');
const dotenv = require('dotenv');
const CloudWatchTransport = require('winston-aws-cloudwatch');

dotenv.config();

// instantiate a new Winston Logger
const logger = winston.createLogger({
  transports: [
    new CloudWatchTransport({
      logGroupName: process.env.CW_LOG_GROUP,
      logStreamName: process.env.CW_LOG_STREAM,
      createLogGroup: true,
      createLogStream: true,
      submissionInterval: 2000,
      submissionRetryCount: 1,
      batchSize: 20,
      awsConfig: {
        accessKeyId: process.env.CW_ACCESS_KEY_ID,
        secretAccessKey: process.env.CW_SECRET_ACCESS_KEY,
        region: process.env.CW_REGION,
      },
      formatLog(item) {
        return `${item.level}: ${item.message} ${JSON.stringify(item.meta)}`;
      },
    }),
  ],
  exitOnError: false, // do not exit on handled exceptions
});

// create a stream object with a 'write' function that will be used by `morgan`
logger.stream = {
  write(message) {
    logger.info(message);
  },
};

module.exports = logger;
