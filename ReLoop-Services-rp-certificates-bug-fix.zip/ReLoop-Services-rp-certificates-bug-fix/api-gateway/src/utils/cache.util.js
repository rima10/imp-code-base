// To be replaced with Redis Cache in future
// Currently node-cache is bieng used for refresh token

const NodeCache = require('node-cache');

const cache = new NodeCache({ stdTTL: 604800 }); // delete refresh token after 7 days

exports.set = (key, val) => {
  const success = cache.set(key, val);
  return success;
};

exports.get = (key) => {
  const value = cache.get(key); // Use only once and delete
  if (value === undefined) {
    return false;
  }
  return value;
};

exports.delete = (key) => {
  const value = cache.del(key);
  return value;
};
