const proxy = require('express-http-proxy');

/*
  @desc reverse proxy the original request to the respected service
  @param String REST API path
  @param String REST API service endpoint
  @return Object - API response
  @example getCustomProxy('https://sampleUrl.com')
*/
exports.getCustomProxy = function (endpoint) {
  return proxy(endpoint, {
    proxyReqPathResolver(req) {
      console.log('url');
      console.log(req.originalUrl);
      return req.originalUrl;
    },
    proxyReqOptDecorator(proxyReqOpts, srcReq) {
      const { cookie } = srcReq.headers;
      const updatedProxyOpts = { ...proxyReqOpts };
      const [, token] = cookie.split('=');
      updatedProxyOpts.headers.authorization = `Bearer ${token}`;
      console.log('auth header');
      console.log(updatedProxyOpts.headers.authorization);
      return proxyReqOpts;
    },
  });
};
