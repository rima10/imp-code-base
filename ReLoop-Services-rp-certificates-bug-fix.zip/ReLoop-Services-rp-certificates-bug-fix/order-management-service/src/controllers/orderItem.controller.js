// eslint-disable-next-line import/no-unresolved

const orderItemService = require('../services/orderItem.service');

/*
  @desc controller function for user registeration
*/
exports.createOrderItem = async function (req, res, next) {
  try {
    await orderItemService.createOrderItem(req, res, next);
    res.send(200);
  } catch (error) {
    next(error);
  }
};

exports.readExcel = async function (req, res, next) {
  try {
    const entries = await orderItemService.readExcel(req, res, next);
    res.json(entries);
  } catch (error) {
    next(error);
  }
};
