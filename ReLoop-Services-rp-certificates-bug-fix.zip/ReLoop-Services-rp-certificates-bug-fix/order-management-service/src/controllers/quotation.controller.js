const mime = require('mime');
const moment = require('moment');
const { Readable } = require('stream');

const quotationService = require('../services/quotation.service');
const userService = require('../services/user.service');

/*
  @desc controller function to invite recyclers
*/
exports.inviteRecyclers = async function (req, res, next) {
  try {
    await quotationService.inviteRecyclers(req, res, next);
    res.send(201);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to submit first level quotes
*/
exports.submitRecycleFirstLevelQuote = async function (req, res, next) {
  try {
    const quote = await quotationService.submitRecycleFirstLevelQuote(req, res, next);
    res.status(201).send(quote);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to submit first level quotes
*/
exports.submitRefurbishFirstLevelQuote = async function (req, res, next) {
  try {
    const quote = await quotationService.submitReFurbishFirstLevelQuote(req, res, next);
    res.status(201).send(quote);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get first level quotes
*/
exports.getRecycleOrderFirstLevelQuotes = async function (req, res, next) {
  try {
    const quotes = await quotationService.getRecycleOrderFirstLevelQuotes(req, res, next);
    res.json(quotes);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get first level quotes
*/
exports.getRefurbishOrderFirstLevelQuotes = async function (req, res, next) {
  try {
    const quotes = await quotationService.getRefurbishOrderFirstLevelQuotes(req, res, next);
    res.json(quotes);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function quote accept
*/
exports.acceptQuote = async function (req, res, next) {
  try {
    const quote = await quotationService.acceptQuote(req, res, next);
    res.json(quote);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function quote accept
*/
exports.temproaryAcceptQuote = async function (req, res, next) {
  try {
    const quote = await quotationService.temproaryAcceptQuote(req, res, next);
    res.json(quote);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function for quote reject
*/
exports.rejectQuote = async function (req, res, next) {
  try {
    const quote = await quotationService.rejectQuote(req, res, next);
    res.json(quote);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get onsite verification details
*/
exports.getScheduledOnsiteVisitDetails = async function (req, res, next) {
  try {
    const quote = await quotationService.getScheduledOnsiteVisitDetails(req, res, next);
    res.json(quote);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to submit order item level quotes
*/
exports.submitRecycleItemLevelQuote = async function (req, res, next) {
  try {
    const quote = await quotationService.submitRecycleItemLevelQuote(req, res, next);
    res.status(201).send(quote);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to submit asset grading quote
*/
exports.submitRefurbishOrderAssetGradingQuote = async function (req, res, next) {
  try {
    const username = req.userInfo['cognito:username'];
    const userData = await userService.getUserDatabyCognito(username);

    const { orderId, quoteId } = req.params;
    const result = await quotationService.submitRefurbishOrderAssetGradingQuote(userData, orderId, quoteId);
    res.status(200).send(result);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get order item level quotes
*/
exports.getRecycleOrderItemLevelQuote = async function (req, res, next) {
  try {
    const quotes = await quotationService.getRecycleOrderItemLevelQuote(req, res, next);
    res.json(quotes);
  } catch (error) {
    next(error);
  }
};

exports.getOrderItemsGradingList = async function (req, res, next) {
  try {
    const { orderId, quoteId } = req.params;
    const entries = await quotationService.getOrderItemsGradingList(orderId, quoteId);
    res.json(entries);
  } catch (error) {
    next(error);
  }
};

function bufferToStream(buffer) {
  const stream = new Readable();
  stream.push(buffer);
  stream.push(null);

  return stream;
}

exports.downloadOrderItemsGradingList = async function (req, res, next) {
  try {
    const { orderId, quoteId } = req.params;
    const wbBuffer = await quotationService.getOrderItemsGradingListInExcel(orderId, quoteId);
    const wbStream = bufferToStream(wbBuffer);
    const filename = `AssetGradeList_${orderId}_${quoteId}_${moment().format('DD-MMM-YYYY hh:mm')}.xlsx`;

    res.set('Content-Type', mime.getType(filename));
    res.attachment(filename);

    wbStream.pipe(res);
  } catch (error) {
    next(error);
  }
};

exports.saveOrderItemsGradingList = async function (req, res, next) {
  try {
    const username = req.userInfo['cognito:username'];
    const userData = await userService.getUserDatabyCognito(username);

    const { orderId, quoteId } = req.params;
    const payload = req.body;
    const result = await quotationService.saveOrderItemsGradingList(userData, orderId,
      quoteId, payload);
    res.status(200).send(result);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get order_quote id by orderId, quoteId
*/
exports.getOrderQuoteDetails = async function (req, res, next) {
  try {
    const { orderId, quoteId } = req.params;
    const projection = req.query && req.query.projection
      ? req.query.projection.split(',').map((str) => (str.trim())) : undefined;
    const result = await quotationService.getOrderQuoteDetails(orderId, quoteId, projection);
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to update order_quote table columns
*/
exports.updateOrderQuoteDetails = async function (req, res, next) {
  try {
    const username = req.userInfo['cognito:username'];
    const userData = await userService.getUserDatabyCognito(username);

    const { orderId, quoteId } = req.params;
    const payload = req.body;
    const result = await quotationService.updateOrderQuoteDetails(userData,
      orderId,
      quoteId,
      payload);
    res.status(200).send(result);
  } catch (error) {
    next(error);
  }
};
