const approvalService = require('../services/approval.service');

/*
  @desc controller function get pending approvals
*/
exports.getPendingApprovals = async (req, res, next) => {
  try {
    const assignedOrders = await approvalService.getPendingApprovals(req, res, next);
    res.json(assignedOrders);
  } catch (error) {
    next(error);
  }
};

exports.approve = async (req, res, next) => {
  try {
    const assignedOrders = await approvalService.approve(req, res, next);
    res.status(201).json(assignedOrders);
  } catch (error) {
    next(error);
  }
};

exports.reject = async (req, res, next) => {
  try {
    const assignedOrders = await approvalService.reject(req, res, next);
    res.status(201).json(assignedOrders);
  } catch (error) {
    next(error);
  }
};
