const orderWorkflowService = require('../services/orderWorkflow.service');

/*
  @desc controller functionto create order workflow
*/
exports.createOrderWorkflow = async (req, res, next) => {
  try {
    const orderWorkflow = await orderWorkflowService.createOrderWorkflow(req, res, next);
    res.status(201).json(orderWorkflow);
  } catch (error) {
    next(error);
  }
};
