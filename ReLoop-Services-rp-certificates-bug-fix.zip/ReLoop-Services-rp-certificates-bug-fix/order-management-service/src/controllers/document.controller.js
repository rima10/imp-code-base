const docService = require('../services/doc.service');

/*
  @desc controller function to generate delivery challan
*/
exports.generateDC = async (req, res, next) => {
  try {
    const stream = await docService.generateDC(req, res, next);
    stream.pipe(res);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to generate form 6
*/
exports.generateForm6 = async (req, res, next) => {
  try {
    const stream = await docService.generateForm6(req, res, next);
    stream.pipe(res);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to generate form 2
*/
exports.generateForm2 = async (req, res, next) => {
  try {
    const stream = await docService.generateForm2(req, res, next);
    stream.pipe(res);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to download document
*/

exports.downloadDocument = async (req, res, next) => {
  try {
    const stream = await docService.downloadFile(req, res, next);
    stream.pipe(res);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to upload document
*/

exports.uploadDocument = async (req, res, next) => {
  try {
    await docService.uploadDocument(req, res, next);
    res.send(201);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function to get order documents
*/

exports.getOrderDocuments = async (req, res, next) => {
  try {
    const documents = await docService.getOrderDocuments(req, res, next);
    res.json(documents);
  } catch (error) {
    next(error);
  }
};
