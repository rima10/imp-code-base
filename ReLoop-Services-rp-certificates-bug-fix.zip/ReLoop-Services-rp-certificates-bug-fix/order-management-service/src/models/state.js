module.exports = function (sequelize, DataTypes) {
  return sequelize.define('state', {
    state_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    state_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    country_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'country',
        key: 'country_id',
      },
    },
  }, {
    sequelize,
    tableName: 'state',
    schema: 'address',
    timestamps: false,
    indexes: [
      {
        name: 'state_pkey',
        unique: true,
        fields: [
          { name: 'state_id' },
        ],
      },
    ],
  });
};
