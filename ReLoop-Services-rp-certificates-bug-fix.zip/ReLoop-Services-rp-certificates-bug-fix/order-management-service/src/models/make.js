module.exports = function (sequelize, DataTypes) {
  return sequelize.define('make', {
    make_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    make_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'make',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'make_pkey',
        unique: true,
        fields: [
          { name: 'make_id' },
        ],
      },
    ],
  });
};
