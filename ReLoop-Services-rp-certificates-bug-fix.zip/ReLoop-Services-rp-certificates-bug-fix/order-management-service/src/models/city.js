module.exports = function (sequelize, DataTypes) {
  return sequelize.define('city', {
    city_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    city_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    state_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'state',
        key: 'state_id',
      },
    },
  }, {
    sequelize,
    tableName: 'city',
    schema: 'address',
    timestamps: false,
    indexes: [
      {
        name: 'city_pkey',
        unique: true,
        fields: [
          { name: 'city_id' },
        ],
      },
    ],
  });
};
