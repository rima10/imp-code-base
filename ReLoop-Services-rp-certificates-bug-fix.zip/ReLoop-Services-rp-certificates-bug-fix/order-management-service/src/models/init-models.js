const { DataTypes } = require('sequelize');
const _approver = require('./approver');
const _bp_private_nwk = require('./bp_private_nwk');
const _business_partner = require('./business_partner');
const _category = require('./category');
const _certificate = require('./certificate');
const _city = require('./city');
const _country = require('./country');
const _doc = require('./doc');
const _event = require('./event');
const _location = require('./location');
const _model_quote = require('./model_quote');
const _notification_mapping = require('./notification_mapping');
const _order = require('./order');
const _order_doc = require('./order_doc');
const _order_invited_business_partner = require('./order_invited_business_partner');
const _order_item = require('./order_item');
const _order_notes = require('./order_notes');
const _order_quote = require('./order_quote');
const _order_quote_item = require('./order_quote_item');
const _order_status = require('./order_status');
const _order_workflow = require('./order_workflow');
const _order_workflow_approver = require('./order_workflow_approver');
const _process_type = require('./process_type');
const _quote_history = require('./quote_history');
const _rating = require('./rating');
const _recycling_category = require('./recycling_category');
const _recycling_sub_category = require('./recycling_sub_category');
const _role = require('./role');
const _role_bp_mapping = require('./role_bp_mapping');
const _state = require('./state');
const _status = require('./status');
const _sub_category = require('./sub_category');
const _workflow = require('./workflow');
const _workflow_approver = require('./workflow_approver');
const _item_type = require('./item_type');
const _make = require('./make');

function initModels(sequelize) {
  const approver = _approver(sequelize, DataTypes);
  const bp_private_nwk = _bp_private_nwk(sequelize, DataTypes);
  const business_partner = _business_partner(sequelize, DataTypes);
  const category = _category(sequelize, DataTypes);
  const certificate = _certificate(sequelize, DataTypes);
  const city = _city(sequelize, DataTypes);
  const country = _country(sequelize, DataTypes);
  const doc = _doc(sequelize, DataTypes);
  const event = _event(sequelize, DataTypes);
  const location = _location(sequelize, DataTypes);
  const model_quote = _model_quote(sequelize, DataTypes);
  const notification_mapping = _notification_mapping(sequelize, DataTypes);
  const order = _order(sequelize, DataTypes);
  const order_doc = _order_doc(sequelize, DataTypes);
  const order_invited_business_partner = _order_invited_business_partner(sequelize, DataTypes);
  const order_item = _order_item(sequelize, DataTypes);
  const order_notes = _order_notes(sequelize, DataTypes);
  const order_quote = _order_quote(sequelize, DataTypes);
  const order_quote_item = _order_quote_item(sequelize, DataTypes);
  const order_status = _order_status(sequelize, DataTypes);
  const order_workflow = _order_workflow(sequelize, DataTypes);
  const order_workflow_approver = _order_workflow_approver(sequelize, DataTypes);
  const process_type = _process_type(sequelize, DataTypes);
  const quote_history = _quote_history(sequelize, DataTypes);
  const rating = _rating(sequelize, DataTypes);
  const recycling_category = _recycling_category(sequelize, DataTypes);
  const recycling_sub_category = _recycling_sub_category(sequelize, DataTypes);
  const role = _role(sequelize, DataTypes);
  const role_bp_mapping = _role_bp_mapping(sequelize, DataTypes);
  const state = _state(sequelize, DataTypes);
  const status = _status(sequelize, DataTypes);
  const sub_category = _sub_category(sequelize, DataTypes);
  const workflow = _workflow(sequelize, DataTypes);
  const workflow_approver = _workflow_approver(sequelize, DataTypes);
  const item_type = _item_type(sequelize, DataTypes);
  const make = _make(sequelize, DataTypes);

  location.belongsTo(city, { as: 'city', foreignKey: 'city_id' });
  city.hasMany(location, { as: 'locations', foreignKey: 'city_id' });
  location.belongsTo(country, { as: 'country', foreignKey: 'country_id' });
  country.hasMany(location, { as: 'locations', foreignKey: 'country_id' });
  state.belongsTo(country, { as: 'country', foreignKey: 'country_id' });
  country.hasMany(state, { as: 'states', foreignKey: 'country_id' });
  city.belongsTo(state, { as: 'state', foreignKey: 'state_id' });
  state.hasMany(city, { as: 'cities', foreignKey: 'state_id' });
  location.belongsTo(state, { as: 'state', foreignKey: 'state_id' });
  state.hasMany(location, { as: 'locations', foreignKey: 'state_id' });
  order_notes.belongsTo(approver, { as: 'approver_update_by_approver', foreignKey: 'approver_update_by' });
  approver.hasMany(order_notes, { as: 'order_notes', foreignKey: 'approver_update_by' });
  order.belongsTo(business_partner, { as: 'businessPartner', foreignKey: 'created_by' });
  business_partner.hasMany(order, { as: 'orders', foreignKey: 'created_by' });
  order.belongsTo(business_partner, { as: 'updated_by_business_partner', foreignKey: 'updated_by' });
  business_partner.hasMany(order, { as: 'updated_by_orders', foreignKey: 'updated_by' });
  order_doc.belongsTo(business_partner, { as: 'created_by_business_partner', foreignKey: 'created_by' });
  business_partner.hasMany(order_doc, { as: 'order_docs', foreignKey: 'created_by' });
  order_doc.belongsTo(business_partner, { as: 'updated_by_business_partner', foreignKey: 'updated_by' });
  business_partner.hasMany(order_doc, { as: 'updated_by_order_docs', foreignKey: 'updated_by' });
  order_invited_business_partner.belongsTo(business_partner, { as: 'invited_bp', foreignKey: 'invited_bp_id' });
  business_partner.hasMany(order_invited_business_partner, { as: 'order_invited_business_partners', foreignKey: 'invited_bp_id' });
  business_partner.hasMany(order_item, { as: 'order_items', foreignKey: 'created_by' });
  business_partner.hasMany(order_item, { as: 'updated_by_order_items', foreignKey: 'updated_by' });
  order_notes.belongsTo(business_partner, { as: 'updated_by_business_partner', foreignKey: 'updated_by' });
  business_partner.hasMany(order_notes, { as: 'order_notes', foreignKey: 'updated_by' });
  order_quote.belongsTo(business_partner, { as: 'createdByBP', foreignKey: 'created_by' });
  business_partner.hasMany(order_quote, { as: 'order_quotes', foreignKey: 'created_by' });
  order_quote.belongsTo(business_partner, { as: 'updated_by_business_partner', foreignKey: 'updated_by' });
  business_partner.hasMany(order_quote, { as: 'updated_by_order_quotes', foreignKey: 'updated_by' });
  order_quote_item.belongsTo(business_partner, { as: 'created_by_business_partner', foreignKey: 'created_by' });
  business_partner.hasMany(order_quote_item, { as: 'order_quote_items', foreignKey: 'created_by' });
  order_quote_item.belongsTo(business_partner, { as: 'updated_by_business_partner', foreignKey: 'updated_by' });
  business_partner.hasMany(order_quote_item, { as: 'updated_by_order_quote_items', foreignKey: 'updated_by' });
  order_status.belongsTo(business_partner, { as: 'created_by_business_partner', foreignKey: 'created_by' });
  business_partner.hasMany(order_status, { as: 'order_statuses', foreignKey: 'created_by' });
  order_status.belongsTo(business_partner, { as: 'updated_by_business_partner', foreignKey: 'updated_by' });
  business_partner.hasMany(order_status, { as: 'updated_by_order_statuses', foreignKey: 'updated_by' });
  quote_history.belongsTo(business_partner, { as: 'updated_by_business_partner', foreignKey: 'updated_by' });
  business_partner.hasMany(quote_history, { as: 'quote_histories', foreignKey: 'updated_by' });
  order.belongsTo(category, { as: 'order_category', foreignKey: 'category' });
  category.hasMany(order, { as: 'orders', foreignKey: 'category' });
  sub_category.belongsTo(category, { as: 'category', foreignKey: 'category_id' });
  category.hasMany(sub_category, { as: 'sub_categories', foreignKey: 'category_id' });
  order_doc.belongsTo(doc, { as: 'doc', foreignKey: 'doc_id' });
  doc.hasMany(order_doc, { as: 'order_docs', foreignKey: 'doc_id' });
  order_doc.belongsTo(order, { as: 'order', foreignKey: 'order_id' });
  order.hasMany(order_doc, { as: 'order_docs', foreignKey: 'order_id' });
  order_invited_business_partner.belongsTo(order, { as: 'order', foreignKey: 'order_id' });
  order.hasMany(order_invited_business_partner, { as: 'order_invited_business_partners', foreignKey: 'order_id' });
  order.hasMany(order_item, { as: 'orderItems', foreignKey: 'order_id' });
  order_notes.belongsTo(order, { as: 'order', foreignKey: 'order_id' });
  order.hasMany(order_notes, { as: 'order_notes', foreignKey: 'order_id' });
  order_quote.belongsTo(order, { as: 'order', foreignKey: 'order_id' });
  order.hasMany(order_quote, { as: 'order_quotes', foreignKey: 'order_id' });
  order_quote_item.belongsTo(order, { as: 'order', foreignKey: 'order_id' });
  order.hasMany(order_quote_item, { as: 'order_quote_items', foreignKey: 'order_id' });
  order_status.belongsTo(order, { as: 'order', foreignKey: 'order_id' });
  order.hasMany(order_status, { as: 'order_statuses', foreignKey: 'order_id' });
  order_workflow.belongsTo(order, { as: 'order', foreignKey: 'order_id' });
  order.hasMany(order_workflow, { as: 'order_workflows', foreignKey: 'order_id' });
  order_quote_item.belongsTo(order_item, { as: 'order_item', foreignKey: 'order_item_id' });
  model_quote.belongsTo(order_quote, { as: 'order_quote', foreignKey: 'order_quote_id' });
  order_quote.hasMany(model_quote, { as: 'modelQuotes', foreignKey: 'order_quote_id' });
  order_quote_item.belongsTo(order_quote, { as: 'order_quote', foreignKey: 'order_quote_id' });
  order_quote.hasMany(order_quote_item, { as: 'orderItemQuotes', foreignKey: 'order_quote_id' });
  quote_history.belongsTo(order_quote, { as: 'order_quote', foreignKey: 'order_quote_id' });
  order_quote.hasMany(quote_history, { as: 'quote_histories', foreignKey: 'order_quote_id' });
  order_workflow_approver.belongsTo(order_workflow, { as: 'orderWorkflow', foreignKey: 'order_workflow_id' });
  order_workflow.hasMany(order_workflow_approver, { as: 'order_workflow_approvers', foreignKey: 'order_workflow_id' });
  order_status.belongsTo(status, { as: 'status', foreignKey: 'status_id' });
  status.hasMany(order_status, { as: 'order_statuses', foreignKey: 'status_id' });
  order.belongsTo(sub_category, { as: 'order_sub_category', foreignKey: 'sub_category' });
  sub_category.hasMany(order, { as: 'orders', foreignKey: 'sub_category' });
  order_workflow.belongsTo(workflow, { as: 'workflow', foreignKey: 'workflow_id' });
  workflow.hasMany(order_workflow, { as: 'order_workflows', foreignKey: 'workflow_id' });
  order_workflow_approver.belongsTo(workflow_approver, { as: 'workflow_approver', foreignKey: 'workflow_approver_id' });
  workflow_approver.hasMany(order_workflow_approver, { as: 'order_workflow_approvers', foreignKey: 'workflow_approver_id' });
  workflow_approver.belongsTo(approver, { as: 'approver', foreignKey: 'approver_id' });
  approver.hasMany(workflow_approver, { as: 'workflow_approvers', foreignKey: 'approver_id' });
  approver.belongsTo(business_partner, { as: 'bp', foreignKey: 'bp_id' });
  business_partner.hasMany(approver, { as: 'approvers', foreignKey: 'bp_id' });
  bp_private_nwk.belongsTo(business_partner, { as: 'gp', foreignKey: 'gp_id' });
  business_partner.hasMany(bp_private_nwk, { as: 'bp_private_nwks', foreignKey: 'gp_id' });
  bp_private_nwk.belongsTo(business_partner, { as: 'rcy', foreignKey: 'rcy_id' });
  business_partner.hasMany(bp_private_nwk, { as: 'rcy_bp_private_nwks', foreignKey: 'rcy_id' });
  certificate.belongsTo(business_partner, { as: 'bp', foreignKey: 'bp_id' });
  business_partner.hasMany(certificate, { as: 'certificates', foreignKey: 'bp_id' });
  rating.belongsTo(business_partner, { as: 'bp', foreignKey: 'bp_id' });
  business_partner.hasMany(rating, { as: 'ratings', foreignKey: 'bp_id' });
  rating.belongsTo(business_partner, { as: 'given_by_business_partner', foreignKey: 'given_by' });
  business_partner.hasMany(rating, { as: 'given_by_ratings', foreignKey: 'given_by' });
  recycling_category.belongsTo(business_partner, { as: 'rcy', foreignKey: 'rcy_id' });
  business_partner.hasMany(recycling_category, { as: 'recycling_categories', foreignKey: 'rcy_id' });
  recycling_sub_category.belongsTo(business_partner, { as: 'rcy', foreignKey: 'rcy_id' });
  business_partner.hasMany(recycling_sub_category, { as: 'recycling_sub_categories', foreignKey: 'rcy_id' });
  role_bp_mapping.belongsTo(business_partner, { as: 'bp', foreignKey: 'bp_id' });
  business_partner.hasMany(role_bp_mapping, { as: 'role_bp_mappings', foreignKey: 'bp_id' });
  workflow.belongsTo(business_partner, { as: 'bp', foreignKey: 'bp_id' });
  business_partner.hasMany(workflow, { as: 'workflows', foreignKey: 'bp_id' });
  recycling_category.belongsTo(category, { as: 'cat', foreignKey: 'cat_id' });
  category.hasMany(recycling_category, { as: 'recycling_categories', foreignKey: 'cat_id' });
  business_partner.belongsTo(location, { as: 'loc', foreignKey: 'loc_id' });
  location.hasMany(business_partner, { as: 'business_partners', foreignKey: 'loc_id' });
  workflow.belongsTo(process_type, { as: 'process_type', foreignKey: 'process_type_id' });
  process_type.hasMany(workflow, { as: 'workflows', foreignKey: 'process_type_id' });
  order.belongsTo(process_type, { as: 'orderProcessType', foreignKey: 'order_type' });
  process_type.hasMany(order, { as: 'order', foreignKey: 'order_type' });
  role_bp_mapping.belongsTo(role, { as: 'role', foreignKey: 'role_id' });
  role.hasMany(role_bp_mapping, { as: 'role_bp_mappings', foreignKey: 'role_id' });
  recycling_sub_category.belongsTo(sub_category, { as: 'subcat', foreignKey: 'subcat_id' });
  sub_category.hasMany(recycling_sub_category, { as: 'recycling_sub_categories', foreignKey: 'subcat_id' });
  workflow_approver.belongsTo(workflow, { as: 'workflow', foreignKey: 'workflow_id' });
  workflow.hasMany(workflow_approver, { as: 'workflow_approvers', foreignKey: 'workflow_id' });
  item_type.hasMany(order_item, { as: 'order_item', foreignKey: 'item_type_name' });
  make.hasMany(order_item, { as: 'order_item', foreignKey: 'make' });
  model_quote.belongsTo(item_type, { as: 'itemType', foreignKey: 'item_type' });
  item_type.hasMany(model_quote, { as: 'modelQuote', foreignKey: 'item_type' });
  model_quote.belongsTo(make, { as: 'modelQuoteMake', foreignKey: 'make' });
  make.hasMany(model_quote, { as: 'modelQuote', foreignKey: 'make' });

  return {
    approver,
    bp_private_nwk,
    business_partner,
    category,
    certificate,
    city,
    country,
    doc,
    event,
    location,
    model_quote,
    notification_mapping,
    order,
    order_doc,
    order_invited_business_partner,
    order_item,
    order_notes,
    order_quote,
    order_quote_item,
    order_status,
    order_workflow,
    order_workflow_approver,
    process_type,
    quote_history,
    rating,
    recycling_category,
    recycling_sub_category,
    role,
    role_bp_mapping,
    state,
    status,
    sub_category,
    workflow,
    workflow_approver,
    item_type,
    make,
  };
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;
