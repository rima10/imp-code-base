const attributesMap = [
  ['modelQuoteId', 'model_quote_id'],
  ['orderQuoteId', 'order_quote_id'],
  ['model', 'model'],
  ['make', 'make'],
  ['price', 'price'],
  ['itemType', 'item_type'],
  ['count', 'count'],
];
const serviceToDbMap = new Map(attributesMap);

const reversedAttributesMap = attributesMap.map((item) => item.reverse());
const dbToServiceMap = new Map(reversedAttributesMap);

module.exports = function (sequelize, DataTypes) {
  /**
 * @swagger
 *  components:
 *    schemas:
 *      ModelQuote:
 *        type: object
 *        required:
 *        properties:
 *          model_quote_id:
 *            type: string
 *          order_id:
 *            type: string
 *          model:
 *            type: string
 *          item_type:
 *            type: string
 *          make:
 *            type: string
 *          price:
 *            type: string
 *        example:
 *           id: 1
 *           order_id: 2
 *           model: Thinkpad
 *           item_type: Laptop
 *           make: Lenovo
 *           price: 4000
 */
  const model = sequelize.define('model_quote', {
    model_quote_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    order_quote_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'order_quote',
        key: 'id',
      },
    },
    model: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    item_type: {
      type: DataTypes.STRING,
      allowNull: true,
      references: {
        model: 'item_type',
        key: 'item_type_name',
      },
    },
    make: {
      type: DataTypes.STRING,
      allowNull: true,
      references: {
        model: 'make',
        key: 'make_name',
      },
    },
    price: {
      type: DataTypes.DECIMAL,
      allowNull: false,
    },
    count: {
      type: DataTypes.DECIMAL,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'model_quote',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'model_quote_pkey',
        unique: true,
        fields: [
          { name: 'model_quote_id' },
        ],
      },
    ],
  });

  model.serviceToDbMap = serviceToDbMap;
  model.dbToServiceMap = dbToServiceMap;

  return model;
};
