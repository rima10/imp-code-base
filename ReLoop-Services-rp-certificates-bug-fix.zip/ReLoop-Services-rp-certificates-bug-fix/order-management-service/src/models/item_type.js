module.exports = function (sequelize, DataTypes) {
  return sequelize.define('item_type', {
    item_type_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    item_type_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'item_type',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'item_type_pkey',
        unique: true,
        fields: [
          { name: 'item_type_id' },
        ],
      },
    ],
  });
};
