/**
 * @swagger
 *  components:
 *    schemas:
 *      OrderType:
 *        type: object
 *        required:
 *        properties:
 *          process_type_id:
 *            type: string
 *          process_type_name:
 *            type: string
 *        example:
 *           process_type_id: 1
 *           process_type_name: Refurbish
 */
module.exports = function (sequelize, DataTypes) {
  return sequelize.define('process_type', {
    process_type_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    process_type_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    sequelize,
    tableName: 'process_type',
    schema: 'order_detail',
    timestamps: false,
    indexes: [
      {
        name: 'process_type_pkey',
        unique: true,
        fields: [
          { name: 'process_type_id' },
        ],
      },
    ],
  });
};
