const widths = [104, 94, 49, 197, 67, 36, 57, 31, 56, 31, 56, 31, 43, 30, 43, 75];
const getCell = (value, i, isLastRow) => `<td width=${widths[i]} valign=top style='width:77.95pt;border:solid black 1.0pt;
border-top:none;mso-border-top-alt:solid black .5pt;mso-border-alt:solid black .5pt;
padding:0cm 0cm 0cm 0cm;height:14.3pt'>
<p class='TableParagraph' align='center' style='margin-top:2.25pt;margin-right:
0cm;margin-bottom:0cm;margin-left:.7pt;margin-bottom:.0001pt;text-align:center;
line-height:150%;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:margin;
mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
style='font-size:8.0pt;line-height:150%;font-family:"Arial",sans-serif;
mso-fareast-font-family:Arial; font-weight:${isLastRow ? 'bold' : 'normal'};'>${value}<o:p></o:p></span></p>
</td>`;

const getRow = (cells, isLastRow) => {
  let rowDOM = '<tr style=\'mso-yfti-irow:3;height:14.3pt\'>';
  cells.map((cell, i) => {
    rowDOM += getCell(cell, i, isLastRow);
  });
  return `${rowDOM}</tr>`;
};
const getRows = (rows) => {
  let rowsDOM = '';
  rows.map((row, index) => {
    const isLastRow = index === rows.length - 1;
    rowsDOM += getRow(row, isLastRow);
  });
  return rowsDOM;
};

exports.getDCTemp = (data) => {
  const {
    consigneeAddress, consigneeAdress2, consigneeGST, consigneeName,
    consigneePAN, consigneeState, consignorAddress, consignorCIN,
    consignorGST, consignorName, consignorPAN, consignorState, rows, consigneeCIN, vehicleDetails, transporterDetails,
    lrGcNote, dcNo, dcDate,
  } = data;
  return `<html style="zoom: 0.55;" xmlns:v="urn:schemas-microsoft-com:vml"
  xmlns:o="urn:schemas-microsoft-com:office:office"
  xmlns:w="urn:schemas-microsoft-com:office:word"
  xmlns:dt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882"
  xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"
  xmlns="http://www.w3.org/TR/REC-html40">
  
  <head>
  <meta http-equiv=Content-Type content="text/html; charset=windows-1252">
  <meta name=ProgId content=Word.Document>
  <meta name=Generator content="Microsoft Word 15">
  <meta name=Originator content="Microsoft Word 15">
  <link rel=File-List href="DC%20New_files/filelist.xml">
  <link rel=Edit-Time-Data href="DC%20New_files/editdata.mso">
  <!--[if !mso]>
  <style>
  v\:* {behavior:url(#default#VML);}
  o\:* {behavior:url(#default#VML);}
  w\:* {behavior:url(#default#VML);}
  .shape {behavior:url(#default#VML);}
  </style>
  <![endif]--><!--[if gte mso 9]><xml>
   <o:DocumentProperties>
    <o:Author>Online2PDF.com</o:Author>
    <o:LastAuthor>Sharma, Amit</o:LastAuthor>
    <o:Revision>3</o:Revision>
    <o:TotalTime>1527</o:TotalTime>
    <o:LastPrinted>2021-06-04T07:19:00Z</o:LastPrinted>
    <o:Created>2021-06-05T12:10:00Z</o:Created>
    <o:LastSaved>2021-06-05T12:13:00Z</o:LastSaved>
    <o:Pages>1</o:Pages>
    <o:Words>217</o:Words>
    <o:Characters>1238</o:Characters>
    <o:Lines>10</o:Lines>
    <o:Paragraphs>2</o:Paragraphs>
    <o:CharactersWithSpaces>1453</o:CharactersWithSpaces>
    <o:Version>16.00</o:Version>
   </o:DocumentProperties>
   <o:CustomDocumentProperties>
    <o:Created dt:dt="date">2021-06-04</o:Created>
    <o:LastSaved dt:dt="date">2021-06-04</o:LastSaved>
   </o:CustomDocumentProperties>
  </xml><![endif]-->
  <link rel=themeData href="DC%20New_files/themedata.thmx">
  <link rel=colorSchemeMapping href="DC%20New_files/colorschememapping.xml">
  <!--[if gte mso 9]><xml>
   <w:WordDocument>
    <w:SpellingState>Clean</w:SpellingState>
    <w:TrackMoves>false</w:TrackMoves>
    <w:TrackFormatting/>
    <w:HyphenationZone>21</w:HyphenationZone>
    <w:PunctuationKerning/>
    <w:DrawingGridHorizontalSpacing>5.5 pt</w:DrawingGridHorizontalSpacing>
    <w:DisplayHorizontalDrawingGridEvery>2</w:DisplayHorizontalDrawingGridEvery>
    <w:ValidateAgainstSchemas/>
    <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
    <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
    <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
    <w:DoNotPromoteQF/>
    <w:LidThemeOther>DE-AT</w:LidThemeOther>
    <w:LidThemeAsian>X-NONE</w:LidThemeAsian>
    <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>
    <w:Compatibility>
     <w:ULTrailSpace/>
     <w:BreakWrappedTables/>
     <w:SnapToGridInCell/>
     <w:WrapTextWithPunct/>
     <w:UseAsianBreakRules/>
     <w:UseWord2010TableStyleRules/>
     <w:DontGrowAutofit/>
     <w:SplitPgBreakAndParaMark/>
    </w:Compatibility>
    <w:DoNotOptimizeForBrowser/>
    <m:mathPr>
     <m:mathFont m:val="Cambria Math"/>
     <m:brkBin m:val="before"/>
     <m:brkBinSub m:val="&#45;-"/>
     <m:smallFrac m:val="off"/>
     <m:dispDef/>
     <m:lMargin m:val="0"/>
     <m:rMargin m:val="0"/>
     <m:defJc m:val="centerGroup"/>
     <m:wrapIndent m:val="1440"/>
     <m:intLim m:val="subSup"/>
     <m:naryLim m:val="undOvr"/>
    </m:mathPr></w:WordDocument>
  </xml><![endif]--><!--[if gte mso 9]><xml>
   <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="false"
    DefSemiHidden="false" DefQFormat="false" DefPriority="99"
    LatentStyleCount="376">
    <w:LsdException Locked="false" Priority="1" QFormat="true" Name="Normal"/>
    <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 1"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 2"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 3"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 4"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 5"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 6"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 7"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 8"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 9"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 5"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 6"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 7"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 8"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 9"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 1"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 2"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 3"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 4"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 5"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 6"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 7"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 8"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 9"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Normal Indent"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="footnote text"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="annotation text"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="header"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="footer"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index heading"/>
    <w:LsdException Locked="false" Priority="35" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="caption"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="table of figures"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="envelope address"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="envelope return"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="footnote reference"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="annotation reference"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="line number"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="page number"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="endnote reference"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="endnote text"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="table of authorities"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="macro"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="toa heading"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Bullet"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Number"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List 5"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Bullet 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Bullet 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Bullet 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Bullet 5"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Number 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Number 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Number 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Number 5"/>
    <w:LsdException Locked="false" Priority="10" QFormat="true" Name="Title"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Closing"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Signature"/>
    <w:LsdException Locked="false" Priority="1" SemiHidden="true"
     UnhideWhenUsed="true" Name="Default Paragraph Font"/>
    <w:LsdException Locked="false" Priority="1" SemiHidden="true"
     UnhideWhenUsed="true" Name="Body Text"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Body Text Indent"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Continue"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Continue 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Continue 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Continue 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Continue 5"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Message Header"/>
    <w:LsdException Locked="false" Priority="11" QFormat="true" Name="Subtitle"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Salutation"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Date"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Body Text First Indent"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Body Text First Indent 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Note Heading"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Body Text 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Body Text 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Body Text Indent 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Body Text Indent 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Block Text"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Hyperlink"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="FollowedHyperlink"/>
    <w:LsdException Locked="false" Priority="22" QFormat="true" Name="Strong"/>
    <w:LsdException Locked="false" Priority="20" QFormat="true" Name="Emphasis"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Document Map"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Plain Text"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="E-mail Signature"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Top of Form"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Bottom of Form"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Normal (Web)"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Acronym"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Address"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Cite"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Code"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Definition"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Keyboard"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Preformatted"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Sample"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Typewriter"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Variable"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Normal Table"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="annotation subject"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="No List"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Outline List 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Outline List 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Outline List 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Simple 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Simple 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Simple 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Classic 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Classic 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Classic 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Classic 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Colorful 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Colorful 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Colorful 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Columns 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Columns 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Columns 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Columns 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Columns 5"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 5"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 6"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 7"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 8"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 5"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 6"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 7"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 8"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table 3D effects 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table 3D effects 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table 3D effects 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Contemporary"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Elegant"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Professional"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Subtle 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Subtle 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Web 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Web 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Web 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Balloon Text"/>
    <w:LsdException Locked="false" Priority="59" Name="Table Grid"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Theme"/>
    <w:LsdException Locked="false" SemiHidden="true" Name="Placeholder Text"/>
    <w:LsdException Locked="false" Priority="1" QFormat="true" Name="No Spacing"/>
    <w:LsdException Locked="false" Priority="60" Name="Light Shading"/>
    <w:LsdException Locked="false" Priority="61" Name="Light List"/>
    <w:LsdException Locked="false" Priority="62" Name="Light Grid"/>
    <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1"/>
    <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2"/>
    <w:LsdException Locked="false" Priority="65" Name="Medium List 1"/>
    <w:LsdException Locked="false" Priority="66" Name="Medium List 2"/>
    <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1"/>
    <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2"/>
    <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3"/>
    <w:LsdException Locked="false" Priority="70" Name="Dark List"/>
    <w:LsdException Locked="false" Priority="71" Name="Colorful Shading"/>
    <w:LsdException Locked="false" Priority="72" Name="Colorful List"/>
    <w:LsdException Locked="false" Priority="73" Name="Colorful Grid"/>
    <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 1"/>
    <w:LsdException Locked="false" Priority="61" Name="Light List Accent 1"/>
    <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 1"/>
    <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 1"/>
    <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 1"/>
    <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 1"/>
    <w:LsdException Locked="false" SemiHidden="true" Name="Revision"/>
    <w:LsdException Locked="false" Priority="1" QFormat="true"
     Name="List Paragraph"/>
    <w:LsdException Locked="false" Priority="29" QFormat="true" Name="Quote"/>
    <w:LsdException Locked="false" Priority="30" QFormat="true"
     Name="Intense Quote"/>
    <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 1"/>
    <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 1"/>
    <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 1"/>
    <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 1"/>
    <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 1"/>
    <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 1"/>
    <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 1"/>
    <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 1"/>
    <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 2"/>
    <w:LsdException Locked="false" Priority="61" Name="Light List Accent 2"/>
    <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 2"/>
    <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 2"/>
    <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 2"/>
    <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 2"/>
    <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 2"/>
    <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 2"/>
    <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 2"/>
    <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 2"/>
    <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 2"/>
    <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 2"/>
    <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 2"/>
    <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 2"/>
    <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 3"/>
    <w:LsdException Locked="false" Priority="61" Name="Light List Accent 3"/>
    <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 3"/>
    <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 3"/>
    <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 3"/>
    <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 3"/>
    <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 3"/>
    <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 3"/>
    <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 3"/>
    <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 3"/>
    <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 3"/>
    <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 3"/>
    <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 3"/>
    <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 3"/>
    <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 4"/>
    <w:LsdException Locked="false" Priority="61" Name="Light List Accent 4"/>
    <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 4"/>
    <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 4"/>
    <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 4"/>
    <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 4"/>
    <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 4"/>
    <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 4"/>
    <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 4"/>
    <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 4"/>
    <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 4"/>
    <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 4"/>
    <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 4"/>
    <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 4"/>
    <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 5"/>
    <w:LsdException Locked="false" Priority="61" Name="Light List Accent 5"/>
    <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 5"/>
    <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 5"/>
    <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 5"/>
    <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 5"/>
    <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 5"/>
    <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 5"/>
    <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 5"/>
    <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 5"/>
    <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 5"/>
    <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 5"/>
    <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 5"/>
    <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 5"/>
    <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 6"/>
    <w:LsdException Locked="false" Priority="61" Name="Light List Accent 6"/>
    <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 6"/>
    <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 6"/>
    <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 6"/>
    <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 6"/>
    <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 6"/>
    <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 6"/>
    <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 6"/>
    <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 6"/>
    <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 6"/>
    <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 6"/>
    <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 6"/>
    <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 6"/>
    <w:LsdException Locked="false" Priority="19" QFormat="true"
     Name="Subtle Emphasis"/>
    <w:LsdException Locked="false" Priority="21" QFormat="true"
     Name="Intense Emphasis"/>
    <w:LsdException Locked="false" Priority="31" QFormat="true"
     Name="Subtle Reference"/>
    <w:LsdException Locked="false" Priority="32" QFormat="true"
     Name="Intense Reference"/>
    <w:LsdException Locked="false" Priority="33" QFormat="true" Name="Book Title"/>
    <w:LsdException Locked="false" Priority="37" SemiHidden="true"
     UnhideWhenUsed="true" Name="Bibliography"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="TOC Heading"/>
    <w:LsdException Locked="false" Priority="41" Name="Plain Table 1"/>
    <w:LsdException Locked="false" Priority="42" Name="Plain Table 2"/>
    <w:LsdException Locked="false" Priority="43" Name="Plain Table 3"/>
    <w:LsdException Locked="false" Priority="44" Name="Plain Table 4"/>
    <w:LsdException Locked="false" Priority="45" Name="Plain Table 5"/>
    <w:LsdException Locked="false" Priority="40" Name="Grid Table Light"/>
    <w:LsdException Locked="false" Priority="46" Name="Grid Table 1 Light"/>
    <w:LsdException Locked="false" Priority="47" Name="Grid Table 2"/>
    <w:LsdException Locked="false" Priority="48" Name="Grid Table 3"/>
    <w:LsdException Locked="false" Priority="49" Name="Grid Table 4"/>
    <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark"/>
    <w:LsdException Locked="false" Priority="51" Name="Grid Table 6 Colorful"/>
    <w:LsdException Locked="false" Priority="52" Name="Grid Table 7 Colorful"/>
    <w:LsdException Locked="false" Priority="46"
     Name="Grid Table 1 Light Accent 1"/>
    <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 1"/>
    <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 1"/>
    <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 1"/>
    <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 1"/>
    <w:LsdException Locked="false" Priority="51"
     Name="Grid Table 6 Colorful Accent 1"/>
    <w:LsdException Locked="false" Priority="52"
     Name="Grid Table 7 Colorful Accent 1"/>
    <w:LsdException Locked="false" Priority="46"
     Name="Grid Table 1 Light Accent 2"/>
    <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 2"/>
    <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 2"/>
    <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 2"/>
    <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 2"/>
    <w:LsdException Locked="false" Priority="51"
     Name="Grid Table 6 Colorful Accent 2"/>
    <w:LsdException Locked="false" Priority="52"
     Name="Grid Table 7 Colorful Accent 2"/>
    <w:LsdException Locked="false" Priority="46"
     Name="Grid Table 1 Light Accent 3"/>
    <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 3"/>
    <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 3"/>
    <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 3"/>
    <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 3"/>
    <w:LsdException Locked="false" Priority="51"
     Name="Grid Table 6 Colorful Accent 3"/>
    <w:LsdException Locked="false" Priority="52"
     Name="Grid Table 7 Colorful Accent 3"/>
    <w:LsdException Locked="false" Priority="46"
     Name="Grid Table 1 Light Accent 4"/>
    <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 4"/>
    <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 4"/>
    <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 4"/>
    <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 4"/>
    <w:LsdException Locked="false" Priority="51"
     Name="Grid Table 6 Colorful Accent 4"/>
    <w:LsdException Locked="false" Priority="52"
     Name="Grid Table 7 Colorful Accent 4"/>
    <w:LsdException Locked="false" Priority="46"
     Name="Grid Table 1 Light Accent 5"/>
    <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 5"/>
    <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 5"/>
    <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 5"/>
    <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 5"/>
    <w:LsdException Locked="false" Priority="51"
     Name="Grid Table 6 Colorful Accent 5"/>
    <w:LsdException Locked="false" Priority="52"
     Name="Grid Table 7 Colorful Accent 5"/>
    <w:LsdException Locked="false" Priority="46"
     Name="Grid Table 1 Light Accent 6"/>
    <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 6"/>
    <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 6"/>
    <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 6"/>
    <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 6"/>
    <w:LsdException Locked="false" Priority="51"
     Name="Grid Table 6 Colorful Accent 6"/>
    <w:LsdException Locked="false" Priority="52"
     Name="Grid Table 7 Colorful Accent 6"/>
    <w:LsdException Locked="false" Priority="46" Name="List Table 1 Light"/>
    <w:LsdException Locked="false" Priority="47" Name="List Table 2"/>
    <w:LsdException Locked="false" Priority="48" Name="List Table 3"/>
    <w:LsdException Locked="false" Priority="49" Name="List Table 4"/>
    <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark"/>
    <w:LsdException Locked="false" Priority="51" Name="List Table 6 Colorful"/>
    <w:LsdException Locked="false" Priority="52" Name="List Table 7 Colorful"/>
    <w:LsdException Locked="false" Priority="46"
     Name="List Table 1 Light Accent 1"/>
    <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 1"/>
    <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 1"/>
    <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 1"/>
    <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 1"/>
    <w:LsdException Locked="false" Priority="51"
     Name="List Table 6 Colorful Accent 1"/>
    <w:LsdException Locked="false" Priority="52"
     Name="List Table 7 Colorful Accent 1"/>
    <w:LsdException Locked="false" Priority="46"
     Name="List Table 1 Light Accent 2"/>
    <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 2"/>
    <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 2"/>
    <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 2"/>
    <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 2"/>
    <w:LsdException Locked="false" Priority="51"
     Name="List Table 6 Colorful Accent 2"/>
    <w:LsdException Locked="false" Priority="52"
     Name="List Table 7 Colorful Accent 2"/>
    <w:LsdException Locked="false" Priority="46"
     Name="List Table 1 Light Accent 3"/>
    <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 3"/>
    <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 3"/>
    <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 3"/>
    <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 3"/>
    <w:LsdException Locked="false" Priority="51"
     Name="List Table 6 Colorful Accent 3"/>
    <w:LsdException Locked="false" Priority="52"
     Name="List Table 7 Colorful Accent 3"/>
    <w:LsdException Locked="false" Priority="46"
     Name="List Table 1 Light Accent 4"/>
    <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 4"/>
    <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 4"/>
    <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 4"/>
    <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 4"/>
    <w:LsdException Locked="false" Priority="51"
     Name="List Table 6 Colorful Accent 4"/>
    <w:LsdException Locked="false" Priority="52"
     Name="List Table 7 Colorful Accent 4"/>
    <w:LsdException Locked="false" Priority="46"
     Name="List Table 1 Light Accent 5"/>
    <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 5"/>
    <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 5"/>
    <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 5"/>
    <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 5"/>
    <w:LsdException Locked="false" Priority="51"
     Name="List Table 6 Colorful Accent 5"/>
    <w:LsdException Locked="false" Priority="52"
     Name="List Table 7 Colorful Accent 5"/>
    <w:LsdException Locked="false" Priority="46"
     Name="List Table 1 Light Accent 6"/>
    <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 6"/>
    <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 6"/>
    <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 6"/>
    <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 6"/>
    <w:LsdException Locked="false" Priority="51"
     Name="List Table 6 Colorful Accent 6"/>
    <w:LsdException Locked="false" Priority="52"
     Name="List Table 7 Colorful Accent 6"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Mention"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Smart Hyperlink"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Hashtag"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Unresolved Mention"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Smart Link"/>
   </w:LatentStyles>
  </xml><![endif]-->
  <style>
  <!--
   /* Font Definitions */
   @font-face
    {font-family:"Cambria Math";
    panose-1:2 4 5 3 5 4 6 3 2 4;
    mso-font-charset:0;
    mso-generic-font-family:roman;
    mso-font-pitch:variable;
    mso-font-signature:3 0 0 0 1 0;}
  @font-face
    {font-family:Calibri;
    panose-1:2 15 5 2 2 2 4 3 2 4;
    mso-font-charset:0;
    mso-generic-font-family:swiss;
    mso-font-pitch:variable;
    mso-font-signature:-469750017 -1073732485 9 0 511 0;}
  @font-face
    {font-family:Georgia;
    panose-1:2 4 5 2 5 4 5 2 3 3;
    mso-font-alt:Georgia;
    mso-font-charset:0;
    mso-generic-font-family:roman;
    mso-font-pitch:variable;
    mso-font-signature:647 0 0 0 159 0;}
  @font-face
    {font-family:Tahoma;
    panose-1:2 11 6 4 3 5 4 4 2 4;
    mso-font-charset:0;
    mso-generic-font-family:swiss;
    mso-font-pitch:variable;
    mso-font-signature:-520081665 -1073717157 41 0 66047 0;}
   /* Style Definitions */
   p.MsoNormal, li.MsoNormal, div.MsoNormal
    {mso-style-priority:1;
    mso-style-unhide:no;
    mso-style-qformat:yes;
    mso-style-parent:"";
    margin:0cm;
    mso-pagination:none;
    font-size:11.0pt;
    font-family:"Calibri",sans-serif;
    mso-ascii-font-family:Calibri;
    mso-ascii-theme-font:minor-latin;
    mso-fareast-font-family:Calibri;
    mso-fareast-theme-font:minor-latin;
    mso-hansi-font-family:Calibri;
    mso-hansi-theme-font:minor-latin;
    mso-bidi-font-family:"Times New Roman";
    mso-bidi-theme-font:minor-bidi;
    mso-ansi-language:EN-US;
    mso-fareast-language:EN-US;}
  p.MsoBodyText, li.MsoBodyText, div.MsoBodyText
    {mso-style-noshow:yes;
    mso-style-priority:1;
    mso-style-qformat:yes;
    mso-style-link:"Body Text Char";
    margin-top:0cm;
    margin-right:0cm;
    margin-bottom:0cm;
    margin-left:7.8pt;
    mso-pagination:none;
    font-size:3.5pt;
    font-family:"Georgia",serif;
    mso-fareast-font-family:Georgia;
    mso-bidi-font-family:"Times New Roman";
    mso-bidi-theme-font:minor-bidi;
    mso-ansi-language:EN-US;
    mso-fareast-language:EN-US;
    font-style:italic;
    mso-bidi-font-style:normal;}
  p.MsoAcetate, li.MsoAcetate, div.MsoAcetate
    {mso-style-noshow:yes;
    mso-style-priority:99;
    mso-style-link:"Balloon Text Char";
    margin:0cm;
    mso-pagination:none;
    font-size:8.0pt;
    font-family:"Tahoma",sans-serif;
    mso-fareast-font-family:Calibri;
    mso-fareast-theme-font:minor-latin;
    mso-ansi-language:EN-US;
    mso-fareast-language:EN-US;}
  p.MsoListParagraph, li.MsoListParagraph, div.MsoListParagraph
    {mso-style-priority:1;
    mso-style-unhide:no;
    mso-style-qformat:yes;
    margin:0cm;
    mso-pagination:none;
    font-size:11.0pt;
    font-family:"Calibri",sans-serif;
    mso-ascii-font-family:Calibri;
    mso-ascii-theme-font:minor-latin;
    mso-fareast-font-family:Calibri;
    mso-fareast-theme-font:minor-latin;
    mso-hansi-font-family:Calibri;
    mso-hansi-theme-font:minor-latin;
    mso-bidi-font-family:"Times New Roman";
    mso-bidi-theme-font:minor-bidi;
    mso-ansi-language:EN-US;
    mso-fareast-language:EN-US;}
  p.msonormal0, li.msonormal0, div.msonormal0
    {mso-style-name:msonormal;
    mso-style-unhide:no;
    mso-margin-top-alt:auto;
    margin-right:0cm;
    mso-margin-bottom-alt:auto;
    margin-left:0cm;
    mso-pagination:widow-orphan;
    font-size:12.0pt;
    font-family:"Times New Roman",serif;
    mso-fareast-font-family:"Times New Roman";
    mso-fareast-theme-font:minor-fareast;}
  span.BodyTextChar
    {mso-style-name:"Body Text Char";
    mso-style-noshow:yes;
    mso-style-priority:99;
    mso-style-unhide:no;
    mso-style-locked:yes;
    mso-style-link:"Body Text";
    mso-ansi-font-size:11.0pt;
    mso-bidi-font-size:11.0pt;}
  span.BalloonTextChar
    {mso-style-name:"Balloon Text Char";
    mso-style-noshow:yes;
    mso-style-priority:99;
    mso-style-unhide:no;
    mso-style-locked:yes;
    mso-style-link:"Balloon Text";
    mso-ansi-font-size:8.0pt;
    mso-bidi-font-size:8.0pt;
    font-family:"Tahoma",sans-serif;
    mso-ascii-font-family:Tahoma;
    mso-hansi-font-family:Tahoma;
    mso-bidi-font-family:Tahoma;}
  p.TableParagraph, li.TableParagraph, div.TableParagraph
    {mso-style-name:"Table Paragraph";
    mso-style-priority:1;
    mso-style-unhide:no;
    mso-style-qformat:yes;
    margin:0cm;
    mso-pagination:none;
    font-size:11.0pt;
    font-family:"Calibri",sans-serif;
    mso-ascii-font-family:Calibri;
    mso-ascii-theme-font:minor-latin;
    mso-fareast-font-family:Calibri;
    mso-fareast-theme-font:minor-latin;
    mso-hansi-font-family:Calibri;
    mso-hansi-theme-font:minor-latin;
    mso-bidi-font-family:"Times New Roman";
    mso-bidi-theme-font:minor-bidi;
    mso-ansi-language:EN-US;
    mso-fareast-language:EN-US;}
  span.SpellE
    {mso-style-name:"";
    mso-spl-e:yes;}
  .MsoChpDefault
    {mso-style-type:export-only;
    mso-default-props:yes;
    font-size:10.0pt;
    mso-ansi-font-size:10.0pt;
    mso-bidi-font-size:10.0pt;
    font-family:"Calibri",sans-serif;
    mso-ascii-font-family:Calibri;
    mso-ascii-theme-font:minor-latin;
    mso-fareast-font-family:Calibri;
    mso-fareast-theme-font:minor-latin;
    mso-hansi-font-family:Calibri;
    mso-hansi-theme-font:minor-latin;
    mso-bidi-font-family:"Times New Roman";
    mso-bidi-theme-font:minor-bidi;
    mso-ansi-language:EN-US;
    mso-fareast-language:EN-US;}
   /* Page Definitions */
   @page
    {mso-footnote-separator:url("DC%20New_files/header.html") fs;
    mso-footnote-continuation-separator:url("DC%20New_files/header.html") fcs;
    mso-endnote-separator:url("DC%20New_files/header.html") es;
    mso-endnote-continuation-separator:url("DC%20New_files/header.html") ecs;}
  @page WordSection1
    {size:842.0pt 595.5pt;
    mso-page-orientation:landscape;
    margin:50.0pt 121.0pt 14.0pt 44.0pt;
    mso-header-margin:36.0pt;
    mso-footer-margin:36.0pt;
    mso-paper-source:0;}
  div.WordSection1
    {page:WordSection1;}
  -->
  </style>
  <!--[if gte mso 10]>
  <style>
   /* Style Definitions */
   table.MsoNormalTable
    {mso-style-name:"Table Normal";
    mso-tstyle-rowband-size:0;
    mso-tstyle-colband-size:0;
    mso-style-noshow:yes;
    mso-style-priority:99;
    mso-style-parent:"";
    mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
    mso-para-margin:0cm;
    mso-pagination:widow-orphan;
    font-size:10.0pt;
    font-family:"Calibri",sans-serif;
    mso-ascii-font-family:Calibri;
    mso-ascii-theme-font:minor-latin;
    mso-hansi-font-family:Calibri;
    mso-hansi-theme-font:minor-latin;
    mso-bidi-font-family:"Times New Roman";
    mso-bidi-theme-font:minor-bidi;
    mso-ansi-language:EN-US;
    mso-fareast-language:EN-US;}
  table.MsoTableGrid
    {mso-style-name:"Table Grid";
    mso-tstyle-rowband-size:0;
    mso-tstyle-colband-size:0;
    mso-style-priority:59;
    mso-style-unhide:no;
    border:solid windowtext 1.0pt;
    mso-border-alt:solid windowtext .5pt;
    mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
    mso-border-insideh:.5pt solid windowtext;
    mso-border-insidev:.5pt solid windowtext;
    mso-para-margin:0cm;
    mso-pagination:none;
    font-size:11.0pt;
    font-family:"Calibri",sans-serif;
    mso-ascii-font-family:Calibri;
    mso-ascii-theme-font:minor-latin;
    mso-hansi-font-family:Calibri;
    mso-hansi-theme-font:minor-latin;
    mso-bidi-font-family:"Times New Roman";
    mso-bidi-theme-font:minor-bidi;
    mso-ansi-language:EN-US;
    mso-fareast-language:EN-US;}
  table.TableNormal1
    {mso-style-name:"Table Normal1";
    mso-tstyle-rowband-size:0;
    mso-tstyle-colband-size:0;
    mso-style-noshow:yes;
    mso-style-priority:2;
    mso-style-unhide:no;
    mso-style-qformat:yes;
    mso-style-parent:"";
    mso-padding-alt:0cm 0cm 0cm 0cm;
    mso-para-margin:0cm;
    mso-pagination:none;
    font-size:11.0pt;
    font-family:"Calibri",sans-serif;
    mso-ascii-font-family:Calibri;
    mso-ascii-theme-font:minor-latin;
    mso-hansi-font-family:Calibri;
    mso-hansi-theme-font:minor-latin;
    mso-bidi-font-family:"Times New Roman";
    mso-bidi-theme-font:minor-bidi;
    mso-ansi-language:EN-US;
    mso-fareast-language:EN-US;}
  </style>
  <![endif]--><!--[if gte mso 9]><xml>
   <o:shapedefaults v:ext="edit" spidmax="2049"/>
  </xml><![endif]--><!--[if gte mso 9]><xml>
   <o:shapelayout v:ext="edit">
    <o:idmap v:ext="edit" data="1"/>
   </o:shapelayout></xml><![endif]-->
  </head>
  
  <body lang=EN-IN style='tab-interval:36.0pt;word-wrap:break-word'>
  
  <div class=WordSection1 style='margin:auto; width:100%; padding-left:10px; padding-top:20px;'>
  
  <p class=MsoNormal style='margin-top:3.65pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:6.35pt;margin-bottom:.0001pt;tab-stops:377.45pt'><span
  lang=DE-AT style='font-size:14.0pt;position:relative;top:4.5pt;mso-text-raise:
  -4.5pt;mso-ansi-language:DE-AT;mso-fareast-language:DE-AT;mso-no-proof:yes'><!--[if gte vml 1]><v:shapetype
   id="_x0000_t75" coordsize="21600,21600" o:spt="75" o:preferrelative="t"
   path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f">
   <v:stroke joinstyle="miter"/>
   <v:formulas>
    <v:f eqn="if lineDrawn pixelLineWidth 0"/>
    <v:f eqn="sum @0 1 0"/>
    <v:f eqn="sum 0 0 @1"/>
    <v:f eqn="prod @2 1 2"/>
    <v:f eqn="prod @3 21600 pixelWidth"/>
    <v:f eqn="prod @3 21600 pixelHeight"/>
    <v:f eqn="sum @0 0 1"/>
    <v:f eqn="prod @6 1 2"/>
    <v:f eqn="prod @7 21600 pixelWidth"/>
    <v:f eqn="sum @8 21600 0"/>
    <v:f eqn="prod @7 21600 pixelHeight"/>
    <v:f eqn="sum @10 21600 0"/>
   </v:formulas>
   <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
   <o:lock v:ext="edit" aspectratio="t"/>
  </v:shapetype><v:shape id="image1.png" o:spid="_x0000_i1025" type="#_x0000_t75"
   style='width:54.6pt;height:27pt;visibility:visible;mso-wrap-style:square'>
   <v:imagedata src="DC%20New_files/image001.png" o:title=""/>
  </v:shape><![endif]--><![if !vml]>
  <img width=73 height=36
  src="data:image/svg+xml;base64, PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI5MiIgaGVpZ2h0PSI0NSIgdmlld0JveD0iMCAwIDkyIDQ1Ij48bGluZWFyR3JhZGllbnQgaWQ9ImEiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIiB4MT0iNDUuNDgzIiB4Mj0iNDUuNDgzIiB5Mj0iNDUuMDAxIj48c3RvcCBvZmZzZXQ9IjAiIHN0b3AtY29sb3I9IiMwMEFFRUYiLz48c3RvcCBvZmZzZXQ9Ii4yMTIiIHN0b3AtY29sb3I9IiMwMDk3REMiLz48c3RvcCBvZmZzZXQ9Ii41MTkiIHN0b3AtY29sb3I9IiMwMDdDQzUiLz48c3RvcCBvZmZzZXQ9Ii43OTIiIHN0b3AtY29sb3I9IiMwMDZDQjgiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiMwMDY2QjMiLz48L2xpbmVhckdyYWRpZW50PjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBmaWxsPSJ1cmwoI2EpIiBkPSJNMCA0NWg0NS45NzRMOTAuOTY2IDBIMHY0NSIvPjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBmaWxsPSIjZmZmIiBkPSJNNTMuOTg0IDlINDVsLjAzIDIxLjEzLTcuODIzLTIxLjEzN0gyOS40NWwtNi42NzggMTcuNjUzYy0uNzEtNC40OTItNS4zNTQtNi4wNDItOS4wMDgtNy4yMDMtMi40MTMtLjc3NS00Ljk3NC0xLjkxNS00Ljk0OC0zLjE3NS4wMi0xLjAzNCAxLjM3LTEuOTkzIDQuMDUzLTEuODUgMS44LjA5NyAzLjM5LjI0MiA2LjU1MyAxLjc3bDMuMTEtNS40MkMxOS42NDggOS4zIDE1LjY2IDguMzczIDEyLjM5IDguMzdoLS4wMmMtMy44MTMgMC02Ljk4OCAxLjIzNS04Ljk1NiAzLjI3LTEuMzcyIDEuNDItMi4xMTIgMy4yMjYtMi4xNDIgNS4yMjMtLjA1IDIuNzQ4Ljk1NyA0LjY5NiAzLjA3MyA2LjI1MyAxLjc4OCAxLjMxIDQuMDc1IDIuMTYgNi4wOSAyLjc4NCAyLjQ4NS43NyA0LjUxNSAxLjQ0IDQuNDkgMi44NjYtLjAyLjUyLS4yMTYgMS4wMDYtLjU5IDEuMzk4LS42Mi42NC0xLjU3Ljg4LTIuODg1LjkwNi0yLjUzNy4wNTQtNC40MTctLjM0NS03LjQxMy0yLjExNkwxLjI3IDM0LjQ0NEM0LjI2MyAzNi4xNDYgNy40NCAzNyAxMS4wNSAzN2wuODEyLS4wMDZjMy4xNDItLjA1NyA1LjY5Mi0uODEgNy43MTgtMi40NC4xMTYtLjA5My4yMi0uMTg3LjMyOC0uMjgybC0uMzQgMS43NTIgNy41OC0uMDI0IDEuMzYtMy40ODJjMS40My40ODggMy4wNTYuNzU4IDQuNzgyLjc1OCAxLjY4MiAwIDMuMjY0LS4yNTYgNC42NjctLjcxNmwuOTQ4IDMuNDQgMTMuNi4wMTMuMDMzLTcuOTM4aDIuODk0YzYuOTk1IDAgMTEuMTMtMy41NiAxMS4xMy05LjUzQzY2LjU2IDExLjg5NiA2Mi41NCA5IDUzLjk4NCA5ek0zMy4yOSAyNy4wNjJjLTEuMDQ1IDAtMi4wMjUtLjE4Mi0yLjg2OC0uNTAybDIuODM2LTguOTU1aC4wNTVsMi43OSA4Ljk4Yy0uODQuMy0xLjc5Ny40NzctMi44MTQuNDc3em0yMS4yMi01LjE0NWgtMS45NzRWMTQuN2gxLjk3NWMyLjYzIDAgNC43My44NzYgNC43MyAzLjU2Mi0uMDAyIDIuNzgtMi4xIDMuNjU1LTQuNzMgMy42NTUiLz48cGF0aCBmaWxsPSJub25lIiBkPSJNMCAwaDkydjQ1SDB6Ii8+PC9zdmc+" v:shapes="image1.png"><![endif]></span><span
  lang=EN-US style='font-size:12.0pt;mso-bidi-font-size:14.0pt;font-family:"Times New Roman",serif;
  mso-hansi-font-family:Calibri;mso-hansi-theme-font:minor-latin;mso-bidi-theme-font:
  minor-bidi'><span style='mso-spacerun:yes'></span></span><b>
  <p lang=EN-US style='text-align:center; width:50%; font-family:"Arial",sans-serif;
  mso-fareast-font-family:Arial'><span>Delivery Challan </span><span lang=EN-US
  style='float:right; font-size:5.5pt;mso-bidi-font-size:14.0pt;font-family:"Georgia",serif;
  mso-hansi-font-family:Calibri;mso-hansi-theme-font:minor-latin;letter-spacing:
  -.05pt'> ORIGINAL</span></p>
  
  <p class=MsoNormal><i style='mso-bidi-font-style:normal'><span lang=EN-US
  style='font-family:"Georgia",serif;mso-fareast-font-family:Georgia;mso-bidi-font-family:
  Georgia'><o:p>&nbsp;</o:p></span></i></p>
  
  <p class=MsoNormal style='margin-top:0cm;margin-bottom:
  0cm;margin-left:398pt;margin-bottom:.0001pt;line-height:106%'>Delivery challan number : ${dcNo}</p>
  
  <p class=MsoNormal style='padding-left:10px; margin-top:0cm;margin-bottom:
  0cm;margin-left:355.0pt;margin-bottom:.0001pt;text-indent:36.0pt;line-height:
  106%'>Delivery challan date  : ${dcDate}</p>
  
  <p class=MsoNormal><span lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;
  mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
  
  <p class=MsoNormal><span lang=EN-US style='font-size:12.0pt;font-family:"Arial",sans-serif;
  mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
  
  <table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
   style='margin-left:-.3pt;border-collapse:collapse;border:none;mso-yfti-tbllook:
   1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt;mso-border-insideh:none;mso-border-insidev:
   none'>
   <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:12.35pt'>
    <td width=175 valign=top style='width:131.6pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><b><span lang=EN-US style='font-size:9.0pt;font-family:
    "Arial",sans-serif;mso-fareast-font-family:Arial'>Consignor Details</span></b><b><span
    lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p></o:p></span></b></p>
    </td>
    <td width=322 valign=top style='width:241.8pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><b><span lang=EN-US style='font-size:9.0pt;font-family:
    "Arial",sans-serif;mso-fareast-font-family:Arial'>Consignee Details</span></b><span
    lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p></o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:1;height:12.95pt'>
    <td width=175 valign=top style='width:131.6pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.95pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>Address line 1<o:p></o:p></span></p>
    </td>
    <td width=322 valign=top style='width:241.8pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.95pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${consignorName}<o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.95pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>Name of the place where goods are consigned<o:p></o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.95pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${consigneeName}<o:p>&nbsp;</o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:2;height:12.35pt'>
    <td width=175 valign=top style='width:131.6pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>Address line 2<o:p></o:p></span></p>
    </td>
    <td width=322 valign=top style='width:241.8pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${consignorAddress}<o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>Address line 1<o:p></o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${consigneeAddress}<o:p>&nbsp;</o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:3;height:12.35pt'>
    <td width=175 valign=top style='width:131.6pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>State Name &amp; Code<o:p></o:p></span></p>
    </td>
    <td width=322 valign=top style='width:241.8pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${consignorState}<o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>Address line 2<o:p></o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${consigneeAdress2}<o:p>&nbsp;</o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:4;height:12.95pt'>
    <td width=175 valign=top style='width:131.6pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.95pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>GSTIN<o:p></o:p></span></p>
    </td>
    <td width=322 valign=top style='width:241.8pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.95pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${consignorGST}<o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.95pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>State Name &amp; Code<o:p></o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.95pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${consigneeState}<o:p>&nbsp;</o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:5;height:12.35pt'>
    <td width=175 valign=top style='width:131.6pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>CIN No.<o:p></o:p></span></p>
    </td>
    <td width=322 valign=top style='width:241.8pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${consignorCIN}<o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>GSTIN/UIN<o:p></o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${consigneeGST}<o:p>&nbsp;</o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:6;height:12.35pt'>
    <td width=175 valign=top style='width:131.6pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>PAN<o:p></o:p></span></p>
    </td>
    <td width=322 valign=top style='width:241.8pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${consignorPAN}<o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>CIN No.<o:p></o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${consigneeCIN}<o:p>&nbsp;</o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:7;height:12.35pt'>
    <td width=175 valign=top style='width:131.6pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=322 valign=top style='width:241.8pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>PAN<o:p></o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${consigneePAN}<o:p>&nbsp;</o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:8;height:12.95pt'>
    <td width=175 valign=top style='width:131.6pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.95pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=322 valign=top style='width:241.8pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.95pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.95pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.95pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:9;height:12.35pt'>
    <td width=175 valign=top style='width:131.6pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>Vehicle Details<o:p></o:p></span></p>
    </td>
    <td width=322 valign=top style='width:241.8pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${vehicleDetails}<o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:10;height:12.35pt'>
    <td width=175 valign=top style='width:131.6pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>Transporter Details<o:p></o:p></span></p>
    </td>
    <td width=322 valign=top style='width:241.8pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${transporterDetails}<o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:11;mso-yfti-lastrow:yes;height:12.35pt'>
    <td width=175 valign=top style='width:131.6pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>Lr/GC Note No. and Date<o:p></o:p></span></p>
    </td>
    <td width=322 valign=top style='width:241.8pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>${lrGcNote}<o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
    </td>
    <td width=254 valign=top style='width:190.5pt;padding:0cm 5.4pt 0cm 5.4pt;
    height:12.35pt'>
    <p class=MsoNormal><span lang=EN-US style='font-size:10.0pt;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
    </td>
   </tr>
  </table>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><span style='mso-spacerun:yes'></span><o:p></o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'>Place of supply (State Name & Code)<o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <table class=TableNormal1 border=0 cellspacing=0 cellpadding=0 align=left
   style='border-collapse:collapse;mso-table-layout-alt:fixed;mso-yfti-tbllook:
   480;mso-table-lspace:9.0pt;margin-left:6.75pt;mso-table-rspace:9.0pt;
   margin-right:6.75pt;mso-table-anchor-vertical:page;mso-table-anchor-horizontal:
   margin;mso-table-left:left;mso-table-top:282.25pt;mso-padding-alt:0cm 0cm 0cm 0cm'>
   <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:17.25pt'>
    <td width=104 rowspan=2 valign=top style='width:77.95pt;border:solid black 1.0pt;
    mso-border-alt:solid black .5pt;padding:0cm 0cm 0cm 0cm;height:17.25pt'>
    <p class=TableParagraph style='mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p>&nbsp;</o:p></span></p>
    <p class=TableParagraph align=center style='margin-top:2.05pt;margin-right:
    0cm;margin-bottom:0cm;margin-left:.15pt;margin-bottom:.0001pt;text-align:
    center;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
    around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:margin;
    mso-element-top:282.25pt;mso-height-rule:exactly'><span class=SpellE><span
    lang=EN-US style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'>S.No</span></span><span lang=EN-US style='font-size:8.0pt;font-family:
    "Arial",sans-serif;mso-fareast-font-family:Arial'>.<o:p></o:p></span></p>
    </td>
    <td width=94 rowspan=2 valign=top style='width:70.55pt;border:solid black 1.0pt;
    padding:0cm 0cm 0cm 0cm;height:17.25pt'>
    <p class=TableParagraph style='mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p>&nbsp;</o:p></span></p>
    <p class=TableParagraph style='margin-top:2.05pt;margin-right:0cm;margin-bottom:
    0cm;margin-left:16.25pt;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'>Description of Goods<o:p></o:p></span></p>
    </td>
    <td width=49 rowspan=2 valign=top style='width:36.45pt;border:solid black 1.0pt;
    mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:0cm 0cm 0cm 0cm;height:17.25pt'>
    <p class=TableParagraph style='mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p>&nbsp;</o:p></span></p>
    <p class=TableParagraph style='margin-top:2.05pt;margin-right:0cm;margin-bottom:
    0cm;margin-left:6.4pt;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'>HSN (Goods)<o:p></o:p></span></p>
    </td>
    <td width=197 rowspan=2 valign=top style='width:148.05pt;border:solid black 1.0pt;
    mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:0cm 0cm 0cm 0cm;height:17.25pt'>
    <p class=TableParagraph style='mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p>&nbsp;</o:p></span></p>
    <p class=TableParagraph align=center style='margin-top:2.05pt;margin-right:
    0cm;margin-bottom:0cm;margin-left:.4pt;margin-bottom:.0001pt;text-align:center;
    mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;
    mso-element-anchor-vertical:page;mso-element-anchor-horizontal:margin;
    mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'>Quantity<o:p></o:p></span></p>
    </td>
    <td width=67 rowspan=2 valign=top style='width:50.35pt;border:solid black 1.0pt;
    mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:0cm 0cm 0cm 0cm;height:17.25pt'>
    <p class=TableParagraph style='mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p>&nbsp;</o:p></span></p>
    <p class=TableParagraph style='margin-top:2.05pt;margin-right:0cm;margin-bottom:
    0cm;margin-left:.9pt;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'>Unit of Measurement<o:p></o:p></span></p>
    </td>
    <td width=36 rowspan=2 valign=top style='width:26.85pt;border:solid black 1.0pt;
    mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:0cm 0cm 0cm 0cm;height:17.25pt'>
    <p class=TableParagraph style='mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p>&nbsp;</o:p></span></p>
    <p class=TableParagraph style='margin-top:2.05pt;margin-right:0cm;margin-bottom:
    0cm;margin-left:3.4pt;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'>Rate/ Price<o:p></o:p></span></p>
    </td>
    <td width=57 rowspan=2 valign=top style='width:42.75pt;border:solid black 1.0pt;
    mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:0cm 0cm 0cm 0cm;height:17.25pt'>
    <p class=TableParagraph style='mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p>&nbsp;</o:p></span></p>
    <p class=TableParagraph align=center style='margin-top:2.05pt;margin-right:
    0cm;margin-bottom:0cm;margin-left:.2pt;margin-bottom:.0001pt;text-align:center;
    mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;
    mso-element-anchor-vertical:page;mso-element-anchor-horizontal:margin;
    mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'>Value<o:p></o:p></span></p>
    </td>
    <td width=87 colspan=2 valign=top style='width:65.3pt;border:solid black 1.0pt;
    mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:0cm 0cm 0cm 0cm;height:17.25pt'>
    <p class=TableParagraph align=center style='margin-top:1.4pt;margin-right:
    0cm;margin-bottom:0cm;margin-left:.2pt;margin-bottom:.0001pt;text-align:center;
    mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;
    mso-element-anchor-vertical:page;mso-element-anchor-horizontal:margin;
    mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'>CGST<o:p></o:p></span></p>
    </td>
    <td width=86 colspan=2 valign=top style='width:64.7pt;border:solid black 1.0pt;
    mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:0cm 0cm 0cm 0cm;height:17.25pt'>
    <p class=TableParagraph style='margin-top:1.4pt;margin-right:0cm;margin-bottom:
    0cm;margin-left:11.95pt;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'>SGST/UTGST<o:p></o:p></span></p>
    </td>
    <td width=74 colspan=2 valign=top style='width:55.4pt;border:solid black 1.0pt;
    mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:0cm 0cm 0cm 0cm;height:17.25pt'>
    <p class=TableParagraph align=center style='margin-top:1.4pt;margin-right:
    0cm;margin-bottom:0cm;margin-left:.2pt;margin-bottom:.0001pt;text-align:center;
    mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;
    mso-element-anchor-vertical:page;mso-element-anchor-horizontal:margin;
    mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'>IGST<o:p></o:p></span></p>
    </td>
    <td width=75 rowspan=2 valign=top style='width:56.35pt;border:solid black 1.0pt;
    mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:0cm 0cm 0cm 0cm;height:17.25pt'>
    <p class=TableParagraph style='margin-top:.35pt;mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p>&nbsp;</o:p></span></p>
    <p class=TableParagraph style='margin-top:0cm;margin-right:3.0pt;margin-bottom:
    0cm;margin-left:15.5pt;margin-bottom:.0001pt;text-indent:-12.15pt;line-height:
    110%;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;
    mso-element-anchor-vertical:page;mso-element-anchor-horizontal:margin;
    mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;line-height:110%;font-family:"Arial",sans-serif;
    mso-fareast-font-family:Arial'>Total Amount (incl. tax)<o:p></o:p></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:1;height:25.45pt'>
    <td width=31 valign=top style='width:23.6pt;border-top:none;
    border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;mso-border-top-alt:
    solid black .5pt;mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:0cm 0cm 0cm 0cm;height:25.45pt'>
    <p class=TableParagraph style='margin-top:.25pt;mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p>&nbsp;</o:p></span></p>
    <p class=TableParagraph style='margin-left:6.15pt;mso-element:frame;
    mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
    page;mso-element-anchor-horizontal:margin;mso-element-top:282.25pt;
    mso-height-rule:exactly'><span lang=EN-US style='font-size:8.0pt;font-family:
    "Arial",sans-serif;mso-fareast-font-family:Arial'>Rate<o:p></o:p></span></p>
    </td>
    <td width=56 valign=top style='width:41.7pt;border-top:none;
    border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;mso-border-top-alt:
    solid black .5pt;mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:0cm 0cm 0cm 0cm;height:25.45pt'>
    <p class=TableParagraph style='margin-top:.25pt;mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p>&nbsp;</o:p></span></p>
    <p class=TableParagraph style='margin-left:4.35pt;mso-element:frame;
    mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
    page;mso-element-anchor-horizontal:margin;mso-element-top:282.25pt;
    mso-height-rule:exactly'><span lang=EN-US style='font-size:8.0pt;font-family:
    "Arial",sans-serif;mso-fareast-font-family:Arial'>Tax Amount<o:p></o:p></span></p>
    </td>
    <td width=31 valign=top style='width:23.0pt;border-top:none;
    border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;mso-border-top-alt:
    solid black .5pt;mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:0cm 0cm 0cm 0cm;height:25.45pt'>
    <p class=TableParagraph style='margin-top:.25pt;mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p>&nbsp;</o:p></span></p>
    <p class=TableParagraph style='margin-left:5.55pt;mso-element:frame;
    mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
    page;mso-element-anchor-horizontal:margin;mso-element-top:282.25pt;
    mso-height-rule:exactly'><span lang=EN-US style='font-size:8.0pt;font-family:
    "Arial",sans-serif;mso-fareast-font-family:Arial'>Rate<o:p></o:p></span></p>
    </td>
    <td width=56 valign=top style='width:41.7pt;border-top:none;
    border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;mso-border-top-alt:
    solid black .5pt;mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:0cm 0cm 0cm 0cm;height:25.45pt'>
    <p class=TableParagraph style='margin-top:.25pt;mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p>&nbsp;</o:p></span></p>
    <p class=TableParagraph style='margin-left:4.35pt;mso-element:frame;
    mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
    page;mso-element-anchor-horizontal:margin;mso-element-top:282.25pt;
    mso-height-rule:exactly'><span lang=EN-US style='font-size:8.0pt;font-family:
    "Arial",sans-serif;mso-fareast-font-family:Arial'>Tax Amount<o:p></o:p></span></p>
    </td>
    <td width=31 valign=top style='width:22.9pt;border-top:none;
    border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;mso-border-top-alt:
    solid black .5pt;mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:0cm 0cm 0cm 0cm;height:25.45pt'>
    <p class=TableParagraph style='margin-top:.25pt;mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p>&nbsp;</o:p></span></p>
    <p class=TableParagraph style='margin-left:5.45pt;mso-element:frame;
    mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
    page;mso-element-anchor-horizontal:margin;mso-element-top:282.25pt;
    mso-height-rule:exactly'><span lang=EN-US style='font-size:8.0pt;font-family:
    "Arial",sans-serif;mso-fareast-font-family:Arial'>Rate<o:p></o:p></span></p>
    </td>
    <td width=43 valign=top style='width:32.5pt;border-top:none;
    border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;mso-border-top-alt:
    solid black .5pt;mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:0cm 0cm 0cm 0cm;height:25.45pt'>
    <p class=TableParagraph style='margin-top:.25pt;mso-element:frame;mso-element-frame-hspace:
    9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:page;mso-element-anchor-horizontal:
    margin;mso-element-top:282.25pt;mso-height-rule:exactly'><span lang=EN-US
    style='font-size:8.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'><o:p>&nbsp;</o:p></span></p>
    <p class=TableParagraph style='margin-left:4.35pt;mso-element:frame;
    mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
    page;mso-element-anchor-horizontal:margin;mso-element-top:282.25pt;
    mso-height-rule:exactly'><span lang=EN-US style='font-size:8.0pt;font-family:
    "Arial",sans-serif;mso-fareast-font-family:Arial'>Tax Amount<o:p></o:p></span></p>
    </td>
   </tr>
   ${getRows(rows)}
  </table>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'><o:p>&nbsp;</o:p></span></b></p>
  
  
  
  <p class=MsoBodyText style='tab-stops:405.2pt'><b style='mso-bidi-font-weight:
  normal'><span lang=EN-US style='font-size:5.5pt;font-family:"Arial",sans-serif;
  mso-hansi-font-family:Georgia;mso-bidi-font-family:"Times New Roman";
  mso-bidi-theme-font:minor-bidi;letter-spacing:-.05pt;mso-font-width:95%;
  font-style:normal'>Remarks:</span></b><b style='mso-bidi-font-weight:normal'><span
  lang=EN-US style='font-size:5.5pt;font-family:"Times New Roman",serif;
  mso-hansi-font-family:Georgia;mso-bidi-theme-font:minor-bidi;letter-spacing:
  -.05pt;mso-font-width:95%;font-style:normal'><span style='mso-tab-count:1'>                                                                                                                                                                                                                                                                                                                                 </span></span></b><span
  lang=EN-US style='font-size:5.5pt;letter-spacing:-.05pt'>Signature</span><span
  lang=EN-US style='font-size:5.5pt;letter-spacing:-.15pt'> </span><span
  lang=EN-US style='font-size:5.5pt'>or<span style='letter-spacing:-.2pt'> </span>digital<span
  style='letter-spacing:-.2pt'> </span><span style='letter-spacing:-.05pt'>signature</span><span
  style='letter-spacing:-.1pt'> </span>of<span style='letter-spacing:-.15pt'> </span><span
  style='letter-spacing:-.05pt'>supplier/</span><span style='letter-spacing:-.1pt'>
  </span><span class=SpellE>authorised</span><span style='letter-spacing:-.15pt'>
  </span><span style='letter-spacing:-.05pt'>representative</span></span><span
  lang=EN-US style='font-size:5.5pt;font-style:normal'><o:p></o:p></span></p>
  
  <p class=MsoNormal style='margin-top:.5pt'><i style='mso-bidi-font-style:normal'><span
  lang=EN-US style='font-size:6.0pt;font-family:"Georgia",serif;mso-fareast-font-family:
  Georgia;mso-bidi-font-family:Georgia'><o:p>&nbsp;</o:p></span></i></p>
  
  </div>
  
  </body>
  
  </html>
  
  `;
};
