exports.getForm2Temp = (data) => {
  const {
    gpName, gpAddress, rpName, rpAddress, totalWeight,

  } = data;
  return `<html style="zoom: 0.85; xmlns:v="urn:schemas-microsoft-com:vml"
  xmlns:o="urn:schemas-microsoft-com:office:office"
  xmlns:w="urn:schemas-microsoft-com:office:word"
  xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"
  xmlns="http://www.w3.org/TR/REC-html40">
  
  <head>
  <meta http-equiv=Content-Type content="text/html; charset=windows-1252">
  <meta name=ProgId content=Word.Document>
  <meta name=Generator content="Microsoft Word 15">
  <meta name=Originator content="Microsoft Word 15">
  <link rel=File-List href="Form%202_files/filelist.xml">
  <title>Microsoft Word - Forms 2</title>
  <link rel=themeData href="Form%202_files/themedata.thmx">
  <link rel=colorSchemeMapping href="Form%202_files/colorschememapping.xml">
  <!--[if gte mso 9]><xml>
   <w:WordDocument>
    <w:SpellingState>Clean</w:SpellingState>
    <w:GrammarState>Clean</w:GrammarState>
    <w:TrackMoves>false</w:TrackMoves>
    <w:TrackFormatting/>
    <w:PunctuationKerning/>
    <w:ValidateAgainstSchemas/>
    <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
    <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
    <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
    <w:DoNotPromoteQF/>
    <w:LidThemeOther>EN-IN</w:LidThemeOther>
    <w:LidThemeAsian>X-NONE</w:LidThemeAsian>
    <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>
    <w:Compatibility>
     <w:BreakWrappedTables/>
     <w:SnapToGridInCell/>
     <w:WrapTextWithPunct/>
     <w:UseAsianBreakRules/>
     <w:DontGrowAutofit/>
     <w:SplitPgBreakAndParaMark/>
     <w:EnableOpenTypeKerning/>
     <w:DontFlipMirrorIndents/>
     <w:OverrideTableStyleHps/>
     <w:UseFELayout/>
    </w:Compatibility>
    <w:DoNotOptimizeForBrowser/>
    <m:mathPr>
     <m:mathFont m:val="Cambria Math"/>
     <m:brkBin m:val="before"/>
     <m:brkBinSub m:val="&#45;-"/>
     <m:smallFrac m:val="off"/>
     <m:dispDef/>
     <m:lMargin m:val="0"/>
     <m:rMargin m:val="0"/>
     <m:defJc m:val="centerGroup"/>
     <m:wrapIndent m:val="1440"/>
     <m:intLim m:val="subSup"/>
     <m:naryLim m:val="undOvr"/>
    </m:mathPr></w:WordDocument>
  </xml><![endif]--><!--[if gte mso 9]><xml>
   <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="false"
    DefSemiHidden="false" DefQFormat="false" DefPriority="99"
    LatentStyleCount="376">
    <w:LsdException Locked="false" Priority="0" QFormat="true" Name="Normal"/>
    <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 1"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 2"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 3"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 4"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 5"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 6"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 7"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 8"/>
    <w:LsdException Locked="false" Priority="9" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="heading 9"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 5"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 6"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 7"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 8"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index 9"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 1"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 2"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 3"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 4"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 5"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 6"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 7"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 8"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" Name="toc 9"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Normal Indent"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="footnote text"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="annotation text"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="header"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="footer"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="index heading"/>
    <w:LsdException Locked="false" Priority="35" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="caption"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="table of figures"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="envelope address"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="envelope return"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="footnote reference"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="annotation reference"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="line number"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="page number"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="endnote reference"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="endnote text"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="table of authorities"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="macro"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="toa heading"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Bullet"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Number"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List 5"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Bullet 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Bullet 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Bullet 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Bullet 5"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Number 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Number 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Number 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Number 5"/>
    <w:LsdException Locked="false" Priority="10" QFormat="true" Name="Title"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Closing"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Signature"/>
    <w:LsdException Locked="false" Priority="1" SemiHidden="true"
     UnhideWhenUsed="true" Name="Default Paragraph Font"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Body Text"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Body Text Indent"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Continue"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Continue 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Continue 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Continue 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="List Continue 5"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Message Header"/>
    <w:LsdException Locked="false" Priority="11" QFormat="true" Name="Subtitle"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Salutation"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Date"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Body Text First Indent"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Body Text First Indent 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Note Heading"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Body Text 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Body Text 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Body Text Indent 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Body Text Indent 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Block Text"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Hyperlink"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="FollowedHyperlink"/>
    <w:LsdException Locked="false" Priority="22" QFormat="true" Name="Strong"/>
    <w:LsdException Locked="false" Priority="20" QFormat="true" Name="Emphasis"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Document Map"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Plain Text"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="E-mail Signature"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Top of Form"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Bottom of Form"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Normal (Web)"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Acronym"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Address"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Cite"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Code"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Definition"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Keyboard"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Preformatted"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Sample"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Typewriter"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="HTML Variable"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Normal Table"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="annotation subject"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="No List"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Outline List 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Outline List 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Outline List 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Simple 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Simple 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Simple 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Classic 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Classic 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Classic 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Classic 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Colorful 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Colorful 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Colorful 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Columns 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Columns 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Columns 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Columns 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Columns 5"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 5"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 6"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 7"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Grid 8"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 4"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 5"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 6"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 7"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table List 8"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table 3D effects 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table 3D effects 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table 3D effects 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Contemporary"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Elegant"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Professional"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Subtle 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Subtle 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Web 1"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Web 2"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Web 3"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Balloon Text"/>
    <w:LsdException Locked="false" Priority="39" Name="Table Grid"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Table Theme"/>
    <w:LsdException Locked="false" SemiHidden="true" Name="Placeholder Text"/>
    <w:LsdException Locked="false" Priority="1" QFormat="true" Name="No Spacing"/>
    <w:LsdException Locked="false" Priority="60" Name="Light Shading"/>
    <w:LsdException Locked="false" Priority="61" Name="Light List"/>
    <w:LsdException Locked="false" Priority="62" Name="Light Grid"/>
    <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1"/>
    <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2"/>
    <w:LsdException Locked="false" Priority="65" Name="Medium List 1"/>
    <w:LsdException Locked="false" Priority="66" Name="Medium List 2"/>
    <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1"/>
    <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2"/>
    <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3"/>
    <w:LsdException Locked="false" Priority="70" Name="Dark List"/>
    <w:LsdException Locked="false" Priority="71" Name="Colorful Shading"/>
    <w:LsdException Locked="false" Priority="72" Name="Colorful List"/>
    <w:LsdException Locked="false" Priority="73" Name="Colorful Grid"/>
    <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 1"/>
    <w:LsdException Locked="false" Priority="61" Name="Light List Accent 1"/>
    <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 1"/>
    <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 1"/>
    <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 1"/>
    <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 1"/>
    <w:LsdException Locked="false" SemiHidden="true" Name="Revision"/>
    <w:LsdException Locked="false" Priority="34" QFormat="true"
     Name="List Paragraph"/>
    <w:LsdException Locked="false" Priority="29" QFormat="true" Name="Quote"/>
    <w:LsdException Locked="false" Priority="30" QFormat="true"
     Name="Intense Quote"/>
    <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 1"/>
    <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 1"/>
    <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 1"/>
    <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 1"/>
    <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 1"/>
    <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 1"/>
    <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 1"/>
    <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 1"/>
    <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 2"/>
    <w:LsdException Locked="false" Priority="61" Name="Light List Accent 2"/>
    <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 2"/>
    <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 2"/>
    <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 2"/>
    <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 2"/>
    <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 2"/>
    <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 2"/>
    <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 2"/>
    <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 2"/>
    <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 2"/>
    <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 2"/>
    <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 2"/>
    <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 2"/>
    <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 3"/>
    <w:LsdException Locked="false" Priority="61" Name="Light List Accent 3"/>
    <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 3"/>
    <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 3"/>
    <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 3"/>
    <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 3"/>
    <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 3"/>
    <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 3"/>
    <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 3"/>
    <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 3"/>
    <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 3"/>
    <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 3"/>
    <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 3"/>
    <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 3"/>
    <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 4"/>
    <w:LsdException Locked="false" Priority="61" Name="Light List Accent 4"/>
    <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 4"/>
    <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 4"/>
    <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 4"/>
    <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 4"/>
    <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 4"/>
    <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 4"/>
    <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 4"/>
    <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 4"/>
    <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 4"/>
    <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 4"/>
    <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 4"/>
    <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 4"/>
    <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 5"/>
    <w:LsdException Locked="false" Priority="61" Name="Light List Accent 5"/>
    <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 5"/>
    <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 5"/>
    <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 5"/>
    <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 5"/>
    <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 5"/>
    <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 5"/>
    <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 5"/>
    <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 5"/>
    <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 5"/>
    <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 5"/>
    <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 5"/>
    <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 5"/>
    <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 6"/>
    <w:LsdException Locked="false" Priority="61" Name="Light List Accent 6"/>
    <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 6"/>
    <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 6"/>
    <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 6"/>
    <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 6"/>
    <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 6"/>
    <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 6"/>
    <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 6"/>
    <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 6"/>
    <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 6"/>
    <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 6"/>
    <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 6"/>
    <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 6"/>
    <w:LsdException Locked="false" Priority="19" QFormat="true"
     Name="Subtle Emphasis"/>
    <w:LsdException Locked="false" Priority="21" QFormat="true"
     Name="Intense Emphasis"/>
    <w:LsdException Locked="false" Priority="31" QFormat="true"
     Name="Subtle Reference"/>
    <w:LsdException Locked="false" Priority="32" QFormat="true"
     Name="Intense Reference"/>
    <w:LsdException Locked="false" Priority="33" QFormat="true" Name="Book Title"/>
    <w:LsdException Locked="false" Priority="37" SemiHidden="true"
     UnhideWhenUsed="true" Name="Bibliography"/>
    <w:LsdException Locked="false" Priority="39" SemiHidden="true"
     UnhideWhenUsed="true" QFormat="true" Name="TOC Heading"/>
    <w:LsdException Locked="false" Priority="41" Name="Plain Table 1"/>
    <w:LsdException Locked="false" Priority="42" Name="Plain Table 2"/>
    <w:LsdException Locked="false" Priority="43" Name="Plain Table 3"/>
    <w:LsdException Locked="false" Priority="44" Name="Plain Table 4"/>
    <w:LsdException Locked="false" Priority="45" Name="Plain Table 5"/>
    <w:LsdException Locked="false" Priority="40" Name="Grid Table Light"/>
    <w:LsdException Locked="false" Priority="46" Name="Grid Table 1 Light"/>
    <w:LsdException Locked="false" Priority="47" Name="Grid Table 2"/>
    <w:LsdException Locked="false" Priority="48" Name="Grid Table 3"/>
    <w:LsdException Locked="false" Priority="49" Name="Grid Table 4"/>
    <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark"/>
    <w:LsdException Locked="false" Priority="51" Name="Grid Table 6 Colorful"/>
    <w:LsdException Locked="false" Priority="52" Name="Grid Table 7 Colorful"/>
    <w:LsdException Locked="false" Priority="46"
     Name="Grid Table 1 Light Accent 1"/>
    <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 1"/>
    <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 1"/>
    <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 1"/>
    <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 1"/>
    <w:LsdException Locked="false" Priority="51"
     Name="Grid Table 6 Colorful Accent 1"/>
    <w:LsdException Locked="false" Priority="52"
     Name="Grid Table 7 Colorful Accent 1"/>
    <w:LsdException Locked="false" Priority="46"
     Name="Grid Table 1 Light Accent 2"/>
    <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 2"/>
    <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 2"/>
    <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 2"/>
    <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 2"/>
    <w:LsdException Locked="false" Priority="51"
     Name="Grid Table 6 Colorful Accent 2"/>
    <w:LsdException Locked="false" Priority="52"
     Name="Grid Table 7 Colorful Accent 2"/>
    <w:LsdException Locked="false" Priority="46"
     Name="Grid Table 1 Light Accent 3"/>
    <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 3"/>
    <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 3"/>
    <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 3"/>
    <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 3"/>
    <w:LsdException Locked="false" Priority="51"
     Name="Grid Table 6 Colorful Accent 3"/>
    <w:LsdException Locked="false" Priority="52"
     Name="Grid Table 7 Colorful Accent 3"/>
    <w:LsdException Locked="false" Priority="46"
     Name="Grid Table 1 Light Accent 4"/>
    <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 4"/>
    <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 4"/>
    <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 4"/>
    <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 4"/>
    <w:LsdException Locked="false" Priority="51"
     Name="Grid Table 6 Colorful Accent 4"/>
    <w:LsdException Locked="false" Priority="52"
     Name="Grid Table 7 Colorful Accent 4"/>
    <w:LsdException Locked="false" Priority="46"
     Name="Grid Table 1 Light Accent 5"/>
    <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 5"/>
    <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 5"/>
    <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 5"/>
    <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 5"/>
    <w:LsdException Locked="false" Priority="51"
     Name="Grid Table 6 Colorful Accent 5"/>
    <w:LsdException Locked="false" Priority="52"
     Name="Grid Table 7 Colorful Accent 5"/>
    <w:LsdException Locked="false" Priority="46"
     Name="Grid Table 1 Light Accent 6"/>
    <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 6"/>
    <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 6"/>
    <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 6"/>
    <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 6"/>
    <w:LsdException Locked="false" Priority="51"
     Name="Grid Table 6 Colorful Accent 6"/>
    <w:LsdException Locked="false" Priority="52"
     Name="Grid Table 7 Colorful Accent 6"/>
    <w:LsdException Locked="false" Priority="46" Name="List Table 1 Light"/>
    <w:LsdException Locked="false" Priority="47" Name="List Table 2"/>
    <w:LsdException Locked="false" Priority="48" Name="List Table 3"/>
    <w:LsdException Locked="false" Priority="49" Name="List Table 4"/>
    <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark"/>
    <w:LsdException Locked="false" Priority="51" Name="List Table 6 Colorful"/>
    <w:LsdException Locked="false" Priority="52" Name="List Table 7 Colorful"/>
    <w:LsdException Locked="false" Priority="46"
     Name="List Table 1 Light Accent 1"/>
    <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 1"/>
    <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 1"/>
    <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 1"/>
    <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 1"/>
    <w:LsdException Locked="false" Priority="51"
     Name="List Table 6 Colorful Accent 1"/>
    <w:LsdException Locked="false" Priority="52"
     Name="List Table 7 Colorful Accent 1"/>
    <w:LsdException Locked="false" Priority="46"
     Name="List Table 1 Light Accent 2"/>
    <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 2"/>
    <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 2"/>
    <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 2"/>
    <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 2"/>
    <w:LsdException Locked="false" Priority="51"
     Name="List Table 6 Colorful Accent 2"/>
    <w:LsdException Locked="false" Priority="52"
     Name="List Table 7 Colorful Accent 2"/>
    <w:LsdException Locked="false" Priority="46"
     Name="List Table 1 Light Accent 3"/>
    <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 3"/>
    <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 3"/>
    <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 3"/>
    <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 3"/>
    <w:LsdException Locked="false" Priority="51"
     Name="List Table 6 Colorful Accent 3"/>
    <w:LsdException Locked="false" Priority="52"
     Name="List Table 7 Colorful Accent 3"/>
    <w:LsdException Locked="false" Priority="46"
     Name="List Table 1 Light Accent 4"/>
    <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 4"/>
    <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 4"/>
    <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 4"/>
    <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 4"/>
    <w:LsdException Locked="false" Priority="51"
     Name="List Table 6 Colorful Accent 4"/>
    <w:LsdException Locked="false" Priority="52"
     Name="List Table 7 Colorful Accent 4"/>
    <w:LsdException Locked="false" Priority="46"
     Name="List Table 1 Light Accent 5"/>
    <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 5"/>
    <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 5"/>
    <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 5"/>
    <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 5"/>
    <w:LsdException Locked="false" Priority="51"
     Name="List Table 6 Colorful Accent 5"/>
    <w:LsdException Locked="false" Priority="52"
     Name="List Table 7 Colorful Accent 5"/>
    <w:LsdException Locked="false" Priority="46"
     Name="List Table 1 Light Accent 6"/>
    <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 6"/>
    <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 6"/>
    <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 6"/>
    <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 6"/>
    <w:LsdException Locked="false" Priority="51"
     Name="List Table 6 Colorful Accent 6"/>
    <w:LsdException Locked="false" Priority="52"
     Name="List Table 7 Colorful Accent 6"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Mention"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Smart Hyperlink"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Hashtag"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Unresolved Mention"/>
    <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
     Name="Smart Link"/>
   </w:LatentStyles>
  </xml><![endif]-->
  <style>
  <!--
   /* Font Definitions */
   @font-face
      {font-family:"Cambria Math";
      panose-1:2 4 5 3 5 4 6 3 2 4;
      mso-font-charset:0;
      mso-generic-font-family:roman;
      mso-font-pitch:variable;
      mso-font-signature:3 0 0 0 1 0;}
  @font-face
      {font-family:Calibri;
      panose-1:2 15 5 2 2 2 4 3 2 4;
      mso-font-charset:0;
      mso-generic-font-family:swiss;
      mso-font-pitch:variable;
      mso-font-signature:-469750017 -1073732485 9 0 511 0;}
   /* Style Definitions */
   p.MsoNormal, li.MsoNormal, div.MsoNormal
      {mso-style-unhide:no;
      mso-style-qformat:yes;
      mso-style-parent:"";
      margin-top:0cm;
      margin-right:0cm;
      margin-bottom:8.0pt;
      margin-left:0cm;
      line-height:106%;
      mso-pagination:widow-orphan;
      font-size:13.0pt;;
      font-family:"Calibri",sans-serif;
      mso-fareast-font-family:Calibri;
      color:black;}
  p.MsoListParagraph, li.MsoListParagraph, div.MsoListParagraph
      {mso-style-priority:34;
      mso-style-unhide:no;
      mso-style-qformat:yes;
      margin-top:0cm;
      margin-right:0cm;
      margin-bottom:8.0pt;
      margin-left:36.0pt;
      mso-add-space:auto;
      line-height:106%;
      mso-pagination:widow-orphan;
      font-size:13.0pt;;
      font-family:"Calibri",sans-serif;
      mso-fareast-font-family:Calibri;
      color:black;}
  p.MsoListParagraphCxSpFirst, li.MsoListParagraphCxSpFirst, div.MsoListParagraphCxSpFirst
      {mso-style-priority:34;
      mso-style-unhide:no;
      mso-style-qformat:yes;
      mso-style-type:export-only;
      margin-top:0cm;
      margin-right:0cm;
      margin-bottom:0cm;
      margin-left:36.0pt;
      mso-add-space:auto;
      line-height:106%;
      mso-pagination:widow-orphan;
      font-size:13.0pt;;
      font-family:"Calibri",sans-serif;
      mso-fareast-font-family:Calibri;
      color:black;}
  p.MsoListParagraphCxSpMiddle, li.MsoListParagraphCxSpMiddle, div.MsoListParagraphCxSpMiddle
      {mso-style-priority:34;
      mso-style-unhide:no;
      mso-style-qformat:yes;
      mso-style-type:export-only;
      margin-top:0cm;
      margin-right:0cm;
      margin-bottom:0cm;
      margin-left:36.0pt;
      mso-add-space:auto;
      line-height:106%;
      mso-pagination:widow-orphan;
      font-size:13.0pt;;
      font-family:"Calibri",sans-serif;
      mso-fareast-font-family:Calibri;
      color:black;}
  p.MsoListParagraphCxSpLast, li.MsoListParagraphCxSpLast, div.MsoListParagraphCxSpLast
      {mso-style-priority:34;
      mso-style-unhide:no;
      mso-style-qformat:yes;
      mso-style-type:export-only;
      margin-top:0cm;
      margin-right:0cm;
      margin-bottom:8.0pt;
      margin-left:36.0pt;
      mso-add-space:auto;
      line-height:106%;
      mso-pagination:widow-orphan;
      font-size:13.0pt;;
      font-family:"Calibri",sans-serif;
      mso-fareast-font-family:Calibri;
      color:black;}
  p.msonormal0, li.msonormal0, div.msonormal0
      {mso-style-name:msonormal;
      mso-style-unhide:no;
      mso-margin-top-alt:auto;
      margin-right:0cm;
      mso-margin-bottom-alt:auto;
      margin-left:0cm;
      mso-pagination:widow-orphan;
      font-size:12.0pt;
      font-family:"Times New Roman",serif;
      mso-fareast-font-family:"Times New Roman";
      mso-fareast-theme-font:minor-fareast;}
  span.SpellE
      {mso-style-name:"";
      mso-spl-e:yes;}
  span.GramE
      {mso-style-name:"";
      mso-gram-e:yes;}
  .MsoChpDefault
      {mso-style-type:export-only;
      mso-default-props:yes;
      font-size:13.0pt;;;
      mso-ansi-font-size:13.0pt;;;
      mso-bidi-font-size:13.0pt;;;
      font-family:"Calibri",sans-serif;
      mso-ascii-font-family:Calibri;
      mso-ascii-theme-font:minor-latin;
      mso-fareast-font-family:"Times New Roman";
      mso-fareast-theme-font:minor-fareast;
      mso-hansi-font-family:Calibri;
      mso-hansi-theme-font:minor-latin;
      mso-bidi-font-family:"Times New Roman";
      mso-bidi-theme-font:minor-bidi;}
   /* Page Definitions */
   @page
      {mso-footnote-separator:url("Form%202_files/header.html") fs;
      mso-footnote-continuation-separator:url("Form%202_files/header.html") fcs;
      mso-endnote-separator:url("Form%202_files/header.html") es;
      mso-endnote-continuation-separator:url("Form%202_files/header.html") ecs;}
  @page WordSection1
      {size:612.0pt 792.0pt;
      margin:27.25pt 122.65pt 24.85pt 72.0pt;
      mso-header-margin:36.0pt;
      mso-footer-margin:36.0pt;
      mso-paper-source:0;}
  div.WordSection1
      {page:WordSection1;}
   /* List Definitions */
   @list l0
      {mso-list-id:1363047911;
      mso-list-type:hybrid;
      mso-list-template-ids:-335372418 1074331663 1074331673 1074331675 1074331663 1074331673 1074331675 1074331663 1074331673 1074331675;}
  @list l0:level1
      {mso-level-tab-stop:none;
      mso-level-number-position:left;
      margin-left:288.0pt;
      text-indent:-18.0pt;}
  @list l0:level2
      {mso-level-number-format:alpha-lower;
      mso-level-tab-stop:none;
      mso-level-number-position:left;
      margin-left:324.0pt;
      text-indent:-18.0pt;}
  @list l0:level3
      {mso-level-number-format:roman-lower;
      mso-level-tab-stop:none;
      mso-level-number-position:right;
      margin-left:360.0pt;
      text-indent:-9.0pt;}
  @list l0:level4
      {mso-level-tab-stop:none;
      mso-level-number-position:left;
      margin-left:95.0pt;
      text-indent:-18.0pt;}
  @list l0:level5
      {mso-level-number-format:alpha-lower;
      mso-level-tab-stop:none;
      mso-level-number-position:left;
      margin-left:432.0pt;
      text-indent:-18.0pt;}
  @list l0:level6
      {mso-level-number-format:roman-lower;
      mso-level-tab-stop:none;
      mso-level-number-position:right;
      margin-left:150.0pt;
      text-indent:-9.0pt;}
  @list l0:level7
      {mso-level-tab-stop:none;
      mso-level-number-position:left;
      margin-left:504.0pt;
      text-indent:-18.0pt;}
  @list l0:level8
      {mso-level-number-format:alpha-lower;
      mso-level-tab-stop:none;
      mso-level-number-position:left;
      margin-left:540.0pt;
      text-indent:-18.0pt;}
  @list l0:level9
      {mso-level-number-format:roman-lower;
      mso-level-tab-stop:none;
      mso-level-number-position:right;
      margin-left:576.0pt;
      text-indent:-9.0pt;}
  ol
      {margin-bottom:0cm;}
  ul
      {margin-bottom:0cm;}
  -->
  </style>
  <!--[if gte mso 10]>
  <style>
   /* Style Definitions */
   table.MsoNormalTable
      {mso-style-name:"Table Normal";
      mso-tstyle-rowband-size:0;
      mso-tstyle-colband-size:0;
      mso-style-noshow:yes;
      mso-style-priority:99;
      mso-style-parent:"";
      mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
      mso-para-margin:0cm;
      mso-pagination:widow-orphan;
      font-size:13.0pt;;;
      font-family:"Calibri",sans-serif;
      mso-ascii-font-family:Calibri;
      mso-ascii-theme-font:minor-latin;
      mso-hansi-font-family:Calibri;
      mso-hansi-theme-font:minor-latin;
      mso-bidi-font-family:"Times New Roman";
      mso-bidi-theme-font:minor-bidi;}
  table.TableGrid
      {mso-style-name:TableGrid;
      mso-tstyle-rowband-size:0;
      mso-tstyle-colband-size:0;
      mso-style-unhide:no;
      mso-style-parent:"";
      mso-padding-alt:0cm 0cm 0cm 0cm;
      mso-para-margin:0cm;
      mso-pagination:widow-orphan;
      font-size:13.0pt;;
      font-family:"Calibri",sans-serif;
      mso-ascii-font-family:Calibri;
      mso-ascii-theme-font:minor-latin;
      mso-hansi-font-family:Calibri;
      mso-hansi-theme-font:minor-latin;
      mso-bidi-font-family:"Times New Roman";
      mso-bidi-theme-font:minor-bidi;}
  </style>
  <![endif]--><!--[if gte mso 9]><xml>
   <o:shapedefaults v:ext="edit" spidmax="2049"/>
  </xml><![endif]--><!--[if gte mso 9]><xml>
   <o:shapelayout v:ext="edit">
    <o:idmap v:ext="edit" data="1"/>
   </o:shapelayout></xml><![endif]-->
  </head>
  
  <body lang=EN-IN style='tab-interval:36.0pt;word-wrap:break-word'>
  
  <div class=WordSection1>
  
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
  margin-left:4.55pt'><span style='font-size:12.0pt;mso-bidi-font-size:13.0pt;;
  line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
  
  <p class=MsoNormal align=center style='margin-bottom:0cm;text-align:center'><b
  style='mso-bidi-font-weight:normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:
  11.0pt;line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman"'>    </span>FORM -2 </span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:53.6pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:10.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-bottom:0cm;text-align:center'><b
  style='mso-bidi-font-weight:normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:
  11.0pt;line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman"'>FORM FOR MAINTAINING RECORDS OF E-WASTE HANDLED/ GENERATED</span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:53.2pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal style='margin-bottom:.85pt'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
  style='mso-spacerun:yes'> </span><span style='mso-tab-count:11'>                                               </span><span
  style='mso-tab-count:1'></span><span style='mso-tab-count:2'></span><span
  style='mso-tab-count:2'>                              </span>Generated Quantity
  in Metric Tonnes (MT) per year</span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:53.65pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:12.0pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <div align=center>
  
  <table class=TableGrid border=0 cellspacing=0 cellpadding=0 width=683
   style='width:700.6pt;border-collapse:collapse;mso-yfti-tbllook:1184;
   mso-padding-alt:13.15pt 5.1pt 13.15pt 5.1pt'>
   <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:59.05pt'>
    <td width=61 valign=top style='width:46.0pt;border:solid black 1.0pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:59.05pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:13.9pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>1.</span></b><b
    style='mso-bidi-font-weight:normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:
    11.0pt;line-height:106%;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'> </span></b><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=256 valign=top style='width:191.8pt;border:solid black 1.0pt;
    border-left:none;mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:59.05pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Name &amp; Address: </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Producer </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>/Manufacturer/<span class=SpellE>refurbisher</span>/Collection
    </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Centre/Dismantler/ </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Recycler/ Bulk consumer * </span></p>
    </td>
    <td width=366 colspan=3 valign=top style='width:274.8pt;border:solid black 1.0pt;
    border-left:none;mso-border-left-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:59.05pt'>
    <p class=MsoNormal align=center style='text-align:center;line-height:115%'>${gpName}</p>
    <p class=MsoNormal align=center style='text-align:center'>${gpAddress}</p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:1;height:30.05pt'>
    <td width=61 valign=top style='width:46.0pt;border:solid black 1.0pt;
    border-top:none;mso-border-top-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:30.05pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:13.9pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>2.</span></b><b
    style='mso-bidi-font-weight:normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:
    11.0pt;line-height:106%;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'> </span></b><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=256 valign=top style='width:191.8pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:30.05pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Date of Issue of Extended producer </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Responsibility </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Authorization*/ </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Registration* </span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:30.05pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:30.05pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:-.7pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:30.05pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:2;height:29.4pt'>
    <td width=61 valign=top style='width:46.0pt;border:solid black 1.0pt;
    border-top:none;mso-border-top-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:29.4pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:13.9pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>3.</span></b><b
    style='mso-bidi-font-weight:normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:
    11.0pt;line-height:106%;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'> </span></b><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=256 valign=top style='width:191.8pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:29.4pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>. Validity of Extended producer </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Responsibility </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Authorization*/ </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>/ Authorization* </span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:29.4pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:29.4pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:-.7pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:29.4pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:3;height:23.95pt'>
    <td width=61 rowspan=2 valign=top style='width:46.0pt;border:solid black 1.0pt;
    border-top:none;mso-border-top-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:13.9pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>4.</span></b><b
    style='mso-bidi-font-weight:normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:
    11.0pt;line-height:106%;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'> </span></b><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=256 rowspan=2 valign=top style='width:191.8pt;border-top:none;
    border-left:solid black 1.0pt;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Types &amp; Quantity of <span class=SpellE>ewaste</span>
    handled/generated** </span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Category: E-Waste<o:p></o:p></span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'>(Sr. No <span class=SpellE>i</span>)</p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Quantity </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal>${totalWeight} kg</p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:4;height:23.95pt'>
    <td width=184 valign=top style='width:138.35pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Item Description: E-Waste</span></p>
    </td>
    <td width=65 valign=bottom style='width:48.95pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-top-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:-.7pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:5;height:23.95pt'>
    <td width=61 rowspan=2 valign=top style='width:46.0pt;border:solid black 1.0pt;
    border-top:none;mso-border-top-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:13.9pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>5.</span></b><b
    style='mso-bidi-font-weight:normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:
    11.0pt;line-height:106%;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'> </span></b><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=256 rowspan=2 valign=top style='width:191.8pt;border-top:none;
    border-left:solid black 1.0pt;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:23.3pt;margin-bottom:
    0cm;margin-left:5.3pt;line-height:97%'><span style='font-size:13.0pt;;;
    mso-bidi-font-size:13.0pt;;line-height:97%;font-family:"Times New Roman",serif;
    mso-fareast-font-family:"Times New Roman"'>Types &amp; Quantity of e-waste
    stored </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Category: E-Waste<o:p></o:p></span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'>(Sr. No <span class=SpellE>i</span>)</p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Quantity </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal>${totalWeight} kg</p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:6;height:23.95pt'>
    <td width=184 valign=top style='width:138.35pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Item Description: E-Waste<b style='mso-bidi-font-weight:
    normal'> </b></span></p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:23.95pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:7;height:23.95pt'>
    <td width=61 rowspan=2 valign=top style='width:46.0pt;border:solid black 1.0pt;
    border-top:none;mso-border-top-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:13.9pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>6.</span></b><b
    style='mso-bidi-font-weight:normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:
    11.0pt;line-height:106%;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'> </span></b><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=256 rowspan=2 valign=top style='width:191.8pt;border-top:none;
    border-left:solid black 1.0pt;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:4.45pt;margin-bottom:
    .05pt;margin-left:5.3pt;text-align:justify;text-justify:inter-ideograph;
    line-height:96%'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:96%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Types &amp; Quantity of e-waste sent to collection centre authorised
    by producer/dismantler/recycler/<span class=SpellE>refurbisher</span> or
    authorised dismantler/ recycler or <span class=SpellE>refurbisher</span> ** </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Category: E-Waste<o:p></o:p></span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'>(Sr. No <span class=SpellE>i</span>)<b style='mso-bidi-font-weight:
    normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:
    106%;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>
    </span></b></p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Quantity </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal>${totalWeight} kg</p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:8;height:46.7pt'>
    <td width=184 valign=top style='width:138.35pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:46.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Item Description: E-Waste<b style='mso-bidi-font-weight:
    normal'> </b></span></p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:46.7pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:46.7pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:9;height:14.1pt'>
    <td width=61 rowspan=3 valign=top style='width:46.0pt;border:solid black 1.0pt;
    border-top:none;mso-border-top-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:14.1pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:13.9pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>7.</span></b><b
    style='mso-bidi-font-weight:normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:
    11.0pt;line-height:106%;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'> </span></b><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=256 rowspan=2 valign=top style='width:191.8pt;border-top:none;
    border-left:solid black 1.0pt;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:14.1pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt;line-height:97%'><span style='font-size:13.0pt;;;mso-bidi-font-size:
    11.0pt;line-height:97%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Types &amp; Quantity of e-waste transported* </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:14.1pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Category: E-Waste<o:p></o:p></span></p>
    <p class=MsoNormal style='margin-bottom:0cm;tab-stops:center 62.9pt'><span
    style='mso-spacerun:yes'>  </span>(Sr. No <span class=SpellE>i</span>)<span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-tab-count:1'>        </span><b style='mso-bidi-font-weight:normal'>
    </b></span></p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:14.1pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Quantity<b style='mso-bidi-font-weight:normal'> </b></span></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:14.1pt'>
    <p class=MsoNormal>${totalWeight} kg</p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:10;height:23.95pt'>
    <td width=184 valign=top style='width:138.35pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Item Description: E-Waste </span></p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:23.95pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:11;height:35.45pt'>
    <td width=256 valign=top style='width:191.8pt;border-top:none;border-left:
    solid black 1.0pt;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.45pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Name, <span class=GramE>address</span> and contact </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>details of the destination </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    </td>
    <td width=366 colspan=3 valign=top style='width:274.8pt;border-top:none;
    border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.45pt'>
    <p class=MsoNormal align=center style='text-align:center'>${rpName}</p>
    <p class=MsoNormal align=center style='text-align:center'>${rpAddress}</p>
    <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:12;height:23.95pt'>
    <td width=61 rowspan=3 valign=top style='width:46.0pt;border:solid black 1.0pt;
    border-top:none;mso-border-top-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:13.9pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>8.</span></b><b
    style='mso-bidi-font-weight:normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:
    11.0pt;line-height:106%;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'> </span></b><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=256 rowspan=2 valign=top style='width:191.8pt;border-top:none;
    border-left:solid black 1.0pt;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt;line-height:97%'><span style='font-size:13.0pt;;;mso-bidi-font-size:
    11.0pt;line-height:97%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Types &amp; Quantity of e-waste refurbished* </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
    margin-bottom:0cm;margin-left:1.55pt;text-align:center'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>Category<b
    style='mso-bidi-font-weight:normal'> </b></span></p>
    </td>
    <td width=182 colspan=2 valign=top style='width:136.45pt;border-top:none;
    border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-bottom:0cm;text-align:justify;text-justify:
    inter-ideograph'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'>  </span>Quantity </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:17.5pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:13;height:23.95pt'>
    <td width=184 valign=top style='width:138.35pt;border-top:none;border-left:
    solid black 1.0pt;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
    margin-bottom:0cm;margin-left:3.6pt;text-align:center'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>Item
    Description: </span></p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:23.95pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:17.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:14;height:35.7pt'>
    <td width=256 valign=top style='width:191.8pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:57.5pt;margin-bottom:
    0cm;margin-left:5.3pt;text-align:justify;text-justify:inter-ideograph'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>Name,
    <span class=GramE>address</span> and contact details of the destination of
    refurbished materials </span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:35.7pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:-.7pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:15;height:35.7pt'>
    <td width=61 rowspan=2 valign=top style='width:46.0pt;border:solid black 1.0pt;
    border-top:none;mso-border-top-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:13.9pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>9.</span></b><b
    style='mso-bidi-font-weight:normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:
    11.0pt;line-height:106%;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'> </span></b><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=256 valign=top style='width:191.8pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt;line-height:97%'><span style='font-size:13.0pt;;;mso-bidi-font-size:
    11.0pt;line-height:97%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Types &amp; Quantity of e-waste dismantled* </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Category<b style='mso-bidi-font-weight:normal'> </b></span></p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Quantity </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:16;height:35.7pt'>
    <td width=256 valign=top style='width:191.8pt;border-top:none;border-left:
    solid black 1.0pt;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Name, <span class=GramE>address</span> and contact </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>details of the destination </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Item Description: E-Waste<b style='mso-bidi-font-weight:
    normal'> </b></span></p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:35.7pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:17;height:35.45pt'>
    <td width=61 rowspan=4 valign=top style='width:46.0pt;border:solid black 1.0pt;
    border-top:solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.45pt'>
    <p class=MsoNormal align=center style='margin-bottom:0cm;text-align:center'><b
    style='mso-bidi-font-weight:normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:
    11.0pt;line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>10.</span></b><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'> </span></b><b
    style='mso-bidi-font-weight:normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:
    11.0pt;line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=256 rowspan=3 valign=top style='width:191.8pt;border-top:none;
    border-left:solid black 1.0pt;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.45pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:9.15pt;margin-bottom:
    0cm;margin-left:5.3pt;line-height:97%'><span style='font-size:13.0pt;;;
    mso-bidi-font-size:13.0pt;;line-height:97%;font-family:"Times New Roman",serif;
    mso-fareast-font-family:"Times New Roman"'>Types &amp; Quantity of e-waste
    recycled* </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:44.1pt;margin-bottom:
    0cm;margin-left:5.3pt;text-align:justify;text-justify:inter-ideograph'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>Types
    &amp; Quantity of materials recovered </span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.45pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Category: E-Waste<o:p></o:p></span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:1.55pt'><span style='mso-spacerun:yes'> </span>(Sr. No <span
    class=SpellE>i</span>)</p>
    </td>
    <td width=182 colspan=2 valign=top style='width:136.45pt;border-top:none;
    border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.45pt'>
    <p class=MsoNormal style='margin-bottom:0cm'><span style='font-size:13.0pt;;;
    mso-bidi-font-size:13.0pt;;line-height:106%;font-family:"Times New Roman",serif;
    mso-fareast-font-family:"Times New Roman"'><span style='mso-spacerun:yes'> 
    </span>Quantity </span>${totalWeight} kg</p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:17.5pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:18;height:12.2pt'>
    <td width=184 valign=top style='width:138.35pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:12.2pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Item Description: E-Waste</span></p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:12.2pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:12.2pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:19;height:12.2pt'>
    <td width=184 valign=top style='width:138.35pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:12.2pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Quantity </span>${totalWeight} kg</p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:12.2pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:12.2pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:20;height:35.7pt'>
    <td width=256 valign=top style='width:191.8pt;border-top:none;border-left:
    solid black 1.0pt;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:30.15pt;margin-bottom:
    .25pt;margin-left:5.3pt;text-align:justify;text-justify:inter-ideograph;
    line-height:95%'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:95%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Name, <span class=GramE>address</span> and contact details
    of the destination </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    </td>
    <td width=366 colspan=3 valign=top style='width:274.8pt;border-top:none;
    border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal align=center style='text-align:center'>${rpName}</p>
    <p class=MsoNormal align=center style='text-align:center'>${rpAddress}</p>
    <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:21;height:14.1pt'>
    <td width=61 rowspan=4 valign=top style='width:46.0pt;border:solid black 1.0pt;
    border-top:none;mso-border-top-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:14.1pt'>
    <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
    margin-bottom:0cm;margin-left:21.6pt;text-align:center'><b style='mso-bidi-font-weight:
    normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:
    106%;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    <p class=MsoNormal align=center style='margin-top:0cm;margin-right:3.1pt;
    margin-bottom:0cm;margin-left:0cm;text-align:center'><b style='mso-bidi-font-weight:
    normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:
    106%;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>11.</span></b><b
    style='mso-bidi-font-weight:normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:
    11.0pt;line-height:106%;font-family:"Arial",sans-serif;mso-fareast-font-family:
    Arial'> </span></b><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
    <td width=256 rowspan=3 valign=top style='width:191.8pt;border-top:none;
    border-left:solid black 1.0pt;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:14.1pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.3pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Types &amp; Quantity of e-waste sent to </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:64.8pt;margin-bottom:
    0cm;margin-left:.25pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>recyclers by dismantlers<span style='mso-spacerun:yes'> 
    </span></span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.25pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:14.1pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Category<b style='mso-bidi-font-weight:normal'> </b></span></p>
    </td>
    <td width=65 valign=top style='width:48.95pt;border:none;border-bottom:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:14.1pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:5.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Quantity </span></p>
    </td>
    <td width=117 valign=top style='width:87.5pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:14.1pt'>
    <p class=MsoNormal>${totalWeight} kg</p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:22;height:23.75pt'>
    <td width=184 valign=top style='width:138.35pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.75pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
    <td width=182 colspan=2 valign=top style='width:136.45pt;border-top:none;
    border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.75pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.95pt'><b style='mso-bidi-font-weight:normal'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:23;height:6.3pt'>
    <td width=184 valign=top style='width:138.35pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:6.3pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Item Description: E-Waste<b style='mso-bidi-font-weight:
    normal'> </b></span></p>
    </td>
    <td width=182 colspan=2 valign=top style='width:136.45pt;border-top:none;
    border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:6.3pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:24;height:35.7pt'>
    <td width=256 valign=top style='width:191.8pt;border-top:none;border-left:
    solid black 1.0pt;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.25pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Name, <span class=GramE>address</span> and contact </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.25pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>details of the destination </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.25pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    </td>
    <td width=182 colspan=2 valign=top style='width:136.45pt;border-top:none;
    border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:25;height:35.7pt'>
    <td width=61 rowspan=2 valign=top style='width:46.0pt;border:solid black 1.0pt;
    border-top:none;mso-border-top-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal align=right style='margin-top:0cm;margin-right:2.4pt;
    margin-bottom:0cm;margin-left:0cm;text-align:right'><b style='mso-bidi-font-weight:
    normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:
    106%;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>12.
    </span></b></p>
    </td>
    <td width=256 valign=top style='width:191.8pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:7.65pt;margin-bottom:
    0cm;margin-left:.25pt;text-align:justify;text-justify:inter-ideograph'><span
    style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:106%;
    font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>Types
    and Quantity of other waste sent to respective recyclers by dismantlers /
    recyclers of e-waste </span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Category<b style='mso-bidi-font-weight:normal'> </b></span></p>
    </td>
    <td width=182 colspan=2 valign=top style='width:136.45pt;border-top:none;
    border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal style='margin-bottom:0cm'><span style='font-size:13.0pt;;;
    mso-bidi-font-size:13.0pt;;line-height:106%;font-family:"Times New Roman",serif;
    mso-fareast-font-family:"Times New Roman"'><span style='mso-spacerun:yes'> 
    </span>Quantity </span></p>
    <p class=MsoNormal style='margin-bottom:0cm'><b style='mso-bidi-font-weight:
    normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:
    106%;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:26;height:35.7pt'>
    <td width=256 valign=top style='width:191.8pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.25pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Name, <span class=GramE>address</span> and contact </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.25pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>details of the destination </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.25pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Item Description: E-Waste </span></p>
    </td>
    <td width=182 colspan=2 valign=top style='width:136.45pt;border-top:none;
    border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:27;height:23.95pt'>
    <td width=61 rowspan=3 valign=top style='width:46.0pt;border:solid black 1.0pt;
    border-top:none;mso-border-top-alt:solid black .5pt;mso-border-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal align=right style='margin-top:0cm;margin-right:2.4pt;
    margin-bottom:0cm;margin-left:0cm;text-align:right'><b style='mso-bidi-font-weight:
    normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:
    106%;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>13.
    </span></b></p>
    </td>
    <td width=256 rowspan=2 valign=top style='width:191.8pt;border-top:none;
    border-left:solid black 1.0pt;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:1.75pt;margin-bottom:
    0cm;margin-left:.25pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Types and Quantity of e-waste treated &amp; disposed </span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border-top:none;border-left:
    none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Category<b style='mso-bidi-font-weight:normal'> </b></span></p>
    </td>
    <td width=182 colspan=2 valign=top style='width:136.45pt;border-top:none;
    border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal style='margin-bottom:0cm'><span style='font-size:13.0pt;;;
    mso-bidi-font-size:13.0pt;;line-height:106%;font-family:"Times New Roman",serif;
    mso-fareast-font-family:"Times New Roman"'><span style='mso-spacerun:yes'> 
    </span>Quantity </span></p>
    <p class=MsoNormal style='margin-bottom:0cm'><b style='mso-bidi-font-weight:
    normal'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:
    106%;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'><span
    style='mso-spacerun:yes'> </span></span></b></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:28;height:23.95pt'>
    <td width=184 valign=top style='width:138.35pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:23.95pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Item Description: E-Waste </span></p>
    </td>
    <td width=182 colspan=2 valign=top style='width:136.45pt;border-top:none;
    border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:23.95pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:29;mso-yfti-lastrow:yes;height:35.7pt'>
    <td width=256 valign=top style='width:191.8pt;border-top:none;border-left:
    solid black 1.0pt;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-left-alt:solid black .5pt;
    mso-border-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.25pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>Name, <span class=GramE>address</span> and contact </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.25pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'>details of the destination </span></p>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.25pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    </td>
    <td width=184 valign=top style='width:138.35pt;border:none;border-bottom:
    solid black 1.0pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-top-alt:solid black .5pt;mso-border-left-alt:
    solid black .5pt;mso-border-bottom-alt:solid black .5pt;padding:5.15pt 3.1pt 3.15pt 5.1pt;
    height:35.7pt'>
    <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
    margin-left:.5pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
    line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
    "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
    </td>
    <td width=182 colspan=2 valign=top style='width:136.45pt;border-top:none;
    border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
    mso-border-top-alt:solid black .5pt;mso-border-top-alt:solid black .5pt;
    mso-border-bottom-alt:solid black .5pt;mso-border-right-alt:solid black .5pt;
    padding:5.15pt 3.1pt 3.15pt 5.1pt;height:35.7pt'>
    <p class=MsoNormal><o:p>&nbsp;</o:p></p>
    </td>
   </tr>
  </table>
  
  </div>
  
  <p class=MsoNormal style='margin-bottom:10.45pt'><span style='font-size:13.0pt;;;
  mso-bidi-font-size:13.0pt;;line-height:106%;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman"'><span
  style='mso-spacerun:yes'> </span></span></p>
  
  <p class=MsoNormal style='margin-top:0cm;margin-right:60.85pt;margin-bottom:
  10.75pt;margin-left:50.0pt;text-indent:36.0pt;line-height:110%'><span
  style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:110%;font-family:
  "Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>Note: - </span></p>
  
  <p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:60.85pt;
  margin-bottom:.35pt;margin-left:100.0pt;mso-add-space:auto;text-indent:-18.0pt;
  line-height:110%;mso-list:l0 level1 lfo2'><![if !supportLists]><span
  style='mso-list:Ignore'>1.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </span></span><![endif]><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
  line-height:110%;font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman"'>Strike off whichever is not applicable </span></p>
  
  <p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:60.85pt;
  margin-bottom:.35pt;margin-left:100.0pt;mso-add-space:auto;text-indent:-18.0pt;
  line-height:110%;mso-list:l0 level1 lfo2'><![if !supportLists]><span
  style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:110%;font-family:
  "Arial",sans-serif;mso-fareast-font-family:Arial'><span style='mso-list:Ignore'>2.<span
  style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span><![endif]><span
  style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:110%;font-family:
  "Times New Roman",serif;mso-fareast-font-family:"Times New Roman"'>Provide any
  other information as stipulated in the conditions to the authorise</span><span
  style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;line-height:110%;font-family:
  "Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
  
  <p class=MsoListParagraphCxSpLast style='margin-top:0cm;margin-right:60.85pt;
  margin-bottom:.35pt;margin-left:100.0pt;mso-add-space:auto;text-indent:-18.0pt;
  line-height:110%;mso-list:l0 level1 lfo2'><![if !supportLists]><span
  style='mso-list:Ignore'>3.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </span></span><![endif]><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
  line-height:110%;font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman"'>** For producers this information <span class=GramE>has to</span>
  be provided State-wise </span></p>
  
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:.6pt;
  margin-left:36.0pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
  line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
  
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:.35pt;
  margin-left:36.0pt'><span style='font-size:13.0pt;;;mso-bidi-font-size:13.0pt;;
  line-height:106%;font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman"'><span style='mso-spacerun:yes'> </span></span></p>
  
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
  margin-left:36.0pt'><b style='mso-bidi-font-weight:normal'><span
  style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:106%;font-family:
  "Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:89.35pt;text-align:center'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:9.5pt;mso-bidi-font-size:13.0pt;;line-height:
  106%;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><span
  style='mso-spacerun:yes'> </span></span></b></p>
  
  </div>
  
  </body>
  
  </html>
  `;
};
