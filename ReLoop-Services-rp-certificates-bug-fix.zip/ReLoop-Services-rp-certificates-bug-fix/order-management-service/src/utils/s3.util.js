const aws = require('aws-sdk');
const dotenv = require('dotenv');
const request = require('request');
const utilFunctions = require('./commonFunctions.util');

dotenv.config();
const s3Data = {
  accessKeyId: process.env.S3_ACCESS_KEY_ID,
  secretAccessKey: process.env.S3_SECRET_ACCESS_KEY,
  region: process.env.S3_REGION,
};

const S3_BUCKET = process.env.S3_Bucket;
aws.config.update(
  {
    accessKeyId: s3Data.accessKeyId,
    secretAccessKey: s3Data.secretAccessKey,
    region: s3Data.region,
    signatureVersion: 'v4',
  },
);

const s3 = new aws.S3();

const s3GetSignedURL = function (file, key) {
  const fileType = file.mimetype; // the content-type of the file
  const s3Params = {
    Bucket: S3_BUCKET,
    Fields: {
      key,
    },
    Conditions: [
      ['content-length-range', 0, 100000000],
    ],
    ContentType: fileType,
  };
  const data = s3.createPresignedPost(s3Params);
  return data;
};

const s3PutOrderImage = async function (s3Detail, file) {
  const options = {
    method: 'POST',
    url: s3Detail.url,
    formData: {
      ...s3Detail.fields,
      file: file.buffer,
    },
  };

  return new Promise((resolve, reject) => {
    request(options, (error, response) => {
      if (error) reject(error);
      resolve(response);
    });
  });
};

exports.downloadFile = (key) => {
  const s3Params = {
    Bucket: S3_BUCKET,
    Key: key,
  };
  return new Promise((resolve, reject) => {
    s3.headObject(s3Params, (err, data) => {
      if (err) {
        reject(err);
      }
      const stream = s3.getObject(s3Params).createReadStream();
      resolve({ stream, data });
    });
  });
};

exports.pushFileToS3 = async function (file, key) {
  const preSignedUrl = s3GetSignedURL(file, key);
  await s3PutOrderImage(preSignedUrl, file);
  return preSignedUrl.fields.key;
};
