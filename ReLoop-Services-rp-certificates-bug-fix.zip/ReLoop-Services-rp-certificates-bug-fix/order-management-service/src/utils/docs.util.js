const pdf = require('html-pdf');

exports.generateDocument = (template, options) => new Promise((resolve, reject) => {
  pdf.create(template, options).toStream((error, stream) => {
    if (error) reject(error);
    resolve(stream);
  });
});
