const router = require('express').Router();
const orderWorkflowController = require('../controllers/orderWorkflow.controller');
const authUtil = require('../utils/auth.util');
const validator = require('../utils/validate.util');

module.exports = (app) => {
  /**
 * @swagger
 * /api/order/workflow/createOrderWorkflow/{userId}:
 *   post:
 *    description:  Endpoint to create order workflow
 *    tags:
 *      - Order Workflow
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            properties:
 *              orderId:
 *                  type: string
 *              processStageSequence:
 *                  type: string
 *              processType:
 *                  type: string
 *      responses:
 *       200:
 *         description: Order Workflow.
 *         content:
 *           application/json:
 *             schema:
 *              type: object
 *              items:
 *                  $ref: '#/components/schemas/OrderWorkflow'
 */
  router.post('/createOrderWorkflow/:userId', [authUtil.validateMiddleware, authUtil.isGpUser], validator.createOrderWorkflowValidations, validator.validate, orderWorkflowController.createOrderWorkflow);
  app.use('/api/order/workflow', router);
};
