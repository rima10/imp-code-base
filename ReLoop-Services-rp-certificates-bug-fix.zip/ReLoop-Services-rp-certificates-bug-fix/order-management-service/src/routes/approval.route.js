const router = require('express').Router();
const approvalController = require('../controllers/approval.controller');
const authUtil = require('../utils/auth.util');
const validator = require('../utils/validate.util');

module.exports = (app) => {
  router.get('/getPendingApprovals/:approverId', [authUtil.validateMiddleware, authUtil.isGPApproverUser],
    validator.approverIdValidations, validator.validate, approvalController.getPendingApprovals);
  router.post('/approve/:approverId', [authUtil.validateMiddleware, authUtil.isGPApproverUser], approvalController.approve);
  router.post('/reject/:approverId', [authUtil.validateMiddleware, authUtil.isGPApproverUser], approvalController.reject);
  app.use('/api/order/approval', router);
};
