const router = require('express').Router();
const multer = require('multer');

const upload = multer();
const orderController = require('../controllers/order.controller');
const authUtil = require('../utils/auth.util');
const validator = require('../utils/validate.util');

module.exports = (app) => {
  /**
 * @swagger
 * /api/order/createOrder:
 *   post:
 *    description:  Endpoint to create Order
 *    tags:
 *      - Order
 *    parameters:
 *      - name: userId
 *        description: id of the green partner
 *        in: path
 *        required: true
 *        type: number
 *    requestBody:
 *      content:
 *        multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *              orderType:
 *                type: string
 *                example: 1
 *              category:
 *                type: integer
 *                example: 1
 *              subcategory:
 *                type: integer
 *                example: 1
 *              network:
 *                type: string
 *                example: Private
 *              orderLocation:
 *                type: string
 *              additionalInfo:
 *                type: string
 *              submissionDeadline:
 *                example: Jul 1, 2021, 11:52:23 AM
 *              processStageSequence:
 *                type: string
 *              picture:
 *                type: string
 *                format: binary
 *              assetExcel:
 *                type: string
 *                format: binary
 *    responses:
 *      200:
 *        description: A list of user's orders.
 *        content:
 *          application/json:
 *            schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Order'
 */
  router.post('/createOrder/:userId', upload.fields([{
    name: 'picture', maxCount: 1,
  }, {
    name: 'assetExcel', maxCount: 1,
  }]), [authUtil.validateMiddleware, authUtil.isGpUser],
  validator.createOrderValidations, validator.validate, orderController.createOrder);

  /**
 * @swagger
 * /api/order/createOrderAsDraft:
 *   post:
 *    description:  Endpoint to create Order as draft
 *    tags:
 *      - Order
 *    parameters:
 *      - name: userId
 *        description: id of the green partner
 *        in: path
 *        required: true
 *        type: number
 *    requestBody:
 *      content:
 *        multipart/form-data:
 *          schema:
 *            type: object
 *            properties:
 *              orderType:
 *                type: string
 *                example: Refurbish
 *              category:
 *                type: integer
 *                example: 1
 *              subcategory:
 *                type: integer
 *                example: 1
 *              network:
 *                type: string
 *                example: Private
 *              orderLocation:
 *                type: string
 *              additionalInfo:
 *                type: string
 *              submissionDeadline:
 *                type: string
 *              picture:
 *                type: string
 *                format: binary
 *              assetExcel:
 *                type: string
 *                format: binary
 */
  router.post('/createOrderAsDraft/:userId', upload.fields([{
    name: 'picture', maxCount: 1,
  }, {
    name: 'assetExcel', maxCount: 1,
  }]), [authUtil.validateMiddleware, authUtil.isGpUser], orderController.createOrderAsDraft);
  /**
 * @swagger
 * /api/order/getOrders/{userId}:
 *   get:
 *    description:  Endpoint to get order data of a business partner
 *    tags:
 *      - Order
 *    parameters:
 *       - name: userId
 *         description: id of the green partner
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: A list of user's orders.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Order'
 */

  router.get('/getOrders/:userId', [authUtil.validateMiddleware, authUtil.isGpUser], validator.userIdValidations, validator.validate, orderController.getOrders);
  /**
 * @swagger
 * /api/order/getRefurbishOrderByOrderId/{orderId}:
 *   get:
 *    description:  Endpoint to get order data based on order id
 *    tags:
 *      - Order
 *    parameters:
 *       - name: orderId
 *         description: id of the particular order
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: order details.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Order'
 */
  router.get('/getRefurbishOrderByOrderId/:orderId', [authUtil.validateMiddleware, authUtil.isGpUser], validator.orderIdValidations, validator.validate, orderController.getRefurbishOrderByOrderId);

  /**
 * @swagger
 * /api/order/getRecycleOrderByOrderId/{orderId}:
 *   get:
 *    description:  Endpoint to get order data based on order id
 *    tags:
 *      - Order
 *    parameters:
 *       - name: orderId
 *         description: id of the particular order
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: order details.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Order'
 */
  router.get('/getRecycleOrderByOrderId/:orderId', [authUtil.validateMiddleware, authUtil.isGpUser], validator.orderIdValidations, validator.validate, orderController.getRecycleOrderByOrderId);
  /**
 * @swagger
 * /api/order/getOrderType:
 *   get:
 *    description:  Endpoint to get order Types
 *    tags:
 *      - OrderType
 *    responses:
 *       200:
 *         description: A list of order types.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/OrderType'
 */
  router.get('/getOrderType', [authUtil.validateMiddleware, authUtil.isGpUser], orderController.getOrderType);
  /**
 * @swagger
 * /api/order/createOrderType:
 *   post:
 *    description:  Endpoint to create Order Type
 *    tags:
 *      - OrderType
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              processTypes:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    processTypeName:
 *                      type: string
 *                      description: Process Type name.
 *                      example: Refurbish
 *                    processTypeid:
 *                      type: string
 *                      description: Process Type Id.
 *                      example: 1
 */
  router.post('/createOrderType', orderController.createOrderType);
  /**
 * @swagger
 * /api/order/getOrderForApprover/{orderId}:
 *   get:
 *    description:  Endpoint to get order data based on order id
 *    tags:
 *      - Order
 *    parameters:
 *       - name: orderId
 *         description: id of the particular order
 *         in: path
 *         required: true
 *         type: string
 *    responses:
 *       200:
 *         description: order details.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Order'
 */
  router.get('/getOrderForApprover/:orderId', [authUtil.validateMiddleware, authUtil.isGPApproverUser], validator.orderIdValidations, validator.validate, orderController.getOrderForApprover);
  /**
    * @swagger
    * /api/order/getConsolidatedOrderData/{orderId}:
    *   get:
    *    description:  Endpoint to get consolidated order data based on order id
    *    tags:
    *      - Order
    *    parameters:
    *       - name: orderId
    *         description: id of the particular order
    *         in: path
    *         required: true
    *         type: string
    *    responses:
    *       200:
    *         description: order details.
    *         content:
    *           application/json:
    *             schema:
    *              type: array
    *              items:
    *                $ref: '#/components/schemas/Order'
    */
  router.get('/getConsolidatedOrderData/:orderId', orderController.getConsolidatedOrderData);
  /**
    * @swagger
    * /api/order/getStageApprovalStatus/{orderId}:
    *   get:
    *    description:  Endpoint to get consolidated order data based on order id
    *    tags:
    *      - Order
    *    parameters:
    *       - name: orderId
    *         description: id of the particular order
    *         in: path
    *         required: true
    *         type: string
    *       - name: processType
    *         description: id of process type
    *         in: query
    *         required: true
    *         type: string
    *       - name: processStageSequence
    *         description: stage sequence number
    *         in: query
    *         required: true
    *         type: string
    *    responses:
    *       200:
    *         description: order details.
    *         content:
    *           application/json:
    *             schema:
    *              type: object
    *              items:
    */
  router.get('/getStageApprovalStatus/:orderId', [authUtil.validateMiddleware, authUtil.isGpUser], validator.getStageApprovalStatusValidations, validator.validate, orderController.getStageApprovalStatus);
  /**
    * @swagger
    * /api/order/moveOrderToNextStep/{userId}:
    *   post:
    *    description:  Endpoint to get consolidated order data based on order id
    *    tags:
    *      - Order
    *    parameters:
    *       - name: userId
    *         description: user id
    *         in: path
    *         required: true
    *         type: string
    *       - name: orderId
    *         description: id of the particular order
    *         in: query
    *         required: true
    *         type: string
    *       - name: nextStage
    *         description: next stage sequence number
    *         in: query
    *         required: true
    *         type: string
    *    responses:
    *       201:
    *         description: order details.
    *         content:
    *           application/json:
    *             schema:
    *              type: object
    *              items:
    *               $ref: '#/components/schemas/Order'
    */
  router.post('/moveOrderToNextStep/:userId', orderController.moveOrderToNextStep);
  /**
 * @swagger
 * /api/order/scheduleLogistics/{orderId}:
 *   post:
 *    description:  Endpoint to schedule logistics
 *    tags:
 *      - Order
 *    parameters:
 *       - name: orderId
 *         description: id of the particular order
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              scheduledLogisticDate:
 *                type: string
 *                description: timestmap.
 *                example: Jul 1, 2021, 11:52:23 AM
 *    responses:
 *       201:
 *         description: order details.
 *         content:
 *           application/json:
 *             schema:
 *              type: object
 *              items:
 *                $ref: '#/components/schemas/Order'
 */
  router.post('/scheduleLogistics/:orderId', [authUtil.validateMiddleware, authUtil.isGpUser], validator.scheduleLogisticsValidations, validator.validate, orderController.scheduleLogistics);

  /**
 * @swagger
 * /api/order/acceptLogistics/{orderId}:
 *   post:
 *    description:  Endpoint to accept logistics by recycler
 *    tags:
 *      - Order
 *    parameters:
 *       - name: orderId
 *         description: id of the particular order
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              vehicleType:
 *                type: string
 *                description: vehicle type.
 *                example: AMT (Semi Trailer)
 *              vehicleNumber:
 *                type: string
 *                description: vehicle Number.
 *                example: HR26DQ5551
 *              driverName:
 *                type: string
 *                description: Driver Name.
 *                example: John Doe
 *              logisticProvider:
 *                type: string
 *                description: Logistic Provider.
 *                example: XYZ Ltd
 *              recyclerContactName:
 *                type: string
 *                description: Recycler Contact Name.
 *                example: Alen
 *              recyclerContactNumber:
 *                type: string
 *                description: Recycler Contact Number.
 *                example: 9876543210
 *              userId:
 *                type: string
 *                description: user ID.
 *                example: 1
 *    responses:
 *       201:
 *         description: order details.
 *         content:
 *           application/json:
 *             schema:
 *              type: object
 *              items:
 *                $ref: '#/components/schemas/Order'
 */
  router.post('/acceptLogistics/:orderId', orderController.acceptLogistics);

  /**
* @swagger
* /api/order/privatenetwork/{userId}:
*   get:
*    description:  Endpoint to get business partner private networks
*    tags:
*      - Private Network
*    parameters:
*       - name: userId
*         description: id of the green partner
*         in: path
*         required: true
*         type: number
*    responses:
*       200:
*         description: A list of user's private networks.
*         content:
*           application/json:
*             schema:
*              type: array
*              items:
*                $ref: '#/components/schemas/PrivateNetwork'
*/
  router.get('/privatenetwork/:userId',
    [authUtil.validateMiddleware, authUtil.isGpUser],
    orderController.getUserPrivateNtw);
  /**
* @swagger
* /api/order/getRequestedHeaderOrderData/{orderId}:
*   get:
*    description:  Endpoint to get header data of order
*    tags:
*      - Initial Quote Submission
*    parameters:
*       - name: orderId
*         description: id of the order
*         in: path
*         required: true
*         type: number
*    responses:
*       200:
*         description: A list of header data of order.
*         content:
*           application/json:
*             schema:
*              type: object
*              items:
*                $ref: '#/components/schemas/Order'
*/
  router.get('/getOrderHeaderData/:orderId', orderController.getOrderHeaderData);

  /**
* @swagger
* /api/order/getRequestedOrder/:recyclerPartnerId:
*   get:
*    description:  Endpoint to get list of orders of a particular recycler partner Id
*    parameters:
*       - name: recyclerPartnerId
*         description: id of the recycle partner
*         in: path
*         required: true
*         type: number
*    responses:
*       200:
*         description: A list of orders for a particular recycler partner id.
*         content:
*           application/json:
*             schema:
*              type: object
*              items:
*                $ref: '#/components/schemas/Order'
*/
  router.get('/getRequestedOrder/:recyclerPartnerId',
    [authUtil.validateMiddleware, authUtil.isRpUser],
    orderController.getNewOrderForRecycler);

  app.use('/api/order', router);
};
