const router = require('express').Router();
const wasteCategoryController = require('../controllers/wasteCategory.controller');
const authUtil = require('../utils/auth.util');
const validator = require('../utils/validate.util');

module.exports = (app) => {
  /**
 * @swagger
 * /api/wasteCategory/createCategory:
 *   post:
 *    description:  Endpoint to create Category
 *    tags:
 *      - Category
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
  *            properties:
 *              categories:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    categoryName:
 *                      type: string
 *                      description: Category name.
 *                      example: Electronics
 *    responses:
 *      200:
 *        description: A list of categories.
 *        content:
 *          application/json:
 *            schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Category'
 */
  router.post('/createCategory', validator.createCategoryValidations, validator.validate, wasteCategoryController.createCategory);

  /**
 * @swagger
 * /api/wasteCategory/createSubcategory/{categoryID}:
 *   post:
 *    description:  Endpoint to create Sub Category
 *    tags:
 *      - SubCategory
 *    parameters:
 *       - name: categoryID
 *         description: id of the Category
 *         in: path
 *         required: true
 *         type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            type: object
 *            required:
 *            properties:
 *              subcategories:
 *                type: array
 *                items:
 *                  type: object
 *                  properties:
 *                    subcategoryName:
 *                      type: string
 *                      description: Sub Category name.
 *                      example: IT and telecom
 *    responses:
 *      200:
 *        description: A list of sub categories.
 *        content:
 *          application/json:
 *            schema:
 *             type: array
 *             items:
 *               $ref: '#/components/schemas/SubCategory'
 */
  router.post('/createSubcategory/:categoryID', validator.createSubCategoryValidations, validator.validate, wasteCategoryController.createSubcategory);
  /**
 * @swagger
 * /api/wasteCategory/getCategory:
 *   get:
 *    description:  Endpoint to get list of categories
 *    tags:
 *      - Category
 *    responses:
 *       200:
 *         description: A list of categories.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/Category'
 */
  router.get('/getCategory', [authUtil.validateMiddleware, authUtil.isGpUser], wasteCategoryController.getCategory);
  /**
 * @swagger
 * /api/wasteCategory/getsubCategory/{categoryID}:
 *   get:
 *    description:  Endpoint to get list of sub categories
 *    tags:
 *      - SubCategory
 *    parameters:
 *      - name: categoryID
 *        description: id of the waste category
 *        in: path
 *        required: true
 *        type: number
 *    responses:
 *       200:
 *         description: A list of sub categories.
 *         content:
 *           application/json:
 *             schema:
 *              type: array
 *              items:
 *                $ref: '#/components/schemas/SubCategory'
 */
  router.get('/getSubcategory/:categoryID', [authUtil.validateMiddleware, authUtil.isGpUser], validator.categoryIdValidations, validator.validate, wasteCategoryController.getsubCategory);
  app.use('/api/wasteCategory', router);
};
