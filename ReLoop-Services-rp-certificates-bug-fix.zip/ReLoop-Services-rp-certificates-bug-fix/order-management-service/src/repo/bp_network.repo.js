const { bp_private_nwk, business_partner } = require('../models/index');

exports.getManyByQuery = async (query) => {
  const dbQuery = bp_private_nwk.attributesMapHelper(query);
  const pvtNetworks = await bp_private_nwk.findAll({
    where: dbQuery,
    attributes: bp_private_nwk.attributesMapHelper(['bpNwkId', ['nwk_member', 'recyclerId'],
      ['nwk_owner', 'greenPartnerId']]),
    include: [{
      model: business_partner,
      attributes: business_partner.attributesMapHelper(['emailId', 'username', 'phoneNumber']),
      as: 'rcy',
    }],
  });
  return pvtNetworks;
};
