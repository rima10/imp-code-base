const dataTypes = require('sequelize').DataTypes;
const { sequelize, order_invited_business_partner } = require('../models/index');
const Order = require('../models/order')(sequelize, dataTypes);

const s3Util = require('../utils/s3.util');
const models = require('../models/init-models')(sequelize, dataTypes);

const attributes = [['order_id', 'orderId'], ['order_no', 'orderNumber'],
  ['order_sub_text', 'orderAdditionalInfo'], 'category', ['sub_category', 'subCategory'], ['order_type', 'orderType'],
  ['submission_deadline', 'submissionDeadline'], ['order_network', 'orderNetwork'],
  ['picture_loc', 'pictureLoc'], 'created_date', 'last_modified_date', ['created_by', 'createdBy'], ['updated_by', 'updatedBy'],
  'preferred_pick_up_time', 'is_verification_reqd', ['order_position', 'orderPosition'], ['current_sequence', 'currentSequence'],
  ['logistics_scheduled_time', 'logisticsScheduledTime'], ['vehicle_type', 'vehicleType'], ['vehicle_licence_no', 'vehicleNumber'], ['recycle_asset_type', 'recycleAssetType'],
  ['total_weight', 'totalWeight'], ['logistic_spoc_number', 'logisticSpocContactNumber'], ['logistic_spoc_name', 'logisticSpocName'],
  ['recycler_contact_number', 'recyclerContactNumber'], ['recycler_contact_name', 'recyclerContactName'], ['logistic_provider', 'logisticProvider'],
  ['driver_name', 'driverName']];

const refurbishOrderItemAttr = ['id', ['order_id', 'orderId'], ['equipment_no', 'equipmentNumber'], ['asset_no', 'assetNumber'],
  ['item_type', 'itemType'], 'make', 'description', 'created_date', 'last_modified_date', ['created_by', 'createdBy'],
  ['updated_by', 'updatedBy'], ['building_loc', 'buildingLocation'], ['manufacture_serial', 'manufactureSerial'],
  ['bond_status', 'bondStatus'], 'model', ['age_in_year', 'ageInYear'], ['purchase_year', 'purchaseYear'],
];

const recycleOrderItemAttr = ['id', ['order_id', 'orderId'], 'description', 'created_date', 'last_modified_date', ['created_by', 'createdBy'],
  ['updated_by', 'updatedBy'], ['building_loc', 'buildingLocation'], 'model', ['recycle_item_unit', 'recycleItemUnit'], ['item_quantity', 'itemQuantity'],
];

const uploadToS3 = async (file, uuid) => {
  const fileNamewithExt = file.originalname;
  const fileName = fileNamewithExt.substr(0, fileNamewithExt.lastIndexOf('.'));
  const fileExt = fileNamewithExt.substr(fileNamewithExt.lastIndexOf('.') + 1);
  const key = `${fileName}_${uuid}.${fileExt}`;
  const s3FileKey = await s3Util.pushFileToS3(file, key);
  return s3FileKey;
};

exports.getOrderHeader = async (orderId) => {
  const order = models.order.findOne({
    where: { order_id: orderId },
    attributes: [['order_id', 'orderId'],
      [sequelize.fn('COUNT', sequelize.col('orderItems.id')), 'itemsCount']],
    include: [{
      model: models.order_item,
      as: 'orderItems',
      attributes: [],
    }],
    group: ['order.order_id'],
  });
  return order;
};

const orderWorkflowQuery = (orderId, processType, processStageSequence) => ({
  where: { order_id: orderId },
  attributes: [['order_workflow_id', 'orderWorkflowId'], ['workflow_id', 'workflowId']],
  include: [{
    model: models.workflow,
    where: {
      process_type_id: processType,
      process_stage_sequence: processStageSequence,
    },
    as: 'workflow',
    attributes: [['workflow_id', 'workflowId'], ['process_type_id', 'processTypeId'], ['process_stage_name', 'processStageName'], ['process_stage_sequence', 'processStageSequence']],
  }, {
    model: models.order_workflow_approver,
    as: 'order_workflow_approvers',
  }],
});

/*
  @desc Map over all the workflowApprovers and create a high level json data out of the nested data
  @desc For each order workflow, add worklow details on the header level
  @desc For each workflow approvers get the status and other relevant data
  @param [Array]  workflows
  @return [Array] updatedWorkflows
*/
const modifyWorkflowData = async (orderWorkflow) => {
  const updatedOrderWorkflow = { ...orderWorkflow.dataValues };
  const {
    processTypeId, processStageName,
    processStageSequence,
  } = updatedOrderWorkflow.workflow.dataValues;
  updatedOrderWorkflow.processTypeId = processTypeId;
  updatedOrderWorkflow.processStageName = processStageName;
  updatedOrderWorkflow.processStageSequence = processStageSequence;
  const workflowApprovers = [];
  const { workflowId } = updatedOrderWorkflow.workflow.dataValues;
  const workflowApproverList = await models.workflow_approver.findAll(
    {
      where: { workflow_id: workflowId },
      attributes: [['workflow_approver_id', 'workflowApproverId'], ['approver_sequence', 'approverSequence']],
      include: [{
        model: models.approver,
        as: 'approver',
      }],
    },
  );
    // Map over all the available order workflow approvers
  workflowApproverList.map((workflowApprover) => {
    const updatedApprover = { ...workflowApprover.dataValues };
    const { workflowApproverId } = updatedApprover;
    const orderWfApprover = updatedOrderWorkflow.order_workflow_approvers.find(
      (approver) => approver.dataValues.workflow_approver_id === workflowApproverId,
    );
    if (orderWfApprover) {
      const { order_workflow_approve, status } = orderWfApprover;
      updatedApprover.orderWorkflowApproverId = order_workflow_approve;
      updatedApprover.status = status;
    } else {
      updatedApprover.status = 'Not Assigned';
    }
    const {
      approver_id, approver_name, approver_role, approver_sequence,
    } = updatedApprover.approver.dataValues;
    updatedApprover.approverId = approver_id;
    updatedApprover.approverName = approver_name;
    updatedApprover.approverRole = approver_role;
    delete updatedApprover.approver;
    workflowApprovers.push(updatedApprover);
  });
  updatedOrderWorkflow.workflowApprovers = workflowApprovers;
  delete updatedOrderWorkflow.workflow;
  delete updatedOrderWorkflow.order_workflow_approvers;
  return updatedOrderWorkflow;
};

exports.getOrdersByUserId = async (userId) => {
  const order = await models.order
    .findAll({
      where:
    { created_by: userId },
      order: [
        ['created_date', 'DESC'],
      ],
      attributes,
      include: [{
        model: models.process_type,
        as: 'orderProcessType',
        attributes: [['process_type_name', 'processTypeName']],
      }],
    });
  return order;
};

exports.getOrderDataByOrderId = async (orderId, approvalDataRequired,
  stageSequence, isRefurbish) => {
  const query = {
    where:
  { order_id: orderId },
    attributes,
    include: [{
      model: models.order_item,
      as: 'orderItems',
      attributes: isRefurbish ? refurbishOrderItemAttr : recycleOrderItemAttr,
    }, {
      model: models.category,
      as: 'order_category',
      attributes: [['category_name', 'categoryName']],
    },
    {
      model: models.sub_category,
      as: 'order_sub_category',
      attributes: [['sub_category_name', 'subCategoryName']],
    },
    {
      model: models.process_type,
      as: 'orderProcessType',
      attributes: [['process_type_name', 'processTypeName']],
    },
    {
      model: models.order_invited_business_partner,
      as: 'order_invited_business_partners',
      attributes: [['invited_bp_id', 'bpId'], ['invited_bp_username', 'bpUsername']],
    },
    ],
  };
  const order = await models.order.findOne(query);
  if (!order) throw new Error('order not found');
  let workflowData = null;
  if (approvalDataRequired) {
    const orderWorkflow = await models.order_workflow.findOne(orderWorkflowQuery(
      orderId, order.dataValues.orderType, stageSequence,
    ));

    if (orderWorkflow) workflowData = await modifyWorkflowData(orderWorkflow);
  }
  // Format order response
  const orderData = { ...order.dataValues };
  if (approvalDataRequired) {
    orderData.workflow = workflowData;
  }
  orderData.categoryName = order.order_category.dataValues.categoryName;
  orderData.subCategoryName = order.order_sub_category.dataValues.subCategoryName;
  orderData.processType = order.orderProcessType.dataValues.processTypeName;
  orderData.recyclers = order.order_invited_business_partners.map((item) => {
    const { bpId, bpUsername } = item.dataValues;
    return { bpId, bpUsername };
  });
  // Delete unnecesaary data
  delete orderData.order_category;
  delete orderData.order_sub_category;
  delete orderData.order_process_type;
  delete orderData.order_invited_business_partners;
  return orderData;
};

exports.getOrder = async (orderId) => {
  const query = {
    where:
  { order_id: orderId },
    attributes: ['order_id', 'current_sequence', 'order_type', 'order_no'],
  };
  const order = await models.order.findOne(query);
  return order;
};

const createOrderNo = async () => {
  let orderNo = '';
  const year = new Date().getFullYear();
  orderNo += year;
  const lastOrder = await models.order.findOne({ order: [['created_date', 'DESC']], attributes: [['order_no', 'orderNo']] });
  if (!lastOrder) return `${orderNo}001`;
  let lastOrderNumber = lastOrder.dataValues.orderNo;
  lastOrderNumber = lastOrderNumber.substr(lastOrderNumber.length - 3);
  let newOrderNum = Number(lastOrderNumber) + 1;
  if (newOrderNum.toString().length === 1) newOrderNum = `00${newOrderNum}`;
  else if (newOrderNum.toString().length === 2) newOrderNum = `0${newOrderNum}`;
  return `${orderNo}${newOrderNum}`;
};

exports.createOrderHeader = async (orderHeaderData, userId, files, orderPosition) => {
  const {
    orderType, category, subcategory, network,
    orderLocation, additionalInfo, submissionDeadline,
    recyclerIds, totalWeight, recycleAssetType,
  } = orderHeaderData;

  const uuid = await createOrderNo();
  let s3FileKey;
  if (files.picture !== undefined) {
    const file = files.picture[0];
    s3FileKey = await uploadToS3(file, uuid);
  }

  const order = await Order.create({
    order_no: uuid,
    order_type: orderType,
    category,
    sub_category: subcategory,
    order_network: network,
    order_loc: orderLocation,
    order_sub_text: additionalInfo,
    submission_deadline: submissionDeadline,
    picture_loc: s3FileKey,
    created_by: userId,
    updated_by: userId,
    order_position: orderPosition,
    current_sequence: '1',
    total_weight: totalWeight,
    recycle_asset_type: recycleAssetType,
  });

  if (recyclerIds && recyclerIds.length) {
    const recyclersInArr = recyclerIds.split(',');
    const dbres = await models.business_partner.findAll({
      where: {
        bp_id: recyclersInArr,
      },
      attributes: ['bp_username', 'bp_id'],
    });
    if (recyclersInArr.length) {
      const recyclersMappedToOrder = dbres.map((item) => ({
        order_id: order.order_id,
        invited_bp_id: item.dataValues.bp_id,
        invited_bp_username: item.dataValues.bp_username,
      }));
      await order_invited_business_partner.bulkCreate(recyclersMappedToOrder, { validate: true });
    }
  }

  return order;
};

exports.getStageApprovalStatus = async (orderId, processType, processStageSequence) => {
  let workflowData = {};
  const approvals = await models.order_workflow.findOne(
    orderWorkflowQuery(orderId, processType, processStageSequence),
  );
  if (approvals) workflowData = await modifyWorkflowData(approvals);
  return workflowData;
};
