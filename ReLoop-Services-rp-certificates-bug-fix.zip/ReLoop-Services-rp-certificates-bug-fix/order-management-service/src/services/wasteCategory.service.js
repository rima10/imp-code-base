const dataTypes = require('sequelize').DataTypes;
const { sequelize } = require('../models/index');
const Category = require('../models/category')(sequelize, dataTypes);
const Subcategory = require('../models/sub_category')(sequelize, dataTypes);

exports.createCategory = async function (req, res, next) {
  try {
    const { categories } = req.body;
    await Promise.all(categories.map(async (category) => {
      await Category.create({ category_name: category.categoryName });
    }));
  } catch (error) {
    next(error);
  }
};

exports.getCategory = async function (req, res, next) {
  try {
    const categories = await Category.findAll({ attributes: [['category_id', 'categoryId'], ['category_name', 'categoryName']] });
    res.json(categories);
  } catch (error) {
    next(error);
  }
};

exports.createSubcategory = async function (req, res, next) {
  try {
    const { subcategories } = req.body;
    const { categoryID } = req.params;
    await Promise.all(subcategories.map(async (subcategory) => {
      const { subcategoryName } = subcategory;
      await Subcategory.create({
        category_id: categoryID,
        sub_category_name: subcategoryName,
      });
    }));
  } catch (error) {
    next(error);
  }
};

exports.getsubCategory = async function (req, res, next) {
  const { categoryID } = req.params;
  try {
    const subcategories = await Subcategory.findAll({
      where: { category_id: categoryID },
      attributes: [['sub_category_id', 'subcategoryId'], ['category_id', 'categoryId'], ['sub_category_name', 'subcategoryName']],
    });
    res.json(subcategories);
  } catch (error) {
    next(error);
  }
};
