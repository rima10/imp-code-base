const dataTypes = require('sequelize').DataTypes;
const { sequelize } = require('../models/index');
const OrderItem = require('../models/order_item')(sequelize, dataTypes);
const utilFunctions = require('../utils/commonFunctions.util');

// Excel to column mapping for refusrbish order
const getRefurbishOrderMapping = (orderId, userId, currElement) => ({
  order_id: orderId,
  equipment_no: currElement.A,
  asset_no: currElement.B,
  building_loc: currElement.E,
  bond_status: currElement.F,
  item_type: currElement.G,
  make: currElement.H,
  model: currElement.I,
  manufacture_serial: currElement.J,
  age_in_year: currElement.K,
  purchase_year: currElement.L,
  description: currElement.M,
  created_by: userId,
  updated_by: userId,
});

// Excel to column mapping for recycle order
const getRecycleOrderMapping = (orderId, userId, currElement) => ({
  order_id: orderId,
  model: currElement.B,
  item_quantity: currElement.C || null,
  recycle_item_unit: currElement.D || null,
  building_loc: currElement.E,
  description: currElement.F,
  created_by: userId,
  updated_by: userId,
});

exports.createOrderItem = async (req) => {
  const assetList = utilFunctions.convertExcelToJson(req.file.buffer);
  const { orderType, orderID } = req;
  const inputArr = assetList.slice(1);
  await Promise.all(inputArr.map(async (currElement) => {
    const orderItemData = orderType === '1' ? getRefurbishOrderMapping(orderID, req.userId, currElement)
      : getRecycleOrderMapping(orderID, req.userId, currElement);
    await OrderItem.create(orderItemData);
  }));
};

exports.readExcel = async (req) => {
  const excelData = utilFunctions.convertExcelToJson(req.file.buffer);
  const header = excelData.shift();
  const assetList = [];
  excelData.forEach((row) => {
    const assetRow = {};
    Object.keys(row).forEach((key) => {
      const value = row[key];
      assetRow[header[key]] = value;
    });
    assetList.push(assetRow);
  });
  return assetList;
};
