const { business_partner } = require('../models/index');

exports.getUserDatabyCognito = async (cognitoId) => {
  const res = await business_partner.findOne({
    where: {
      bp_userid: cognitoId,
      // Will be used when existing useer archive flag is set to false
      // [Op.not]: [{ archive: true }],
    },
    attributes: ['bp_id', 'bp_username', 'bp_email_id'],
  });
  if (!res) throw new Error('Invalid or inactive user');
  const userData = business_partner.attributesMapHelper(res.dataValues, { method: 'out' });
  return userData;
};
