const XLSX = require('xlsx');

const dataTypes = require('sequelize').DataTypes;
const { sequelize, order_quote, order_quote_item } = require('../models/index');
const models = require('../models/init-models')(sequelize, dataTypes);
const orderDataFormatUtil = require('../utils/order/dataFormat.util');
const orderService = require('./order.service');
const kakfaUtil = require('../utils/kafka.util');
const quotationRepo = require('../repo/quotation.repo');
const orderItemRepo = require('../repo/order_item.repo');

const getRefurbishQuote = async (quoteId) => {
  const updatedQuote = await models.order_quote.findOne(
    {
      where: { id: quoteId },
      attributes: [['id', 'quoteId']],
      include: [
        {
          model: models.model_quote,
          as: 'modelQuotes',
          attributes: [
            ['model_quote_id', 'modelQuoteId'], 'make', ['item_type', 'itemType'], 'model', 'price'],
        }],
    },
  );
  return updatedQuote;
};

const getRecycleQuote = async (quoteId) => {
  const updatedQuote = await models.order_quote.findOne(
    {
      where: { id: quoteId },
      attributes: [['id', 'quoteId']],
      include: [
        {
          model: models.order_quote_item,
          as: 'orderItemQuotes',
          attributes: [
            ['id', 'orderQuoteItemId'], ['order_item_id', 'orderItemId'], ['recycle_item_unit', 'recycleItemUnit']],
        }],
    },
  );
  return updatedQuote;
};

const getOrderQuoteItemData = (quotes, isRefurbishOrder) => {
  const quotesData = [];
  let quotesOverallStatus = 'In Review';
  const acceptedStatus = ['Accepted', 'Temporarily Accepted'];
  quotes.map((quote) => {
    const quoteData = { ...quote.dataValues };
    // Set quotesOverallStatus flag to accepted if any quote has been accepted by green partner
    if (!acceptedStatus.includes(quotesOverallStatus)
      && acceptedStatus.includes(quoteData.quoteStatus)) {
      quotesOverallStatus = quoteData.quoteStatus;
    }

    quoteData.recyclerId = quoteData.createdByBP.dataValues.recyclerId;
    quoteData.name = quoteData.createdByBP.dataValues.recyclerName;
    delete quoteData.createdByBP;
    if (isRefurbishOrder && quote.modelQuotes.length) {
      const result = orderDataFormatUtil.createQuotesTreeData(quoteData.modelQuotes);
      quoteData.totalPrice = result.totalPrice;
      quoteData.data = result.modelQuotes;
      delete quoteData.modelQuotes;
    } else if (!isRefurbishOrder && quote.orderItemQuotes.length) {
      const orderQuoteItems = quote.orderItemQuotes.reduce((acc, item) => {
        acc.push({ name: `${item.dataValues.order_item.dataValues.model} (Unit in ${item.dataValues.recycleItemUnit})` });
        return acc;
      }, []);
      quoteData.data = orderQuoteItems;
      delete quoteData.orderItemQuotes;
    } else quoteData.data = [];

    quotesData.push(quoteData);
  });
  return { quotesOverallStatus, quotesData };
};

exports.getRefurbishOrderFirstLevelQuotes = async (req) => {
  const { orderId } = req.params;
  const quotes = await quotationRepo.getRefurbishInitialQuote(orderId);
  const result = getOrderQuoteItemData(quotes, true);
  return result;
};

exports.getRecycleOrderFirstLevelQuotes = async (req) => {
  const { orderId } = req.params;
  const quotes = await quotationRepo.getRecycleInitialQuote(orderId);
  const result = getOrderQuoteItemData(quotes, false);
  return result;
};

const notifyBP = async (type, orderId, recyclerId) => {
  const order = await models.order.findOne({
    where: { order_id: orderId },
    attributes: ['order_id', 'order_no'],
    include: [{ model: models.business_partner, as: 'businessPartner', atrributes: ['bp_email_id'] }],
  });
  const recycler = await models.business_partner.findOne({ where: { bp_id: recyclerId }, attributes: [['bp_username', 'recyclerName']] });
  const { recyclerName } = recycler.dataValues;
  const receiver = order.businessPartner.bp_email_id;
  const notification = {
    type,
    receivers: [{ receiverType: 'bp', email: receiver }],
    values: {
      orderNo: order.order_no,
      recycler: recyclerName,
    },
  };
  kakfaUtil.runProducer('user-notification', notification);
};

/*
  @desc Create order quote data for refurbishing order
  @desc by creating model quotes for the consolidated order items
  @param Object params
  @return Object - quote data
*/
const submitRefurbishInitialQuote = async (params) => {
  const {
    userId, orderId, orderItems, quoteComments,
  } = params;
  const totalPrice = orderDataFormatUtil.calcTotalPrice(orderItems);
  const quote = await models.order_quote.create({
    order_id: orderId,
    created_by: userId,
    quote_status: 'In Review',
    total_price: totalPrice,
    comments: quoteComments,
  });

  // Create model quotes for each consolidated order item
  await Promise.all(orderItems.map(async (orderItem) => {
    const {
      itemType, make, model, price, count,
    } = orderItem;
    await models.model_quote.create({
      order_quote_id: quote.id,
      item_type: itemType,
      make,
      model,
      price,
      count,
    });
  }));
  const updatedQuote = await getRefurbishQuote(quote.id);
  return updatedQuote;
};

/*
  @desc Create order quote data for recycling order
  @desc by creating order quotes items with respective unit of measurement
  @param Object params
  @return Object - quote data
*/
const submitRecycleInitialQuote = async (params) => {
  const {
    userId, orderId, orderItems, quoteComments, pricePerKg,
  } = params;
  const quote = await models.order_quote.create({
    order_id: orderId,
    created_by: userId,
    quote_status: 'In Review',
    recycle_price_per_kg: pricePerKg,
    comments: quoteComments,
  });

  // Create order quote item for each order item
  await Promise.all(orderItems.map(async (orderItem) => {
    const {
      orderItemId, itemUnit,
    } = orderItem;
    await models.order_quote_item.create({
      order_quote_id: quote.id,
      order_item_id: orderItemId,
      recycle_item_unit: itemUnit,
    });
  }));
  const updatedQuote = await getRecycleQuote(quote.id);
  return updatedQuote;
};

exports.inviteRecyclersForQuote = async (orderId, recyclers) => {
  await Promise.all(recyclers.map(async (recycler) => {
    await models.order_invited_business_partner.create({
      order_id: orderId,
      invited_bp_id: recycler.recyclerId,
    });
  }));
};

exports.inviteRecyclers = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { orderId } = req.body;
    let { recyclers } = req.body;
    if (!recyclers) {
      recyclers = await models.bp_private_nwk.findAll({ where: { nwK_owner: userId }, atrributes: [['nwk_member', 'recyclerId']] });
    }
    await exports.inviteRecyclersForQuote(orderId, recyclers);
  } catch (error) {
    next(error);
  }
};

/*
  @desc Check if recycler has already submitted the quote for the order
  @param String orderId
  @param String userId
*/
const checkExistingQuote = async (orderId, userId) => {
  const existingQuote = await models.order_quote.findOne({
    where: {
      order_id: orderId,
      created_by: userId,
    },
  });
  if (existingQuote) throw new Error('Quote already submitted by recycler');
};

exports.submitRecycleFirstLevelQuote = async (req) => {
  const { userId } = req.params;
  const {
    orderId, orderItems, quoteComments, pricePerKg,
  } = req.body;

  await checkExistingQuote(orderId, userId);

  const params = {
    userId, orderId, orderItems, quoteComments, pricePerKg,
  };
  const quote = await submitRecycleInitialQuote(params);
  notifyBP('quote submitted', orderId, userId);
  return quote;
};

exports.submitReFurbishFirstLevelQuote = async (req) => {
  const { userId } = req.params;
  const {
    orderId, orderItems, quoteComments,
  } = req.body;

  await checkExistingQuote(orderId, userId);

  const params = {
    userId, orderId, orderItems, quoteComments,
  };
  const quote = await submitRefurbishInitialQuote(params);
  notifyBP('quote submitted', orderId, userId);
  return quote;
};

exports.acceptQuote = async (req) => {
  const { orderId } = req.params;
  const { scheduledOnsiteDate, estimatedTime, comment } = req.body;
  let selectedQuote = await models.order_quote.findOne(
    { where: { order_id: orderId, quote_status: 'Temporarily Accepted' } },
  );
  if (selectedQuote) {
    selectedQuote = selectedQuote.update({ quote_status: 'Accepted', onsite_scheduled_time: scheduledOnsiteDate });
  }
  return selectedQuote;
};

exports.temproaryAcceptQuote = async (req) => {
  const { orderId, quoteId } = req.params;
  const alreadyApprovedQuotes = await models.order_quote.findAll(
    { where: { order_id: orderId, quote_status: 'Temporarily Accepted' } },
  );
  if (alreadyApprovedQuotes.length) {
    throw new Error('A quote has already been accepted for this order');
  }
  let selectedQuote = await models.order_quote.findOne(
    { where: { id: quoteId, order_id: orderId } },
  );
  if (selectedQuote) {
    selectedQuote = selectedQuote.update({ quote_status: 'Temporarily Accepted' });
  }
  return selectedQuote;
};

exports.rejectQuote = async (req) => {
  const { orderId, quoteId } = req.params;
  const { comment } = req.body;
  let selectedQuote = await models.order_quote.findOne(
    { where: { id: quoteId, order_id: orderId } },
  );
  if (selectedQuote) {
    selectedQuote = selectedQuote.update({ quote_status: 'Rejected' });
  }
  return selectedQuote;
};

exports.getCurrentAcceptedOrderQuotation = async (orderId) => {
  const res = await order_quote.findOne({
    where: { order_id: orderId, quote_status: 'Accepted' },
    attributes: order_quote.attributesMapHelper([], { method: 'out' }),
  });
  return res ? res.dataValues : undefined;
};

exports.getScheduledOnsiteVisitDetails = async (req) => {
  const { orderId } = req.params;
  const quote = await models.order_quote.findOne({
    where: { order_id: orderId, quote_status: 'Accepted' },
    attributes: [['id', 'quoteId'], ['id', 'quoteId'], ['quote_status', 'quoteStatus'], ['total_price', 'totalPrice'], ['onsite_scheduled_time', 'onsiteScheduledTime']],
    include: [{
      model: models.business_partner,
      as: 'createdByBP',
      attributes: [['bp_id', 'recyclerId'], ['bp_username', 'recyclerName']],
    }],
  });
  return quote;
};

const getItemQuote = async (quoteId) => {
  const updatedOrderItemQuote = await models.order_quote.findOne(
    {
      where: { id: quoteId },
      attributes: [['id', 'quoteId']],
      include: [
        {
          model: models.order_quote_item,
          as: 'orderItemQuotes',
          attributes: order_quote_item.attributesMapHelper([], { method: 'out' }),
        }],
    },
  );
  return updatedOrderItemQuote;
};

const submitRecycleFinalQuote = async (orderItemQuote) => {
  const {
    orderQuoteItemsId, finalQty, pricePerUnit,
  } = orderItemQuote;
  await Promise.all(orderQuoteItemsId.map(async (orderQuoteItem) => {
    const existingQuoteItem = await models.order_quote_item.findOne(
      { where: { id: orderQuoteItem } },
    );
    if (!existingQuoteItem) throw new Error('Order quote item does not exist');
    await existingQuoteItem.update({
      recycle_final_qty: finalQty,
      recycle_price_per_unit: pricePerUnit,
      to_be_invoiced: finalQty * pricePerUnit,
    });
  }));
};

const getRecycleOrderItemQuotes = (itemLevelQuote) => {
  const orderItemGroupByUnit = itemLevelQuote.reduce((groupedOrderItem, quote) => {
    const quoteItem = quote.dataValues;
    const uom = quoteItem.itemUnit.toLowerCase();
    if (uom === 'kg') {
      groupedOrderItem.kg.push(quoteItem);
    } else groupedOrderItem.other.push(quoteItem);
    return groupedOrderItem;
  }, { kg: [], other: [] });
  const quoteItemData = [];
  Object.keys(orderItemGroupByUnit).map((unit) => {
    if (unit === 'kg') {
      const kgItems = {
        item: [],
        finalQty: '',
        unit: 'kg',
        pricePerUnit: '',
        totalPrice: '',
      };
      orderItemGroupByUnit[unit].map((quoteItem, index) => {
        kgItems.item.push(quoteItem.order_item.dataValues.model);
        if (index === orderItemGroupByUnit[unit].length - 1) {
          kgItems.finalQty = quoteItem.recycleFinalQty;
          kgItems.pricePerUnit = quoteItem.pricePerUnit;
          kgItems.totalPrice = quoteItem.toBeInvoiced;
        }
      });
      kgItems.item = kgItems.item.join(', ');
      quoteItemData.push(kgItems);
    } else {
      orderItemGroupByUnit[unit].map((quoteItem) => {
        const otherItems = {
          item: quoteItem.order_item.dataValues.model,
          finalQty: quoteItem.recycleFinalQty,
          unit: quoteItem.itemUnit.toLowerCase(),
          pricePerUnit: quoteItem.pricePerUnit,
          totalPrice: quoteItem.toBeInvoiced,
        };
        quoteItemData.push(otherItems);
      });
    }
  });
  return quoteItemData;
};

const getFirstLevelQuote = async (orderId) => {
  const firstLevelQuote = await models.order_quote.findOne({
    where: {
      order_id: orderId,
      quote_status: 'Accepted',
    },
    attributes: [['id', 'orderQuoteId']],
  });

  if (firstLevelQuote === null) {
    throw new Error('The First level quote is not accepted, can not post item level quote');
  }
  return firstLevelQuote;
};

const moveToNextStep = (gpUserId, orderId) => {
  orderService.moveOrderToNextStep({
    params: { userId: gpUserId },
    query: { orderId, nextStage: 5 },
  });
};

exports.submitRecycleItemLevelQuote = async (req) => {
  const { userId, orderId } = req.params;
  const { orderItemQuotes } = req.body;
  const firstLevelQuote = await getFirstLevelQuote(orderId);
  const orderData = await models.order.findOne({ where: { order_id: orderId }, attributes: [['created_by', 'createdBy']] });
  const gpUserId = orderData.dataValues.createdBy;
  await Promise.all(orderItemQuotes.map(async (orderItemQuote) => {
    submitRecycleFinalQuote(orderItemQuote);
  }));
  const updatedOrderItemQuote = await getItemQuote(firstLevelQuote.dataValues.orderQuoteId);
  moveToNextStep(gpUserId, orderId);
  notifyBP('asset grading completed', orderId, userId);
  return updatedOrderItemQuote;
};

function validateOrderQuoteItems(orderQuoteItems) {
  const requiredFields = ['orderItemQuoteId', 'grade', 'dataWipeStatus', 'reportStatus', 'accessoriesStatus',
    'serviceCost', 'invoiceAmount'];

  for (let i = 0; i < orderQuoteItems.length; i++) {
    let valid = true;
    const item = orderQuoteItems[i];
    requiredFields.forEach((field) => {
      if (item[field] === null || item[field] === undefined || item[field] === '') {
        valid = false;
      }
    });
    if (!valid) return false;
  }
  return true;
}
exports.submitRefurbishOrderAssetGradingQuote = async (user, orderId, quoteId) => {
  const { userId } = user;
  const orderQuoteItems = await orderItemRepo.getOrderItemsWithOrderQuoteItems(orderId, quoteId);
  if (!validateOrderQuoteItems(orderQuoteItems)) {
    throw new Error('Order Asset Grading Quotation is incomplete. Cannot submit incomplete Quotation.');
  }
  const orderData = await models.order.findOne({ where: { order_id: orderId }, attributes: [['created_by', 'createdBy']] });
  const gpUserId = orderData.dataValues.createdBy;
  moveToNextStep(gpUserId, orderId);
  notifyBP('asset grading completed', orderId, userId);
  return true;
};

exports.getRecycleOrderItemLevelQuote = async (req) => {
  const { orderId } = req.params;
  const orderQuote = await models.order_quote.findOne(
    {
      where: { order_id: orderId, quote_status: 'Accepted' },
      attributes: [['id', 'orderQuoteId'],
      ['recycle_price_per_kg', 'pricePerKg']],
      include: [{
        model: models.order_quote_item,
        as: 'orderItemQuotes',
        attributes: [['id', 'orderItemQuoteId'],
        ['recycle_price_per_unit', 'pricePerUnit'], ['recycle_final_qty', 'recycleFinalQty'], ['to_be_invoiced', 'toBeInvoiced'], ['recycle_item_unit', 'itemUnit']],
        include: [{
          model: models.order_item,
          as: 'order_item',
          attributes: ['model'],
        }],
      },
      {
        model: models.business_partner,
        as: 'createdByBP',
        attributes: [['bp_id', 'recyclerId'], ['bp_username', 'recyclerName']],
      }],
    },
  );
  let result;
  if (orderQuote) {
    const orderQuoteData = orderQuote.dataValues;
    result = {
      quoteId: orderQuoteData.orderQuoteId,
      pricePerKg: orderQuoteData.pricePerKg,
      recyclerName: orderQuoteData.createdByBP.dataValues.recyclerName,
      recyclerId: orderQuoteData.createdByBP.dataValues.recyclerId,
    };
    result.orderQuoteItems = getRecycleOrderItemQuotes(orderQuote.orderItemQuotes);
    result.totalPrice = result.orderQuoteItems
      .reduce((acc, quoteItem) => acc + Number(quoteItem.totalPrice), 0);
  } else result = {};
  return result;
};

exports.getOrderItemsGradingList = async function (orderId, quoteId) {
  return orderItemRepo.getOrderItemsWithOrderQuoteItems(orderId, quoteId);
};
const assetColumns = [{
  heading: 'Equipment No.',
  key: 'equipmentNumber',
}, {
  heading: 'Asset No.',
  key: 'assetNumber',
}, {
  heading: 'Location',
  key: 'buildingLocation',
}, {
  heading: 'Bond Status',
  key: 'bondStatus',
}, {
  heading: 'Item Type',
  key: 'itemType',
}, {
  heading: 'Make',
  key: 'make',
}, {
  heading: 'Model',
  key: 'model',
}, {
  heading: 'Age in Years',
  key: 'ageInYear',
}, {
  heading: 'Description',
  key: 'description',
}, {
  heading: 'Grade',
  key: 'grade',
}, {
  heading: 'Data wipe',
  key: 'dataWipeStatus',
}, {
  heading: 'Report status',
  key: 'reportStatus',
}, {
  heading: 'Accessories',
  key: 'accessoriesStatus',
}, {
  heading: 'List price',
  key: 'listPrice',
}, {
  heading: 'To be invoiced',
  key: 'invoiceAmount',
}, {
  heading: 'Service cost',
  key: 'serviceCost',
}];
exports.getOrderItemsGradingListInExcel = async function (orderId, quoteId) {
  const orderItems = await orderItemRepo.getOrderItemsWithOrderQuoteItems(orderId, quoteId);
  // create new excel workbook and add orderItems json into a sheet
  const excelOrderItems = orderItems.map((item) => {
    const excelRow = {};
    assetColumns.forEach((colItem) => {
      excelRow[colItem.heading] = item[colItem.key];
    });
    return excelRow;
  });
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(excelOrderItems);
  XLSX.utils.book_append_sheet(wb, ws, 'Asset Grade list');
  const wbOpts = { bookType: 'xlsx', type: 'buffer' };
  const bufferData = XLSX.write(wb, wbOpts);
  return bufferData;
};

exports.saveOrderItemsGradingList = async function (userData, orderId, quoteId, payload) {
  return quotationRepo.updateOrderQuoteItems(userData, orderId, quoteId, payload);
};

exports.getOrderQuoteDetails = async function (orderId, quoteId, projection) {
  return quotationRepo.getOrderQuote(orderId, quoteId, projection);
};

exports.updateOrderQuoteDetails = async function (userData, orderId, quoteId, payload) {
  return quotationRepo.updateOrderQuote(userData, orderId, quoteId, payload);
};
