const dataTypes = require('sequelize').DataTypes;
const { sequelize, order_invited_business_partner, business_partner, order_quote } = require('../models/index');
const Order = require('../models/order')(sequelize, dataTypes);
const OrderType = require('../models/process_type')(sequelize, dataTypes);
const Models = require('../models/init-models')(sequelize, dataTypes);
const orderItemService = require('./orderItem.service');
const docService = require('./doc.service');
const orderWorkflowService = require('./orderWorkflow.service');
const orderDataFormatUtil = require('../utils/order/dataFormat.util');
const orderRepo = require('../repo/order.repo');
const bpNetworkRepo = require('../repo/bp_network.repo');
const quotationService = require('./quotation.service');

const kakfaUtil = require('../utils/kafka.util');

async function assetExcelHandler(userId, orderDetails, excelFileMeta, orderType) {
  try {
    const { order_no, order_id } = orderDetails;
    const orderItemReq = {
      file: excelFileMeta,
      order_no,
      userId,
      orderID: order_id,
      orderType,
    };

    await orderItemService.createOrderItem(orderItemReq);

    // after creating the order, save the asset file
    const docItemReq = {
      files: { document: [excelFileMeta] },
      params: { orderId: order_id },
      body: { documentName: 'Asset List', orderNo: order_no },
    };
    await docService.uploadDocument(docItemReq);

    return Promise.resolve(true);
  } catch (err) {
    return Promise.reject(err);
  }
}

exports.createOrder = async (req) => {
  const orderDetails = req.body;
  const { processStageSequence, orderType } = orderDetails;
  const { userId } = req.params;
  const { files } = req;
  const orderPosition = 'In Progress';
  const orderHeader = await orderRepo.createOrderHeader(orderDetails, userId, files, orderPosition);

  // after creating the order, add the order item and link the order with the order item
  await assetExcelHandler(userId, orderHeader, req.files.assetExcel[0], orderType);

  await orderWorkflowService.createOrderWorkflowData(
    userId, { processStageSequence, processType: orderType, orderId: orderHeader.order_id },
  );

  const orders = await orderRepo.getOrdersByUserId(userId);
  return orders;
};

exports.saveOrderAsDraft = async (req, res, next) => {
  try {
    const orderDetails = req.body;
    const { userId } = req.params;
    const { files } = req;
    const orderPosition = 'Draft';
    const orderHeader = await orderRepo.createOrderHeader(orderDetails, userId, files, orderPosition);

    if (req.files && req.files.assetExcel[0]) {
      await assetExcelHandler(userId, orderHeader, req.files.assetExcel[0]);
    }
    const order = await orderRepo.getOrderDataByOrderId(
      orderHeader.order_id,
      false,
    );
    return order;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to get orders based on business partner id
*/
exports.getOrders = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const order = await orderRepo.getOrdersByUserId(userId);
    return order;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to get orders based on business partner id
*/
exports.getOrderForApprover = async (req, res, next) => {
  try {
    const { orderId } = req.params;
    const order = await orderRepo.getOrderDataByOrderId(orderId, false);
    return order;
  } catch (error) {
    return next(error);
  }
};
/*
  @desc service function to get orders based on order id
*/
exports.getRecycleOrderByOrderId = async (req, res, next) => {
  try {
    const { orderId } = req.params;
    const order = await orderRepo.getOrderDataByOrderId(orderId, true, '1', false);
    return order;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to get orders based on order id
*/
exports.getRefurbishOrderByOrderId = async (req, res, next) => {
  try {
    const { orderId } = req.params;
    const order = await orderRepo.getOrderDataByOrderId(orderId, true, '1', true);
    return order;
  } catch (error) {
    return next(error);
  }
};

exports.getConsolidatedOrderData = async (req, res, next) => {
  try {
    const { orderId } = req.params;
    const order = await orderRepo.getOrderDataByOrderId(orderId, true, '2', true);
    const consolidatedOrderData = orderDataFormatUtil.createConsolidatedOrderData(order);
    order.orderItems = consolidatedOrderData;
    return order;
  } catch (error) {
    return next(error);
  }
};

/*
  @desc service function to get asset file url based on order id
*/
exports.getFileURL = async (req, res, next) => {
  const { orderId } = req.params;
  const s3Key = await exports.getFileKeyForDownload(orderId);
  const s3URLForTemplate = await s3UtilFunctions.getUrlForDownloadTemplate(
    s3Key,
  );
  return s3URLForTemplate;
};

/*
  @desc service function to get OrderType
*/
exports.getOrderType = async (req, res, next) => {
  try {
    const orderType = await OrderType.findAll({
      attributes: [
        ['process_type_name', 'processTypeName'],
        ['process_type_id', 'processTypeId'],
      ],
    });
    return orderType;
  } catch (error) {
    next(error);
  }
};

exports.createOrderType = async function (req, res, next) {
  try {
    const { processTypes } = req.body;
    await Promise.all(
      processTypes.map(async (processType) => {
        const { processTypeName, processTypeId } = processType;
        await OrderType.create({
          process_type_id: processTypeId,
          process_type_name: processTypeName,
        });
      }),
    );
  } catch (error) {
    next(error);
  }
};

exports.getFileKeyForDownload = async function (orderId) {
  const fileKey = await Order.findOne({
    where: { order_id: orderId },
    attributes: ['asset_excel_loc', 'assetExcelLoc'],
  });
  return fileKey;
};

exports.getStageApprovalStatus = async (req) => {
  const { orderId } = req.params;
  const { processType, processStageSequence } = req.query;
  const approvals = await orderRepo.getStageApprovalStatus(
    orderId,
    processType,
    processStageSequence,
  );
  return approvals;
};

async function notifyRecyclersForOrder(userId, orderId, options = {}) {
  let { order, user } = options;
  if (!order) {
    order = await orderRepo.getOrder(orderId);
    order = order.dataValues;
  }
  if (!user) {
    user = await business_partner.findOne({
      where: business_partner.attributesMapHelper({ userId }),
      attributes: business_partner.attributesMapHelper(['emailId', 'username', 'userId']),
    });
    user = user.dataValues;
  }
  const dbres = await order_invited_business_partner.findAll({
    where: order_invited_business_partner.attributesMapHelper({ orderId }),
    include: [{
      model: business_partner,
      attributes: business_partner.attributesMapHelper(['emailId', 'username', 'userId']),
      as: 'invited_bp',
    }],
  });
  const invitedRecyclers = dbres.map((item) => {
    // eslint-disable-next-line no-shadow
    const { emailId, userId, username } = item.invited_bp.dataValues;
    return { emailId, userId, username };
  });

  const notification = {
    type: 'invite recyclers',
    receivers: invitedRecyclers.map((item) => ({ receiverType: 'bp', email: item.emailId })),
    values: {
      orderNo: order.order_no,
      greenPartnerName: user.username,
    },
  };
  kakfaUtil.runProducer('user-notification', notification);
  return Promise.resolve(invitedRecyclers);
}

exports.moveOrderToNextStep = async (req) => {
  const { userId } = req.params;
  const { orderId, nextStage, addApprovers } = req.query;
  let order = await orderRepo.getOrder(orderId);
  if (!order) throw new Error('Invalid order id');
  const orderType = order.order_type;
  order = await order.update({ order_id: orderId, current_sequence: nextStage });
  // Do not add approvers for quotation step
  await orderWorkflowService.createOrderWorkflowData(
    userId, {
      processStageSequence: nextStage, processType: orderType, orderId, addApprovers,
    },
  );
  // notify recyclers about the quotation submission
  if (nextStage.toString() === '4') {
    await notifyRecyclersForOrder(userId, orderId, { order: order.dataValues });
  }
  return order;
};

async function createAssetGradingDocument(orderId, quoteId) {
  try {
    const wbBuffer = await quotationService.getOrderItemsGradingListInExcel(orderId, quoteId);
    const documentName = 'Asset Grading';
    const fileName = `AssetGrading_${orderId}_${quoteId}.xlsx`;
    const file = {
      buffer: wbBuffer,
    };
    const document = await docService.uploadDocToS3(orderId, documentName, file, fileName);
    return Promise.resolve(document);
  } catch (e) {
    return Promise.reject(e);
  }
}
exports.scheduleLogistics = async (req) => {
  const { orderId } = req.params;
  // create asset grading file document and push to s3
  const orderQuote = await quotationService.getCurrentAcceptedOrderQuotation(orderId);
  if (!orderQuote) throw new Error('Accepted order quotation is not found');

  createAssetGradingDocument(orderId, orderQuote.quoteId);

  const {
    scheduledLogisticDate, userId, logisticSpocName, logisticSpocContactNumber,
  } = req.body;
  let order = await Order.findOne({ where: { order_id: orderId } });
  if (order) {
    order = order.update({
      logistics_scheduled_time: scheduledLogisticDate,
      updated_by: userId,
      logistic_spoc_name: logisticSpocName,
      logistic_spoc_number: logisticSpocContactNumber,
    });
  }
  return order;
};

exports.acceptLogistics = async (req) => {
  const { orderId } = req.params;
  const {
    vehicleType,
    vehicleNumber,
    driverName,
    logisticProvider,
    recyclerContactName,
    recyclerContactNumber,
    userId,
  } = req.body;
  let order = await Order.findOne(
    { where: { order_id: orderId } },
  );
  if (order) {
    order = order.update({
      vehicle_type: vehicleType,
      vehicle_licence_no: vehicleNumber,
      driver_name: driverName,
      logistic_provider: logisticProvider,
      recycler_contact_name: recyclerContactName,
      recycler_contact_number: recyclerContactNumber,
      updated_by: userId,
    });
  }
  return order;
};

/*
  @desc service function to get private network
*/
exports.getUserPrivateNtw = async (userId) => {
  try {
    const query = {
      ownerUserId: userId,
    };
    const userPrivateNtws = await bpNetworkRepo.getManyByQuery(query);
    return Promise.resolve(userPrivateNtws);
  } catch (error) {
    return Promise.reject(error);
  }
};

/*
  @desc service function to get header data of the order
*/
exports.getOrderHeaderData = async (orderId) => {
  const order = await Models.order.findOne({
    where: { order_id: orderId },
    attributes: [
      ['order_id', 'orderId'],
      ['submission_deadline', 'submissionDeadline'],
      ['picture_loc', 'pictureLoc'],
      ['order_network', 'order_network'],
      ['order_sub_text', 'additionaInfo'],
      [sequelize.fn('COUNT', sequelize.col('orderItems.id')), 'itemsCount'],
    ],
    include: [
      {
        model: Models.order_item,
        as: 'orderItems',
        attributes: [],
      },
      {
        model: Models.category,
        as: 'order_category',
        attributes: [['category_name', 'categoryName']],
      },
      {
        model: Models.sub_category,
        as: 'order_sub_category',
        attributes: [['sub_category_name', 'subCategoryName']],
      },
      {
        model: Models.business_partner,
        as: 'businessPartner',
        attributes: [['bp_username', 'bpUserName']],
        include: [
          {
            model: Models.location,
            as: 'loc',
            attributes: ['pincode', ['loc_details', 'locDetails']],
            include: [
              {
                model: Models.city,
                as: 'city',
                attributes: ['city_name'],
              },
              {
                model: Models.state,
                as: 'state',
                attributes: ['state_name', 'country_id'],
              },
            ],
          },
        ],
      },
    ],
    group: [
      'order.order_id',
      'businessPartner.bp_id',
      'businessPartner.loc.city.city_id',
      'businessPartner.loc.loc_id',
      'order_category.category_id',
      'order_sub_category.sub_category_id',
      'businessPartner.loc.state.state_id',
    ],
  });
  const orderData = {
    orderId: order.dataValues.orderId,
    submissionDeadline: order.dataValues.submissionDeadline,
    category: order.dataValues.order_category.dataValues.categoryName,
    subCategory: order.dataValues.order_sub_category.dataValues.subCategoryName,
    pictureLoc: order.dataValues.pictureLoc,
    orderNetwork: order.dataValues.order_network,
    additionalInfo: order.dataValues.additionalInfo || null,
    itemsCount: order.dataValues.itemsCount,
    bpUserName: order.dataValues.businessPartner
      ? order.dataValues.businessPartner.dataValues.bpUserName : null,
    // eslint-disable-next-line no-nested-ternary
    locPincode: order.dataValues.businessPartner
      ? order.dataValues.businessPartner.loc
        ? order.dataValues.businessPartner.loc.pincode : null : null,
    locDetails:
      // eslint-disable-next-line no-nested-ternary
      order.dataValues.businessPartner
        ? order.dataValues.businessPartner.loc
          ? order.dataValues.businessPartner.loc.dataValues.locDetails : null : null,
    // eslint-disable-next-line no-nested-ternary
    locCity: order.dataValues.businessPartner
      ? order.dataValues.businessPartner.loc
        ? order.dataValues.businessPartner.loc.city.city_name : null : null,
    // eslint-disable-next-line no-nested-ternary
    locState: order.dataValues.businessPartner
      ? order.dataValues.businessPartner.loc
        ? order.dataValues.businessPartner.loc.state.state_name : null : null,
  };
  return orderData;
};

const getOrder = async (recyclerId) => {
  const OrderDetails = await Models.order_invited_business_partner.findAll({
    attributes: [['invited_bp_id', 'invitedBpId']],
    where: { invited_bp_id: recyclerId },
    as: 'order_invited_business_partner',
    separate: true,
    include: [
      {
        model: Models.order,
        attributes: [
          'order_no',
          'order_id',
          'created_date',
          'current_sequence',
        ],
        as: 'order',
        include: [
          {
            model: Models.business_partner,
            as: 'businessPartner',
            attributes: [['bp_username', 'bpUserName'], 'bp_id'],
          },
        ],
      },
    ],
  });
  const StatusValue = [];
  let finalStatus;
  /* eslint no-restricted-syntax: ["error", "FunctionExpression", "WithStatement",
  "BinaryExpression[operator='in']"] */
  for (const order of OrderDetails) {
    // eslint-disable-next-line no-await-in-loop
    const StatusDetails = await Models.order_quote.findOne({
      attributes: [['id', 'quoteId'], 'quote_status', 'order_id', 'created_by'],
      where: {
        created_by: recyclerId,
        order_id: order.order.dataValues.order_id,
      },
    });
    if (StatusDetails) {
      // eslint-disable-next-line prefer-destructuring
      finalStatus = StatusDetails.dataValues.quote_status;
      if (finalStatus === 'Accepted') {
        if (order.order.dataValues.current_sequence > 6) {
          finalStatus = 'Completed';
        } else if (
          order.order.dataValues.current_sequence === 4
          || order.order.dataValues.current_sequence === 5
          || order.order.dataValues.current_sequence === 6
        ) {
          finalStatus = 'In Progress';
        } else if (order.order.dataValues.current_sequence === 3) {
          finalStatus = 'Waiting';
        }
      }
      StatusValue.push({
        order_id: order.order.dataValues.order_id,
        order_no: order.order.dataValues.order_no,
        currentSequence: order.order.dataValues.current_sequence,
        created_by:
          order.order.dataValues.businessPartner.dataValues.bpUserName,
        created_date: order.order.dataValues.created_date,
        quote_status: finalStatus,
        quoteId: StatusDetails.dataValues.quoteId,
      });
    } else {
      StatusValue.push({
        order_id: order.order.dataValues.order_id,
        order_no: order.order.dataValues.order_no,
        currentSequence: order.order.dataValues.current_sequence,
        created_by:
          order.order.dataValues.businessPartner.dataValues.bpUserName,
        created_date: order.order.dataValues.created_date,
        quote_status: 'New',
        quoteId: undefined,
      });
    }
  }
  return StatusValue;
};

exports.getNewOrderForRecycler = async (req) => {
  const { recyclerPartnerId } = req.params;
  const details = await getOrder(recyclerPartnerId);
  return details;
};
