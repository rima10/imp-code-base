import React, { Fragment } from 'react';
import { connect } from 'react-redux';
import Header from '../header/Header';
import OrderFCL from '../order/OrderFCL.js';

const Home = ({ userInfo }) => {
    return (
        <Fragment>
            <Header userName={userInfo.approverName}/>
            <OrderFCL style={{ height: '100%' }}/>
        </Fragment>
    );
};

const mapStateToProps = (state) => {
    return {
        userInfo: state.userInfo
    };
};

export default connect(mapStateToProps)(Home);
