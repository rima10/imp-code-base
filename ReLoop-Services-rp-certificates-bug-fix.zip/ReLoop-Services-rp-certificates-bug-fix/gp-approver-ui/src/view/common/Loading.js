import React from 'react';
import { BusyIndicator } from '@ui5/webcomponents-react';

const LoadingIndicator = ({ text = '' }) => {
    return (
        <BusyIndicator
            text={text}
            style={{ position: 'fixed', zIndex: 100, top: '50%', left: '50%' }}
            active
        />
    );
};

// {{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}
export default LoadingIndicator;
