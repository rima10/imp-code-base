import { FlexibleColumnLayout, List, StandardListItem } from '@ui5/webcomponents-react';
import React, { useState, Fragment, useEffect } from 'react';
import { connect } from "react-redux";
import { getOrdersInfo } from '../../store/action/taskAction';
import OrderDetails from './OrderDetails';

const getInfoState = (approverStatus) => {
    let infoState = 'none';
    switch (approverStatus) {
        case 'Pending':
            infoState = 'Warning';
            break;
        case 'Approved':
            infoState = 'Success';
            break;
        case 'Rejected':
            infoState = 'Error';
            break;
    }
    return infoState;
};
const OrderFCL = ({ orderList = [], startGetOrdersInfo }) => {
    const [layout, setLayout] = useState('OneColumn');
    const [selectedOrder, setSelectedOrder] = useState({});
    useEffect(() => {
        startGetOrdersInfo();
    }, []);
    const onSelectionChange = (event) => {
        const orderNumber = event.detail.selectedItems[0].innerHTML;
        const orderCurrentStatus = (event.detail.selectedItems[0].description).split(': ')[1];
        const order = orderList.find(order => order.orderNo === orderNumber &&
            order.processStageName === orderCurrentStatus);
        setSelectedOrder(order);
        setLayout('TwoColumnsMidExpanded');
    };
    return (<Fragment >
        <FlexibleColumnLayout
            midColumn={<><OrderDetails orderWorkflow={selectedOrder}/></>}
            startColumn={<List headerText="Order List" noDataText="No order data present"
                onSelectionChange={(e) => onSelectionChange(e)} mode={'SingleSelect'}>
                {orderList.map((order, idx) => {
                    return (<StandardListItem key={idx} info={order.status.toUpperCase()}
                        infoState={getInfoState(order.status)}
                        description={`Current Status : ${order.processStageName}`} >
                        {order.orderNo}</StandardListItem>);
                })}
            </List>}
            layout = {layout}
            style={{ height: '100vh' }}
        />
    </Fragment>);
};

const mapStateToProps = state => {
    return {
        orderList: state.order.orderList
    };
};

const mapDispatchToProps = dispatch => {
    return {
        startGetOrdersInfo: async () => dispatch(getOrdersInfo())
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderFCL);
