import React, { useState, useEffect } from 'react';
import AccountTable from '../common/Table';
import { connect } from 'react-redux';
import { getOrderItemLevelQuote, getOrderInfo
} from '../../store/action/taskAction';

const ApproveFinalQuote = ({ orderWorkflow, startGetItemQuote, orderItemQuotation, startGetOrderInfo, orderType }) => {
    const [assetRows, setAssetRows] = useState([]);
    const assetColumns = [
        'Equipment No.',
        'Location',
        'Bond Status',
        'Item Type',
        'Make',
        'Model',
        'Age in Years',
        'Description',
        'Grade',
        'Blancco',
        'Report status',
        'List price',
        'To be invoiced',
        'service cost'

    ];

    const recycleAssetColumns = [
        'Item',
        'Final Quantity',
        'Unit',
        'Price per Unit (INR)',
        'Total Price (INR)'
    ];

    const getOrderItemQuoteDetails = (orderItemQuotation) => {
        const newRows = [];
        if (orderType === '1') {
            orderItemQuotation.map((index) => {
                const row = [];
                const orderItem = index.order_item;
                row.push({ name: assetColumns[0], value: orderItem.equipmentNumber, type: 'text' });
                row.push({ name: assetColumns[2], value: orderItem.buildingLoc, type: 'text' });
                row.push({ name: assetColumns[3], value: orderItem.bondStatus, type: 'text' });
                row.push({ name: assetColumns[4], value: orderItem.itemType, type: 'text' });
                row.push({ name: assetColumns[5], value: orderItem.make, type: 'text' });
                row.push({ name: assetColumns[6], value: orderItem.model, type: 'text' });
                row.push({ name: assetColumns[8], value: orderItem.ageInYear, type: 'text' });
                row.push({ name: assetColumns[10], value: orderItem.description, type: 'text' });
                row.push({ name: assetColumns[11], value: index.grade, type: 'text' });
                row.push({ name: assetColumns[12], value: index.blancco, type: 'text' });
                row.push({ name: assetColumns[13], value: index.reportStatus, type: 'text' });
                row.push({ name: assetColumns[14], value: index.listPrice, type: 'text' });
                row.push({ name: assetColumns[15], value: index.serviceCost, type: 'text' });
                row.push({ name: assetColumns[16], value: index.toBeInvoiced, type: 'text' });
                newRows.push(row);
            });
        } else {
            orderItemQuotation.orderQuoteItems.map((orderItem) => {
                const row = [];
                row.push({ name: assetColumns[0], value: orderItem.item, type: 'text' });
                row.push({ name: assetColumns[1], value: orderItem.finalQty, type: 'text' });
                row.push({ name: assetColumns[2], value: orderItem.unit, type: 'text' });
                row.push({ name: assetColumns[3], value: orderItem.pricePerUnit, type: 'text' });
                row.push({ name: assetColumns[4], value: orderItem.totalPrice, type: 'text' });
                newRows.push(row);
            });
        }
        return newRows;
    };

    const getColumns = () => {
        return orderType === '1' ? assetColumns : recycleAssetColumns;
    };
    useEffect(() => {
        startGetOrderInfo(orderWorkflow.orderId);
        startGetItemQuote(orderWorkflow.orderId, orderType);
    }, []);

    useEffect(() => {
        if (orderItemQuotation) {
            const assetRows = getOrderItemQuoteDetails(orderItemQuotation);
            setAssetRows(assetRows);
        }
    }, [orderItemQuotation]);
    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <AccountTable columns={getColumns()} edit={false} text="Asset List" rows={assetRows} />
        </div>
    );
};


const mapStateToProps = (state) => {
    return {
        orderItemQuotation: state.order.orderItemQuotation
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetItemQuote: (orderId, orderType) =>
            dispatch(getOrderItemLevelQuote(orderId, orderType)),
        startGetOrderInfo: (orderId) => dispatch(getOrderInfo(orderId))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(ApproveFinalQuote);
