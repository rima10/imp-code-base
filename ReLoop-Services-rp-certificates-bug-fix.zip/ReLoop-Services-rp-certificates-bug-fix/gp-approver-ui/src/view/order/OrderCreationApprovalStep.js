import React, { useState, useEffect } from 'react';
import AccountTable from '../common/Table';
import { connect } from 'react-redux';
import { getOrderInfo, downloadFile } from '../../store/action/taskAction';

const OrderCreationApproval = ({ orderWorkflow, startGetOrderInfo, orderInfo = {} }) => {
    const [assetRows, setAssetRows] = useState([]);
    const assetColumns = [
        'Equipment No.',
        'Asset No.',
        'Location',
        'Bond Status',
        'Item Type',
        'Make',
        'Model',
        'Manuf. Serial No.',
        'Age in Years',
        'Purchase Year',
        'Description'
    ];
    const recycleAssetColumns = ['Item', 'Quantity', 'Unit', 'Location', 'Remarks'];
    const onDownloadBtnClick = (event) => {
        downloadFile(`Asset List_${orderInfo.orderNumber}.xlsx`);
    };

    const buttons = [
        {
            name: 'Download Excel',
            icon: 'download',
            onClick: onDownloadBtnClick
        }
    ];
    const getOrderItemDetails = (orderItemInfo) => {
        const newRows = [];
        if (orderInfo.orderType === '1') {
            orderItemInfo.map((index) => {
                const row = [];
                row.push({ name: assetColumns[0], value: index.equipmentNumber, type: 'text' });
                row.push({ name: assetColumns[1], value: index.assetNumber, type: 'text' });
                row.push({ name: assetColumns[2], value: index.buildingLocation, type: 'text' });
                row.push({ name: assetColumns[3], value: index.bondStatus, type: 'text' });
                row.push({ name: assetColumns[4], value: index.itemType, type: 'text' });
                row.push({ name: assetColumns[5], value: index.make, type: 'text' });
                row.push({ name: assetColumns[6], value: index.model, type: 'text' });
                row.push({ name: assetColumns[7], value: index.manufactureSerial, type: 'text' });
                row.push({ name: assetColumns[8], value: index.ageInYear, type: 'text' });
                row.push({ name: assetColumns[9], value: index.purchaseYear, type: 'text' });
                row.push({ name: assetColumns[10], value: index.description, type: 'text' });
                newRows.push(row);
            });
        } else {
            orderItemInfo.map((index) => {
                const row = [];
                row.push({ name: 'Item', value: index.model, type: 'text' });
                row.push({ name: 'Quantity', value: index.itemQuantity || '-', type: 'text' });
                row.push({ name: 'Unit', value: index.recycleItemUnit || '-', type: 'text' });
                row.push({ name: 'Location', value: index.buildingLocation, type: 'text' });
                row.push({ name: 'Remarks', value: index.description, type: 'text' });
                newRows.push(row);
            });
        }
        return newRows;
    };
    const getColumns = () => {
        return orderInfo.orderType === '1' ? assetColumns : recycleAssetColumns;
    };
    useEffect(() => {
        startGetOrderInfo(orderWorkflow.orderId);
    }, []);
    useEffect(() => {
        if (orderInfo.orderItems) {
            let rows = getOrderItemDetails(orderInfo.orderItems);
            setAssetRows(rows);
        }
    }, [orderInfo.orderItems]);

    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <AccountTable columns={getColumns()} edit={false} text="Asset List" rows={assetRows} buttons={buttons}/>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        orderInfo: state.order.order
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetOrderInfo: (orderId) => dispatch(getOrderInfo(orderId))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderCreationApproval);
