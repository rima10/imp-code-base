/* eslint-disable max-len */
import React, { useState, useRef } from 'react';
import { connect } from "react-redux";
import {
    Button, Title, Text, Toolbar, Form,
    FormItem, FormGroup, ObjectStatus
} from '@ui5/webcomponents-react';
import { spacing } from "@ui5/webcomponents-react-base";
import '../../asset/style/style.css';
import CommentDialog from './CommentDialog';
import { getOrderInfo, approveRequest, rejectRequest } from '../../store/action/taskAction';
import OrderCreationApprovalStep from './OrderCreationApprovalStep';
import QuoteSelectionApprovalStep from './QuoteSelectionApprovalStep';
import ApproveQuoteStep from './ApproveQuoteStep';

const OrderDetails = ({ orderInfo = {}, orderWorkflow = {}, slot, startReject, startApprove }) => {
    const [action, setAction] = useState(null);
    const [comment, setComment] = useState();
    const [btnView, setBtnView] = useState(true);
    const getStepContent = (processStageSequence) => {
        switch (processStageSequence) {
            case '1':
                return <OrderCreationApprovalStep orderWorkflow={orderWorkflow} orderType={orderWorkflow.orderType}/>;
            case '3':
                return <QuoteSelectionApprovalStep orderWorkflow={orderWorkflow} orderType={orderWorkflow.orderType} totalWeight={orderWorkflow.totalWeight}/>;
            case '5':
                return <ApproveQuoteStep orderWorkflow={orderWorkflow} orderType={orderWorkflow.orderType}/>;
            default:
                return 'Unknown step';
        }
    };
    const dialogRef = useRef(null);

    const onButtonClick = (action) => {
        dialogRef.current.open();
        setAction(action);
    };

    const onCancel = (action) => {
        dialogRef.current.close();
    };

    const onSubmit = () => {
        dialogRef.current.close();
        const payload = { orderId: orderWorkflow.orderId, orderWorkflowApproverId: orderWorkflow.orderWorkflowApproverId, comment: comment };
        if (action === 'Accept') {
            startApprove(payload);
            orderWorkflow.status = 'Approved';
        } else {
            startReject(payload);
            orderWorkflow.status = 'Rejected';
        }
        setBtnView(!btnView);
    };
    const onCommentChange = (event) => {
        setComment(event.target.value);
    };

    const getButtons = (approverStatus) => {
        let buttonsJSX = null;
        switch (approverStatus) {
            case 'Pending':
                buttonsJSX = (<div style={{ float: 'right', margin: '3px', justifyContent: 'space-between' }}>
                    <Button style={spacing.sapUiTinyMargin} design="Positive" icon="accept" onClick={() => onButtonClick('Accept')}>Approve</Button>
                    <Button style={spacing.sapUiTinyMargin} design="Negative" icon="decline" onClick={() => onButtonClick('Reject')}>Reject</Button>
                </div>);
                break;
            case 'Approved':
                buttonsJSX = (<div style={{ float: 'right', margin: '3px', justifyContent: 'space-between', display: 'flex' }}>
                    <ObjectStatus style={spacing.sapUiSmallMargin} state="Success" >Approved</ObjectStatus>
                </div>);
                break;
            case 'Rejected':
                buttonsJSX = (<div style={{ float: 'right', margin: '3px', justifyContent: 'space-between' }}>
                    <ObjectStatus style={spacing.sapUiTinyMargin} state="Error" >Rejected</ObjectStatus>
                </div>);
                break;
        }
        return buttonsJSX;
    };


    return (
        <div slot={slot} style={spacing.sapUiMediumMarginBeginEnd}>
            <Toolbar>
                <Title>Order Details : </Title>
                <Title>{orderInfo.orderNumber}</Title>
            </Toolbar>
            {getButtons(orderWorkflow.status)}
            <div style={{ clear: 'both' }} />
            <Form columnsL={2}
                columnsM={2}
                columnsS={2}
                labelSpanM={5}

                style={spacing.sapUiLargeMarginBottom}>
                <FormGroup>
                    <FormItem label="Order Type">
                        <Text>{orderInfo.processType}</Text>
                    </FormItem>
                    <FormItem label="Category">
                        <Text>{orderInfo.categoryName}</Text>
                    </FormItem>
                    <FormItem label="Subcategory">
                        <Text>{orderInfo.subCategoryName}</Text>
                    </FormItem>
                    {orderInfo.totalWeight && <FormItem label="Total Weight">
                        <Text>{`${orderInfo.totalWeight} kg`}</Text>
                    </FormItem>}
                </FormGroup>
                <FormGroup>
                    <FormItem label="Private/Public Network">
                        <Text>Private Network</Text>
                    </FormItem>
                    {orderInfo.recycleAssetType && <FormItem label="Asset Type">
                        <Text>{orderInfo.recycleAssetType}</Text>
                    </FormItem>}
                    <FormItem label="Order Submission Deadline">
                        <Text>{orderInfo.submissionDeadline !== undefined ? new Date(orderInfo.submissionDeadline).toDateString() : ''}
                        </Text>
                    </FormItem>
                    <FormItem label="Additional information">
                        <Text> {orderInfo.orderAdditionalInfo} </Text>
                    </FormItem>
                </FormGroup>
            </Form>
            {getStepContent(orderWorkflow.processStageSequence)}
            <CommentDialog ref={dialogRef} onCancel={onCancel} onSubmit={onSubmit} onCommentChange={onCommentChange} btnText={action} />
        </div>
    );
};
const mapStateToProps = state => {
    return {
        orderInfo: state.order.order
    };
};

const mapDispatchToProps = dispatch => {
    return {
        startGetOrderInfo: (orderId) => dispatch(getOrderInfo(orderId)),
        startApprove: (payload) => dispatch(approveRequest(payload)),
        startReject: (payload) => dispatch(rejectRequest(payload))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderDetails);

