import React, { useEffect } from 'react';
import { AnalyticalTable, Label, ObjectStatus, Text, Button } from '@ui5/webcomponents-react';

import {
    getOrderQuotation, getOrderInfo, rejectQuote, temporaryAcceptQuote
} from '../../store/action/taskAction';
import { connect } from 'react-redux';

const QuoteSelectionApproval = ({ startGetOrderInfo, orderType,
    totalWeight, orderWorkflow, startGetOrderQuotation, orderQuotation = {}, startTemporaryAcceptQuote
    , startRejectQuote
}) => {
    useEffect(() => {
        startGetOrderQuotation(orderWorkflow.orderId, orderType);
        startGetOrderInfo(orderWorkflow.orderId);
    }, []);

    const renderTotalPrice = (instance) => {
        let price = '-';
        if (!instance.cell.value) price = '';
        if (totalWeight && instance.cell.value) price = instance.cell.value * totalWeight;
        return <Text>{price}</Text>;
    };
    const renderName = (value) => {
        if (typeof value === 'object' && value !== null) {
            return (
                <Text>
                    {value.name} ({value.count})
                </Text>
            );
        }
        return <Text>{value}</Text>;
    };


    const getValueState = (value) => {
        if (value === 'In Review') {
            return 'Warning';
        }
        if (value === 'Accepted' || value === 'Temporarily Accepted') {
            return 'Success';
        }
        if (value === 'Rejected') {
            return 'Error';
        }
        return 'Information';
    };

    const renderPrice = (instance) => {
        const rowProps = instance.row.getRowProps();
        const rowKeyArr = rowProps.key.split('.');
        let price = instance.cell.value;
        if (price && rowKeyArr.length > 1) {
            return (<><Text>{price}</Text>
                <Text style={{ fontStyle: 'italic', fontSize: '1rem', margin: '2px' }}> / unit</Text></>);
        }
        return <Text>{price}</Text>;
    };

    const onAcceptQuote = (quoteId) => {
        startTemporaryAcceptQuote(orderWorkflow.orderId, quoteId, orderType);
    };

    const onRejectQuote = (quoteId) => {
        startRejectQuote(orderWorkflow.orderId, quoteId, orderType);
    };

    const getQuoteStatus = (value) => {
        if (value === 'Accepted' || value === 'Temporarily Accepted') {
            return 'Accepted';
        }
        return value;
    };


    const renderButton = (value) => {
        if (value) {
            let status = orderQuotation.quotesData.find((quote) => quote.quoteId === value).quoteStatus;
            if (status === 'Accepted' || status === 'Temporarily Accepted') {
                return (
                    <>
                        <Button onClick={() => onRejectQuote(value)} design="Negative">
                            Reject Quote
                        </Button>
                    </>
                );
            } else {
                if (
                    orderQuotation.quotesOverallStatus === 'Accepted' ||
                    orderQuotation.quotesOverallStatus === 'Temporarily Accepted'
                ) {
                    return <Button disabled>Accept Quote</Button>;
                }
                return (
                    <Button onClick={() => onAcceptQuote(value)} disabled={false}>
                        Accept Quote
                    </Button>
                );
            }
        }
        return null;
    };

    const renderAnalyticalTable = () => {
        if (orderType === '1') {
            return (<AnalyticalTable
                columns={[
                    {
                        Header: 'Recycler Company',
                        accessor: 'name',
                        Cell: (instance) => renderName(instance.cell.value)
                    },
                    {
                        Header: 'Price (INR)',
                        accessor: 'totalPrice',
                        Cell: (instance) => renderPrice(instance)
                    },
                    {
                        Header: 'Status',
                        accessor: 'quoteStatus',
                        Cell: (instance) => {
                            return (
                                <ObjectStatus state={getValueState(instance.cell.value)}>
                                    {getQuoteStatus(instance.cell.value)}
                                </ObjectStatus>
                            );
                        }
                    },
                    {
                        Header: 'Action',
                        accessor: 'quoteId',
                        Cell: (instance) => renderButton(instance.cell.value)
                    }
                ]}
                data={orderQuotation.quotesData}
                isTreeTable
                minRows={1}
                subRowsKey="data"
            />);
        }
        return (<AnalyticalTable
            columns={[
                {
                    Header: 'Recycler Company',
                    accessor: 'name',
                    Cell: (instance) => renderName(instance.cell.value),
                    width: 240
                },
                {
                    Header: 'Price/kg (INR)',
                    accessor: 'pricePerKg',
                    Cell: (instance) => <Text>{instance.cell.value}</Text>
                },
                {
                    Header: 'Total Price (INR)',
                    id: 'totalPrice',
                    accessor: 'pricePerKg',
                    Cell: (instance) => renderTotalPrice(instance)
                },
                {
                    Header: 'Comments',
                    accessor: 'quoteComments',
                    Cell: (instance) => <Text>{instance.cell.value}</Text>
                },
                {
                    Header: 'Status',
                    accessor: 'quoteStatus',
                    Cell: (instance) => {
                        return (
                            <ObjectStatus state={getValueState(instance.cell.value)}>
                                {getQuoteStatus(instance.cell.value)}
                            </ObjectStatus>
                        );
                    }
                },
                {
                    Header: 'Action',
                    accessor: 'quoteId',
                    Cell: (instance) => renderButton(instance.cell.value)
                }
            ]}
            data={orderQuotation.quotesData}
            isTreeTable
            minRows={1}
            subRowsKey="data"
        />);
    };

    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <Label style={{ fontSize: '1rem', fontWeight: 'bold', marginBottom: '10px' }}>Quotes From Recyclers</Label>
            {renderAnalyticalTable()}

        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        orderQuotation: state.order.orderQuotation
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startRejectQuote: (orderId, quoteId, orderType) => dispatch(rejectQuote(orderId, quoteId, orderType)),
        startTemporaryAcceptQuote: (orderId, quoteId, orderType) =>
            dispatch(temporaryAcceptQuote(orderId, quoteId, orderType)),
        startGetOrderQuotation: (orderId, orderType) => dispatch(getOrderQuotation(orderId, orderType)),
        startGetOrderInfo: (orderId) => dispatch(getOrderInfo(orderId))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(QuoteSelectionApproval);
