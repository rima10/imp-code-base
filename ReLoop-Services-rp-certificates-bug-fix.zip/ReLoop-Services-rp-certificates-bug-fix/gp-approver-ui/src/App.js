import React, { Component } from "react";
import { ThemeProvider } from '@ui5/webcomponents-react';
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Home from "./view/home/Home";
import PrivateRoute from "./view/login/PrivateRoute";
import LoginSuccess from './view/login/loginSuccess';
import { Provider } from "react-redux";
import { store } from "./store/store";


class App extends Component {
    constructor (props) {
        super(props);
    }

    render () {
        return (
            <Provider store = {store}>
                <ThemeProvider>
                    <BrowserRouter>
                        <Switch>
                            <Route path="/loginSuccessful">
                                <LoginSuccess/>
                            </Route>
                            <PrivateRoute exact path="/" component={Home}/>
                        </Switch>
                    </BrowserRouter>
                </ThemeProvider>
            </Provider>
        );
    }
}
export default App;
