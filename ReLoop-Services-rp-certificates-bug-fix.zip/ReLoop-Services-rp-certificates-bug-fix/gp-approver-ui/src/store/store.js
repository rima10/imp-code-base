import userInfo from './reducer/loginReducer';
import notification from './reducer/notificationReducer';
import order from './reducer/orderReducer';
import isLoading from './reducer/loadingReducer';
import { createStore, applyMiddleware, combineReducers } from "redux";
import thunk from 'redux-thunk';
import { composeWithDevTools } from 'redux-devtools-extension';

const reducers = {
    userInfo,
    notification,
    order,
    isLoading
};
const rootReducer = combineReducers(reducers);
export const store = createStore(rootReducer, composeWithDevTools(applyMiddleware(thunk)));
