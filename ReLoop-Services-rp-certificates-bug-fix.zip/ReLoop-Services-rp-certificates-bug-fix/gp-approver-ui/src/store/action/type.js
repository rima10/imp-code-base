export const SET_USER_INFO = 'SET_USER_INFO';
export const setUserInfo = (userInfo, isLoggedIn) => ({
    type: SET_USER_INFO,
    payload: { userInfo, isLoggedIn }
});

export const SET_ORDER_LIST_INFO = 'SET_ORDER_LIST_INFO';
export const setOrderListInfo = (orderList) => ({
    type: SET_ORDER_LIST_INFO,
    payload: orderList
});

export const SET_ORDER_INFO = 'SET_ORDER_INFO';
export const setOrderInfo = (order) => ({
    type: SET_ORDER_INFO,
    payload: order
});

export const SET_NOTIFICATION_LIST_INFO = 'SET_NOTIFICATION_LIST_INFO';
export const setNotificationsInfo = (notificationList) => ({
    type: SET_NOTIFICATION_LIST_INFO,
    payload: notificationList
});

export const SET_NOTIFICATION_READ = 'SET_NOTIFICATION_READ';
export const setNotificationRead = (notification) => ({
    type: SET_NOTIFICATION_READ,
    payload: notification
});

export const SET_LOAD_IN_PROGRESS = 'SET_LOAD_IN_PROGRESS';
export const loadInProgress = () => ({
    type: SET_LOAD_IN_PROGRESS
});

export const SET_LOAD_COMPLETED = 'SET_LOAD_COMPLETED';
export const loadCompleted = () => ({
    type: SET_LOAD_COMPLETED
});
export const SET_ORDER_QUOTATION = "SET_ORDER_QUOTATION";
export const setOrderQuotation = (orderQuotation) => ({
    type: SET_ORDER_QUOTATION,
    payload: orderQuotation
});
export const ORDER_QUOTATION_FAILED = "ORDER_QUOTATION_FAILED";
export const orderQuotationFailed = (errMsg) => ({
    type: ORDER_QUOTATION_FAILED,
    payload: errMsg
});
export const SET_ORDER_ITEM_QUOTATION = "SET_ORDER_ITEM_QUOTATION";
export const setOrderItemQuotation = (orderItemQuotation) => ({
    type: SET_ORDER_ITEM_QUOTATION,
    payload: orderItemQuotation
});
