import { SET_USER_INFO } from "../action/type";

export default (state = {}, action) => {
    const { type, payload } = action;
    switch (type) {
        case SET_USER_INFO:
            const { userInfo } = payload;
            return { ...state, ...userInfo, isLoggedIn: payload.isLoggedIn };
        default:
            return state;
    }
};
