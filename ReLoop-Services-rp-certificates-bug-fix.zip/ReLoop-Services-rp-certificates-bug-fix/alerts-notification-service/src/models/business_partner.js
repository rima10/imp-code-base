const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('business_partner', {
    bp_id: {
      autoIncrement: true,
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
    },
    bp_userid: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: 'business_partner_bp_userid_key',
    },
    bp_username: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    bp_email_id: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    bp_phone_number: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    loc_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'location',
        key: 'loc_id',
      },
    },
    certification_details: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    certificate_metadata: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    recycling_unit_capacity: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    gst_number: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    overall_rating: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    opted_network: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    has_pvt_network: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
    },
    is_part_of_pvt_nwk: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
    },
    archive: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    created_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    last_modified_date: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: Sequelize.Sequelize.literal('CURRENT_TIMESTAMP'),
    },
  }, {
    sequelize,
    tableName: 'business_partner',
    schema: 'user_detail',
    timestamps: false,
    indexes: [
      {
        name: 'business_partner_bp_userid_key',
        unique: true,
        fields: [
          { name: 'bp_userid' },
        ],
      },
      {
        name: 'business_partner_pkey',
        unique: true,
        fields: [
          { name: 'bp_id' },
        ],
      },
    ],
  });
};
