const AWS = require('aws-sdk');
const dotenv = require('dotenv');
const emailTemp = require('../resources/emailTemplate');

dotenv.config();

const { ACCESS_KEY_ID, SECRET_ACCESS_KEY, REGION } = process.env;
const sesData = {
  accessKeyId: ACCESS_KEY_ID,
  secretAccessKey: SECRET_ACCESS_KEY,
  region: REGION,
};
const SES = new AWS.SES(sesData);

exports.sendMail = async function (params, toAddresses) {
  const emailTempParams = emailTemp[params];
  emailTempParams.Destination.ToAddresses.push(toAddresses);
  const result = await SES.sendEmail(emailTempParams).promise();
  console.log(result);
};
