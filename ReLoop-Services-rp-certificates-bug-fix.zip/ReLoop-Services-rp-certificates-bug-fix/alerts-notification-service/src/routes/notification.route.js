const router = require('express').Router();
const notificationController = require('../controllers/notification.controller');

module.exports = (app) => {
  router.get('/getNotifications/:userId', notificationController.getNotifications);
  router.get('/getApproverNotifications/:approverId', notificationController.getApproverNotifications);
  router.post('/readNotification/:bpNotificationId', notificationController.readNotification);
  app.use('/api/notification', router);
};
