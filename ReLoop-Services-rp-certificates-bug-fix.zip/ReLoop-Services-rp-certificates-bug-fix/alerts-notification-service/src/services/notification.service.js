const dataTypes = require('sequelize').DataTypes;
const { sequelize } = require('../models/index');
const Models = require('../models/init-models')(sequelize, dataTypes);

const getNotificationQueryObj = (where, skip, top) => ({
  where,
  offset: skip || 0,
  limit: top || 5,
  order: [['created_date', 'DESC']],
  attributes: [
    ['bp_notification_id', 'bpNotificationId'],
    ['bp_id', 'bpId'],
    ['notification_id', 'notificationId'],
    ['is_read', 'isRead']],
  include: [
    {
      model: Models.notification,
      as: 'notification',
      attributes: [
        ['notification_body', 'notificationBody'],
        ['notification_text', 'notificationText'],
        ['created_date', 'createdDate']],
    }],
});

const getNotificationList = async (userId, skip, top, key) => {
  const where = {};
  where[key] = userId;
  where.is_read = false;
  const notificationquery = getNotificationQueryObj(where, skip, top);
  const notifications = await Models.bp_notification.findAll(notificationquery);
  return notifications;
};
exports.getNotifications = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { skip, top } = req.query;
    const notifications = await getNotificationList(userId, skip, top, 'bp_id');
    return notifications;
  } catch (error) {
    return next(error);
  }
};

exports.getApproverNotifications = async (req, res, next) => {
  try {
    const { approverId } = req.params;
    const { skip, top } = req.query;
    const notifications = await getNotificationList(approverId, skip, top, 'approver_id');
    return notifications;
  } catch (error) {
    return next(error);
  }
};

exports.readNotification = async (req, res, next) => {
  try {
    const { bpNotificationId } = req.params;
    const where = { bp_notification_id: bpNotificationId };
    const notificationQuery = getNotificationQueryObj(where);
    const notification = await Models.bp_notification.findOne(
      { where },
    );
    notification.update({ is_read: true });
    const notificationData = await Models.bp_notification.findOne(
      notificationQuery,
    );
    return notificationData;
  } catch (error) {
    return next(error);
  }
};
