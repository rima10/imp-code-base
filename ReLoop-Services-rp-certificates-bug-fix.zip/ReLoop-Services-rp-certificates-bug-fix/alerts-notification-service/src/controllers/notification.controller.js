const notificationService = require('../services/notification.service');

/*
  @desc controller function get business partner notifications
*/
exports.getNotifications = async function (req, res, next) {
  try {
    const notifications = await notificationService.getNotifications(req, res, next);
    res.json(notifications);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function get approver notifications
*/
exports.getApproverNotifications = async function (req, res, next) {
  try {
    const notifications = await notificationService.getApproverNotifications(req, res, next);
    res.json(notifications);
  } catch (error) {
    next(error);
  }
};

/*
  @desc controller function read notifications
*/
exports.readNotification = async (req, res, next) => {
  try {
    const notification = await notificationService.readNotification(req, res, next);
    res.status(201).json(notification);
  } catch (error) {
    next(error);
  }
};
