import '@testing-library/jest-dom/extend-expect';

jest.mock('@ui5/webcomponents-react-base/dist/Device', () => {
    const Device = jest.genMockFromModule('@ui5/webcomponents-react-base/dist/Device');
    Device.getCurrentRange = () => ({
        name: 'Desktop'
    });
    return Device;
});

beforeAll(() => {
    Object.defineProperty(window, 'matchMedia', {
        writable: true,
        value: jest.fn().mockImplementation((query) => ({
            matches: false,
            media: query,
            onchange: null,
            addListener: jest.fn(),
            removeListener: jest.fn(),
            addEventListener: jest.fn(),
            removeEventListener: jest.fn(),
            dispatchEvent: jest.fn()
        }))
    });
    window.ResizeObserver =
        window.ResizeObserver ||
        jest.fn().mockImplementation(() => ({
            disconnect: jest.fn(),
            observe: jest.fn(),
            unobserve: jest.fn()
        }));
    window.IntersectionObserver = jest.fn().mockImplementation(() => ({
        observe: jest.fn(),
        disconnect: jest.fn()
    }));
});
