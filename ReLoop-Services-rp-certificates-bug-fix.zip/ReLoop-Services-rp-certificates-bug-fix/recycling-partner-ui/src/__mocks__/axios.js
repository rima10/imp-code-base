export default {
    get: jest.fn(() => Promise.resolve({ data: [] })),
    post: jest.fn(() => Promise.resolve({ data: 'Successful' })),
    patch: jest.fn(() => Promise.resolve({ data: 'Successful' })),
    delete: jest.fn(() => Promise.resolve({ data: 'Successful' }))
};
