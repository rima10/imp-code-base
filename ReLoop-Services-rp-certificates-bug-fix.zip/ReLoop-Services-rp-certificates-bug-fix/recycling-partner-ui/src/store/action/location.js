import { FETCH_STATES_INFO, FETCH_CITIES_INFO } from '../actionType';
import http from '../../utils/httpService';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

export const getStates = () => (dispatch) => {
    dispatch({
        type: FETCH_STATES_INFO,
        payload: http.get(`${API_BASE_URL}user/loc/getStatesbyCountry/1`, {
            withCredentials: true
        })
    });
};

export const getCities = (stateId) => (dispatch) => {
    dispatch({
        type: FETCH_CITIES_INFO,
        payload: http.get(`${API_BASE_URL}user/loc/getCitiesbyState/${stateId}`, {
            withCredentials: true
        })
    });
};
