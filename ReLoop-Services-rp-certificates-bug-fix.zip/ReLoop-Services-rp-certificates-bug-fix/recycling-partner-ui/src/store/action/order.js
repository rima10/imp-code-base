import {
    SUBMIT_FIRST_LEVEL_QUOTE,
    ACCEPT_LOGISTIC_SCHEDULE,
    FETCH_ORDER_LIST,
    FETCH_ORDER_HEADER_DATA,
    FETCH_CONSOLIDATED_ORDER_ITEMS_INFO
} from '../actionType';
import http from '../../utils/httpService';
import { getErrorMessage } from '../../utils/errorMessage';
import { showErrorMessage, showMessage } from './toast';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

export const getConsolidatedOrderItemInfo = (orderId) => async (dispatch) => {
    dispatch({
        type: FETCH_CONSOLIDATED_ORDER_ITEMS_INFO,
        payload: http.get(`${API_BASE_URL}order/getConsolidatedOrderData/${orderId}`, {
            withCredentials: true
        })
    });
};

export const submitFirstLevelQuote = (payload) => async (dispatch, getState) => {
    const userId = getState().userInfo.bp_id;
    await dispatch({
        type: SUBMIT_FIRST_LEVEL_QUOTE,
        payload: http.post(`${API_BASE_URL}order/quotation/submitRefurbishInitialQuote/${userId}`, payload, {
            withCredentials: true
        })
    });
    dispatch(showMessage({ message: 'Successfully Submitted Quote', status: 'Positive' }));
};

export const acceptLogisticSchedule = (orderId, payload) => async (dispatch, getState) => {
    const userId = getState().userInfo.bp_id;
    payload['userId'] = userId;
    await dispatch({
        type: ACCEPT_LOGISTIC_SCHEDULE,
        payload: http.post(`${API_BASE_URL}order/acceptLogistics/${orderId}`, payload, {
            withCredentials: true
        })
    });
    dispatch(showMessage({ message: 'You successfully accepted the logistics schedule.', status: 'Positive' }));
};

export const getOrderList = () => async (dispatch, getState) => {
    const userId = getState().userInfo.bp_id;
    dispatch({
        type: FETCH_ORDER_LIST,
        payload: http.get(API_BASE_URL + `order/getRequestedOrder/${userId}`, {
            withCredentials: true
        })
    });
};

export const getOrderHeaderData = (orderId) => async (dispatch) => {
    dispatch({
        type: FETCH_ORDER_HEADER_DATA,
        payload: http.get(`${API_BASE_URL}order/getOrderHeaderData/${orderId}`, {
            withCredentials: true
        })
    });
};

export const getOrderItemsGradeList = (orderId, quoteId) => async (dispatch, getState) => {
    try {
        const response = await http.get(`${API_BASE_URL}order/quotation/refurbish/grading/${orderId}/${quoteId}`, {
            withCredentials: true
        });
        return Promise.resolve(response.data);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showErrorMessage(errorMessage));
        return Promise.reject(error);
    }
};

export const saveAssetGradeList = (orderId, quoteId, payload) => async (dispatch, getState) => {
    try {
        const url = `${API_BASE_URL}order/quotation/refurbish/grading/${orderId}/${quoteId}`;
        const response = await http.post(url, payload, {
            withCredentials: true
        });
        dispatch(showMessage({ message: `Successfully saved Asset grading changes`, status: 'Positive' }));
        return Promise.resolve(response.data);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showErrorMessage(errorMessage));
        return Promise.reject(error);
    }
};

export const getOrderQuoteDetails = (orderId, quoteId, projection) => async (dispatch, getState) => {
    try {
        const response = await http.get(`${API_BASE_URL}order/quotation/${orderId}/${quoteId}`, {
            params: { projection },
            withCredentials: true
        });
        return Promise.resolve(response.data);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showErrorMessage(errorMessage));
        return Promise.reject(error);
    }
};

export const updateOrderQuote = (orderId, quoteId, payload) => async (dispatch, getState) => {
    try {
        const response = await http.post(`${API_BASE_URL}order/quotation/${orderId}/${quoteId}`, payload, {
            withCredentials: true
        });
        dispatch(showMessage({ message: `Successfully saved Asset grading comments`, status: 'Positive' }));
        return Promise.resolve(response.data);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showErrorMessage(errorMessage));
        return Promise.reject(error);
    }
};

export const submitAssetGrading = (orderId, quoteId) => async (dispatch, getState) => {
    try {
        const url = `${API_BASE_URL}order/quotation/refurbish/grading/${orderId}/${quoteId}/submit`;
        const response = await http.post(url, {}, {
            withCredentials: true
        });
        dispatch(showMessage({
            message: `Asset verification and grading was successfuly submited to the customer. Next process
             steps will be enabled when they reply.`,
            status: 'Positive'
        }));
        return Promise.resolve(response.data);
    } catch (error) {
        const errorMessage = getErrorMessage(error);
        dispatch(showErrorMessage(errorMessage));
        return Promise.reject(error);
    }
};
