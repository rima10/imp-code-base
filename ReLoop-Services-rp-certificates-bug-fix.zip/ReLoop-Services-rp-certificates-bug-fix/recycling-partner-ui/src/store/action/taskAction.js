import { setUserInfo, loadInProgress, loadCompleted, setNotificationsInfo } from '../actionType';
import { getToken } from '../../utils/authUtils';
import http from '../../utils/httpService';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;

export const validateUser = (tokenObj) => async (dispatch, getState) => {
    try {
        const isLoggedIn = getState().userInfo.isLoggedIn;
        if (!isLoggedIn) {
            dispatch(loadInProgress());
            let params = {
                withCredentials: true
            };
            if (tokenObj) {
                params.headers = {
                    authorization: 'Bearer ' + tokenObj.idToken,
                    refresh: tokenObj.refreshToken
                };
            }
            const response = await http.post(API_BASE_URL + 'auth/validate?app=rp', null, params);
            const cognitoId = response.data.cognitoId;
            const userData = await http.get(API_BASE_URL + `user/getUserData/${cognitoId}?bp=rp`, {
                withCredentials: true
            });
            userData.data['cognitoId'] = cognitoId;
            dispatch(setUserInfo(userData.data, true));
            dispatch(loadCompleted());
        }
    } catch (error) {
        dispatch(setUserInfo(null, false));
        dispatch(loadCompleted());
    }
};

export const getAccessToken = () => async (dispatch, getState) => {
    const tokenObj = await getToken();
    await validateUser(tokenObj)(dispatch, getState);
};

export const getNotificationInfo = () => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.bp_id;
        const notifications = await http.get(`${API_BASE_URL}notification/getNotifications/${userId}?$skip=0&top=5`, {
            withCredentials: true
        });
        dispatch(setNotificationsInfo(notifications.data));
    } catch (error) {
        console.log(error);
    }
};

export const readNotification = (bpNotificationId) => async (dispatch, getState) => {
    try {
        await http.post(`${API_BASE_URL}notification/readNotification/${bpNotificationId}`, null, {
            withCredentials: true
        });
        dispatch(getNotificationInfo()(dispatch, getState));
    } catch (error) {
        console.log(error);
    }
};

export const getUserData = () => async (dispatch, getState) => {
    try {
        const cognitoId = getState().userInfo.cognitoId;
        const userData = await http.get(API_BASE_URL + `user/getUserData/${cognitoId}?bp=rp`, {
            withCredentials: true
        });
        dispatch(setUserInfo(userData.data, true));
    } catch (error) {
        console.log(error);
    }
};
