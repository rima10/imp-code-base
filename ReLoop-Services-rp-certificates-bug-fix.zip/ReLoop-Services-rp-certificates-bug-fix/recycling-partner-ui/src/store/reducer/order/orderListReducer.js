import { FETCH_ORDER_LIST } from '../../actionType';
import { ActionType } from 'redux-promise-middleware';

const initialState = {
    isLoading: false,
    errMsg: null,
    data: []
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_ORDER_LIST}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${FETCH_ORDER_LIST}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: payload.data };

        case `${FETCH_ORDER_LIST}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: [] };

        default:
            return state;
    }
};
