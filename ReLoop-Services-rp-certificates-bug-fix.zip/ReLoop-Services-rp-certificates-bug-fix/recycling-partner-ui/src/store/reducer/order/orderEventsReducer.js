import { SUBMIT_FIRST_LEVEL_QUOTE, ACCEPT_LOGISTIC_SCHEDULE } from '../../actionType';
import { ActionType } from 'redux-promise-middleware';

const initialState = {
    isLoading: false
};

export default (state = initialState, action) => {
    const { type } = action;
    switch (type) {
        case `${SUBMIT_FIRST_LEVEL_QUOTE}_${ActionType.Pending}`:
        case `${ACCEPT_LOGISTIC_SCHEDULE}_${ActionType.Pending}`:
            return { ...state, isLoading: true };

        case `${SUBMIT_FIRST_LEVEL_QUOTE}_${ActionType.Fulfilled}`:
        case `${ACCEPT_LOGISTIC_SCHEDULE}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false };

        case `${SUBMIT_FIRST_LEVEL_QUOTE}_${ActionType.Rejected}`:
        case `${ACCEPT_LOGISTIC_SCHEDULE}_${ActionType.Rejected}`:
            return { ...state, isLoading: false };

        default:
            return state;
    }
};
