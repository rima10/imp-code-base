import { SET_LOAD_IN_PROGRESS, SET_LOAD_COMPLETED } from '../actionType';

export default (state = true, action) => {
    const { type } = action;
    switch (type) {
        case SET_LOAD_IN_PROGRESS:
            return true;

        case SET_LOAD_COMPLETED:
            return false;

        default:
            return state;
    }
};
