import { FETCH_SERVICE_LOCATION, CREATE_SERVICE_LOCATION, DELETE_SERVICE_LOCATION } from '../../actionType';
import { ActionType } from 'redux-promise-middleware';

const initialState = {
    isLoading: false,
    errMsg: null,
    data: []
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_SERVICE_LOCATION}_${ActionType.Pending}`:
        case `${CREATE_SERVICE_LOCATION}_${ActionType.Pending}`:
        case `${DELETE_SERVICE_LOCATION}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${FETCH_SERVICE_LOCATION}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: payload.data };

        case `${FETCH_SERVICE_LOCATION}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: [] };

        case `${CREATE_SERVICE_LOCATION}_${ActionType.Rejected}`:
        case `${DELETE_SERVICE_LOCATION}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload };

        default:
            return state;
    }
};
