import { FETCH_BP_NETWORK_INFO, CREATE_BP_NETWORK_INFO, DELETE_BP_NETWORK_INFO } from '../../actionType';
import { ActionType } from 'redux-promise-middleware';

const initialState = {
    isLoading: false,
    errMsg: null,
    data: []
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${FETCH_BP_NETWORK_INFO}_${ActionType.Pending}`:
        case `${CREATE_BP_NETWORK_INFO}_${ActionType.Pending}`:
        case `${DELETE_BP_NETWORK_INFO}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };

        case `${FETCH_BP_NETWORK_INFO}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: payload.data };

        case `${FETCH_BP_NETWORK_INFO}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: [] };

        case `${CREATE_BP_NETWORK_INFO}_${ActionType.Rejected}`:
        case `${DELETE_BP_NETWORK_INFO}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload };

        default:
            return state;
    }
};
