import { POST_CERTIFICATES, GET_CERTIFICATES, DOWNLOAD_CERTIFICATE } from '../../actionType';
import { ActionType } from 'redux-promise-middleware';

const initialState = {
    isLoading: false,
    errMsg: null,
    data: []
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case `${POST_CERTIFICATES}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };
        case `${POST_CERTIFICATES}_${ActionType.Fulfilled}`:
            const updatedData = [...state.data];
            if (payload && payload.data) {
                payload.data.forEach((item) => {
                    var existsIndex = updatedData.findIndex((i) => i.certificateId === item.certificateId);
                    if (existsIndex === -1) {
                        updatedData.push(item);
                    } else {
                        updatedData[existsIndex] = item;
                    }
                });
            }
            return { ...state, isLoading: false, errMsg: null, data: [...updatedData] };
        case `${POST_CERTIFICATES}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload };
        case `${GET_CERTIFICATES}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null, data: [] };
        case `${GET_CERTIFICATES}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null, data: payload.data };
        case `${GET_CERTIFICATES}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload, data: [] };
        case `${DOWNLOAD_CERTIFICATE}_${ActionType.Pending}`:
            return { ...state, isLoading: true, errMsg: null };
        case `${DOWNLOAD_CERTIFICATE}_${ActionType.Fulfilled}`:
            return { ...state, isLoading: false, errMsg: null };
        case `${DOWNLOAD_CERTIFICATE}_${ActionType.Rejected}`:
            return { ...state, isLoading: false, errMsg: payload };
        default:
            return state;
    }
};
