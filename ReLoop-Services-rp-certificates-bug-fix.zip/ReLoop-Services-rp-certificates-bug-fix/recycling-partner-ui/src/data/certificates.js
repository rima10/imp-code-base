export const certificateTypes = [
    {
        value: '1',
        text: 'State Pollution Control Board Authorization',
        visibleInputFields: ['certificateType', 'certificateFile', 'validPeriod', 'authorizationNumber',
            'recyclingCapacity', 'issuedDate'],
        required: true
    },
    {
        value: '2',
        text: 'Authorization under Hazardous & Other Wastes',
        visibleInputFields: ['certificateType', 'certificateFile', 'validPeriod'],
        required: true
    },
    {
        value: '3',
        text: 'Other Certificate',
        visibleInputFields: ['certificateType', 'certificateFile', 'validPeriod', 'certificateName'],
        required: false
    }
];
