import React from 'react';
import PropTypes from 'prop-types';
import { Wizard, WizardStep } from '@ui5/webcomponents-react';
import BusinessProfileStep from './BusinessProfile';
import ServiceLocation from './ServiceLocation';
import UploadCerificate from './UploadCertificate';
import PrivateNetworkStep from './PrivateNetwork';

const BusinessProfileWizard = ({ steps, onNextClick }) => {
    const getContent = (id) => {
        if (parseInt(id, 10) > steps.length) {
            return;
        }
        switch (id) {
            case '1':
                return <BusinessProfileStep onNextClick={onNextClick} />;
            case '2':
                return <ServiceLocation onNextClick={onNextClick} />;
            case '3':
                return <UploadCerificate onNextClick={onNextClick} />;
            case '4':
                return <PrivateNetworkStep />;
        }
    };

    return (
        <>
            <Wizard style={{ height: 'fit-content' }}>
                {Object.keys(steps).map((idx) => {
                    return (
                        <WizardStep
                            branching={false}
                            titleText={steps[idx].name}
                            selected={steps[idx].selected}
                            disabled={steps[idx].disabled}
                            key={idx}
                        >
                            {steps[idx].selected ? getContent(idx) : null}
                        </WizardStep>
                    );
                })}
            </Wizard>
        </>
    );
};

BusinessProfileWizard.propTypes = {
    steps: PropTypes.object,
    onNextClick: PropTypes.func
};
BusinessProfileWizard.defaultProps = {
    steps: []
};

export default BusinessProfileWizard;
