import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { SideNavigation, SideNavigationItem, SideNavigationSubItem } from '@ui5/webcomponents-react';
import { withRouter } from 'react-router-dom';
import { getUserInfo } from '../../selectors/common';
import { isEmpty } from '../../validation/common';

class NavBar extends Component {
    constructor (props) {
        super(props);
        this.state = {
            activePath: '/',
            accountItems: [
                {
                    path: '/account/businessInfo' /* path is used as id to check which NavItem is active basically */,
                    name: 'Business Information',
                    // eslint-disable-next-line max-len
                    key: 'accountKey1' /* Key is required, else console throws error. Does this please you Mr. Browser?! */,
                    icon: 'business-card'
                },
                {
                    path: '/account/serviceLocationInfo',
                    name: 'Service Locations',
                    key: 'accountKey2',
                    icon: 'cancel-share'
                },
                {
                    path: '/account/certificatesInfo',
                    name: 'Certificates',
                    key: 'accountKey3',
                    icon: 'documents'
                }
            ],
            OrderManagement: [
                {
                    path: '/order',
                    name: 'Orders List',
                    key: 'orderKey1',
                    icon: 'cancel-share'
                }
            ]
        };
    }
    componentDidMount () {
        if (isEmpty(this.props.userInfo.isPartOfPvtNwk) || this.props.userInfo.isPartOfPvtNwk === false) {
            this.setState({
                accountItems: [
                    ...this.state.accountItems,
                    {
                        path: '/account/privateNetworkInfo',
                        name: 'Private Network',
                        key: 'accountKey4',
                        icon: 'add-activity'
                    }
                ]
            });
        }
    }
    onSelectionChange = (event) => {
        this.setState({ activePath: event.detail.item.getAttribute('path') });
        let path = event.detail.item.getAttribute('path');
        this.props.history.push(`${path}`);
    };
    render () {
        const { accountItems, activePath, OrderManagement } = this.state;
        return (
            <>
                <SideNavigation
                    style={{ position: 'fixed', top: '0', marginTop: '44px', bottom: '0' }}
                    slot=""
                    onSelectionChange={this.onSelectionChange}
                    collapsed={this.props.isCollapsed}
                >
                    <SideNavigationItem path="#" text="Account Management" icon="sap-icon://account">
                        {accountItems.map((item) => (
                            /* Return however many NavItems in array to be rendered */
                            <SideNavigationSubItem
                                id={item.key}
                                path={item.path}
                                text={item.name}
                                active={item.path === activePath}
                                key={item.key}
                                icon={item.icon}
                            />
                        ))}
                    </SideNavigationItem>
                    <SideNavigationItem path="#" text="Order Management" icon="sap-icon://sales-order-item">
                        {OrderManagement.map((item) => (
                            /* Return however many NavItems in array to be rendered */
                            <SideNavigationSubItem
                                id={item.key}
                                path={item.path}
                                text={item.name}
                                active={item.path === activePath}
                                key={item.key}
                                icon={item.icon}
                            />
                        ))}
                    </SideNavigationItem>
                </SideNavigation>
            </>
        );
    }
}

NavBar.propTypes = {
    isCollapsed: PropTypes.bool,
    history: PropTypes.object,
    userInfo: PropTypes.object
};

const mapStateToProps = (state) => {
    return {
        userInfo: getUserInfo(state)
    };
};

export default withRouter(connect(mapStateToProps)(NavBar));
