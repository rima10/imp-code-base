import React, { useState } from 'react';
import { Card, CardHeader } from '@ui5/webcomponents-react';
import BusinessProfileWorkflow from './BusinessProfileWorkflow';
import SetupProfile from './SetupProfile';

const Home = () => {
    const [isHidden, setIsHidden] = useState(true);
    return (
        <>
            <Card header={<CardHeader titleText="Home" />} />
            {isHidden ? <SetupProfile toggleHidden={() => setIsHidden()} /> : <BusinessProfileWorkflow />}
        </>
    );
};

export default Home;
