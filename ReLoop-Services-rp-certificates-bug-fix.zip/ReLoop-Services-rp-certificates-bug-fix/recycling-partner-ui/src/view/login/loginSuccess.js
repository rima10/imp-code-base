import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import { getAccessToken } from '../../store/action/taskAction';
import LoadingIndicator from '../common/Loading';

const LoginSuccess = ({ userInfo, isLoading = true, startGetAccessToken }) => {
    useEffect(() => {
        startGetAccessToken();
    }, []);

    const authFailedMessage = <div>Authentication Failed</div>;

    const redirect = (isInitialSetupDone) => {
        return isInitialSetupDone ? (
            <Redirect to="/order" />
        ) : (
            <Redirect to="/" />
        );
    };

    if (isLoading) {
        return <LoadingIndicator />;
    } else {
        const isInitialSetupDone = userInfo.isBusinessDataPresent;
        return userInfo.isLoggedIn ? redirect(isInitialSetupDone) : authFailedMessage;
    }
};

const mapStateToProps = (state) => {
    return {
        isLoading: state.isLoading,
        userInfo: state.userInfo
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetAccessToken: () => dispatch(getAccessToken())
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(LoginSuccess);
