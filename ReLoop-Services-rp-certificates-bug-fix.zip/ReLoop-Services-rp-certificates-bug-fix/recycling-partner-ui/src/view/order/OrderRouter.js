import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { Route, Switch, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import PrivateRoute from '../login/PrivateRoute';
import LoginSuccess from '../login/loginSuccess';
import ErrorComponent from '../common/Error';
import { getOrderList } from '../../store/action/order';
import OrderHome from './OrderHome';
import OrderContainer from './OrderContainer';

const OrderRouter = ({ startGetOrderList }) => {
    useEffect(() => {
        startGetOrderList();
    }, []);

    return (
        <Switch>
            <Route path="/loginSuccessful">
                <LoginSuccess />
            </Route>
            <PrivateRoute path="/order/:orderNumber" component={OrderContainer} />
            <PrivateRoute exact path="/order" component={OrderHome} />
            <PrivateRoute exact path="/404" component={() => <ErrorComponent text="Page Not Found" />} />
            <Redirect from="/" to="/404" />
        </Switch>
    );
};

const mapStateToProps = () => {
    return {};
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetOrderList: () => dispatch(getOrderList())
    };
};

OrderRouter.propTypes = {
    startGetOrderList: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderRouter);
