import React, { useState, useEffect } from 'react';
import OrderWizard from './OrderWizard';

const OrderWizardContainer = ({}) => {
    const [steps, setSteps] = useState({});

    useEffect(() => {
        const defaultSteps = {
            1: {
                name: 'Order Detail',
                selected: true,
                disabled: false
            },
            2: {
                name: 'Onsite Visit',
                selected: false,
                disabled: true
            },
            3: {
                name: 'Asset Verification & Grading',
                selected: false,
                disabled: true
            },
            4: {
                name: 'Logistics',
                selected: false,
                disabled: true
            }
        };
        setSteps(defaultSteps);
    }, []);

    return <OrderWizard steps={steps} />;
};

export default OrderWizardContainer;
