import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Grid, Label, Input, Text, Panel, Toolbar, Bar, Button } from '@ui5/webcomponents-react';
import AccountTable from '../../common/Table';
import { spacing } from '@ui5/webcomponents-react-base';
import { camelCaseToSentence } from '../../../utils/formatter';
import { acceptLogisticSchedule } from '../../../store/action/order';
import OrderHeader from './OrderHeader';
import LoadingIndicator from '../../common/Loading';
import { getOrderHeaderDataState, isAcceptLogisticsScheduleLoading } from '../../../selectors/common';
import validateInput from '../../../validation/LogisticsData';
import AssetGradingComponent from './AssetGradingComponent';

const Logistics = ({ isLoading, orderHeaderData, startAcceptLogisticSchedule }) => {
    const [rows] = useState([]);
    const columns = ['Suggested Date', 'Time', 'Customer Contact', 'Phone Number'];
    const [inputBox, setInputBox] = useState({
        vehicleType: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        vehicleNumber: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        driverName: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        logisticProvider: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: false
        },
        recyclerContactName: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: false
        },
        recyclerContactNumber: {
            value: '',
            valueState: 'None',
            valueStateMessage: '',
            required: false
        }
    });

    useEffect(() => {
        // startGetOnsiteVisitDetails(orderId);
    }, []);

    const onInputChange = (event) => {
        let tempInputBox = { ...inputBox };
        let field = event.target.name;
        let { isValid, errorMessage } = validateInput(event.target.value, field, tempInputBox[field]);
        if (isValid) {
            tempInputBox[field]['value'] = event.target.value;
            tempInputBox[field]['valueState'] = 'None';
            tempInputBox[field]['valueStateMessage'] = <span>{errorMessage}</span>;
        } else {
            tempInputBox[field]['value'] = '';
            tempInputBox[field]['valueState'] = 'Error';
            tempInputBox[field]['valueStateMessage'] = <span>{errorMessage}</span>;
        }
        setInputBox(tempInputBox);
    };

    const onAcceptScheduleClick = () => {
        let isValid = true;
        let tempInputBox = { ...inputBox };
        Object.keys(tempInputBox).map((field) => {
            if (tempInputBox[field]['required'] && tempInputBox[field]['value'] === '') {
                let fieldName = '';
                fieldName = camelCaseToSentence(field);
                tempInputBox[field]['valueState'] = 'Error';
                tempInputBox[field]['valueStateMessage'] = <span>{fieldName} is required</span>;
                isValid = false;
            }
        });
        if (isValid) {
            const payload = {
                vehicleType: inputBox.vehicleType.value,
                vehicleNumber: inputBox.vehicleNumber.value,
                driverName: inputBox.driverName.value,
                logisticProvider: inputBox.logisticProvider.value,
                recyclerContactName: inputBox.recyclerContactName.value,
                recyclerContactNumber: inputBox.recyclerContactNumber.value
            };
            startAcceptLogisticSchedule(orderHeaderData.orderId, payload)
                .then(() => console.log('Successful'))
                .catch(() => console.log('Something went wrong!'));
        } else {
            setInputBox(tempInputBox);
        }
    };

    if (isLoading) {
        return <LoadingIndicator />;
    }
    return (
        <>
            <Panel headerText="Order Details" collapsed>
                <OrderHeader />
            </Panel>
            <AssetGradingComponent />
            <Panel headerText="Logistic Details">
                <AccountTable columns={columns} rows={rows} />
                <Toolbar style={{ ...spacing.sapUiSmallMarginTop }}>
                    <Text>Additional Logistics Information</Text>
                </Toolbar>
                <Text style={{ ...spacing.sapUiTinyMarginTop }}>
                    In order to create additional documents (i.e. e-way bill etc.) please provide the mandatory
                    information below.
                </Text>
                <Grid style={spacing.sapUiLargeMarginTop}>
                    <div data-layout-span="XL4 L4 M4 S4">
                        <Label required style={{ display: 'block', marginTop: '1rem' }}>
                            Vehicle Type
                        </Label>
                        <Input
                            id="vehicleType"
                            name="vehicleType"
                            value={inputBox.vehicleType.value}
                            valueState={inputBox.vehicleType.valueState}
                            valueStateMessage={inputBox.vehicleType.valueStateMessage}
                            onInput={(e) => onInputChange(e)}
                            style={{ width: '80%' }}
                        />
                        <Label required style={{ display: 'block', marginTop: '1rem' }}>
                            Vehicle Number
                        </Label>
                        <Input
                            id="vehicleNumber"
                            name="vehicleNumber"
                            value={inputBox.vehicleNumber.value}
                            valueState={inputBox.vehicleNumber.valueState}
                            valueStateMessage={inputBox.vehicleNumber.valueStateMessage}
                            onInput={(e) => onInputChange(e)}
                            style={{ width: '80%' }}
                        />
                    </div>
                    <div data-layout-span="XL4 L4 M4 S4">
                        <Label required style={{ display: 'block', marginTop: '1rem' }}>
                            Driver Name
                        </Label>
                        <Input
                            id="driverName"
                            name="driverName"
                            value={inputBox.driverName.value}
                            valueState={inputBox.driverName.valueState}
                            valueStateMessage={inputBox.driverName.valueStateMessage}
                            onInput={(e) => onInputChange(e)}
                            style={{ width: '80%' }}
                        />
                        <Label style={{ display: 'block', marginTop: '1rem' }}>Logistic Provider</Label>
                        <Input
                            id="logisticProvider"
                            name="logisticProvider"
                            value={inputBox.logisticProvider.value}
                            valueState={inputBox.logisticProvider.valueState}
                            valueStateMessage={inputBox.logisticProvider.valueStateMessage}
                            onInput={(e) => onInputChange(e)}
                            style={{ width: '80%' }}
                        />
                    </div>
                    <div data-layout-span="XL4 L4 M4 S4">
                        <Label style={{ display: 'block', marginTop: '1rem' }}>Recycler Contact Name</Label>
                        <Input
                            id="recyclerContactName"
                            name="recyclerContactName"
                            value={inputBox.recyclerContactName.value}
                            valueState={inputBox.recyclerContactName.valueState}
                            valueStateMessage={inputBox.recyclerContactName.valueStateMessage}
                            onInput={(e) => onInputChange(e)}
                            style={{ width: '80%' }}
                        />
                        <Label style={{ display: 'block', marginTop: '1rem' }}>Recycler Contact Number</Label>
                        <Input
                            id="recyclerContactNumber"
                            name="recyclerContactNumber"
                            value={inputBox.recyclerContactNumber.value}
                            valueState={inputBox.recyclerContactNumber.valueState}
                            valueStateMessage={inputBox.recyclerContactNumber.valueStateMessage}
                            onInput={(e) => onInputChange(e)}
                            style={{ width: '80%' }}
                        />
                    </div>
                </Grid>
                <Bar
                    style={{ ...spacing.sapUiLargeMarginTop }}
                    design="FloatingFooter"
                    endContent={
                        <Button design="Emphasized" onClick={onAcceptScheduleClick}>
                            Accept Schedule
                        </Button>
                    }
                />
            </Panel>
        </>
    );
};

const mapStateToProps = (state) => {
    return {
        isLoading: isAcceptLogisticsScheduleLoading(state),
        orderHeaderData: getOrderHeaderDataState(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startAcceptLogisticSchedule: async (orderId, payload) => dispatch(acceptLogisticSchedule(orderId, payload))
    };
};

Logistics.propTypes = {
    startAcceptLogisticSchedule: PropTypes.func,
    isLoading: PropTypes.bool,
    orderHeaderData: PropTypes.object
};

export default connect(mapStateToProps, mapDispatchToProps)(Logistics);
