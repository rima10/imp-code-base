import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Form, FormItem, Text, Title } from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';

const OrderHeader = ({ orderHeaderData }) => {
    const modifyDate = () => {
        if (orderHeaderData) {
            let newDate = new Date(orderHeaderData.submissionDeadline);
            newDate = newDate.toDateString();
            return newDate;
        }
        return '';
    };

    return (
        <>
            <Title level="H3" style={{ ...spacing.sapUiMediumMarginTopBottom }}>
                Order Details
            </Title>
            <Form columnsL={3} columnsM={3} columnsS={3} labelSpanM={5} style={{ ...spacing.sapUiLargeMarginBottom }}>
                <FormItem label="Category">
                    <Text>{orderHeaderData.category}</Text>
                </FormItem>
                <FormItem label="Private / Public Network">
                    <Text>{orderHeaderData.orderNetwork}</Text>
                </FormItem>
                <FormItem label="Area">
                    <Text>{orderHeaderData.locCity + ', ' + orderHeaderData.locState} </Text>
                </FormItem>
                <FormItem label="Subcategory">
                    <Text>{orderHeaderData.subCategory}</Text>
                </FormItem>
                <FormItem label="Additional Information">
                    <Text>
                        {orderHeaderData.additionalInfo == null ? 'No Information' : orderHeaderData.additionalInfo}
                    </Text>
                </FormItem>
                <FormItem label="PIN Code">
                    <Text>{orderHeaderData.locPincode}</Text>
                </FormItem>
                <FormItem label="Quote Submission Deadline">
                    <Text>{modifyDate()}</Text>
                </FormItem>
                <FormItem label="Picture">
                    <Text>{orderHeaderData.pictureLoc == null ? 'No pictures' : orderHeaderData.pictureLoc}</Text>
                </FormItem>
                <FormItem label="Address">
                    <Text>{orderHeaderData.locDetails}</Text>
                </FormItem>
            </Form>
        </>
    );
};

const mapStateToProps = (state) => {
    return {
        orderHeaderData: state.order.orderHeaderData.data
    };
};

const mapDispatchToProps = () => {
    return {};
};

OrderHeader.propTypes = {
    orderHeaderData: PropTypes.object
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderHeader);
