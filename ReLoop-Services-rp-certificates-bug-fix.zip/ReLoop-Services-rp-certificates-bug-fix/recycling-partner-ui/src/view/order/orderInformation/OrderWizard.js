import React from 'react';
import PropTypes from 'prop-types';
import { Wizard, WizardStep, Toolbar } from '@ui5/webcomponents-react';
import OrderDetailStep from './OrderDetailStep';
import LogisticsStep from './LogisticsStep';
import AssetGradingComponent from './AssetGradingComponent';

const OrderWizard = ({ steps }) => {
    const getStepContent = (step) => {
        switch (step) {
            case '1':
                return <OrderDetailStep />;
            case '2':
                return <LogisticsStep />;
            case '3':
                return <AssetGradingComponent />;
            case '4':
                return <LogisticsStep />;
            default:
                return 'Unknown step';
        }
    };

    return (
        <Wizard style={{ height: '100%' }}>
            {Object.keys(steps).map((idx) => {
                return (
                    <WizardStep
                        heading={steps[idx].name}
                        selected={steps[idx].selected}
                        disabled={steps[idx].disabled}
                        key={idx}
                    >
                        {getStepContent(idx)}
                        {idx === '4' ? null : <Toolbar />}
                    </WizardStep>
                );
            })}
        </Wizard>
    );
};

OrderWizard.propTypes = {
    steps: PropTypes.object
};

OrderWizard.defaultProps = {
    steps: {}
};

export default OrderWizard;
