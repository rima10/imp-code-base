import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import {
    Button,
    FlexBox,
    Text,
    Input,
    Bar,
    Title,
    TextArea,
    Table,
    TableColumn,
    TableCell,
    TableRow,
    Label
} from '@ui5/webcomponents-react';
import { useParams } from 'react-router-dom';
import OrderHeader from './OrderHeader';
import { getConsolidatedOrderItemInfo, submitFirstLevelQuote } from '../../../store/action/order';
import {
    getOrderList,
    getOrderHeaderDataState,
    getConsolidatedOrderItemsState,
    isSubmitFirstLevelQuoteLoading
} from '../../../selectors/common';
import LoadingIndicator from '../../common/Loading';

const OrderDetailStep = ({
    orderList,
    orderHeaderData,
    consolidatedOrderItems,
    startGetConsolidatedOrderItemInfo,
    startSubmitFirstLevelQuote,
    isLoading
}) => {
    const { orderNumber } = useParams();
    const [isEditMode, setEditMode] = useState(0);
    const [isEditModeComments, setEditModeComments] = useState(0);
    const [order, setOrder] = useState([]);

    useEffect(() => {
        if (orderList && orderList.length > 0) {
            // eslint-disable-next-line eqeqeq
            let order = orderList.find((order) => order.order_no == orderNumber);
            let id = order.order_id;
            startGetConsolidatedOrderItemInfo(id);
        }
    }, [orderList]);

    useEffect(() => {
        setOrder(consolidatedOrderItems);
    }, [consolidatedOrderItems]);

    const submitQuote = () => {
        let payload = { orderId: order.orderId, orderItems: order.orderItems, quoteComments: order.comment };
        startSubmitFirstLevelQuote(payload);
    };

    const onPriceChange = (event, index) => {
        let newOrder = { ...order };
        newOrder.orderItems[index].price = parseInt(event.target.value, 10);
        if (index !== 0) {
            newOrder.orderItems[index].finalPrice =
                newOrder.orderItems[index - 1].finalPrice +
                newOrder.orderItems[index].count * parseInt(event.target.value, 10);
        } else {
            newOrder.orderItems[index].finalPrice = parseInt(event.target.value, 10);
        }
        newOrder.finalPrice = newOrder.orderItems[index].finalPrice;
        setOrder(newOrder);
    };

    const onSubmitComment = (event) => {
        let newOrder = { ...order };
        newOrder.comment = event.target.value;
        setOrder(newOrder);
    };

    if (isLoading) {
        return <LoadingIndicator />;
    }
    return (
        <>
            <OrderHeader />
            <FlexBox direction="Row">
                <Title style={{ margin: '20px' }}>{'Asset List (' + orderHeaderData.itemsCount + ')'}</Title>
                <Button
                    style={{ position: 'absolute', right: '0', marginRight: '20px' }}
                    design="Transparent"
                    onClick={() => {
                        if (isEditMode === 0) {
                            setEditMode(1);
                        } else {
                            setEditMode(0);
                        }
                    }}
                >
                    {isEditMode ? 'Save' : 'Edit'}
                </Button>
            </FlexBox>
            <Table
                columns={
                    <>
                        <TableColumn style={{ width: '12rem' }}>
                            <Label>Category</Label>
                        </TableColumn>
                        <TableColumn minWidth={800} popinText="Supplier">
                            <Label>Make</Label>
                        </TableColumn>
                        <TableColumn demandPopin minWidth={600} popinText="Dimensions">
                            <Label>Model</Label>
                        </TableColumn>
                        <TableColumn demandPopin minWidth={600} popinText="Weight">
                            <Label>Quantity</Label>
                        </TableColumn>
                        <TableColumn>
                            <Label>Initial Price per Item (INR)</Label>
                        </TableColumn>
                        <TableColumn>
                            <Label>Total Price (INR)</Label>
                        </TableColumn>
                    </>
                }
            >
                {consolidatedOrderItems.orderItems &&
                    consolidatedOrderItems.orderItems.map((order, index) => (
                        <TableRow key={index}>
                            <TableCell>
                                <Text>{order.itemType}</Text>
                            </TableCell>
                            <TableCell>
                                <Text>{order.make}</Text>
                            </TableCell>
                            <TableCell>
                                <Text>{order.model}</Text>
                            </TableCell>
                            <TableCell>
                                <Text id={'countLabel' + index}>{order.count}</Text>
                            </TableCell>
                            <TableCell>
                                {isEditMode ? (
                                    <Input
                                        style={{ height: '20%' }}
                                        id={'initialPrice' + index}
                                        value={order.price}
                                        onChange={(e) => onPriceChange(e, index)}
                                    />
                                ) : (
                                    <Text id={'initialPriceLabel' + index}>{order.price}</Text>
                                )}
                            </TableCell>
                            <TableCell>
                                <Text id={'totalAmountLabel' + index}>
                                    {order && order.price ? order.price * order.count : ' '}
                                </Text>
                            </TableCell>
                        </TableRow>
                    ))}
            </Table>
            <Bar
                endContent={
                    <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                        {order && order.finalPrice ? order.finalPrice : ' '}
                    </Label>
                }
                startContent={<Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>Total Price </Label>}
                style={{ background: '#f2f2f2' }}
            />
            <FlexBox direction="Row">
                <Title style={{ margin: '20px' }}>Additional Comment</Title>
                <Button
                    style={{ position: 'absolute', right: '0', marginRight: '20px' }}
                    design="Transparent"
                    onClick={() => {
                        if (isEditModeComments === 0) {
                            setEditModeComments(1);
                        } else {
                            setEditModeComments(0);
                        }
                    }}
                >
                    {isEditModeComments ? 'Save' : 'Edit'}
                </Button>
            </FlexBox>
            <TextArea value={order.comment} disabled={!isEditModeComments} onChange={(e) => onSubmitComment(e)} />
            <Bar
                design="FloatingFooter"
                style={{ marginTop: '30px', width: '100%', boxShadow: 'none' }}
                endContent={
                    <>
                        <Button design="Emphasized" onClick={submitQuote}>
                            Submit Quote
                        </Button>
                        <Button design="None">Cancel</Button>
                    </>
                }
            />
        </>
    );
};

const mapStateToProps = (state) => {
    return {
        orderList: getOrderList(state),
        orderHeaderData: getOrderHeaderDataState(state),
        consolidatedOrderItems: getConsolidatedOrderItemsState(state),
        isLoading: isSubmitFirstLevelQuoteLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetConsolidatedOrderItemInfo: (orderId) => dispatch(getConsolidatedOrderItemInfo(orderId)),
        startSubmitFirstLevelQuote: (payload) => dispatch(submitFirstLevelQuote(payload))
    };
};

OrderDetailStep.propTypes = {
    startGetConsolidatedOrderItemInfo: PropTypes.func,
    startSubmitFirstLevelQuote: PropTypes.func,
    orderList: PropTypes.array,
    orderHeaderData: PropTypes.object,
    consolidatedOrderItems: PropTypes.object,
    isLoading: PropTypes.bool
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderDetailStep);
