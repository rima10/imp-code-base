import React, { useState } from 'react';
import { Card, CardHeader } from '@ui5/webcomponents-react';
import OrderList from './OrderList';
import SetupOrderProfile from './SetUpOrderProfile';

const OrderHome = () => {
    const [isHidden, setIsHidden] = useState(true);
    return (
        <>
            <Card header={<CardHeader titleText="Home" />} />
            {isHidden ? <SetupOrderProfile toggleHidden={() => setIsHidden(false)} /> : <OrderList />}
        </>
    );
};

export default OrderHome;
