import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import {
    ObjectPage,
    Breadcrumbs,
    Link,
    FlexBox,
    Text,
    Title,
    ObjectPageSection,
    DynamicPageTitle,
    DynamicPageHeader,
    ObjectStatus,
    Label
} from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import { useHistory, useParams } from 'react-router-dom';
import LoadingIndicator from '../common/Loading';
import { getOrderHeaderData } from '../../store/action/order';
import {
    getOrderList,
    getOrderHeaderDataState,
    isOrderHeaderLoading,
    isOrderListLoading
} from '../../selectors/common';
import OrderWizardContainer from './orderInformation/OrderWizardContainer';

const OrderContainer = ({
    orderList,
    startGetOrderHeaderData,
    orderHeaderData,
    isOrderListLoading,
    isOrderHeaderLoading
}) => {
    const { orderNumber } = useParams();
    useEffect(() => {
        if (orderList && orderList.length > 0) {
            // eslint-disable-next-line eqeqeq
            let order = orderList.find((order) => order.order_no == orderNumber);
            let id = order.order_id;
            startGetOrderHeaderData(id);
        }
    }, [orderList]);

    const history = useHistory();

    //This function is only to manipulate the date to return the time left
    const dateManipulation = () => {
        let today = new Date();
        let deadline = new Date(orderHeaderData.submissionDeadline);
        let diff = deadline - today;
        let finalString = '';
        if (diff > 0) {
            let seconds = Math.floor(diff / 1000);
            let minutes = Math.floor(seconds / 60);
            let hours = Math.floor(minutes / 60);
            let days = Math.floor(hours / 24);
            let months = Math.floor(days / 30);
            let years = Math.floor(days / 365);
            seconds %= 60;
            minutes %= 60;
            hours %= 24;
            days %= 30;
            months %= 12;
            finalString = years ? years + 'yy' : ' ';
            finalString += ' ' + months ? months + 'm' : ' ';
            finalString += ' ' + hours ? hours + 'h' : ' ';
            finalString += ' ' + days ? days + 'd' : ' ';
            finalString += ' ' + minutes ? minutes + 'min' : ' ';
        } else {
            finalString = 'Overdue';
        }
        return finalString;
    };

    if (isOrderHeaderLoading || isOrderListLoading) {
        return <LoadingIndicator />;
    }
    return (
        <ObjectPage
            headerContent={
                <DynamicPageHeader>
                    <FlexBox alignItems="Center" wrap="Wrap">
                        <FlexBox direction="Column">
                            <Title>Customer</Title>
                            <Text style={{ fontSize: '20px', marginTop: '1rem', color: '#0099ff' }}>
                                {orderHeaderData.bpUserName}
                            </Text>
                        </FlexBox>
                        <FlexBox direction="Column" style={{ padding: '30px' }}>
                            <Title>Total Assets</Title>
                            <Label style={{ fontSize: '20px', marginTop: '1rem', color: '#009933' }}>
                                {orderHeaderData.itemsCount + ' Assets'}
                            </Label>
                        </FlexBox>
                        <FlexBox direction="Column" style={{ padding: '30px' }}>
                            <Title>Total Price</Title>
                            <Label style={{ fontSize: '20px', marginTop: '1rem' }}>
                                {/* Get total price from orderHeaderData */}
                                {/* {order && order.finalPrice ? order.finalPrice + ' INR' : '- INR'} */}- INR
                            </Label>
                        </FlexBox>
                        <FlexBox direction="Column" style={{ padding: '30px' }}>
                            <Title>Remaining Time</Title>
                            <Text style={{ fontSize: '20px', marginTop: '1rem', color: '#ff9900' }}>
                                {dateManipulation()}
                            </Text>
                        </FlexBox>
                    </FlexBox>
                </DynamicPageHeader>
            }
            headerContentPinnable
            headerTitle={
                <DynamicPageTitle
                    breadcrumbs={
                        <Breadcrumbs currentLocationText={orderNumber}>
                            <Link onClick={() => history.push(`/order`)}>Order Details</Link>
                        </Breadcrumbs>
                    }
                    heading={'Order Number ' + orderNumber}
                    // Get process Type from orderHeaderData
                    subheading="Refurbish"
                    // subheading={order && order.orderProcessType && order.orderProcessType.processTypeName}
                >
                    <ObjectStatus />
                </DynamicPageTitle>
            }
            imageShapeCircle
            selectedSectionId="orderInformation"
            showHideHeaderButton
            style={{
                height: '700px'
            }}
        >
            <ObjectPageSection aria-label="Order Information" heading="Order Information" id="orderInformation">
                <OrderWizardContainer />
            </ObjectPageSection>
            <ObjectPageSection aria-label="Order Documentation" heading="Order Documentation" id="orderDocumentation" />
        </ObjectPage>
    );
};

OrderContainer.propTypes = {
    orderList: PropTypes.array,
    orderHeaderData: PropTypes.object,
    startGetOrderHeaderData: PropTypes.func,
    isOrderListLoading: PropTypes.bool,
    isOrderHeaderLoading: PropTypes.bool
};

const mapStateToProps = (state) => {
    return {
        orderList: getOrderList(state),
        orderHeaderData: getOrderHeaderDataState(state),
        isOrderListLoading: isOrderListLoading(state),
        isOrderHeaderLoading: isOrderHeaderLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetOrderHeaderData: (orderId) => dispatch(getOrderHeaderData(orderId))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderContainer);
