import React from 'react';
import PropTypes from 'prop-types';
import { Panel, Label, List, StandardListItem } from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { getOrderList } from '../../selectors/common';
import { isOrderListLoading } from '../../selectors/common';
import LoadingIndicator from '../common/Loading';

const OrderList = ({ orderList, isLoading }) => {
    const history = useHistory();
    const onSelectionChange = (e) => {
        let orderNumber = e.detail.selectedItems[0].textContent;
        history.push(`/order/${orderNumber}`);
    };
    const getInfoState = (orderPosition) => {
        // eslint-disable-next-line eqeqeq
        if (orderPosition == 'In Progress') {
            return 'Warning';
        }
        // eslint-disable-next-line eqeqeq
        if (orderPosition == 'Completed' || orderPosition == 'Accepted') {
            return 'Success';
        }
        return 'Information';
    };
    const uniqueStatus = [
        {
            status1: 'New',
            status2: '',
            status3: ''
        },
        {
            status1: 'In Progress',
            status2: 'Accepted',
            status3: 'Waiting'
        },
        {
            status1: 'Completed',
            status2: 'Rejected',
            status3: ''
        }
    ];
    const getDescription = (createdBy, createdDate) => {
        if (createdBy && createdDate) {
            return `${createdBy} |  Received Date: ${createdDate.substring(0, 10)} `;
        }
        return 'Description';
    };
    const getDataWithSpecificStatus = (status1, status2, status3) => {
        return orderList.filter(
            (order) =>
                order.quote_status === status1 || order.quote_status === status2 || order.quote_status === status3
        );
    };

    if (isLoading) {
        return <LoadingIndicator />;
    }
    return (
        <>
            <Label style={{ fontSize: '1.3rem', fontWeight: 'Bold', marginTop: '30px', marginBottom: '20px' }}>
                Orders List
            </Label>
            {uniqueStatus.map((status, index) => {
                let data = getDataWithSpecificStatus(status.status1, status.status2, status.status3, status.status4);
                return (
                    <Panel
                        headerText={`${status.status1} Orders (${data.length})`}
                        key={index}
                        style={{ overflow: 'hidden' }}
                    >
                        <List
                            noDataText="No Previous Orders"
                            mode="SingleSelect"
                            separators="None"
                            growing="Scroll"
                            onSelectionChange={onSelectionChange}
                        >
                            {data.map((order, idx) => (
                                <StandardListItem
                                    selected={false}
                                    description={getDescription(order.created_by, order.created_date)}
                                    icon="slim-arrow-right"
                                    mode="None"
                                    iconEnd
                                    info={order.quote_status}
                                    infoState={getInfoState(order.quote_status)}
                                    key={'List' + idx}
                                    id={order.order_no}
                                >
                                    {order.order_no}
                                </StandardListItem>
                            ))}
                        </List>
                    </Panel>
                );
            })}
        </>
    );
};

OrderList.propTypes = {
    orderList: PropTypes.array,
    isLoading: PropTypes.bool
};

OrderList.defaultProps = {
    orderList: []
};

const mapStateToProps = (state) => {
    return {
        orderList: getOrderList(state),
        isLoading: isOrderListLoading(state)
    };
};

export default connect(mapStateToProps)(OrderList);
