import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Label, Input, Select, Title, Option, TextArea, Button, FlexBox } from '@ui5/webcomponents-react';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport.js';
import bg from '../../asset/images/background-image.png';
import { updateBusinessInfo } from '../../store/action/account';
import { getStates, getCities } from '../../store/action/location';
import { GST_MAXLENGTH, PHONE_LENGTH } from '../../asset/constants/constant';
import { getStatesInfo, getCitiesInfo } from '../../selectors/common';
import validateInput from '../../validation/BusinessProfile';
import { camelCaseToSentence } from '../../utils/formatter';
import { isEmpty } from '../../validation/common';

const BusinessInfoForm = ({
    startUpdateBusinessInfo,
    startGetStates,
    startGetCities,
    businessInfo,
    states,
    cities,
    onBiSave
}) => {
    const [selectedState, setSelectedState] = useState(businessInfo.location && businessInfo.location.stateId);
    const [inputBox, setInputBox] = useState({
        businessName: {
            value: businessInfo.bpUsername,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        gstin: {
            value: businessInfo.gstNumber,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        cin: {
            value: businessInfo.cin,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        pan: {
            value: businessInfo.pan,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        pincode: {
            value: businessInfo.location && businessInfo.location.pincode,
            valueState: 'None',
            valueStateMessage: '',
            required: false
        },
        phoneNumber: {
            value: businessInfo.bpPhoneNumber,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        address: {
            value: businessInfo.location && businessInfo.location.locDetails,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        state: {
            value: businessInfo.location && businessInfo.location.stateId,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        },
        city: {
            value: businessInfo.location && businessInfo.location.cityId,
            valueState: 'None',
            valueStateMessage: '',
            required: true
        }
    });

    useEffect(() => {
        startGetStates();
    }, []);

    useEffect(() => {
        if (!isEmpty(selectedState)) {
            startGetCities(selectedState);
        }
    }, [selectedState]);

    const onSelectionChange = (event) => {
        let tempInputBox = { ...inputBox };
        let field = event.target.name;
        let value = event.target.selectedOption.value;
        tempInputBox[field]['value'] = value;
        tempInputBox[field]['valueState'] = 'None';
        tempInputBox[field]['valueStateMessage'] = '';
        if (field === 'state') {
            if (!isEmpty(value)) {
                startGetCities(value);
            }
            tempInputBox['city']['value'] = '';
            setSelectedState(value);
        }
        setInputBox(tempInputBox);
    };

    const onInputChange = (event) => {
        let tempInputBox = { ...inputBox };
        let field = event.target.name;
        let { isValid, errorMessage } = validateInput(event.target.value, field, tempInputBox[field]);
        if (isValid) {
            tempInputBox[field]['value'] = event.target.value;
            tempInputBox[field]['valueState'] = 'None';
            tempInputBox[field]['valueStateMessage'] = <span>{errorMessage}</span>;
        } else {
            tempInputBox[field]['value'] = '';
            tempInputBox[field]['valueState'] = 'Error';
            tempInputBox[field]['valueStateMessage'] = <span>{errorMessage}</span>;
        }
        setInputBox(tempInputBox);
    };

    const submitBusinessInfoForm = async (event) => {
        event.preventDefault();
        let isValid = true;
        let tempInputBox = { ...inputBox };
        Object.keys(tempInputBox).map((field) => {
            if (tempInputBox[field]['required'] && tempInputBox[field]['value'] === '') {
                let fieldName = '';
                if (field === 'cin' || field === 'pan' || field === 'gstin') {
                    fieldName = field.toUpperCase();
                } else {
                    fieldName = camelCaseToSentence(field);
                }
                tempInputBox[field]['valueState'] = 'Error';
                tempInputBox[field]['valueStateMessage'] = <span>{fieldName} is required</span>;
                isValid = false;
            }
        });
        if (isValid) {
            const payload = {
                bpPhoneNumber: inputBox.phoneNumber.value,
                bpUsername: inputBox.businessName.value,
                cin: inputBox.cin.value,
                gstNumber: inputBox.gstin.value,
                pan: inputBox.pan.value,
                location: {
                    country: '1',
                    stateId: inputBox.state.value,
                    cityId: inputBox.city.value,
                    pincode: inputBox.pincode.value,
                    locDetails: inputBox.address.value
                }
            };
            startUpdateBusinessInfo(payload)
                .then(() => onBiSave())
                .catch(() => console.log('Something went wrong!'));
        } else {
            setInputBox(tempInputBox);
        }
    };

    return (
        <FlexBox alignItems="Center" direction="Column" justifyContent="SpaceBetween">
            <div style={{ backgroundImage: `url(${bg})`, width: '100%', height: '270px', textAlign: 'center' }}>
                <Title
                    style={{
                        fontSize: 'x-large',
                        textAlign: 'center',
                        marginTop: '80px',
                        color: '#000000'
                    }}
                >
                    <b>Business Information</b>
                </Title>
                <Label
                    wrappingType="Normal"
                    style={{
                        fontSize: 'large',
                        marginTop: '20px',
                        color: '#000000'
                    }}
                >
                    Please add all the additional data needed to complete your Business Profile
                </Label>
            </div>
            <FlexBox alignItems="Start" justifyContent="SpaceBetween">
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label required style={{ fontSize: 'large', marginTop: '2rem', display: 'block' }}>
                        Business Name
                    </Label>
                    <Label required style={{ fontSize: 'large', marginTop: '2rem', display: 'block' }}>
                        GSTIN
                    </Label>
                    <Label required style={{ fontSize: 'large', marginTop: '2rem', display: 'block' }}>
                        CIN Number
                    </Label>
                    <Label required style={{ fontSize: 'large', marginTop: '2rem', display: 'block' }}>
                        PAN
                    </Label>
                    <Label required style={{ fontSize: 'large', marginTop: '2rem', display: 'block' }}>
                        Phone Number
                    </Label>
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Input
                        id="businessName"
                        style={{ marginTop: '1.4rem', display: 'block' }}
                        name="businessName"
                        value={inputBox.businessName.value}
                        valueState={inputBox.businessName.valueState}
                        valueStateMessage={inputBox.businessName.valueStateMessage}
                        readonly
                    >
                        {inputBox.businessName.value}
                    </Input>
                    <Input
                        style={{ marginTop: '1.4rem', display: 'block' }}
                        name="gstin"
                        id="gstin"
                        maxlength={GST_MAXLENGTH}
                        value={inputBox.gstin.value}
                        valueState={inputBox.gstin.valueState}
                        valueStateMessage={inputBox.gstin.valueStateMessage}
                        onChange={(e) => {
                            onInputChange(e);
                        }}
                        placeholder="Enter GSTIN"
                    />
                    <Input
                        style={{ marginTop: '1.4rem', display: 'block' }}
                        id="cin"
                        name="cin"
                        value={inputBox.cin.value}
                        valueState={inputBox.cin.valueState}
                        valueStateMessage={inputBox.cin.valueStateMessage}
                        onChange={(e) => {
                            onInputChange(e);
                        }}
                        placeholder="Enter CIN Number"
                    />
                    <Input
                        style={{ marginTop: '1.4rem', display: 'block' }}
                        id="pan"
                        name="pan"
                        placeholder="Enter PAN"
                        value={inputBox.pan.value}
                        valueState={inputBox.pan.valueState}
                        valueStateMessage={inputBox.pan.valueStateMessage}
                        onChange={(e) => {
                            onInputChange(e);
                        }}
                    />
                    <Input
                        style={{ marginTop: '1.4rem', display: 'block' }}
                        id="phoneNumber"
                        name="phoneNumber"
                        placeholder="Enter phone number"
                        maxlength={PHONE_LENGTH}
                        value={inputBox.phoneNumber.value}
                        valueState={inputBox.phoneNumber.valueState}
                        valueStateMessage={inputBox.phoneNumber.valueStateMessage}
                        onChange={(e) => {
                            onInputChange(e);
                        }}
                    />
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label
                        required
                        style={{ fontSize: 'large', marginLeft: '7rem', marginTop: '2rem', display: 'block' }}
                    >
                        State
                    </Label>
                    <Label
                        required
                        style={{ fontSize: 'large', marginLeft: '7rem', marginTop: '2rem', display: 'block' }}
                    >
                        City
                    </Label>
                    <Label style={{ fontSize: 'large', marginLeft: '7rem', marginTop: '2rem', display: 'block' }}>
                        Pincode
                    </Label>
                    <Label
                        required
                        style={{ fontSize: 'large', marginLeft: '7rem', marginTop: '2rem', display: 'block' }}
                    >
                        Address
                    </Label>
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Select
                        id="state"
                        style={{ marginTop: '1.5rem', display: 'block' }}
                        name="state"
                        valueState={inputBox.state.valueState}
                        valueStateMessage={inputBox.state.valueStateMessage}
                        onChange={(e) => {
                            onSelectionChange(e);
                        }}
                    >
                        <Option id="-1" name="-" value="">
                            Select State
                        </Option>
                        {states.map((stateVal) => (
                            <Option
                                selected={stateVal.state_id === inputBox.state.value}
                                key={stateVal.state_id}
                                value={stateVal.state_id}
                            >
                                {stateVal.state_name}
                            </Option>
                        ))}
                    </Select>
                    <Select
                        style={{ marginTop: '1.5rem', display: 'block' }}
                        name="city"
                        id="city"
                        onChange={(e) => {
                            onSelectionChange(e);
                        }}
                        valueState={inputBox.city.valueState}
                        valueStateMessage={inputBox.city.valueStateMessage}
                        disabled={states.length}
                    >
                        <Option id="-1" name="-" value="">
                            Select City
                        </Option>
                        {cities[selectedState] &&
                            cities[selectedState].map((cityVal) => (
                                <Option
                                    selected={cityVal.city_id === inputBox.city.value}
                                    key={cityVal.city_id}
                                    value={cityVal.city_id}
                                >
                                    {cityVal.city_name}
                                </Option>
                            ))}
                    </Select>
                    <Input
                        style={{ marginTop: '1.5rem', display: 'block' }}
                        value={inputBox.pincode.value}
                        valueState={inputBox.pincode.valueState}
                        valueStateMessage={inputBox.pincode.valueStateMessage}
                        id="pincode"
                        name="pincode"
                        onChange={(e) => {
                            onInputChange(e);
                        }}
                        placeholder="Pincode"
                    />
                    <TextArea
                        rows={3}
                        style={{
                            width: '210px',
                            fontSize: 'medium',
                            marginTop: '1.5rem',
                            display: 'block'
                        }}
                        value={inputBox.address.value}
                        valueState={inputBox.address.valueState}
                        valueStateMessage={inputBox.address.valueStateMessage}
                        id="address"
                        name="address"
                        onChange={(e) => {
                            onInputChange(e);
                        }}
                        placeholder="Street and number, Building Name, Landmark etc."
                    />
                </FlexBox>
            </FlexBox>
            <FlexBox>
                <Button
                    design="Emphasized"
                    style={{
                        marginLeft: '45rem',
                        marginTop: '1.5rem',
                        float: 'right'
                    }}
                    onClick={submitBusinessInfoForm}
                >
                    Submit
                </Button>
            </FlexBox>
        </FlexBox>
    );
};

const mapStateToProps = (state) => {
    return {
        states: getStatesInfo(state),
        cities: getCitiesInfo(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetStates: () => dispatch(getStates()),
        startGetCities: (stateId) => dispatch(getCities(stateId)),
        startUpdateBusinessInfo: async (payload) => dispatch(updateBusinessInfo(payload))
    };
};

BusinessInfoForm.propTypes = {
    startUpdateBusinessInfo: PropTypes.func,
    startGetStates: PropTypes.func,
    startGetCities: PropTypes.func,
    businessInfo: PropTypes.object,
    states: PropTypes.array,
    cities: PropTypes.object,
    onBiSave: PropTypes.func
};

BusinessInfoForm.defaultProps = {
    businessInfo: {},
    states: [],
    cities: {}
};

export default connect(mapStateToProps, mapDispatchToProps)(BusinessInfoForm);
