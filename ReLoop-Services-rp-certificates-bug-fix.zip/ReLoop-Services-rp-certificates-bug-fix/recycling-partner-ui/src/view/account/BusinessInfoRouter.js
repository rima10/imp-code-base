import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import BusinessInfoForm from './BusinessInfoForm';
import BusinessInfoView from './BusinessInfoView';
import { getBusinessInfo } from '../../store/action/account';
import { getBusinessInfoState, isBusinessInfoLoading, getUserInfo } from '../../selectors/common';
import LoadingIndicator from '../common/Loading';

const BusinessInfo = ({ businessInfo, startGetBusinessInfo, isLoading, userInfo }) => {
    const [showBiForm, setShowBiForm] = useState(!userInfo.isBusinessDataPresent);

    useEffect(() => {
        startGetBusinessInfo();
    }, []);

    useEffect(() => {
        setShowBiForm(!userInfo.isBusinessDataPresent);
    }, [userInfo.isBusinessDataPresent]);

    const onEditClick = () => {
        setShowBiForm(true);
    };

    const onBiSave = () => {
        setShowBiForm(false);
    };

    const isBiView = !showBiForm && userInfo.isBusinessDataPresent;
    const component = isBiView ? (
        <BusinessInfoView businessInfo={businessInfo} onEditClick={onEditClick} />
    ) : (
        <BusinessInfoForm businessInfo={businessInfo} onBiSave={onBiSave} />
    );
    if (isLoading) {
        return <LoadingIndicator />;
    } else {
        return component;
    }
};

const mapStateToProps = (state) => {
    return {
        businessInfo: getBusinessInfoState(state),
        isLoading: isBusinessInfoLoading(state),
        userInfo: getUserInfo(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetBusinessInfo: () => dispatch(getBusinessInfo())
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(BusinessInfo);
