import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Label, Title } from '@ui5/webcomponents-react';
import bg from '../../asset/images/background-image.png';
import AccountTable from '../common/Table';
import { getNetworkInfo, registerBPNetworkInfo, deleteBPNetworkInfo } from '../../store/action/account';
import { getNetworkInfoState, isNetworkInfoLoading } from '../../selectors/common';
import validateInput from '../../validation/PrivateNetworkData.js';
import { camelCaseToSentence } from '../../utils/formatter';

const NetworkInfoView = ({
    startGetNetworkInfo,
    startRegisterBPNetworkInfo,
    networkInfo,
    isLoading,
    startDeleteBPNetworkInfo
}) => {
    const [rows, setRows] = useState([]);
    const [isNewRow, setIsNewRow] = useState(false);
    const [rowsToDelete, setRowsToDelete] = useState([]);

    const initializeState = () => {
        setIsNewRow(false);
        setRowsToDelete([]);
    };

    const getRowsFromNetworkInfo = () => {
        let existingRows = [...rows];
        existingRows = [];
        if (!networkInfo.length) {
            setRows([]);
        } else {
            networkInfo.map((network) => {
                existingRows.push({
                    isSelected: {
                        value: false,
                        valueState: 'None',
                        type: 'checkbox',
                        readonly: false,
                        id: network.bp_nwk_id
                    },
                    companyName: {
                        value: network.nwk_member_business_partner.bp_username,
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    },
                    contactName: {
                        value: network.nwk_member_business_partner.bp_username,
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    },
                    emailAddress: {
                        value: network.nwk_member_business_partner.bp_email_id,
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    },
                    phoneNumber: {
                        value: network.nwk_member_business_partner.bp_phone_number,
                        valueState: 'None',
                        valueStateMessage: '',
                        type: 'text'
                    }
                });
            });
            setRows(existingRows);
        }
    };

    useEffect(() => {
        startGetNetworkInfo();
    }, []);

    useEffect(() => {
        getRowsFromNetworkInfo();
        initializeState();
    }, [networkInfo]);

    const getAddedRows = () => {
        const newRows = [];
        rows.forEach((row) => {
            if ('isNewRecord' in row.isSelected) {
                newRows.push(row);
            }
        });
        return newRows;
    };

    const saveNetworkInfo = async (event) => {
        event.preventDefault();
        let isValid = true;
        let existingRows = [...rows];
        if (!existingRows.length) {
            isValid = false;
        } else {
            existingRows.map((input, idx) => {
                Object.keys(input).map((field) => {
                    if (existingRows[idx][field]['value'] === '') {
                        let fieldName = camelCaseToSentence(field);
                        existingRows[idx][field]['valueState'] = 'Error';
                        existingRows[idx][field]['valueStateMessage'] = <span>{fieldName} is required</span>;
                        isValid = false;
                    }
                });
            });
        }
        if (isValid) {
            const addedRows = getAddedRows();
            if (addedRows.length) {
                const payload = { pvtNwkMembers: [] };
                addedRows.map((row) => {
                    payload.pvtNwkMembers.push({
                        emailId: row.emailAddress.value,
                        username: row.companyName.value,
                        phoneNumber: row.phoneNumber.value
                    });
                });
                startRegisterBPNetworkInfo(payload);
            }
        } else {
            setRows(existingRows);
        }
    };

    const getRowsToBeDeleted = () => {
        const selectedRows = [];
        rows.forEach((row) => {
            if (row.isSelected.value === true) {
                selectedRows.push(row.isSelected.id);
            }
        });
        return setRowsToDelete(selectedRows);
    };

    const onInputChange = (rowIndex, field, event) => {
        let tempRows = [...rows];
        let idx = rowIndex;
        if (field === 'isSelected') {
            tempRows[idx][field]['value'] = !tempRows[idx][field]['value'];
            tempRows[idx][field]['valueState'] = 'None';
            getRowsToBeDeleted();
        } else {
            let { isValid, errorMessage } = validateInput(event.target.value, field, tempRows[idx][field]);
            if (isValid) {
                tempRows[idx][field]['value'] = event.target.value;
                tempRows[idx][field]['valueState'] = 'None';
                tempRows[idx][field]['valueStateMessage'] = <span>{errorMessage}</span>;
            } else {
                tempRows[idx][field]['value'] = '';
                tempRows[idx][field]['valueState'] = 'Error';
                tempRows[idx][field]['valueStateMessage'] = <span>{errorMessage}</span>;
            }
        }
        setRows(tempRows);
    };

    const onAddRowClick = () => {
        setIsNewRow(true);
        const existingRows = [
            ...rows,
            {
                isSelected: {
                    value: false,
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'checkbox',
                    readonly: true,
                    isNewRecord: true
                },
                companyName: {
                    value: '',
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'input'
                },
                contactName: {
                    value: '',
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'input'
                },
                emailAddress: {
                    value: '',
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'input'
                },
                phoneNumber: {
                    value: '',
                    valueState: 'None',
                    valueStateMessage: '',
                    type: 'input'
                }
            }
        ];
        setRows(existingRows);
    };

    const onCancel = async (event) => {
        event.preventDefault();
        setIsNewRow(false);
        getRowsFromNetworkInfo();
    };

    const onDeleteClick = async (event) => {
        event.preventDefault();
        if (rowsToDelete.length) {
            const payload = { pvtNetworks: [] };
            networkInfo.map((network) => {
                if (rowsToDelete.includes(network.bp_nwk_id)) {
                    payload.pvtNetworks.push({
                        recyclerId: network.nwk_member,
                        networkId: network.bp_nwk_id
                    });
                }
            });
            startDeleteBPNetworkInfo(payload);
        }
    };

    const buttons = [
        {
            name: 'Save',
            icon: 'save',
            onClick: saveNetworkInfo,
            disabled: !isNewRow
        },
        {
            name: 'Cancel',
            icon: 'decline',
            onClick: onCancel,
            disabled: !isNewRow
        },
        {
            name: 'Add',
            icon: 'add',
            onClick: onAddRowClick,
            disabled: false
        },
        {
            name: 'Delete',
            icon: 'delete',
            onClick: onDeleteClick,
            disabled: !rowsToDelete.length
        }
    ];

    const columns = ['', 'Company Name', 'Contact Name', 'Email Address', 'Phone Number'];

    return (
        <div style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ backgroundImage: `url(${bg})`, width: '100%', height: '270px', textAlign: 'center' }}>
                <Title
                    style={{
                        fontSize: 'x-large',
                        textAlign: 'center',
                        marginTop: '80px',
                        color: '#000000'
                    }}
                >
                    <b>Private Network</b>
                </Title>
                <Label
                    wrappingType="Normal"
                    style={{
                        fontSize: 'large',
                        textAlign: 'center',
                        marginTop: '20px',
                        color: '#000000'
                    }}
                >
                    Set your Private Network adding all the vendors you are currently working with
                </Label>
            </div>
            <AccountTable
                isLoading={isLoading}
                buttons={buttons}
                columns={columns}
                rows={rows}
                onInputChange={onInputChange}
            />
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        networkInfo: getNetworkInfoState(state),
        isLoading: isNetworkInfoLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetNetworkInfo: () => dispatch(getNetworkInfo()),
        startRegisterBPNetworkInfo: (payload) => dispatch(registerBPNetworkInfo(payload)),
        startDeleteBPNetworkInfo: (payload) => dispatch(deleteBPNetworkInfo(payload))
    };
};

NetworkInfoView.propTypes = {
    startGetNetworkInfo: PropTypes.func,
    startRegisterBPNetworkInfo: PropTypes.func,
    startDeleteBPNetworkInfo: PropTypes.func,
    networkInfo: PropTypes.array,
    isLoading: PropTypes.bool
};

NetworkInfoView.defaultProps = {
    networkInfo: []
};

export default connect(mapStateToProps, mapDispatchToProps)(NetworkInfoView);
