import React from 'react';
import PropTypes from 'prop-types';
import { MessageStrip } from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import { hideToast } from '../../store/action/toast';
import StatusColor from '../../asset/constants/statusColor';

const MessageBar = ({ message, type, startHideToast }) => {
    const closeMessageBar = () => {
        startHideToast();
    };

    const delay = type === StatusColor.Negative ? 7000 : 3000;
    setTimeout(() => {
        closeMessageBar();
    }, delay);

    if (typeof message === 'object' && message !== null) {
        message = JSON.stringify(message);
    }

    return (
        <MessageStrip
            onClose={closeMessageBar}
            style={{
                position: 'fixed',
                bottom: '10px',
                transform: 'translate(-50%, -50%)',
                width: '50%',
                left: '50%',
                zIndex: 110,
                margin: '0 auto',
                textAlign: 'center'
            }}
            design={type}
        >
            {message}
        </MessageStrip>
    );
};

const mapStateToProps = (state) => {
    return {};
};

const mapDispatchToProps = (dispatch) => {
    return {
        startHideToast: () => dispatch(hideToast())
    };
};

MessageBar.propTypes = {
    message: PropTypes.string,
    startHideToast: PropTypes.func,
    type: PropTypes.oneOf(['Negative', 'Positive', 'Information', 'Warning'])
};

MessageBar.defaultProps = {
    message: 'Something went wrong, please try again',
    type: 'Negative'
};

export default connect(mapStateToProps, mapDispatchToProps)(MessageBar);
