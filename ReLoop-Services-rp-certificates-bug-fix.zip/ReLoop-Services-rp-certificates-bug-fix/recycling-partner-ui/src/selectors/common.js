export const getUserInfo = (state) => state.userInfo;

export const getStatesInfo = (state) => state.location.states;

export const getCitiesInfo = (state) => state.location.cities;

export const getBusinessInfoState = (state) => state.account.businessInfo.data;

export const isBusinessInfoLoading = (state) => state.account.businessInfo.isLoading;

export const getNetworkInfoState = (state) => state.account.networkInfo.data;

export const isNetworkInfoLoading = (state) => state.account.networkInfo.isLoading;

export const getServiceLocationState = (state) => state.account.serviceLocation.data;

export const isServiceLocationLoading = (state) => state.account.serviceLocation.isLoading;

export const getCertificatesState = (state) => state.account.certificates.data;

export const isCertificatesInfoLoading = (state) => state.account.certificates.isLoading;

export const getOrderList = (state) => state.order.orderList.data;

export const isOrderListLoading = (state) => state.order.orderList.isLoading;

export const getOrderHeaderDataState = (state) => state.order.orderHeaderData.data;

export const isOrderHeaderLoading = (state) => state.order.orderHeaderData.isLoading;

export const getConsolidatedOrderItemsState = (state) => state.order.consolidatedOrderItems.data;

export const isSubmitFirstLevelQuoteLoading = (state) => state.order.orderEvents.isLoading;

export const isAcceptLogisticsScheduleLoading = (state) => state.order.orderEvents.isLoading;
