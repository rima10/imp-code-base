/* eslint-disable react/prop-types */
import React from 'react';
import { render as rtlRender } from '@testing-library/react';
import { configureStore } from '@reduxjs/toolkit';
import { Provider } from 'react-redux';
import { combineReducers } from 'redux';
import thunk from 'redux-thunk';
import promise from 'redux-promise-middleware';

// Import reducers
import businessInfo from '../store/reducer/account/businessInfoReducer';
import networkInfo from '../store/reducer/account/privateNetworkReducer';
import serviceLocation from '../store/reducer/account/serviceLocationReducer';
import certificates from '../store/reducer/account/certificatesReducer';
import location from '../store/reducer/locationReducer';
import userInfo from '../store/reducer/loginReducer';
import isLoading from '../store/reducer/loadingReducer';
import toast from '../store/reducer/messageReducer';
import orderList from '../store/reducer/order/orderListReducer';
import orderHeaderData from '../store/reducer/order/orderHeaderReducer';
import consolidatedOrderItems from '../store/reducer/order/consolidatedOrderItemReducer';
import orderEvents from '../store/reducer/order/orderEventsReducer';

const accountReducer = {
    businessInfo,
    networkInfo,
    serviceLocation,
    certificates
};

const orderReducer = {
    orderList,
    orderHeaderData,
    consolidatedOrderItems,
    orderEvents
};

function render (
    ui,
    {
        preloadedState,
        store = configureStore({
            reducer: {
                account: combineReducers(accountReducer),
                location,
                userInfo,
                isLoading,
                toast,
                order: combineReducers(orderReducer)
            },
            middleware: [thunk, promise],
            preloadedState
        }),
        ...renderOptions
    } = {}
) {
    function Wrapper ({ children }) {
        return <Provider store={store}>{children}</Provider>;
    }
    return rtlRender(ui, { wrapper: Wrapper, ...renderOptions });
}

// re-export everything
export * from '@testing-library/react';
// override render method
export { render };
