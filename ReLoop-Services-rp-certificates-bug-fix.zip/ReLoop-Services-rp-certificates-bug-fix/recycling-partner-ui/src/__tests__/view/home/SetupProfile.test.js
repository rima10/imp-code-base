import React from 'react';
import { render } from '../../../utils/testUtils';
import SetupProfile from '../../../view/home/SetupProfile';

describe('Setup Profile Tests', () => {
    it('renders the correct content', () => {
        const { getByText } = render(<SetupProfile />);
        getByText('Welcome to EverLoop!');
        // eslint-disable-next-line max-len
        getByText('Welcome to EverLoop! The platform for environment friendly disposal of e-waste. In order to use the platform and');
        getByText('be able to submit quotes, you have to verify your business account first.');
        getByText('Setup Profile');
    });
});
