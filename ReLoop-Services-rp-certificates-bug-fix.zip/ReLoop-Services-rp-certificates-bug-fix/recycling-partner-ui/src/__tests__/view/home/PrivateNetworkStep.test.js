import React from 'react';
import { render, fireEvent } from '../../../utils/testUtils';
import { PrivateNetworkStep } from '../../../view/home/PrivateNetwork';

const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush
    })
}));

describe('Initial Screen Private Network Tests', () => {
    let props;
    beforeEach(() => {
        props = {
            isLoading: false,
            startRegisterBPNetworkInfo: jest.fn().mockImplementation(() => Promise.resolve())
        };
    });

    it('renders the correct content', () => {
        const { getByText } = render(<PrivateNetworkStep />);
        getByText('Set your Private Network by adding all the vendors you are currently working with.');
        getByText('This step could be skipped and set up later under');
        getByText('Menu > Account Management > Private Network.');
        getByText('Company Name');
        getByText('Contact Name');
        getByText('Email Address');
        getByText('Phone Number');
        getByText('+ Add Vendor');
        getByText('Skip');
        getByText('Save & Go Next');
    });

    it('checks if I can save a private network', async () => {
        const result = render(<PrivateNetworkStep {...props} />);
        const { getByText, queryByText, container } = result;
        // Add a row
        const addButton = getByText('+ Add Vendor');
        fireEvent.click(addButton);
        expect(container.querySelector('#companyName1')).not.toBeNull();
        expect(container.querySelector('#contactName1')).not.toBeNull();
        expect(container.querySelector('#emailAddress1')).not.toBeNull();
        expect(container.querySelector('#phoneNumber1')).not.toBeNull();
        // Delete the added row
        const deleteRowButton = container.querySelector('#delete1');
        fireEvent.click(deleteRowButton);
        expect(container.querySelector('#companyName1')).toBeNull();
        expect(container.querySelector('#contactName1')).toBeNull();
        expect(container.querySelector('#emailAddress1')).toBeNull();
        expect(container.querySelector('#phoneNumber1')).toBeNull();
        // Click on Save with filling up the input to get validation errors
        const saveButton = getByText('Save & Go Next');
        fireEvent.click(saveButton);
        getByText('Company Name is required');
        getByText('Contact Name is required');
        getByText('Email Address is required');
        getByText('Phone Number is required');
        // Fill the input field with valid values
        const companyName = container.querySelector('#companyName0');
        const contactName = container.querySelector('#contactName0');
        const emailAddress = container.querySelector('#emailAddress0');
        const phoneNumber = container.querySelector('#phoneNumber0');
        fireEvent.input(companyName, { target: { value: '' } });
        fireEvent.input(companyName, { target: { value: 'Model Company' } });
        fireEvent.input(contactName, { target: { value: 'John Doe' } });
        fireEvent.input(emailAddress, { target: { value: 'johndoe@everloop.com' } });
        fireEvent.input(phoneNumber, { target: { value: '9278871239' } });
        fireEvent.click(saveButton);
        expect(queryByText('Company Name is required')).toBeNull();
        expect(queryByText('Contact Name is required')).toBeNull();
        expect(queryByText('Email Address is required')).toBeNull();
        expect(queryByText('Phone Number is required')).toBeNull();
        expect(props.startRegisterBPNetworkInfo).toHaveBeenCalledTimes(1);
        // Skip the step
        const skipButton = getByText('Skip');
        fireEvent.click(skipButton);
        expect(mockHistoryPush).toHaveBeenCalledWith('/account/businessInfo');
    });
});
