import React from 'react';
import { render, fireEvent } from '../../../utils/testUtils';
import Home from '../../../view/home/Home';

describe('Home Component Tests', () => {
    it('renders the correct content', () => {
        const HomeComponent = render(<Home />);
        const { getByText, queryByText } = HomeComponent;
        getByText('Your Orders');
        getByText('New Order');
        const toggleButton = getByText('Setup Profile');
        fireEvent.click(toggleButton);
        expect(queryByText('Setup Profile')).toBeNull();
    });
});
