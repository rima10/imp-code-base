import React from 'react';
import { render, fireEvent } from '../../../utils/testUtils';
import ServiceLocation from '../../../view/home/ServiceLocation';

describe('Initial Screen Service Location Tests', () => {
    it('renders the correct content', () => {
        const { getByText } = render(<ServiceLocation />);
        // eslint-disable-next-line max-len
        getByText('Add any additional locations you are providing your services at. If you don’t have others you can skip this step.');
        getByText('Across PAN India');
        getByText('State');
        getByText('City');
        getByText('+ Add Another');
        getByText('Save & Go Next');
    });

    it('checks if I can save service location', async () => {
        const result = render(<ServiceLocation />);
        const { getByText, container } = result;
        // Add a row
        const addButton = getByText('+ Add Another');
        fireEvent.click(addButton);
        expect(container.querySelector('#state1')).not.toBeNull();
        expect(container.querySelector('#cities1')).not.toBeNull();
        // Delete the added row
        const deleteRowButton = container.querySelector('#delete1');
        fireEvent.click(deleteRowButton);
        expect(container.querySelector('#state1')).toBeNull();
        expect(container.querySelector('#cities1')).toBeNull();
        // Click on Save with filling up the input to get validation errors
        const saveButton = getByText('Save & Go Next');
        fireEvent.click(saveButton);
        getByText('State is required');
        getByText('Cities is required');
        // Click on Across PAN India
        const acrossAllStateButton = container.querySelector('#isAllStateSwitch');
        fireEvent.click(acrossAllStateButton);
    });
});
