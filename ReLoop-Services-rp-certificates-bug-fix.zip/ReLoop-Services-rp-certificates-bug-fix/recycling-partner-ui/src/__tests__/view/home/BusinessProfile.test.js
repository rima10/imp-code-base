import React from 'react';
import { render, fireEvent } from '../../../utils/testUtils';
import BusinessProfile from '../../../view/home/BusinessProfile';

describe('Initial Screen Business Profile Tests', () => {
    it('renders the correct content', () => {
        const { getByText } = render(<BusinessProfile />);
        getByText('Please add all the additional data needed to complete your');
        getByText('Business Profile');
        getByText('Business Name');
        getByText('GSTIN');
        getByText('CIN');
        getByText('State');
        getByText('City');
        getByText('Pincode');
        getByText('PAN');
        getByText('Phone Number');
        getByText('Address');
        getByText('Save & Go Next');
    });

    it('checks if I can save business data', () => {
        const result = render(<BusinessProfile />);
        const { getByText, queryByText, container } = result;
        // Click on Save with filling up the input to get validation errors
        const saveButton = getByText('Save & Go Next');
        fireEvent.click(saveButton);
        getByText('Business Name is required');
        getByText('Phone Number is required');
        getByText('GSTIN is required');
        getByText('CIN is required');
        getByText('PAN is required');
        getByText('State is required');
        getByText('City is required');
        getByText('Address is required');
        // Fill the input field with valid values
        const businessName = container.querySelector('#businessName');
        const phoneNumber = container.querySelector('#phoneNumber');
        const gstin = container.querySelector('#gstin');
        const cin = container.querySelector('#cin');
        const pan = container.querySelector('#pan');
        const pincode = container.querySelector('#pincode');
        const address = container.querySelector('#address');
        fireEvent.input(businessName, { target: { value: 'Model Company' } });
        fireEvent.input(phoneNumber, { target: { value: '9877896757' } });
        fireEvent.input(gstin, { target: { value: '18AABCU9603R1ZM' } });
        fireEvent.input(cin, { target: { value: '18AABCU96' } });
        fireEvent.input(pan, { target: { value: 'BDAPN2345A' } });
        fireEvent.input(pincode, { target: { value: '421789' } });
        fireEvent.input(address, { target: { value: 'XYZ Zone' } });
        fireEvent.click(saveButton);
        expect(queryByText('Business Name is required')).toBeNull();
        expect(queryByText('Phone Number is required')).toBeNull();
        expect(queryByText('GSTIN is required')).toBeNull();
        expect(queryByText('CIN is required')).toBeNull();
        expect(queryByText('PAN is required')).toBeNull();
        expect(queryByText('Address is required')).toBeNull();
    });
});
