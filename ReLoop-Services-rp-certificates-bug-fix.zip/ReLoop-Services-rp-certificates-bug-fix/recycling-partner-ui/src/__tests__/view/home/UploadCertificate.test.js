import React from 'react';
import { render, fireEvent, cleanup, createEvent, waitFor } from '../../../utils/testUtils';
import UploadCerificate from '../../../view/home/UploadCertificate';
import { certificateTypes } from '../../../data/certificates';

describe('Initial Certificate Upload in RP profile', () => {
    afterEach(cleanup);
    it('Should render the component in DOM', () => {
        const { asFragment } = render(<UploadCerificate />);
        expect(asFragment(<UploadCerificate />)).toMatchSnapshot();
    });

    it('Should add new certificate form item', () => {
        const { container, getByTestId } = render(<UploadCerificate />);
        fireEvent.click(getByTestId("addbutton"));

        expect(container.querySelector("#certificateType1")).toBeInTheDocument();
    });
    it('Should delete a certificate form item', () => {
        const itemIndex = 1;
        const { container, getByTestId } = render(<UploadCerificate />);
        fireEvent.click(getByTestId("addbutton"));
        fireEvent.click(getByTestId(`delete${itemIndex}`));

        expect(container.querySelector(`#certificateType${itemIndex}`)).toBeNull();
    });
});
