import React from 'react';
import { render, fireEvent } from '../../../utils/testUtils';
import GeneralQuote from '../../../view/order/GeneralQuote';

describe('General Quote Tests', () => {
    it('renders the correct content', () => {
        const { getByText } = render(<GeneralQuote />);
        getByText('Order Number');
    });
});
