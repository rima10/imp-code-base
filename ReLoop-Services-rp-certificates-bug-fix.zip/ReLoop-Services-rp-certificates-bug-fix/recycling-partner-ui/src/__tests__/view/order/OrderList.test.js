import React from 'react';
import { render, fireEvent } from '../../../utils/testUtils';
import OrderList from '../../../view/order/GeneralQuote';

describe('General Quote Tests', () => {
    it('renders the correct content', () => {
        const { getByText } = render(<OrderList />);
        getByText('Customer');
        getByText('Assets in Total');
        getByText('Total Price');
        getByText('Order Details');
    });
});
