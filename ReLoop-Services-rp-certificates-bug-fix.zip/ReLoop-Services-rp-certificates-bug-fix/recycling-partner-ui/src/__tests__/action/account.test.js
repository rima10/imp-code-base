import {
    getBusinessInfo,
    updateBusinessInfo,
    getNetworkInfo,
    registerBPNetworkInfo,
    deleteBPNetworkInfo,
    getServiceLocation,
    createServiceLocation,
    deleteServiceLocation,
    getCertificates,
    saveCertificates,
    downloadCertificate
} from '../../store/action/account';
import sinon from 'sinon';
import mockedAxios from '../../__mocks__/axios';

jest.mock('axios');

describe('Account Action Creator Tests', () => {
    let fakeDispatch;
    let fakeState;

    beforeEach(() => {
        fakeDispatch = sinon.spy();
        fakeState = sinon.stub();
    });

    it('returns the action object on getBusinessInfo call', async () => {
        const responseData = {
            data: {
                bpUsername: 'Model Company',
                bpEmailId: 'test@everloop.com',
                bpPhoneNumber: '8775371921',
                gstNumber: '18AABCU9603R1ZM',
                industryType: null,
                locId: '8',
                cin: 'L2109',
                pan: 'HVUIN4180J',
                companyCode: null,
                location: {
                    countryId: '1',
                    stateId: '3',
                    cityId: '898',
                    locId: '8',
                    state: 'Karnataka',
                    city: 'Banglore',
                    locDetails: 'XYZ Zone',
                    pincode: 560066
                }
                //need to remove this
                //isBusinessDataPresent: true
            }
        };
        mockedAxios.get.mockReturnValue(responseData);
        fakeState.returns({
            userInfo: {
                bp_id: 1
            }
        });
        const fakePayload = responseData;
        const expected = {
            type: 'FETCH_BP_BUSINESS_INFO',
            payload: fakePayload
        };
        await getBusinessInfo()(fakeDispatch, fakeState);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expected);
    });

    it('returns the action object on updateBusinessInfo call', async () => {
        const payload = {
            orderId: '1',
            orderItems: [
                {
                    itemType: 'Mobile',
                    make: 'SAMSUNG',
                    model: 'Thinkpad T240',
                    count: 1
                },
                {
                    itemType: 'Server',
                    make: 'IBM',
                    model: 'Server',
                    count: 1
                }
            ],
            quoteComments: 'Test Comment'
        };
        mockedAxios.patch.mockReturnValue({ data: 'Successful' });
        fakeState.returns({
            userInfo: {
                bp_id: 1
            }
        });
        const fakeResponse = { data: 'Successful' };
        const expectedFirstAction = {
            type: 'UPDATE_BP_BUSINESS_INFO',
            payload: fakeResponse
        };
        const expectedThirdAction = {
            type: 'SHOW_MSG_TOASTER',
            payload: { message: 'Updated Business Information', status: 'Positive' }
        };
        await updateBusinessInfo(payload)(fakeDispatch, fakeState);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expectedFirstAction);
        expect(fakeDispatch.getCall(2).args[0]).toEqual(expectedThirdAction);
    });

    it('returns the action object on getNetworkInfo call', async () => {
        const responseData = {
            data: [
                {
                    bp_nwk_id: '21',
                    nwk_member: '73',
                    nwk_owner: '64',
                    nwk_member_business_partner: {
                        bp_email_id: 'demo@everloop.com',
                        bp_username: 'Demo',
                        bp_phone_number: '9876543219'
                    }
                }
            ]
        };
        mockedAxios.get.mockReturnValue(responseData);
        fakeState.returns({
            userInfo: {
                bp_id: 1
            }
        });
        const fakePayload = responseData;
        const expected = {
            type: 'FETCH_BP_NETWORK_INFO',
            payload: fakePayload
        };
        await getNetworkInfo()(fakeDispatch, fakeState);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expected);
    });

    it('returns the action object on registerBPNetworkInfo call', async () => {
        const payload = {
            pvtNwkMembers: [{ emailId: 'demo@everloop.com', username: 'demo', phoneNumber: '9876543210' }]
        };
        mockedAxios.post.mockReturnValue({ data: 'Successful' });
        fakeState.returns({
            userInfo: {
                bp_id: 1
            }
        });
        const fakeResponse = { data: 'Successful' };
        const expectedFirstAction = {
            type: 'CREATE_BP_NETWORK_INFO',
            payload: fakeResponse
        };
        const expectedThirdAction = {
            type: 'SHOW_MSG_TOASTER',
            payload: { message: 'Private Network Added', status: 'Positive' }
        };
        await registerBPNetworkInfo(payload)(fakeDispatch, fakeState);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expectedFirstAction);
        expect(fakeDispatch.getCall(2).args[0]).toEqual(expectedThirdAction);
    });

    it('returns the action object on deleteBPNetworkInfo call', async () => {
        const payload = {
            pvtNwkMembers: [{ recyclerId: '1', networkId: '2' }]
        };
        mockedAxios.delete.mockReturnValue({ data: 'Successful' });
        fakeState.returns({
            userInfo: {
                bp_id: 1
            }
        });
        const fakeResponse = { data: 'Successful' };
        const expectedFirstAction = {
            type: 'DELETE_BP_NETWORK_INFO',
            payload: fakeResponse
        };
        const expectedThirdAction = {
            type: 'SHOW_MSG_TOASTER',
            payload: { message: 'Private Network Deleted', status: 'Positive' }
        };
        await deleteBPNetworkInfo(payload)(fakeDispatch, fakeState);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expectedFirstAction);
        expect(fakeDispatch.getCall(2).args[0]).toEqual(expectedThirdAction);
    });

    it('returns the action object on getServiceLocation call', async () => {
        const responseData = {
            data: [
                {
                    servLocId: '16',
                    isAllState: false,
                    countryId: '1',
                    serviceable_states: [
                        {
                            stateId: '3',
                            stateName: 'Nagaland',
                            isAllCity: true,
                            serviceable_cities: []
                        }
                    ]
                }
            ]
        };
        mockedAxios.get.mockReturnValue(responseData);
        fakeState.returns({
            userInfo: {
                bp_id: 1
            }
        });
        const fakePayload = responseData;
        const expected = {
            type: 'FETCH_SERVICE_LOCATION',
            payload: fakePayload
        };
        await getServiceLocation()(fakeDispatch, fakeState);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expected);
    });

    it('returns the action object on createServiceLocation call', async () => {
        const payload = {
            countryId: '1',
            isAllStateSelected: false,
            serviceLocations: [
                {
                    state: '2',
                    stateName: 'Kashmir',
                    isAllCitySelected: false,
                    city: [
                        {
                            cityId: '2',
                            cityName: 'Punch'
                        }
                    ]
                }
            ]
        };
        mockedAxios.post.mockReturnValue({ data: 'Successful' });
        fakeState.returns({
            userInfo: {
                bp_id: 1
            }
        });
        const fakeResponse = { data: 'Successful' };
        const expectedFirstAction = {
            type: 'CREATE_SERVICE_LOCATION',
            payload: fakeResponse
        };
        const expectedThirdAction = {
            type: 'SHOW_MSG_TOASTER',
            payload: { message: 'Service Location Added', status: 'Positive' }
        };
        await createServiceLocation(payload)(fakeDispatch, fakeState);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expectedFirstAction);
        expect(fakeDispatch.getCall(2).args[0]).toEqual(expectedThirdAction);
    });

    it('returns the action object on deleteServiceLocation call', async () => {
        const payload = {
            statesDetail: ['1']
        };
        mockedAxios.delete.mockReturnValue({ data: 'Successful' });
        fakeState.returns({
            userInfo: {
                bp_id: 1
            }
        });
        const fakeResponse = { data: 'Successful' };
        const expectedFirstAction = {
            type: 'DELETE_SERVICE_LOCATION',
            payload: fakeResponse
        };
        const expectedThirdAction = {
            type: 'SHOW_MSG_TOASTER',
            payload: { message: 'Service Location Deleted', status: 'Positive' }
        };
        await deleteServiceLocation(payload)(fakeDispatch, fakeState);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expectedFirstAction);
        expect(fakeDispatch.getCall(2).args[0]).toEqual(expectedThirdAction);
    });

    it('returns the action object on getCertificates call', async () => {
        const responseData = {
            data: ['1', '2']
        };
        mockedAxios.get.mockReturnValue(responseData);
        fakeState.returns({
            userInfo: {
                bp_id: 1
            }
        });
        const fakePayload = responseData;
        const expected = {
            type: 'GET_CERTIFICATES',
            payload: fakePayload
        };
        await getCertificates()(fakeDispatch, fakeState);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expected);
    });

    it('returns the action object on downloadCertificate call', async () => {
        const responseData = {
            data: 'document downloaded.'
        };
        const certificateId = '1';
        mockedAxios.get.mockReturnValue(responseData);
        fakeState.returns({
            userInfo: {
                bp_id: 1
            }
        });
        const fakePayload = responseData;
        const expected = {
            type: 'DOWNLOAD_CERTIFICATE',
            payload: fakePayload
        };
        await downloadCertificate(certificateId)(fakeDispatch, fakeState);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expected);
    });

    it('returns the action object on saveCertificates call', async () => {
        const payload = ['1', '2'];
        mockedAxios.post.mockReturnValue({ data: 'Successful' });
        fakeState.returns({
            userInfo: {
                bp_id: 1
            }
        });
        const fakeResponse = { data: 'Successful' };
        const expectedFirstAction = {
            type: 'POST_CERTIFICATES',
            payload: fakeResponse
        };
        const expectedSecondAction = {
            type: 'SHOW_MSG_TOASTER',
            payload: { message: `Successfully saved the certificates`, status: 'Positive' }
        };
        await saveCertificates(payload)(fakeDispatch, fakeState);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expectedFirstAction);
        expect(fakeDispatch.getCall(1).args[0]).toEqual(expectedSecondAction);
    });
});
