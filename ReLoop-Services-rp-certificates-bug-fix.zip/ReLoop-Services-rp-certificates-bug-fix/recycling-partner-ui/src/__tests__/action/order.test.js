import {
    getConsolidatedOrderItemInfo,
    submitFirstLevelQuote,
    acceptLogisticSchedule,
    getOrderList,
    getOrderHeaderData
} from '../../store/action/order';
import sinon from 'sinon';
import mockedAxios from '../../__mocks__/axios';

jest.mock('axios');

describe('Order Action Creator Tests', () => {
    let fakeDispatch;
    let fakeState;

    beforeEach(() => {
        fakeDispatch = sinon.spy();
        fakeState = sinon.stub();
    });

    it('returns the action object on getConsolidatedOrderItemInfo call', async () => {
        const payload = {
            orderId: '1',
            orderNumber: '2021006',
            orderAdditionalInfo: null,
            category: 1,
            subCategory: '1',
            orderType: '1',
            submissionDeadline: '2021-08-24T05:05:14.000Z',
            orderNetwork: 'Private',
            pictureLoc: null,
            created_date: '2021-08-23T05:05:25.525Z',
            last_modified_date: '2021-08-23T05:05:25.525Z',
            createdBy: '1',
            updatedBy: '64',
            preferred_pick_up_time: null,
            is_verification_reqd: null,
            orderPosition: 'In Progress',
            currentSequence: '3',
            logisticsScheduledTime: '2021-07-23T02:00:00.000Z',
            vehicleType: 'test11',
            vehicleNumber: 'test22',
            recycleAssetType: null,
            totalWeight: null,
            logisticSpocContactNumber: null,
            logisticSpocName: null,
            recyclerContactNumber: '9876543210',
            recyclerContactName: 'test55',
            logisticProvider: 'test44',
            driverName: 'test33',
            orderItems: [
                {
                    itemType: 'Mobile',
                    make: 'SAMSUNG',
                    model: 'Thinkpad T240',
                    count: 1
                },
                {
                    itemType: 'Server',
                    make: 'IBM',
                    model: 'Server',
                    count: 1
                }
            ],
            orderProcessType: {
                processTypeName: 'Refurbish'
            },
            workflow: {
                orderWorkflowId: '14',
                workflowId: '2',
                processTypeId: '1',
                processStageName: 'Order Submission',
                processStageSequence: '2',
                workflowApprovers: []
            },
            categoryName: 'Electronics',
            subCategoryName: 'Information technology and telecommunication equipment',
            processType: 'Refurbish',
            recyclers: [
                {
                    bpId: '34',
                    bpUsername: 'Electro'
                }
            ]
        };
        mockedAxios.get.mockReturnValue({
            data: payload
        });
        const fakePayload = {
            data: payload
        };
        const expected = {
            type: 'FETCH_CONSOLIDATED_ORDER_ITEMS_INFO',
            payload: fakePayload
        };
        const orderId = 1;
        await getConsolidatedOrderItemInfo(orderId)(fakeDispatch);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expected);
    });

    it('returns the action object on submitFirstLevelQuote call', async () => {
        const payload = {
            orderId: '1',
            orderItems: [
                {
                    itemType: 'Mobile',
                    make: 'SAMSUNG',
                    model: 'Thinkpad T240',
                    count: 1
                },
                {
                    itemType: 'Server',
                    make: 'IBM',
                    model: 'Server',
                    count: 1
                }
            ],
            quoteComments: 'Test Comment'
        };
        mockedAxios.post.mockReturnValue({ data: 'Successful' });
        fakeState.returns({
            userInfo: {
                bp_id: 1
            }
        });
        const fakePayload = { data: 'Successful' };
        const expectedFirstAction = {
            type: 'SUBMIT_FIRST_LEVEL_QUOTE',
            payload: fakePayload
        };
        const expectedSecondAction = {
            type: 'SHOW_MSG_TOASTER',
            payload: { message: 'Successfully Submitted Quote', status: 'Positive' }
        };
        await submitFirstLevelQuote(payload)(fakeDispatch, fakeState);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expectedFirstAction);
        expect(fakeDispatch.getCall(1).args[0]).toEqual(expectedSecondAction);
    });

    it('returns the action object on acceptLogisticSchedule call', async () => {
        const payload = {
            vehicleType: 'AMT',
            vehicleNumber: '1234',
            driverName: 'John Doe',
            logisticProvider: 'XYZ Ltd',
            recyclerContactName: 'Smith',
            recyclerContactNumber: 'Joe'
        };
        mockedAxios.post.mockReturnValue({ data: 'Successful' });
        fakeState.returns({
            userInfo: {
                bp_id: 1
            }
        });
        const fakePayload = { data: 'Successful' };
        const expectedFirstAction = {
            type: 'ACCEPT_LOGISTIC_SCHEDULE',
            payload: fakePayload
        };
        const expectedSecondAction = {
            type: 'SHOW_MSG_TOASTER',
            payload: { message: 'You successfully accepted the logistics schedule.', status: 'Positive' }
        };
        const orderId = '1';
        await acceptLogisticSchedule(orderId, payload)(fakeDispatch, fakeState);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expectedFirstAction);
        expect(fakeDispatch.getCall(1).args[0]).toEqual(expectedSecondAction);
    });

    it('returns the action object on getOrderList call', async () => {
        const payload = [
            {
                order_id: '1',
                order_no: '2021001',
                created_by: 'XYZ',
                created_date: '2021-08-23T05:03:16.117Z',
                quote_status: 'New'
            }
        ];
        mockedAxios.get.mockReturnValue({
            data: payload
        });
        fakeState.returns({
            userInfo: {
                bp_id: 1
            }
        });
        const fakePayload = {
            data: payload
        };
        const expected = {
            type: 'FETCH_ORDER_LIST',
            payload: fakePayload
        };
        await getOrderList()(fakeDispatch, fakeState);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expected);
    });

    it('returns the action object on getOrderHeaderData call', async () => {
        const payload = {
            orderId: '6',
            submissionDeadline: '2021-08-24T05:05:14.000Z',
            category: 'Electronics',
            subCategory: 'Information technology and telecommunication equipment',
            pictureLoc: null,
            orderNetwork: 'Private',
            additionalInfo: null,
            itemsCount: '19',
            bpUserName: 'Test',
            locPincode: 421513,
            locDetails: 'Address',
            locCity: 'Virār',
            locState: 'Maharashtra'
        };
        mockedAxios.get.mockReturnValue({
            data: payload
        });
        const fakePayload = {
            data: payload
        };
        const expected = {
            type: 'FETCH_ORDER_HEADER_DATA',
            payload: fakePayload
        };
        const orderId = 1;
        await getOrderHeaderData(orderId)(fakeDispatch);
        expect(fakeDispatch.getCall(0).args[0]).toEqual(expected);
    });
});
