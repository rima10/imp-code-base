import orderEvents from '../../../store/reducer/order/orderEventsReducer';

const getInitialState = () => {
    return { isLoading: false };
};

describe('Order Events Reducer', () => {
    it('returns the initial state', () => {
        const fakeAction = {
            type: undefined
        };
        const originalState = getInitialState();
        const expected = getInitialState();
        expect(orderEvents(originalState, fakeAction)).toEqual(expected);
    });

    it('sets Loading to true when SUBMIT_FIRST_LEVEL_QUOTE_PENDING action is received', () => {
        const fakeAction = {
            type: 'SUBMIT_FIRST_LEVEL_QUOTE_PENDING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true };
        const actual = orderEvents(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets Loading to false when SUBMIT_FIRST_LEVEL_QUOTE_FULFILLED action is received', () => {
        const fakeAction = {
            type: 'SUBMIT_FIRST_LEVEL_QUOTE_FULFILLED'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false };
        const actual = orderEvents(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets Loading to false when SUBMIT_FIRST_LEVEL_QUOTE_REJECTED action is received', () => {
        const fakeAction = {
            type: 'SUBMIT_FIRST_LEVEL_QUOTE_REJECTED'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false };
        const actual = orderEvents(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });
});
