import orderHeader from '../../../store/reducer/order/orderHeaderReducer';

const getInitialState = () => {
    return { isLoading: false, errMsg: null, data: {} };
};

const getPayload = () => {
    return {
        data: {
            orderId: '6',
            submissionDeadline: '2021-08-24T05:05:14.000Z',
            category: 'Electronics',
            subCategory: 'Information Technology and Telecommunication equipment',
            pictureLoc: null,
            orderNetwork: 'Private',
            additionalInfo: null,
            itemsCount: '19',
            bpUserName: 'Test',
            locPincode: 421513,
            locDetails: 'Address',
            locCity: 'Virār',
            locState: 'Maharashtra'
        }
    };
};

describe('Order Header Reducer', () => {
    it('returns the initial state', () => {
        const fakeAction = {
            type: undefined
        };
        const originalState = getInitialState();
        const expected = getInitialState();
        expect(orderHeader(originalState, fakeAction)).toEqual(expected);
    });

    it('sets Loading to true when FETCH_ORDER_HEADER_DATA_PENDING action is received', () => {
        const fakeAction = {
            type: 'FETCH_ORDER_HEADER_DATA_PENDING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true, errMsg: null };
        const actual = orderHeader(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets order header data when FETCH_ORDER_HEADER_DATA_FULFILLED action is received', () => {
        const payload = getPayload();
        const fakeAction = {
            type: 'FETCH_ORDER_HEADER_DATA_FULFILLED',
            payload: payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: null, data: payload.data };
        const actual = orderHeader(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets errMsg when FETCH_ORDER_HEADER_DATA_REJECTED action is received', () => {
        const payload = 'Something went wrong';
        const fakeAction = {
            type: 'FETCH_ORDER_HEADER_DATA_REJECTED',
            payload: payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: payload, data: {} };
        const actual = orderHeader(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });
});
