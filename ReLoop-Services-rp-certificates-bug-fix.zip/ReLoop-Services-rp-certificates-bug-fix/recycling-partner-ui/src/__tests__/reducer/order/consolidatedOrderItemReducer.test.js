import consolidatedOrderItem from '../../../store/reducer/order/consolidatedOrderItemReducer';

const getInitialState = () => {
    return { isLoading: false, errMsg: null, data: {} };
};

const getPayload = () => {
    return {
        data: {
            orderId: '6',
            orderNumber: '2021006',
            orderAdditionalInfo: null,
            category: 1,
            subCategory: '1',
            orderType: '1',
            submissionDeadline: '2021-08-24T05:05:14.000Z',
            orderNetwork: 'Private',
            pictureLoc: null,
            created_date: '2021-08-23T05:05:25.525Z',
            last_modified_date: '2021-08-23T05:05:25.525Z',
            createdBy: '1',
            updatedBy: '64',
            preferred_pick_up_time: null,
            is_verification_reqd: null,
            orderPosition: 'In Progress',
            currentSequence: '3',
            logisticsScheduledTime: '2021-07-23T02:00:00.000Z',
            vehicleType: 'test11',
            vehicleNumber: 'test22',
            recycleAssetType: null,
            totalWeight: null,
            logisticSpocContactNumber: null,
            logisticSpocName: null,
            recyclerContactNumber: '9876543210',
            recyclerContactName: 'test55',
            logisticProvider: 'test44',
            driverName: 'test33',
            orderItems: [
                {
                    itemType: 'Mobile',
                    make: 'SAMSUNG',
                    model: 'Thinkpad T240',
                    count: 1
                },
                {
                    itemType: 'Server',
                    make: 'IBM',
                    model: 'Server',
                    count: 1
                }
            ],
            orderProcessType: {
                processTypeName: 'Refurbish'
            },
            workflow: {
                orderWorkflowId: '14',
                workflowId: '2',
                processTypeId: '1',
                processStageName: 'Order Submission',
                processStageSequence: '2',
                workflowApprovers: []
            },
            categoryName: 'Electronics',
            subCategoryName: 'Information Technology and Telecommunication equipment',
            processType: 'Refurbish',
            recyclers: [
                {
                    bpId: '34',
                    bpUsername: 'Electro'
                }
            ]
        }
    };
};

describe('Consolidate Order Items Reducer', () => {
    it('returns the initial state', () => {
        const fakeAction = {
            type: undefined
        };
        const originalState = getInitialState();
        const expected = getInitialState();
        expect(consolidatedOrderItem(originalState, fakeAction)).toEqual(expected);
    });

    it('sets Loading to true when FETCH_CONSOLIDATED_ORDER_ITEMS_INFO_PENDING action is received', () => {
        const fakeAction = {
            type: 'FETCH_CONSOLIDATED_ORDER_ITEMS_INFO_PENDING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true, errMsg: null };
        const actual = consolidatedOrderItem(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets order header data when FETCH_CONSOLIDATED_ORDER_ITEMS_INFO_FULFILLED action is received', () => {
        const payload = getPayload();
        const fakeAction = {
            type: 'FETCH_CONSOLIDATED_ORDER_ITEMS_INFO_FULFILLED',
            payload: payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: null, data: payload.data };
        const actual = consolidatedOrderItem(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets errMsg when FETCH_CONSOLIDATED_ORDER_ITEMS_INFO_REJECTED action is received', () => {
        const payload = 'Something went wrong';
        const fakeAction = {
            type: 'FETCH_CONSOLIDATED_ORDER_ITEMS_INFO_REJECTED',
            payload: payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: payload, data: {} };
        const actual = consolidatedOrderItem(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });
});
