import businessInfo from '../../../store/reducer/account/businessInfoReducer';

const getInitialState = () => {
    return {
        isLoading: false,
        errMsg: null,
        data: {}
    };
};

const getPayload = () => {
    return {
        data: {
            bpUsername: 'Model Company',
            bpEmailId: 'test@everloop.com',
            bpPhoneNumber: '8775371921',
            gstNumber: '18AABCU9603R1ZM',
            industryType: null,
            locId: '8',
            cin: 'L2109',
            pan: 'HVUIN4180J',
            companyCode: null,
            location: {
                countryId: '1',
                stateId: '3',
                cityId: '898',
                locId: '8',
                state: 'Karnataka',
                city: 'Banglore',
                locDetails: 'XYZ Zone',
                pincode: 560066
            }
            // need to remove this
            //isBusinessDataPresent: true
        }
    };
};

describe('Business Info Reducer', () => {
    it('returns the initial state', () => {
        const fakeAction = {
            type: undefined
        };
        const originalState = getInitialState();
        const expected = getInitialState();
        expect(businessInfo(originalState, fakeAction)).toEqual(expected);
    });

    it('sets isLoading to true when FETCH_BP_BUSINESS_INFO_PENDING action is received', () => {
        const fakeAction = {
            type: 'FETCH_BP_BUSINESS_INFO_PENDING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true, errMsg: null };
        const actual = businessInfo(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets isLoading to true when UPDATE_BP_BUSINESS_INFO_PENDING action is received', () => {
        const fakeAction = {
            type: 'UPDATE_BP_BUSINESS_INFO_PENDING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true, errMsg: null };
        const actual = businessInfo(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets businessInfo data when FETCH_BP_BUSINESS_INFO_FULFILLED action is received', () => {
        const payload = getPayload();
        const fakeAction = {
            type: 'FETCH_BP_BUSINESS_INFO_FULFILLED',
            payload: payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: null, data: payload.data };
        const actual = businessInfo(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets errMsg when FETCH_BP_BUSINESS_INFO_REJECTED action is received', () => {
        const payload = 'Something went wrong';
        const fakeAction = {
            type: 'FETCH_BP_BUSINESS_INFO_REJECTED',
            payload: payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: payload, data: {} };
        const actual = businessInfo(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets errMsg when UPDATE_BP_BUSINESS_INFO_REJECTED action is received', () => {
        const payload = 'Something went wrong';
        const fakeAction = {
            type: 'UPDATE_BP_BUSINESS_INFO_REJECTED',
            payload: payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: payload };
        const actual = businessInfo(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });
});
