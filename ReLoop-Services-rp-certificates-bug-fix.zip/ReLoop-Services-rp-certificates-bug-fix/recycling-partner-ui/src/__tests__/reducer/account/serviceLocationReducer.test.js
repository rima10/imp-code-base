import serviceLocation from '../../../store/reducer/account/serviceLocationReducer';

const getInitialState = () => {
    return {
        isLoading: false,
        errMsg: null,
        data: []
    };
};

const getPayload = () => {
    return {
        data: [
            {
                servLocId: '3',
                isAllState: false,
                countryId: '1',
                serviceable_states: [
                    {
                        stateId: '6',
                        stateName: 'Maharashtra',
                        isAllCity: false,
                        serviceable_cities: [
                            {
                                cityId: '22',
                                cityName: 'Warora'
                            },
                            {
                                cityId: '24',
                                cityName: 'Wardha'
                            }
                        ]
                    }
                ]
            }
        ]
    };
};

describe('Private Network Reducer', () => {
    it('returns the initial state', () => {
        const fakeAction = {
            type: undefined
        };
        const originalState = getInitialState();
        const expected = getInitialState();
        expect(serviceLocation(originalState, fakeAction)).toEqual(expected);
    });

    it('sets isLoading to true when FETCH_SERVICE_LOCATION_PENDING action is received', () => {
        const fakeAction = {
            type: 'FETCH_SERVICE_LOCATION_PENDING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true, errMsg: null };
        const actual = serviceLocation(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets isLoading to true when CREATE_SERVICE_LOCATION_PENDING action is received', () => {
        const fakeAction = {
            type: 'CREATE_SERVICE_LOCATION_PENDING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true, errMsg: null };
        const actual = serviceLocation(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets isLoading to true when DELETE_SERVICE_LOCATION_PENDING action is received', () => {
        const fakeAction = {
            type: 'DELETE_SERVICE_LOCATION_PENDING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true, errMsg: null };
        const actual = serviceLocation(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets serviceLocation data when FETCH_SERVICE_LOCATION_FULFILLED action is received', () => {
        const payload = getPayload();
        const fakeAction = {
            type: 'FETCH_SERVICE_LOCATION_FULFILLED',
            payload: payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: null, data: payload.data };
        const actual = serviceLocation(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets errMsg when FETCH_SERVICE_LOCATION_REJECTED action is received', () => {
        const payload = 'Something went wrong';
        const fakeAction = {
            type: 'FETCH_SERVICE_LOCATION_REJECTED',
            payload: payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: payload, data: [] };
        const actual = serviceLocation(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets errMsg when CREATE_SERVICE_LOCATION_REJECTED action is received', () => {
        const payload = 'Something went wrong';
        const fakeAction = {
            type: 'CREATE_SERVICE_LOCATION_REJECTED',
            payload: payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: payload };
        const actual = serviceLocation(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });

    it('sets errMsg when DELETE_SERVICE_LOCATION_REJECTED action is received', () => {
        const payload = 'Something went wrong';
        const fakeAction = {
            type: 'DELETE_SERVICE_LOCATION_REJECTED',
            payload: payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: payload };
        const actual = serviceLocation(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });
});
