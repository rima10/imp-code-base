import { camelCaseToSentence } from '../utils/formatter.js';
import {
    EMAIL_REGEX,
    PHONE_REGEX,
    PAN_REGEX,
    GST_REGEX,
    PINCODE_REGEX,
    CIN_REGEX
} from '../asset/constants/constant.js';

const isEmpty = (value) =>
    value === undefined ||
    value === null ||
    (typeof value === 'object' && Object.keys(value).length === 0) ||
    (typeof value === 'string' && value.trim().length === 0);

const isEmail = (value) => EMAIL_REGEX.test(value);

const isContactNumber = (value) => PHONE_REGEX.test(value);

const isGSTNumber = (value) => GST_REGEX.test(value);

const isPANNumber = (value) => PAN_REGEX.test(value);

const isPincode = (value) => PINCODE_REGEX.test(value);

const isCIN = (value) => CIN_REGEX.test(value);

const validateEmail = (value) => {
    let errorMessage = '';
    if (value && !isEmail(value)) {
        errorMessage = 'Enter valid Email';
    }
    if (isEmpty(value)) {
        errorMessage = 'Email is required';
    }
    return {
        errorMessage,
        isValid: isEmpty(errorMessage)
    };
};

const validateCompanyCode = (value) => {
    let errorMessage = '';
    if (!(value.length === 4)) {
        errorMessage = 'Enter valid Company Code';
    }
    return {
        errorMessage,
        isValid: isEmpty(errorMessage)
    };
};

const validateContactNumber = (value, required = false) => {
    let errorMessage = '';
    if (value && !isContactNumber(value)) {
        errorMessage = 'Enter valid Number';
    }
    if (required && isEmpty(value)) {
        errorMessage = 'Phone Number is required';
    }
    return {
        errorMessage,
        isValid: isEmpty(errorMessage)
    };
};

const validateIsEmpty = (value, field) => {
    let errorMessage = '';
    if (isEmpty(value)) {
        let fieldName = camelCaseToSentence(field);
        errorMessage = `${fieldName} is required`;
    }
    return {
        errorMessage,
        isValid: isEmpty(errorMessage)
    };
};

const validateGST = (value) => {
    let errorMessage = '';
    if (value && !isGSTNumber(value)) {
        errorMessage = 'Enter valid GST Number';
    }
    if (isEmpty(value)) {
        errorMessage = 'GST Number is required';
    }
    return {
        errorMessage,
        isValid: isEmpty(errorMessage)
    };
};

const validatePAN = (value) => {
    let errorMessage = '';
    if (value && !isPANNumber(value)) {
        errorMessage = 'Enter valid PAN Number';
    }
    if (isEmpty(value)) {
        errorMessage = 'PAN Number is required';
    }
    return {
        errorMessage,
        isValid: isEmpty(errorMessage)
    };
};

const validatePincode = (value, required = false) => {
    let errorMessage = '';
    if (value && !isPincode(value)) {
        errorMessage = 'Enter valid Pincode';
    }
    if (required && isEmpty(value)) {
        errorMessage = 'Pincode is required';
    }
    return {
        errorMessage,
        isValid: isEmpty(errorMessage)
    };
};

const validateCIN = (value) => {
    let errorMessage = '';
    if (value && !isCIN(value)) {
        errorMessage = 'Enter valid CIN';
    }
    if (isEmpty(value)) {
        errorMessage = 'CIN is required';
    }
    return {
        errorMessage,
        isValid: isEmpty(errorMessage)
    };
};

export {
    isEmpty,
    isEmail,
    isContactNumber,
    isGSTNumber,
    isPANNumber,
    isPincode,
    isCIN,
    validateEmail,
    validateCompanyCode,
    validateContactNumber,
    validateIsEmpty,
    validateGST,
    validatePAN,
    validatePincode,
    validateCIN
};
