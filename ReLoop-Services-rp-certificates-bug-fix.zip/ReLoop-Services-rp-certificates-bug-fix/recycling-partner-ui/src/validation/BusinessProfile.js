import {
    validateCIN,
    validateContactNumber,
    validateGST,
    validateIsEmpty,
    validatePAN,
    validatePincode
} from './common.js';

const validateInput = (value, field, fieldConfig) => {
    if (field === 'businessName') {
        return validateIsEmpty(value, field);
    } else if (field === 'gstin') {
        return validateGST(value);
    } else if (field === 'phoneNumber') {
        return validateContactNumber(value, fieldConfig.required);
    } else if (field === 'pan') {
        return validatePAN(value);
    } else if (field === 'cin') {
        return validateCIN(value);
    } else if (field === 'address') {
        return validateIsEmpty(value, field);
    } else if (field === 'pincode') {
        return validatePincode(value, fieldConfig.required);
    } else {
        return { isValid: true, errorMessage: '' };
    }
};
export default validateInput;
