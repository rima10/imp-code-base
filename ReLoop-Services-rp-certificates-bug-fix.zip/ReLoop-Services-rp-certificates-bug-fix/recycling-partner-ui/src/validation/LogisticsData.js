import { validateContactNumber, validateIsEmpty } from './common';

const validateInput = (value, field, fieldConfig) => {
    if (field === 'vehicleType') {
        return validateIsEmpty(value, field);
    } else if (field === 'vehicleNumber') {
        return validateIsEmpty(value, field);
    } else if (field === 'driverName') {
        return validateIsEmpty(value, field);
    } else if (field === 'recyclerContactNumber') {
        return validateContactNumber(value, fieldConfig.required);
    } else {
        return { isValid: true, errorMessage: '' };
    }
};

export default validateInput;
