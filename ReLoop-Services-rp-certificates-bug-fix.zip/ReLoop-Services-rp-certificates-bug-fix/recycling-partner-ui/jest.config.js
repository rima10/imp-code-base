const path = require('path');

module.exports = {
    testEnvironment: 'jsdom',
    transformIgnorePatterns: ['node_modules/(?!(@ui5|lit-html)).*\\.js$'],
    setupFilesAfterEnv: ['./jest-setup.js'],
    moduleNameMapper: {
        '\\.(jpg|ico|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$':
            path.join(__dirname, '/src/__mocks__/fileMock.js'),
        '\\.(css|less)$': path.join(__dirname, '/src/__mocks__/fileMock.js')
    }
};
