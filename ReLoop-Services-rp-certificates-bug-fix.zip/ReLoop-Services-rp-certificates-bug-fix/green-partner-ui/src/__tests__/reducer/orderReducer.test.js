import order from '../../store/reducer/orderReducer';

const getInitialState = () => {
    return {
        isLoading: true,
        isOnsiteLoading: true,
        onsiteErrMsg: null,
        errMsg: null,
        orderInfo: [],
        orderItemInfo: {},
        isOrderItemInfoLoading: true,
        orderItemInfoErrMsg: null,
        consolidatedOrderItemInfo: {},
        isConsolidatedOrderItemInfoLoading: true,
        consolidatedOrderItemInfoErrMsg: null,
        previewOrderItemInfo: [],
        orderQuotation: {},
        isOrderQuotationLoading: true,
        orderQuotationErrMsg: null,
        approver: { 1: [], 3: [], 5: [] },
        onSiteVisitDetails: {},
        orderItemQuotation: []
    };
};

describe('Order Reducer', () => {
    it('returns the initial state', () => {
        const fakeAction = {
            type: undefined
        };
        const originalState = getInitialState();
        const expected = getInitialState();
        expect(order(originalState, fakeAction)).toEqual(expected);
    });
    it('sets isLoading to true when ORDER_INFO_LOADING action is received', () => {
        const fakeAction = {
            type: 'ORDER_INFO_LOADING'
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: true, errMsg: null, orderInfo: [] };
        const actual = order(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });
    it('sets orderInfo data when SET_ORDER_INFO action is received', () => {
        const payload = [
            {
                orderId: '4',
                orderNumber: '2021004',
                orderAdditionalInfo: 'Looking for an Industry Standard Quote Value for the Assets',
                category: 1,
                subCategory: '1',
                orderType: '1',
                submissionDeadline: '2021-07-16T09:30:00.000Z',
                orderNetwork: 'Private',
                pictureLoc: null,
                created_date: '2021-07-09T10:43:31.265Z',
                last_modified_date: '2021-07-09T10:43:31.265Z',
                createdBy: '1',
                updatedBy: '1',
                preferred_pick_up_time: null,
                is_verification_reqd: null,
                orderPosition: 'In Progress',
                currentSequence: '6',
                logisticsScheduledTime: '2021-07-23T02:00:00.000Z',
                vehicleType: 'AMT (Semi Trailer)',
                vehicleNumber: 'HR26DQ5551',
                orderProcessType: {
                    processTypeName: 'Refurbish'
                }
            }
        ];
        const fakeAction = {
            type: 'SET_ORDER_INFO',
            payload: payload
        };
        const originalState = getInitialState();
        const expected = { ...originalState, isLoading: false, errMsg: null, orderInfo: payload };
        const actual = order(originalState, fakeAction);
        expect(actual).toEqual(expected);
    });
});
