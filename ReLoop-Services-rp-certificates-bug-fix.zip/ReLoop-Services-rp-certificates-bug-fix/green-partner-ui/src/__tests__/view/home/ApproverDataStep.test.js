import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { render, fireEvent } from '../../../utils/testUtils';
import ApproverDataStep from '../../../view/home/ApproverDataStep';

describe('Approver Data Tests', () => {
    it('renders the correct content', () => {
        const { getByText } = render(
            <BrowserRouter>
                <ApproverDataStep />
            </BrowserRouter>
        );
        getByText('For Refurbishing requests only:');
        getByText('In order to create Approval Workflows please add all the approver details.');
        getByText('This step could be skipped and set up later under');
        getByText('Menu > Account Management > Approver’s Data.');
        getByText('Approver Role');
        getByText('Approver Name');
        getByText('Email Address');
        getByText('Phone Number');
        getByText('+ Add Approver');
        getByText('Skip Steps 3 and 4');
        getByText('Save & Go Next');
    });
    it('checks if I can save a private network', async () => {
        const result = render(
            <BrowserRouter>
                <ApproverDataStep />
            </BrowserRouter>
        );
        const { getByText, queryByText, container } = result;
        // Add a row
        const addButton = getByText('+ Add Approver');
        fireEvent.click(addButton);
        expect(container.querySelector('#approverRole1')).not.toBeNull();
        expect(container.querySelector('#approverName1')).not.toBeNull();
        expect(container.querySelector('#emailAddress1')).not.toBeNull();
        expect(container.querySelector('#phoneNumber1')).not.toBeNull();
        // Delete the added row
        const deleteRowButton = container.querySelector('#delete1');
        fireEvent.click(deleteRowButton);
        expect(container.querySelector('#approverRole1')).toBeNull();
        expect(container.querySelector('#approverName1')).toBeNull();
        expect(container.querySelector('#emailAddress1')).toBeNull();
        expect(container.querySelector('#phoneNumber1')).toBeNull();
        // Click on Save with filling up the input to get validation errors
        const saveButton = getByText('Save & Go Next');
        fireEvent.click(saveButton);
        getByText('Approver Role is required');
        getByText('Approver Name is required');
        getByText('Email Address is required');
        getByText('Phone Number is required');
        // Fill the input field with valid values
        const approverRole = container.querySelector('#approverRole0');
        const approverName = container.querySelector('#approverName0');
        const emailAddress = container.querySelector('#emailAddress0');
        const phoneNumber = container.querySelector('#phoneNumber0');
        fireEvent.input(approverRole, { target: { value: 'Admin' } });
        fireEvent.input(approverName, { target: { value: 'John Doe' } });
        fireEvent.input(emailAddress, { target: { value: 'johndoe@everloop.com' } });
        fireEvent.input(phoneNumber, { target: { value: '9278871239' } });
        fireEvent.click(saveButton);
        expect(queryByText('Approver Role is required')).toBeNull();
        expect(queryByText('Approver Name is required')).toBeNull();
        expect(queryByText('Email Address is required')).toBeNull();
        expect(queryByText('Phone Number is required')).toBeNull();
    });
});
