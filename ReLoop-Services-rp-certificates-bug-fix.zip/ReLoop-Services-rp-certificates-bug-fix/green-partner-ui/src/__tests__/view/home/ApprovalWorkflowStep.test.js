import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { render } from '../../../utils/testUtils';
import ApprovalWorkflowStep from '../../../view/home/ApprovalWorkflowStep';

describe('Approver Workflow Tests', () => {
    it('renders the correct content', () => {
        const { getByText, getAllByText } = render(
            <BrowserRouter>
                <ApprovalWorkflowStep />
            </BrowserRouter>
        );
        getByText('Please select the approvers');
        getByText('that you created in the previous steps in order');
        getByText('to assign them to the approval steps below.');
        getByText('This step could be skipped and set up later under');
        getByText('Menu > Account Management > Approval Workflows.');
        getByText('In your Process, who is responsible for the internal approval of the asset list?');
        getAllByText('Approval Sequence');
        getAllByText('Approver Role');
        getAllByText('Approver Name');
        getAllByText('Email Address');
        getAllByText('+ Add Approver');
        getByText(
            'In your Process, who is responsible for internally approving higher level quotes from your recycler?'
        );
        getByText('In your Process, who is responsible for internally approving item level quotes from your recycler?');
        getByText('Skip');
        getByText('Save & Enter EverLoop');
    });
});
