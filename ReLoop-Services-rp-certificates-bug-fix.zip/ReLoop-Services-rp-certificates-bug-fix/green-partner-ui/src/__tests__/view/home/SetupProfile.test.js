import React from 'react';
import { render } from '../../../utils/testUtils';
import SetupProfile from '../../../view/home/SetupProfile';

describe('Setup Profile Tests', () => {
    it('renders the correct content', () => {
        const { getByText } = render(<SetupProfile />);
        getByText('Welcome to EverLoop!');
        getByText('The marketplace for recycling and refurbishing your electronic assets.');
        getByText(
            'In order to use the platform and be able to create orders, you have to pre-setup your account first.'
        );
        getByText('Setup Profile');
    });
});
