import React from 'react';
import { render, fireEvent } from '../../../utils/testUtils';
import BusinessProfile from '../../../view/home/BusinessProfile';

describe('Business Profile Tests', () => {
    it('renders the correct content', () => {
        const { getByText } = render(<BusinessProfile />);
        getByText('Please add all the additional data needed to complete your');
        getByText('Business Profile');
        getByText('Business Name');
        getByText('Industry Type');
        getByText('Phone Number');
        getByText('GSTIN');
        getByText('CIN');
        getByText('PAN');
        getByText('State');
        getByText('City');
        getByText('Pincode');
        getByText('Company Code');
        getByText('Address');
        getByText('Save');
    });
    it('checks if I can save a business data', async () => {
        const result = render(<BusinessProfile />);
        const { getByText } = result;
        // Click on Save with filling up the input to get validation errors
        const saveButton = getByText('Save');
        fireEvent.click(saveButton);
        getByText('Business Name is required');
        getByText('Industry Type is required');
        getByText('Phone Number is required');
        getByText('Gstin is required');
        getByText('Cin is required');
        getByText('Pan is required');
        getByText('State is required');
        getByText('City is required');
        getByText('Address is required');
    });
});
