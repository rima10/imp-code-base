import {
    isEmpty,
    isEmail,
    isContactNumber,
    isGSTNumber,
    isPANNumber,
    isCompanyCode,
    isPincode
} from '../../validation/common';

describe('Validator Tests', () => {
    it('should return true for empty values', () => {
        let value = '';
        let expected = true;
        expect(isEmpty(value)).toEqual(expected);
        value = '   ';
        expect(isEmpty(value)).toEqual(expected);
        value = [];
        expect(isEmpty(value)).toEqual(expected);
        value = {};
        expect(isEmpty(value)).toEqual(expected);
        value = undefined;
        expect(isEmpty(value)).toEqual(expected);
        value = null;
        expect(isEmpty(value)).toEqual(expected);
    });
    it('should return false for non-empty values', () => {
        let value = 'Some string';
        let expected = false;
        expect(isEmpty(value)).toEqual(expected);
        value = { name: 'John Doe' };
        expect(isEmpty(value)).toEqual(expected);
        value = [1, 2, 3];
        expect(isEmpty(value)).toEqual(expected);
    });
    it('should return true for valid email', () => {
        let value = 'johndoe@everloop.com';
        let expected = true;
        expect(isEmail(value)).toEqual(expected);
    });
    it('should return false for invalid email', () => {
        let value = '';
        let expected = false;
        expect(isEmail(value)).toEqual(expected);
        value = 'johndoe';
        expect(isEmail(value)).toEqual(expected);
        value = 'johndoe@everloop';
        expect(isEmail(value)).toEqual(expected);
        value = 'johndoe@everloop@';
        expect(isEmail(value)).toEqual(expected);
    });
    it('should return true for valid phone number', () => {
        let value = '9877890931';
        let expected = true;
        expect(isContactNumber(value)).toEqual(expected);
    });
    it('should return false for invalid phone number', () => {
        let value = '';
        let expected = false;
        expect(isContactNumber(value)).toEqual(expected);
        value = '98778909';
        expect(isContactNumber(value)).toEqual(expected);
        value = '98778909319';
        expect(isContactNumber(value)).toEqual(expected);
        value = 'abcd';
        expect(isContactNumber(value)).toEqual(expected);
    });
    it('should return true for valid GST number', () => {
        let value = '18AABCU9603R1ZM';
        let expected = true;
        expect(isGSTNumber(value)).toEqual(expected);
    });
    it('should return false for invalid GST number', () => {
        let value = '';
        let expected = false;
        expect(isGSTNumber(value)).toEqual(expected);
        value = '98778909';
        expect(isGSTNumber(value)).toEqual(expected);
        value = '98778909319';
        expect(isGSTNumber(value)).toEqual(expected);
        value = 'abcd';
        expect(isGSTNumber(value)).toEqual(expected);
    });
    it('should return true for valid PAN number', () => {
        let value = 'BDAPN1023C';
        let expected = true;
        expect(isPANNumber(value)).toEqual(expected);
    });
    it('should return false for invalid PAN number', () => {
        let value = '';
        let expected = false;
        expect(isPANNumber(value)).toEqual(expected);
        value = '98778909';
        expect(isPANNumber(value)).toEqual(expected);
        value = '98778909319';
        expect(isPANNumber(value)).toEqual(expected);
        value = 'abcd';
        expect(isPANNumber(value)).toEqual(expected);
    });
    it('should return true for valid Pincode', () => {
        let value = '421391';
        let expected = true;
        expect(isPincode(value)).toEqual(expected);
    });
    it('should return false for invalid Pincode', () => {
        let value = '';
        let expected = false;
        expect(isPincode(value)).toEqual(expected);
        value = '98778909';
        expect(isPincode(value)).toEqual(expected);
        value = '98778909319';
        expect(isPincode(value)).toEqual(expected);
        value = 'abcd';
        expect(isPincode(value)).toEqual(expected);
    });
    it('should return true for valid Company Code', () => {
        let value = '1010';
        let expected = true;
        expect(isCompanyCode(value)).toEqual(expected);
    });
    it('should return false for invalid Company Code', () => {
        let value = '';
        let expected = false;
        expect(isCompanyCode(value)).toEqual(expected);
        value = '98778909';
        expect(isCompanyCode(value)).toEqual(expected);
        value = '98778909319';
        expect(isCompanyCode(value)).toEqual(expected);
        value = 'abcd';
        expect(isCompanyCode(value)).toEqual(expected);
    });
});
