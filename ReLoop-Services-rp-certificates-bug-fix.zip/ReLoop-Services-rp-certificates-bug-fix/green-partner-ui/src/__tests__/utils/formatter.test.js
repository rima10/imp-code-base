import { camelCaseToSentence } from '../../utils/formatter';

describe('Camel Case to Sentence', () => {
    it('should fail to convert the camel case value into sentence format', () => {
        const value = 'ApproverRole';
        const expected = ' Approver Role';
        expect(camelCaseToSentence(value)).toEqual(expected);
    });
    it('should return the camel case value in sentence format', () => {
        const value = 'approverRole';
        const expected = 'Approver Role';
        expect(camelCaseToSentence(value)).toEqual(expected);
    });
});
