export const getWorkflow = (state) => state.account.workflows;

export const getNetworkInfoState = (state) => state.account.networkInfo;

export const isApproverInfoLoading = (state) => state.account.isLoading;

export const getApproverInfoState = (state) => state.account.approverInfo;

export const getUserInfo = (state) => state.userInfo;

export const isOrderInfoLoading = (state) => state.order.isLoading;

export const getOrderInfoState = (state) => state.order.orderInfo;

export const getOrderItemInfoState = (state) => state.order.orderItemInfo;

export const isOrderItemInfoLoading = (state) => state.order.isOrderItemInfoLoading;

export const getConsolidatedOrderItemInfoState = (state) => state.order.consolidatedOrderItemInfo;

export const isConsolidatedOrderItemInfoLoading = (state) => state.order.isConsolidatedOrderItemInfoLoading;

export const getOrderQuotationState = (state) => state.order.orderQuotation;

export const isOrderQuotationLoading = (state) => state.order.isOrderQuotationLoading;

export const getOnsiteDetails = (state) => state.order.onSiteVisitDetails;

export const isOnsiteLoading = (state) => state.order.isOnsiteLoading;

export const getOrderDocInfoState = (state) => state.documents;
