const Information = "Information";
const Positive = "Positive";
const Negative = "Negative";
const Warning = "Warning";

export default {
    Information,
    Positive,
    Negative,
    Warning
};
