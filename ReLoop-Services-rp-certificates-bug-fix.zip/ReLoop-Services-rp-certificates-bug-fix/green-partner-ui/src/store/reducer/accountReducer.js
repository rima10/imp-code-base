import {
    SET_BP_BUSINESS_INFO,
    SET_BP_NETWORK_INFO,
    ACCOUNT_INFO_LOADING,
    ACCOUNT_INFO_FAILED,
    SET_BP_APPROVER_INFO,
    SET_CITIES_INFO,
    SET_STATES_INFO,
    SET_INDUSTRY_INFO,
    SET_WORKFLOW_INFO
} from '../action/type';

export default (state = { isLoading: true, errMsg: null }, action) => {
    const { type, payload } = action;
    switch (type) {
        case SET_BP_BUSINESS_INFO:
            return { ...state, businessInfo: payload };
        case ACCOUNT_INFO_LOADING:
            return { ...state, isLoading: true, errMsg: null };
        case SET_BP_NETWORK_INFO:
            return { ...state, isLoading: false, errMsg: null, networkInfo: payload };
        case ACCOUNT_INFO_FAILED:
            return { ...state, isLoading: false, errMsg: payload };
        case SET_BP_APPROVER_INFO:
            return { ...state, isLoading: false, errMsg: null, approverInfo: payload };
        case SET_STATES_INFO:
            return { ...state, states: payload };
        case SET_CITIES_INFO:
            return { ...state, cities: payload };
        case SET_INDUSTRY_INFO:
            return { ...state, industry: payload };
        case SET_WORKFLOW_INFO:
            return { ...state, isLoading: false, errMsg: null, workflows: payload };
        default:
            return state;
    }
};
