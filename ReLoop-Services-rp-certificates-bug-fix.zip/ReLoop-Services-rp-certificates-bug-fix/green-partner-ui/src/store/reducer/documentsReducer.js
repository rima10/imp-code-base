import {
    SET_ORDER_DOCUMENTS,
    ORDER_DOCUMENTS_LOADING,
    ORDER_DOCUMENTS_FAILED,
    ORDER_DOCUMENTS_LOADED
} from '../action/type';

const initialState = {
    isLoading: true,
    errMsg: null,
    orderDocuments: []
};

export default (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case ORDER_DOCUMENTS_LOADING:
            return { ...state, isLoading: true, errMsg: null };
        case ORDER_DOCUMENTS_LOADED:
            return { ...state, isLoading: false, errMsg: null };
        case ORDER_DOCUMENTS_FAILED:
            return { ...state, isLoading: true, errMsg: payload };
        case SET_ORDER_DOCUMENTS:
            return { ...state, isLoading: false, errMsg: null, orderDocuments: payload };
        default:
            return state;
    }
};
