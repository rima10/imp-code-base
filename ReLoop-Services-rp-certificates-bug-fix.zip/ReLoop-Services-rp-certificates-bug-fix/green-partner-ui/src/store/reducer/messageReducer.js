import {
    SHOW_MSG_TOASTER,
    HIDE_MSG_TOASTER,
    ACCOUNT_INFO_FAILED,
    ORDER_INFO_FAILED,
    ORDER_ITEM_INFO_FAILED,
    CONSOLIDATED_ORDER_ITEM_INFO_FAILED,
    ORDER_QUOTATION_FAILED,
    ONSITE_VISIT_FAILED
} from '../action/type';
import StatusColor from '../../asset/constants/statusColor';

const initialState = {
    show: false,
    status: 'Information',
    message: ''
};

const messageToaster = (state = initialState, action) => {
    const { type, payload } = action;

    switch (type) {
        case SHOW_MSG_TOASTER: {
            return {
                ...state,
                message: payload.message,
                status: payload.status,
                show: true
            };
        }

        case HIDE_MSG_TOASTER: {
            return {
                ...initialState
            };
        }

        case ACCOUNT_INFO_FAILED: {
            return {
                ...state,
                message: payload.error.message,
                status: StatusColor.Negative,
                show: true
            };
        }

        case ORDER_INFO_FAILED:
        case ORDER_ITEM_INFO_FAILED:
        case CONSOLIDATED_ORDER_ITEM_INFO_FAILED:
        case ORDER_QUOTATION_FAILED:
        case ONSITE_VISIT_FAILED: {
            return {
                ...state,
                message: payload,
                status: StatusColor.Negative,
                show: true
            };
        }

        default: {
            return state;
        }
    }
};

export default messageToaster;
