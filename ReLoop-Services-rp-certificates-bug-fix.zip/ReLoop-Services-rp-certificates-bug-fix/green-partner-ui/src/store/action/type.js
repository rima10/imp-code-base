export const SET_USER_INFO = 'SET_USER_INFO';
export const setUserInfo = (userInfo, isLoggedIn) => ({
    type: SET_USER_INFO,
    payload: { userInfo, isLoggedIn }
});


export const SET_LOAD_IN_PROGRESS = 'SET_LOAD_IN_PROGRESS';
export const loadInProgress = () => ({
    type: SET_LOAD_IN_PROGRESS
});

export const SET_LOAD_COMPLETED = 'SET_LOAD_COMPLETED';
export const loadCompleted = () => ({
    type: SET_LOAD_COMPLETED
});

export const SET_BP_BUSINESS_INFO = 'SET_BP_BUSINESS_INFO';
export const setBusinessInfo = (businessInfo) => ({
    type: SET_BP_BUSINESS_INFO,
    payload: businessInfo
});

export const ACCOUNT_INFO_LOADING = "ACCOUNT_INFO_LOADING";
export const ACCOUNT_INFO_FAILED = "ACCOUNT_INFO_FAILED";

export const SET_BP_NETWORK_INFO = "SET_BP_NETWORK_INFO";

export const accountInfoLoading = () => ({
    type: ACCOUNT_INFO_LOADING
});

export const accountInfoFailed = (errMsg) => ({
    type: ACCOUNT_INFO_FAILED,
    payload: errMsg
});

export const setNetworkInfo = (networkInfo) => ({
    type: SET_BP_NETWORK_INFO,
    payload: networkInfo
});

export const SET_BP_APPROVER_INFO = "SET_BP_APPROVER_INFO";

export const setApproverInfo = (approverInfo) => ({
    type: SET_BP_APPROVER_INFO,
    payload: approverInfo
});

export const SET_STATES_INFO = "SET_STATES_INFO";
export const setStatesInfo = (stateInfo) => ({
    type: SET_STATES_INFO,
    payload: stateInfo
});

export const SET_CITIES_INFO = "SET_CITIES_INFO";
export const setCitiesInfo = (cityInfo) => ({
    type: SET_CITIES_INFO,
    payload: cityInfo
});

export const SET_INDUSTRY_INFO = "SET_INDUSTRY_INFO";
export const setIndustryInfo = (industryInfo) => ({
    type: SET_INDUSTRY_INFO,
    payload: industryInfo
});

export const SET_WORKFLOW_INFO = "SET_WORKFLOW_INFO";
export const setWorkflowInfo = (workflowInfo) => ({
    type: SET_WORKFLOW_INFO,
    payload: workflowInfo
});

// Order Info Action Types & Action Creators
export const SET_ORDER_INFO = "SET_ORDER_INFO";
export const ORDER_INFO_LOADING = "ORDER_INFO_LOADING";
export const ORDER_INFO_FAILED = "ORDER_INFO_FAILED";

export const orderInfoLoading = () => ({
    type: ORDER_INFO_LOADING
});

export const setOrderInfo = (orderInfo) => ({
    type: SET_ORDER_INFO,
    payload: orderInfo
});

export const orderInfoFailed = (errMsg) => ({
    type: ORDER_INFO_FAILED,
    payload: errMsg
});

export const SET_ORDER_ITEM_INFO = "SET_ORDER_ITEM_INFO";
export const ORDER_ITEM_INFO_LOADING = "ORDER_ITEM_INFO_LOADING";
export const ORDER_ITEM_INFO_FAILED = "ORDER_ITEM_INFO_FAILED";

export const orderItemInfoLoading = () => ({
    type: ORDER_ITEM_INFO_LOADING
});

export const setOrderItemInfo = (orderItemInfo) => ({
    type: SET_ORDER_ITEM_INFO,
    payload: orderItemInfo
});

export const orderItemInfoFailed = (errMsg) => ({
    type: ORDER_ITEM_INFO_FAILED,
    payload: errMsg
});

export const SET_PREVIEW_ORDER_ITEM_INFO = "SET_PREVIEW_ORDER_ITEM_INFO";
export const CLEAR_PREVIEW_ORDER_ITEMS = "CLEAR_PREVIEW_ORDER_ITEMS";

export const setPreviewOrderItemInfo = (previewOrderItemInfo) => ({
    type: SET_PREVIEW_ORDER_ITEM_INFO,
    payload: previewOrderItemInfo
});

export const clearPreviewOrderItems = () => ({
    type: CLEAR_PREVIEW_ORDER_ITEMS
});

export const SET_CONSOLIDATED_ORDER_ITEM_INFO = "SET_CONSOLIDATED_ORDER_ITEM_INFO";
export const CONSOLIDATED_ORDER_ITEM_INFO_LOADING = "CONSOLIDATED_ORDER_ITEM_INFO_LOADING";
export const CONSOLIDATED_ORDER_ITEM_INFO_FAILED = "CONSOLIDATED_ORDER_ITEM_INFO_FAILED";

export const consolidatedOrderItemInfoLoading = () => ({
    type: CONSOLIDATED_ORDER_ITEM_INFO_LOADING
});

export const setConsolidatedOrderItemInfo = (consolidatedOrderItemInfo) => ({
    type: SET_CONSOLIDATED_ORDER_ITEM_INFO,
    payload: consolidatedOrderItemInfo
});

export const consolidatedOrderItemInfoFailed = (errMsg) => ({
    type: CONSOLIDATED_ORDER_ITEM_INFO_FAILED,
    payload: errMsg
});

export const SET_ORDER_QUOTATION = "SET_ORDER_QUOTATION";
export const ORDER_QUOTATION_LOADING = "ORDER_QUOTATION_LOADING";
export const ORDER_QUOTATION_FAILED = "ORDER_QUOTATION_FAILED";

export const orderQuotationLoading = () => ({
    type: ORDER_QUOTATION_LOADING
});


export const setOrderQuotation = (orderQuotation) => ({
    type: SET_ORDER_QUOTATION,
    payload: orderQuotation
});

export const orderQuotationFailed = (errMsg) => ({
    type: ORDER_QUOTATION_FAILED,
    payload: errMsg
});

export const SET_ORDER_DOCUMENTS = "SET_ORDER_DOCUMENTS";
export const ORDER_DOCUMENTS_LOADING = "ORDER_DOCUMENTS_LOADING";
export const ORDER_DOCUMENTS_FAILED = "ORDER_DOCUMENTS_FAILED";
export const ORDER_DOCUMENTS_LOADED = "ORDER_DOCUMENTS_LOADED";

export const orderDocumentsLoading = () => ({
    type: ORDER_DOCUMENTS_LOADING
});


export const setOrderDocuments = (orderDocuments) => ({
    type: SET_ORDER_DOCUMENTS,
    payload: orderDocuments
});

export const orderDocumentsFailed = (errMsg) => ({
    type: ORDER_DOCUMENTS_FAILED,
    payload: errMsg
});

export const orderDocumentsLoaded = () => ({
    type: ORDER_DOCUMENTS_LOADED
});


export const SHOW_MSG_TOASTER = "SHOW_MSG_TOASTER";
export const HIDE_MSG_TOASTER = "HIDE_MSG_TOASTER";

export const showMessage = (messagePayload) => ({
    type: SHOW_MSG_TOASTER,
    payload: messagePayload
});

export const SET_NOTIFICATION_LIST_INFO = 'SET_NOTIFICATION_LIST_INFO';
export const setNotificationsInfo = (notificationList) => ({
    type: SET_NOTIFICATION_LIST_INFO,
    payload: notificationList
});

export const SET_NOTIFICATION_READ = 'SET_NOTIFICATION_READ';
export const setNotificationRead = (notification) => ({
    type: SET_NOTIFICATION_READ,
    payload: notification
});

export const SET_ORDERTYPE_INFO = "SET_ORDERTYPE_INFO";
export const setOrderTypeInfo = (orderTypeInfo) => ({
    type: SET_ORDERTYPE_INFO,
    payload: orderTypeInfo
});

export const SET_CATEGORY_INFO = "SET_CATEGORY_INFO";
export const setCategoryInfo = (categoryInfo) => ({
    type: SET_CATEGORY_INFO,
    payload: categoryInfo
});
export const SET_SUBCATEGORY_INFO = "SET_SUBCATEGORY_INFO";
export const setSubCategoryInfo = (subcategoryInfo) => ({
    type: SET_SUBCATEGORY_INFO,
    payload: subcategoryInfo
});

export const SET_APPROVER = "SET_APPROVER";
export const setOrderApprover = (approver) => ({
    type: SET_APPROVER,
    payload: approver
});

export const SET_ONSITE_VISIT_DETAILS = "SET_ONSITE_VISIT_DETAILS";
export const ONSITE_VISIT_LOADING = "ONSITE_VISIT_LOADING";
export const ONSITE_VISIT_FAILED = "ONSITE_VISIT_FAILED";

export const setOnsiteVisitDetails = (details) => ({
    type: SET_ONSITE_VISIT_DETAILS,
    payload: details
});

export const onsiteVisitDetailsLoading = () => ({
    type: ONSITE_VISIT_LOADING
});

export const onsiteVisitDetailsFailed = (errMsg) => ({
    type: ONSITE_VISIT_FAILED,
    payload: errMsg
});

export const TEMPORARY_ACCEPT_QUOTE = "TEMPORARY_ACCEPT_QUOTE";
export const setTemporaryAcceptQuote = (payload) => ({
    type: TEMPORARY_ACCEPT_QUOTE,
    payload: payload
});

export const SET_ORDER_ITEM_QUOTATION = "SET_ORDER_ITEM_QUOTATION";
export const setOrderItemQuotation = (orderItemQuotation) => ({
    type: SET_ORDER_ITEM_QUOTATION,
    payload: orderItemQuotation
});

export const hideToast = () => ({
    type: HIDE_MSG_TOASTER
});
