
import {
    setUserInfo,
    loadInProgress,
    loadCompleted,
    setBusinessInfo,
    accountInfoLoading,
    accountInfoFailed,
    setNetworkInfo,
    setApproverInfo,
    setCitiesInfo,
    setStatesInfo,
    setIndustryInfo,
    setWorkflowInfo,
    showMessage,
    setNotificationsInfo,
    setOrderTypeInfo,
    setCategoryInfo,
    setSubCategoryInfo,
    setPreviewOrderItemInfo,
    orderInfoLoading
} from './type';
import { getToken } from '../../utils/authUtils';
import http from '../../utils/httpService';
import { getErrorMessage } from '../../utils/errorMessage';
import { getOrderInfo } from './order';

const API_BASE_URL = process.env.REACT_APPAPI_BASE_URL;


export const validateUser = (tokenObj) => async (dispatch, getState) => {
    try {
        const isLoggedIn = getState().userInfo.isLoggedIn;
        if (!isLoggedIn) {
            dispatch(loadInProgress());
            let params = {
                withCredentials: true
            };
            if (tokenObj) {
                params.headers = {
                    authorization: 'Bearer ' + tokenObj.idToken,
                    refresh: tokenObj.refreshToken
                };
            }
            const response = await http.post(API_BASE_URL + 'auth/validate?app=gp', null, params);
            const userData = await http.get(API_BASE_URL + `user/getUserData/${response.data.cognitoId}?bp=gp`,
                { withCredentials: true });
            dispatch(setUserInfo(userData.data, true));
            dispatch(loadCompleted());
        }
    } catch (error) {
        dispatch(setUserInfo(null, false));
        dispatch(loadCompleted());
    }
};


export const getAccessToken = () => async (dispatch, getState) => {
    const tokenObj = await getToken();
    await validateUser(tokenObj)(dispatch, getState);
};

export const getBusinessInfo = () => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const userId = getState().userInfo.bp_id;
        const response = await http.get(`${API_BASE_URL}user/getBusinessInfo/${userId}`, {
            withCredentials: true
        });
        dispatch(setBusinessInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const getNetworkInfo = () => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const userId = getState().userInfo.bp_id;
        const response = await http.get(`${API_BASE_URL}user/getprivatenetwork/${userId}`, {
            withCredentials: true
        });
        dispatch(setNetworkInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const getApproverInfo = () => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const userId = getState().userInfo.bp_id;
        const response = await http.get(`${API_BASE_URL}user/approver/getApprovers/${userId}`, {
            withCredentials: true
        });
        dispatch(setApproverInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const getStates = () => async (dispatch, getState) => {
    const response = await http.get(`${API_BASE_URL}user/loc/getStatesbyCountry/1`, {
        withCredentials: true
    });
    dispatch(setStatesInfo(response.data));
};

export const getCities = (stateId) => async (dispatch, getState) => {
    const response = await http.get(`${API_BASE_URL}user/loc/getCitiesbyState/${stateId}`, {
        withCredentials: true
    });
    dispatch(setCitiesInfo(response.data));
};

export const getIndustry = () => async (dispatch, getState) => {
    dispatch(setIndustryInfo(['IT & Telecommunications', 'Oil & Gas', 'Retail', 'Mining', 'Public Sector',
        'High Tech', 'Banking', 'Higher Education']));
};

export const updateBusinessInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const userId = getState().userInfo.bp_id;
        await http.patch(`${API_BASE_URL}user/update/${userId}`, payload, {
            withCredentials: true
        });
        await getBusinessInfo()(dispatch, getState);
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
        console.log(error);
        throw new Error(error);
    }
};

export const registerBPApproverInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const userId = getState().userInfo.bp_id;
        await http.post(`${API_BASE_URL}user/approver/addApprovers/${userId}`, payload, {
            withCredentials: true
        });
        await getApproverInfo()(dispatch, getState);
        dispatch(showMessage({ message: 'Approver Added', status: 'Positive' }));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
        throw new Error(error);
    }
};

export const registerBPNetworkInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const userId = getState().userInfo.bp_id;
        await http.post(`${API_BASE_URL}user/createPrivateNetwork/${userId}?bp=gp`, payload, {
            withCredentials: true
        });
        await getNetworkInfo()(dispatch, getState);
        dispatch(showMessage({ message: 'Private Network Added', status: 'Positive' }));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
        throw new Error(error);
    }
};

export const getWorkflowsInfo = () => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const userId = getState().userInfo.bp_id;
        const response = await http.get(`${API_BASE_URL}user/workflow/getWorkflows/${userId}`, {
            withCredentials: true
        });
        dispatch(setWorkflowInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const registerBPWorkflowInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const userId = getState().userInfo.bp_id;
        await http.post(`${API_BASE_URL}user/workflow/addWorkflow/${userId}`, payload, {
            withCredentials: true
        });
        await getWorkflowsInfo()(dispatch, getState);
        dispatch(showMessage({ message: 'Workflow Added', status: 'Positive' }));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
        throw new Error(error);
    }
};

export const updateOrderInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(orderInfoLoading());
        const userId = getState().userInfo.bp_id;
        await http.post(`${API_BASE_URL}order/createOrder/${userId}`, payload, {
            withCredentials: true
        });
        dispatch(getOrderInfo()(dispatch, getState));
    } catch (error) {
        console.log(error);
    }
};

export const deleteBPNetworkInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const userId = getState().userInfo.bp_id;
        await http.delete(`${API_BASE_URL}user/deleteprivatenetwork/${userId}`, {
            data: payload,
            withCredentials: true
        });
        await getNetworkInfo()(dispatch, getState);
        dispatch(showMessage({ message: 'Private Network Deleted', status: 'Positive' }));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const deleteBPApproverInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const userId = getState().userInfo.bp_id;
        const response = await http.delete(
            `${API_BASE_URL}user/approver/deleteApprovers/${userId}`,
            {
                data: payload,
                withCredentials: true
            }
        );
        dispatch(setApproverInfo(response.data));
        dispatch(showMessage({ message: 'Approver Deleted', status: 'Positive' }));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const readExcelInfo = (payload) => async (dispatch, getState) => {
    try {
        const response = await http.post(`${API_BASE_URL}order/orderItem/readExcel`, payload, {
            withCredentials: true
        });
        if (response.data.length === 0) {
            dispatch(showMessage({ message: 'No asset data present in excel', status: 'Negative' }));
        } else dispatch(setPreviewOrderItemInfo(response.data));
    } catch (error) {
        console.log(error);
    }
};

export const deleteBPWorkflowInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const userId = getState().userInfo.bp_id;
        const workflowId = payload;
        const response = await http.delete(
            `${API_BASE_URL}user/workflow/deleteWorkflow/${userId}/${workflowId}`,
            {
                withCredentials: true
            }
        );
        dispatch(setWorkflowInfo(response.data));
        dispatch(showMessage({ message: 'Workflow Deleted', status: 'Positive' }));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const deleteBPWorkflowApproverInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        await http.delete(`${API_BASE_URL}user/workflow/deleteWorkflowApprover`, {
            data: payload,
            withCredentials: true
        });
        await getWorkflowsInfo()(dispatch, getState);
        dispatch(showMessage({ message: 'Workflow Approver Deleted', status: 'Positive' }));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const getNotificationInfo = () => async (dispatch, getState) => {
    try {
        const userId = getState().userInfo.bp_id;
        const notifications = await
        http.get(`${API_BASE_URL}notification/getNotifications/${userId}?$skip=0&top=5`,
            { withCredentials: true });
        dispatch(setNotificationsInfo(notifications.data));
    } catch (error) {
        console.log(error);
    }
};

export const readNotification = (bpNotificationId) => async (dispatch, getState) => {
    try {
        await http.post(`${API_BASE_URL}notification/readNotification/${bpNotificationId}`, null,
            { withCredentials: true });
        dispatch(getNotificationInfo()(dispatch, getState));
    } catch (error) {
        console.log(error);
    }
};

export const updateDraftOrderInfo = (payload) => async (dispatch, getState) => {
    try {
        dispatch(orderInfoLoading());
        const userId = getState().userInfo.bp_id;
        await http.post(`${API_BASE_URL}order/createOrderAsDraft/${userId}`, payload, {
            withCredentials: true
        });
    } catch (error) {
        console.log(error);
    }
};

export const getOrderType = () => async (dispatch, getState) => {
    const response = await http.get(`${API_BASE_URL}order/getOrderType`, {
        withCredentials: true
    });
    dispatch(setOrderTypeInfo(response.data));
};

export const getCategory = () => async (dispatch, getState) => {
    const response = await http.get(`${API_BASE_URL}wasteCategory/getCategory`, {
        withCredentials: true
    });
    dispatch(setCategoryInfo(response.data));
};

export const getSubCategory = () => async (dispatch, getState) => {
    const response = await http.get(`${API_BASE_URL}wasteCategory/getsubCategory/1`, {
        withCredentials: true
    });
    dispatch(setSubCategoryInfo(response.data));
};

export const getPrivateNetworkRecyclers = () => async (dispatch, getState) => {
    try {
        dispatch(accountInfoLoading(true));
        const userId = getState().userInfo.bp_id;
        const response = await http.get(`${API_BASE_URL}order/privatenetwork/${userId}`, {
            withCredentials: true
        });
        dispatch(setNetworkInfo(response.data));
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        dispatch(accountInfoFailed(errorMessage));
    }
};

export const downloadFile = async (key) => {
    try {
        const response = await http.get(`${API_BASE_URL}order/document/downloadDocument/${key}`, {
            responseType: 'arraybuffer',
            withCredentials: true
        });
        const responseBlob = new Blob([response.data]);
        const url = window.URL.createObjectURL(responseBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = key;
        a.click();
    } catch (error) {
        let errorMessage = getErrorMessage(error);
        console.log(errorMessage);
    }
};

