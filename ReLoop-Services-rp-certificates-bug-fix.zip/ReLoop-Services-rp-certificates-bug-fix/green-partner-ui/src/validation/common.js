import { camelCaseToSentence } from '../utils/formatter';
import {
    EMAIL_REGEX,
    PHONE_REGEX,
    PAN_REGEX,
    GST_REGEX,
    COMPANYCODE_REGEX,
    PINCODE_REGEX
} from '../asset/constants/constant';

const isEmpty = (value) =>
    value === undefined ||
    value === null ||
    (typeof value === 'object' && Object.keys(value).length === 0) ||
    (typeof value === 'string' && value.trim().length === 0);

const isEmail = (value) => EMAIL_REGEX.test(value);

const isContactNumber = (value) => PHONE_REGEX.test(value);

const isGSTNumber = (value) => GST_REGEX.test(value);

const isPANNumber = (value) => PAN_REGEX.test(value);

const isCompanyCode = (value) => COMPANYCODE_REGEX.test(value);

const isPincode = (value) => PINCODE_REGEX.test(value);

const validateEmail = (value) => {
    let errorMessage = '';
    if (!isEmail(value)) {
        errorMessage = 'Enter valid Email';
    }
    if (isEmpty(value)) {
        errorMessage = 'Email is required';
    }
    return {
        errorMessage,
        isValid: isEmpty(errorMessage)
    };
};

const validateContactNumber = (value) => {
    let errorMessage = '';
    if (!isContactNumber(value)) {
        errorMessage = 'Enter valid Number';
    }
    if (isEmpty(value)) {
        errorMessage = 'Phone Number is required';
    }
    return {
        errorMessage,
        isValid: isEmpty(errorMessage)
    };
};

const validateIsEmpty = (value, field) => {
    let errorMessage = '';
    if (isEmpty(value)) {
        let fieldName = camelCaseToSentence(field);
        errorMessage = `${fieldName} is required`;
    }
    return {
        errorMessage,
        isValid: isEmpty(errorMessage)
    };
};

const validateGST = (value) => {
    let errorMessage = '';
    if (!isGSTNumber(value)) {
        errorMessage = 'Enter valid GST Number';
    }
    if (isEmpty(value)) {
        errorMessage = 'GST Number is required';
    }
    return {
        errorMessage,
        isValid: isEmpty(errorMessage)
    };
};

const validatePAN = (value) => {
    let errorMessage = '';
    if (!isPANNumber(value)) {
        errorMessage = 'Enter valid PAN Number';
    }
    if (isEmpty(value)) {
        errorMessage = 'PAN Number is required';
    }
    return {
        errorMessage,
        isValid: isEmpty(errorMessage)
    };
};

const validateCompanyCode = (value) => {
    let errorMessage = '';
    if (!isCompanyCode(value)) {
        errorMessage = 'Enter valid Company Code';
    }
    if (isEmpty(value)) {
        errorMessage = 'Company Code is required';
    }
    return {
        errorMessage,
        isValid: isEmpty(errorMessage)
    };
};

const validatePincode = (value) => {
    let errorMessage = '';
    if (!isPincode(value)) {
        errorMessage = 'Enter valid Pincode';
    }
    if (isEmpty(value)) {
        errorMessage = 'Pincode is required';
    }
    return {
        errorMessage,
        isValid: isEmpty(errorMessage)
    };
};

export {
    isEmpty,
    isEmail,
    isContactNumber,
    isGSTNumber,
    isPANNumber,
    isCompanyCode,
    isPincode,
    validateEmail,
    validateContactNumber,
    validateIsEmpty,
    validateGST,
    validatePAN,
    validateCompanyCode,
    validatePincode
};
