import { validateEmail, validateContactNumber, validateIsEmpty } from './common';

const validateInput = (value, field) => {
    if (field === 'emailAddress') {
        return validateEmail(value);
    } else if (field === 'phoneNumber') {
        return validateContactNumber(value);
    } else if (field === 'approverRole') {
        return validateIsEmpty(value, field);
    } else if (field === 'approverName') {
        return validateIsEmpty(value, field);
    } else {
        return { isValid: true, errorMessage: '' };
    }
};

export default validateInput;
