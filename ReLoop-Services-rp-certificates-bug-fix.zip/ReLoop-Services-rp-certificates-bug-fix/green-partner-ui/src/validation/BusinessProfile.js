import {
    validateContactNumber,
    validateGST,
    validateIsEmpty,
    validatePAN,
    validateCompanyCode,
    validatePincode
} from './common';

const validateInput = (value, field) => {
    if (field === 'businessName') {
        return validateIsEmpty(value, field);
    } else if (field === 'gstin') {
        return validateGST(value);
    } else if (field === 'pan') {
        return validatePAN(value);
    } else if (field === 'cin') {
        return validateIsEmpty(value, field);
    } else if (field === 'companyCode') {
        return validateCompanyCode(value);
    } else if (field === 'phoneNumber') {
        return validateContactNumber(value, field);
    } else if (field === 'address') {
        return validateIsEmpty(value, field);
    } else if (field === 'pincode') {
        return validatePincode(value);
    } else {
        return { isValid: true, errorMessage: '' };
    }
};

export default validateInput;
