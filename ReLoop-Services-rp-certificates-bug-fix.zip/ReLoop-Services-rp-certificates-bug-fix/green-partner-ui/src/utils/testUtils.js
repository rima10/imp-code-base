/* eslint-disable react/prop-types */
import React from 'react';
import { render as rtlRender } from '@testing-library/react';
import { configureStore } from '@reduxjs/toolkit';
import { Provider } from 'react-redux';
// Import reducers
import account from '../store/reducer/accountReducer';
import userInfo from '../store/reducer/loginReducer';
import isLoading from '../store/reducer/loadingReducer';
import order from '../store/reducer/orderReducer';
import messageToaster from '../store/reducer/messageReducer';
import notification from '../store/reducer/notificationReducer';
import documents from '../store/reducer/documentsReducer';

function render (
    ui,
    {
        preloadedState,
        store = configureStore({
            reducer: {
                account: account,
                userInfo: userInfo,
                isLoading: isLoading,
                order: order,
                toast: messageToaster,
                notification: notification,
                documents: documents
            },
            preloadedState
        }),
        ...renderOptions
    } = {}
) {
    function Wrapper ({ children }) {
        return <Provider store={store}>{children}</Provider>;
    }
    return rtlRender(ui, { wrapper: Wrapper, ...renderOptions });
}

// re-export everything
export * from '@testing-library/react';
// override render method
export { render };
