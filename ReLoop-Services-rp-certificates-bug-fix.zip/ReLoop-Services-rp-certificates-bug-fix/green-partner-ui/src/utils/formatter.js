const camelCaseToSentence = (value) => {
    value = value.trim();
    let temp = value.replace(/([A-Z])/g, ' $1');
    let sentence = temp.charAt(0).toUpperCase() + temp.slice(1);
    return sentence;
};

export { camelCaseToSentence };
