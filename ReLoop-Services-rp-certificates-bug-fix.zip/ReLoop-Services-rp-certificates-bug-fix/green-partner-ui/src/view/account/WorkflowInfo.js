import React, { useEffect } from "react";
import PropTypes from 'prop-types';
import { connect } from "react-redux";
import {
    Label,
    Panel,
    Toolbar,
    Text,
    Title
} from "@ui5/webcomponents-react";
import { spacing } from "@ui5/webcomponents-react-base";
import RecyclingWorkflow from "./RecyclingWorkflow";
import bg from '../../asset/images/background-image.png';
import RefurbishingWorkflow from "./RefurbishingWorkflow";
import { getWorkflowsInfo, getApproverInfo } from "../../store/action/taskAction";
import { getWorkflow } from "../../selectors/common";

const WorkflowInfo = ({ startGetWorkflowsInfo, startGetApproverInfo, workflowsInfo }) => {
    useEffect(() => {
        startGetWorkflowsInfo();
        startGetApproverInfo();
    }, []);
    const recycleWorkflows = [];
    const refurbishWorkflows = [];
    if (workflowsInfo.length) {
        workflowsInfo.map((workflow) => {
            // eslint-disable-next-line camelcase
            const { process_type_id } = workflow;
            // eslint-disable-next-line camelcase
            if (process_type_id === "1") refurbishWorkflows.push(workflow);
            else recycleWorkflows.push(workflow);
        });
    }
    return (
        <div style={{ display: "flex", flexDirection: "column" }}>
            <div style={{ backgroundImage: `url(${bg})`, width: "100%", height: "270px", textAlign: "center" }}>
                <Title style={{
                    fontSize: "x-large",
                    textAlign: "center",
                    marginTop: "80px",
                    color: "#000000"
                }}><b> Approval Workflow</b></Title>
                <Label wrap style={{
                    fontSize: "large",
                    textAlign: "center",
                    marginTop: "20px",
                    color: "#000000"
                }}> Please select the approvers that you created in the previous steps in order to assign them to
                 the approval process below
                </Label>

            </div>

            <Label
                style={{ fontWeight: 'Bold', ...spacing.sapUiMediumMargin, fontSize: "1.3rem" }}>
                Define workflow for Approval Process
            </Label>
            <div style={spacing.sapUiMediumMargin}>
                <Panel
                    accessibleRole="Region"
                    className=""
                    headerLevel="H2"
                    headerText="Recycling"
                    header={
                        <Toolbar toolbarStyle="Clear">
                            <Text>Recycling</Text>
                            {/* <ToolbarSpacer />
                            <Switch
                                style= {{ zoom: '0.7' }}
                                checked={isOnSiteRequestForRecycle}
                                onChange={handleOnSiteRequestForRecycleToggle}
                            /> */}
                        </Toolbar>
                    }
                    collapsed
                >
                    <RecyclingWorkflow
                        workflows={recycleWorkflows}
                    />
                </Panel>
                <Panel
                    accessibleRole="Region"
                    className=""
                    headerLevel="H2"
                    headerText="Refurbishing"
                    collapsed
                    header={
                        <Toolbar toolbarStyle="Clear">
                            <Text>Refurbishing</Text>
                            {/* <ToolbarSpacer />
                             <Switch
                                style= {{ zoom: '0.7' }}
                                checked={isOnSiteRequestForRefurbish}
                                onChange={handleOnSiteRequestForRefurbishToggle}
                            />  */}
                        </Toolbar>
                    }
                >
                    <RefurbishingWorkflow
                        workflows={refurbishWorkflows}
                    />
                </Panel>
            </div>
        </div>
    );
};
const mapStateToProps = (state) => {
    return {
        workflowsInfo: getWorkflow(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetWorkflowsInfo: () => dispatch(getWorkflowsInfo()),
        startGetApproverInfo: () => dispatch(getApproverInfo())
    };
};

WorkflowInfo.propTypes = {
    startGetWorkflowsInfo: PropTypes.func,
    startGetApproverInfo: PropTypes.func,
    workflowsInfo: PropTypes.array
};

WorkflowInfo.defaultProps = {
    workflowsInfo: []
};

export default connect(mapStateToProps, mapDispatchToProps)(WorkflowInfo);
