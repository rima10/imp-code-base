import React, { useEffect, useState, useRef } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Label, Title, Toast } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import bg from '../../asset/images/background-image.png';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport.js';
import AccountTable from '../common/Table';
import { EMAIL_REGEX } from '../../asset/constants/constant';
import {
    getNetworkInfo,
    registerBPNetworkInfo,
    deleteBPNetworkInfo
} from '../../store/action/taskAction';
import {
    getNetworkInfoState,
    isApproverInfoLoading
} from '../../selectors/common';

const NetworkInfoView = ({
    startGetNetworkInfo,
    startRegisterBPNetworkInfo,
    networkInfo,
    isLoading,
    startDeleteBPNetworkInfo
}) => {
    const [rows, setRows] = useState([]);
    const [isNewRow, setIsNewRow] = useState(false);
    const [selectedRow, setSelectedRow] = useState([]);
    const [newNetworks, setNewNetworks] = useState({});
    const [errorMessage, setErrorMessage] = useState("");
    const toast = useRef();
    const stateRef = useRef();
    stateRef.current = selectedRow;
    const newNetRef = useRef({});
    newNetRef.current = newNetworks;

    const initializeState = () => {
        setIsNewRow(false);
    };
    const isRowSelected = async (event, rowNumber) => {
        event.preventDefault();
        let row = stateRef.current;
        const index = row.indexOf(rowNumber);
        if (index > -1) {
            row.splice(index, 1);
        } else {
            row.push(rowNumber);
        }
        setSelectedRow(row);
    };
    const getRowsFromNetworkInfo = (networkInfo) => {
        const newRows = [];
        // can be simply networkInfo.length
        if (Object.keys(networkInfo).length !== 0) {
            networkInfo.map((network) => {
                const row = [
                    {
                        type: 'checkbox',
                        onInputChange: isRowSelected,
                        disabled: false
                    }
                ];
                const keys = Object.keys(network.nwk_member_business_partner);
                keys.map((key) => {
                    if (['bp_email_id', 'bp_phone_number', 'bp_username'].includes(key)) {
                        row.push({
                            name: key,
                            value: network.nwk_member_business_partner[key],
                            type: 'text'
                        });
                    }
                });
                newRows.push(row);
            });
        }
        return newRows;
    };

    const updateNetworkList = (networkInfo) => {
        const newRows = getRowsFromNetworkInfo(networkInfo);
        setRows(newRows);
    };

    useEffect(() => {
        startGetNetworkInfo();
    }, []);

    useEffect(() => {
        updateNetworkList(networkInfo);
        initializeState();
    }, [networkInfo.length]);

    const saveNetworkInfo = async (event) => {
        event.preventDefault();
        const payload = { pvtNwkMembers: [] };
        const networks = newNetRef.current;
        for (const key in networks) {
            const network = networks[key];
            if (!EMAIL_REGEX.test(network.email)) {
                setErrorMessage("Please enter valid Email Address");
                toast.current.show();
                return;
            }
            payload.pvtNwkMembers.push({
                emailId: network.email,
                username: network.name,
                phoneNumber: network.number
            });
        }
        startRegisterBPNetworkInfo(payload);
        setNewNetworks({});
    };

    const inputChange = (event) => {
        const { slot } = event.currentTarget.parentElement.parentElement;
        const { name, value } = event.target;
        const { current } = newNetRef;
        const networks = { ...current };
        if (networks[slot]) networks[slot][name] = value;
        else {
            networks[slot] = {};
            networks[slot][name] = value;
        }
        setNewNetworks(networks);
    };


    const onAddRowClick = () => {
        setIsNewRow(true);
        const row = [];
        row.push({
            type: 'checkbox',
            onInputChange: isRowSelected,
            disabled: true
        });
        row.push({ name: 'email', value: 'email', type: 'input', onInputChange: inputChange });
        row.push({ name: 'name', value: 'name', type: 'input', onInputChange: inputChange });
        row.push({ name: 'number', value: 'number', type: 'input', onInputChange: inputChange });
        const existingRows = [...rows];
        existingRows.push(row);
        setRows(existingRows);
    };

    const onCancel = async (event) => {
        event.preventDefault();
        setIsNewRow(false);
        const newRows = getRowsFromNetworkInfo(networkInfo);
        setRows(newRows);
    };

    const onDeleteClick = async (event) => {
        event.preventDefault();
        const rowsToDelete = stateRef.current;
        const payload = { pvtNetworks: [] };
        rowsToDelete.map((row) => {
            payload.pvtNetworks.push({
                recyclerId: networkInfo[row].nwk_member,
                networkId: networkInfo[row].bp_nwk_id
            });
        });
        startDeleteBPNetworkInfo(payload);
        setSelectedRow([]);
    };

    const buttons = [
        {
            name: 'Save',
            icon: 'save',
            onClick: saveNetworkInfo,
            disabled: !isNewRow
        },
        {
            name: 'Cancel',
            icon: 'decline',
            onClick: onCancel,
            disabled: !isNewRow
        },
        {
            name: 'Add',
            icon: 'add',
            onClick: onAddRowClick
        },
        {
            name: 'Delete',
            icon: 'delete',
            onClick: onDeleteClick
        }
    ];

    const columns = ['', 'Email ID', 'Business Name', 'Contact Number'];

    return (
        <div style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ backgroundImage: `url(${bg})`, width: "100%", height: "270px", textAlign: "center" }}>
                <Title style={{
                    fontSize: "x-large",
                    textAlign: "center",
                    marginTop: "80px",
                    color: "#000000"
                }}><b> Private Network</b></Title>
                <Label wrap style={{
                    fontSize: "large",
                    textAlign: "center",
                    marginTop: "20px",
                    color: "#000000"
                }}>Add your existing/new vendors as part of your Private Network</Label>

            </div>

            <AccountTable
                selectedRow={selectedRow}
                isLoading={isLoading}
                buttons={buttons}
                columns={columns}
                rows={rows}
                edit={false}
            />
            <Toast ref={toast}>{errorMessage}</Toast>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        networkInfo: getNetworkInfoState(state),
        isLoading: isApproverInfoLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetNetworkInfo: () => dispatch(getNetworkInfo()),
        startRegisterBPNetworkInfo: (payload) => dispatch(registerBPNetworkInfo(payload)),
        startDeleteBPNetworkInfo: (payload) => dispatch(deleteBPNetworkInfo(payload))
    };
};


NetworkInfoView.propTypes = {
    startGetNetworkInfo: PropTypes.func,
    startRegisterBPNetworkInfo: PropTypes.func,
    networkInfo: PropTypes.array,
    isLoading: PropTypes.bool,
    startDeleteBPNetworkInfo: PropTypes.func
};

NetworkInfoView.defaultProps = {
    networkInfo: []
};

export default connect(mapStateToProps, mapDispatchToProps)(NetworkInfoView);
