import React, { useEffect, useState, useRef } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Label, Input, Select, Title, Option, TextArea, Button, Toast, FlexBox } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import bg from '../../asset/images/background-image.png';
import '@ui5/webcomponents/dist/features/InputElementsFormSupport.js';
import { getBusinessInfo, updateBusinessInfo, getStates, getIndustry, getCities } from '../../store/action/taskAction';
import { GST_REGEX, GST_MAXLENGTH, PAN_REGEX, PHONE_LENGTH, COMPANYCODE_LENGTH,
    PINCODE_REGEX, CIN_NO_LENGTH } from '../../asset/constants/constant';

const BusinessInfoForm = ({
    startUpdateBusinessInfo,
    startGetStates,
    startGetCities,
    startGetIndustry,
    startGetBusinessInfo,
    businessInfo,
    industry,
    states,
    cities,
    onBiSave
}) => {
    const toast = useRef();

    const [errorMessage, setErrorMessage] = useState('');

    const [isGSTValid, setIsGstValid] = useState(true);
    const [isPANValid, setIsPANValid] = useState(true);
    const [isPhoneValid, setIsPhoneValid] = useState(true);
    const [isCompanyCodeValid, setIsCompanyCodeValid] = useState(true);
    const [isPincodeValid, setIsPincodeValid] = useState(true);
    const [isCINValid, setIsCINValid] = useState(true);

    useEffect(() => {
        startGetBusinessInfo();
        startGetIndustry();
        startGetStates();
    }, []);
    useEffect(() => {
        if (businessInfo.location) {
            startGetCities(businessInfo.location.stateId);
        }
    }, [businessInfo.location]);
    const getCity = (stateID) => {
        startGetCities(stateID);
    };
    const submitBusinessInfoForm = async (event) => {
        event.preventDefault();
        let msg = '';
        let flag = 0;
        const { bpPhoneNumber, cin, gstNumber, industryType, location } = businessInfo;

        if (!isPANValid || !isGSTValid || !isPhoneValid || !isCompanyCodeValid || !isPincodeValid || !isCINValid) {
            if (!isPANValid) {
                msg += 'PAN';
                flag = 1;
            }
            if (!isGSTValid) {
                if (flag === 1) {
                    msg += ' and ';
                }
                msg += ' GSTIN';
                flag = 1;
            }
            if (!isPhoneValid) {
                if (flag === 1) {
                    msg += ' and ';
                }

                msg += ' Phone Number';
                flag = 1;
            }
            if (!isCompanyCodeValid) {
                if (flag === 1) {
                    msg += ' and ';
                }

                msg += ' Company Code';
            }
            if (!isPincodeValid) {
                if (flag === 1) {
                    msg += ' and ';
                }

                msg += ' Pin Code';
            }
            if (!isCINValid) {
                if (flag === 1) {
                    msg += ' and ';
                }

                msg += ' Pin Code';
            }
            setErrorMessage('Please Enter Valid ' + msg);
            toast.current.show();
            return;
        // eslint-disable-next-line max-len
        } else if (bpPhoneNumber == null || cin == null || gstNumber == null || industryType == null || location.stateId === undefined || location.cityId === undefined || location.pincode === undefined || location.locDetails === undefined || industryType === "Select Industry Type") {
            msg = 'Please Enter all mandatory fields';
            setErrorMessage(msg);
            toast.current.show();
            return;
        } else {
            businessInfo.location.country = '1';
            startUpdateBusinessInfo(businessInfo);
            onBiSave();
        }
    };
    const inputChange = (event) => {
        const { name, value } = event.target;
        if (name === 'locDetails' || name === 'pincode') {
            businessInfo.location = businessInfo.location ? businessInfo.location : {};
            businessInfo.location[name] = value;
        } else businessInfo[name] = value;
    };
    const validateGST = (event) => {
        const { value } = event.target;
        if (!GST_REGEX.test(value)) {
            setIsGstValid(false);
        } else {
            setIsGstValid(true);
            inputChange(event);
        }
    };
    const validatePAN = (event) => {
        const { value } = event.target;
        if (!PAN_REGEX.test(value)) {
            setIsPANValid(false);
        } else {
            setIsPANValid(true);
            inputChange(event);
        }
    };
    const validatePhone = (event) => {
        const { value } = event.target;
        if (value.length === 10) {
            setIsPhoneValid(true);
            inputChange(event);
        } else {
            setIsPhoneValid(false);
        }
    };
    const validateCompanyCode = (event) => {
        const { value } = event.target;
        if (value.length === 4) {
            setIsCompanyCodeValid(true);
            inputChange(event);
        } else {
            setIsCompanyCodeValid(false);
        }
    };
    const validateCIN = (event) => {
        const { value } = event.target;
        if (value.length === 21) {
            setIsCINValid(true);
            inputChange(event);
        } else {
            setIsCINValid(false);
        }
    };
    const validatePinCode = (event) => {
        const { value } = event.target;
        if (value.length === 6 && PINCODE_REGEX.test(value)) {
            setIsPincodeValid(true);
            inputChange(event);
        } else {
            setIsPincodeValid(false);
        }
    };
    const selectStateChange = (e) => {
        businessInfo.location = businessInfo.location ? businessInfo.location : {};
        businessInfo.location.stateId = e.detail.selectedOption.value;
        getCity(e.detail.selectedOption.value);
    };
    const selectCityChange = (e) => {
        businessInfo.location = businessInfo.location ? businessInfo.location : {};
        businessInfo.location.cityId = e.detail.selectedOption.value;
    };
    const selectIndustryChange = (e) => {
        businessInfo[e.target.name] = e.detail.selectedOption.innerText;
    };
    const { industryType, gstNumber, cin, pan, bpPhoneNumber, companyCode, bpUsername, location = {} } = businessInfo;
    const { pincode, stateId, cityId, locDetails } = location;
    return (
        <FlexBox alignItems="Center" direction="Column" justifyContent="SpaceBetween">
            <div style={{ backgroundImage: `url(${bg})`, width: '100%', height: '270px', textAlign: 'center' }}>
                <Title
                    style={{
                        fontSize: 'x-large',
                        textAlign: 'center',
                        marginTop: '80px',
                        color: '#000000'
                    }}
                >
                    <b> Business Information </b>
                </Title>
                <Label
                    wrap
                    style={{
                        fontSize: 'large',
                        marginTop: '20px',
                        color: '#000000'
                    }}
                >
                    {' '}
                    Please add all the additional data needed to complete your Business Profile
                </Label>
            </div>
            <FlexBox alignItems="Start" justifyContent="SpaceBetween">
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label style={{ fontSize: 'large', marginTop: '2rem', display: 'block' }}>Business Name</Label>
                    <Label style={{ fontSize: 'large', marginTop: '2rem', display: 'block' }}>Industry Type </Label>
                    <Label style={{ fontSize: 'large', marginTop: '2.5rem', display: 'block' }}>GSTIN</Label>
                    <Label style={{ fontSize: 'large', marginTop: '2rem', display: 'block' }}>CIN Number</Label>
                    <Label style={{ fontSize: 'large', marginTop: '2rem', display: 'block' }}>PAN</Label>
                    <Label style={{ fontSize: 'large', marginTop: '2rem', display: 'block' }}>Phone Number</Label>
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '3rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2.5rem', display: 'block' }} />
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Input
                        style={{ marginTop: '2rem', display: 'block' }}
                        name="businessName"
                        value={bpUsername}
                        readonly
                    >
                        {bpUsername}
                    </Input>
                    <Select
                        style={{ marginTop: '1rem', display: 'block', width: '100px' }}
                        name="industryType"
                        onChange={selectIndustryChange}
                    >
                        <Option key="-1" id="-1" name="-" value="-">
                            Select Industry Type
                        </Option>
                        {industry.map((indus) => {
                            return (
                                <Option selected={indus === industryType} key={indus} value={indus}>
                                    {indus}
                                </Option>
                            );
                        })}
                    </Select>
                    <Input
                        style={{ marginTop: '1.5rem', display: 'block' }}
                        name="gstNumber"
                        valueState={isGSTValid ? 'None' : 'Error'}
                        maxlength={GST_MAXLENGTH}
                        value={gstNumber}
                        onChange={(e) => {
                            validateGST(e);
                        }}
                        placeholder="Enter GSTIN"
                    />
                    <Input
                        style={{ marginTop: '1.5rem', display: 'block' }}
                        name="cin"
                        value={cin}
                        maxlength={CIN_NO_LENGTH}
                        valueState={isCINValid ? 'None' : 'Error'}
                        onChange={(e) => {
                            validateCIN(e);
                        }}
                        placeholder="Enter CIN Number"
                    />
                    <Input
                        style={{ marginTop: '1.25rem', display: 'block' }}
                        name="pan"
                        placeholder="Enter PAN"
                        valueState={isPANValid ? 'None' : 'Error'}
                        value={pan}
                        onChange={(e) => {
                            validatePAN(e);
                        }}
                    />
                    <Input
                        style={{ marginTop: '1.25rem', display: 'block' }}
                        name="bpPhoneNumber"
                        placeholder="Enter Business phone number"
                        valueState={isPhoneValid ? 'None' : 'Error'}
                        maxlength={PHONE_LENGTH}
                        value={bpPhoneNumber}
                        onChange={(e) => {
                            validatePhone(e);
                        }}
                    />
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label style={{ fontSize: 'large', marginLeft: '7rem', marginTop: '2rem', display: 'block' }}>
                        State
                    </Label>
                    <Label style={{ fontSize: 'large', marginLeft: '7rem', marginTop: '2rem', display: 'block' }}>
                        City
                    </Label>
                    <Label style={{ fontSize: 'large', marginLeft: '7rem', marginTop: '2rem', display: 'block' }}>
                        Pincode
                    </Label>
                    <Label style={{ fontSize: 'large', marginLeft: '7rem', marginTop: '2rem', display: 'block' }}>
                        Company Code
                    </Label>
                    <Label style={{ fontSize: 'large', marginLeft: '7rem', marginTop: '2rem', display: 'block' }}>
                        Address
                    </Label>
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '3rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2rem', display: 'block' }} />
                    <Label style={{ marginLeft: '2.5rem', display: 'block' }} />
                </FlexBox>
                <FlexBox direction="Column" justifyContent="SpaceBetween">
                    <Select
                        style={{ marginTop: '1.5rem', display: 'block' }}
                        name="state"
                        onChange={(e) => {
                            selectStateChange(e);
                        }}
                    >
                        <Option key="-1" id="-1" name="-" value="-">
                            Select State
                        </Option>
                        {states.map((stateVal) => (
                            <Option
                                selected={stateVal.state_id === stateId}
                                key={stateVal.state_id}
                                value={stateVal.state_id}
                            >
                                {stateVal.state_name}
                            </Option>
                        ))}
                    </Select>
                    <Select
                        style={{ marginTop: '1.5rem', display: 'block' }}
                        name="city"
                        onChange={(e) => {
                            selectCityChange(e);
                        }}
                        disabled={states.length}
                    >
                        <Option key="-1" id="-1" name="-" value="-">
                            Select City
                        </Option>
                        {cities.map((cityVal) => (
                            <Option selected={cityVal.city_id === cityId} key={cityVal.city_id} value={cityVal.city_id}>
                                {cityVal.city_name}
                            </Option>
                        ))}
                    </Select>
                    <Input
                        style={{ marginTop: '1.5rem', display: 'block' }}
                        value={pincode}
                        name="pincode"
                        valueState={isPincodeValid ? 'None' : 'Error'}
                        onChange={(e) => {
                            validatePinCode(e);
                        }}
                        placeholder="Pincode"
                    />
                    <Input
                        style={{ marginTop: '1.5rem', display: 'block' }}
                        name="companyCode"
                        placeholder="Enter Company Code"
                        valueState={isCompanyCodeValid ? 'None' : 'Error'}
                        maxlength={COMPANYCODE_LENGTH}
                        value={companyCode}
                        onChange={(e) => {
                            validateCompanyCode(e);
                        }}
                    />
                    <TextArea
                        rows={3}
                        style={{
                            width: '210px',
                            fontSize: 'medium',
                            marginTop: '1.5rem',
                            display: 'block'
                        }}
                        value={locDetails}
                        name="locDetails"
                        onChange={(e) => {
                            inputChange(e);
                        }}
                        placeholder="Street and number, Building Name, Landmark etc."
                    />
                </FlexBox>
            </FlexBox>
            <FlexBox>
                <Button
                    design="Emphasized"
                    style={{
                        marginLeft: '45rem',
                        marginTop: '1.5rem',
                        float: 'right'
                    }}
                    onClick={submitBusinessInfoForm}
                >
                    Submit
                </Button>
            </FlexBox>
            <Toast ref={toast}>{errorMessage}</Toast>
        </FlexBox>
    );
};

const mapStateToProps = (state) => {
    return {
        businessInfo: state.account.businessInfo,
        industry: state.account.industry,
        states: state.account.states,
        cities: state.account.cities
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetBusinessInfo: () => dispatch(getBusinessInfo()),
        startGetIndustry: () => dispatch(getIndustry()),
        startGetStates: () => dispatch(getStates()),
        startGetCities: (stateId) => dispatch(getCities(stateId)),
        startUpdateBusinessInfo: (payload) => dispatch(updateBusinessInfo(payload))
    };
};

BusinessInfoForm.propTypes = {
    startUpdateBusinessInfo: PropTypes.func,
    startGetStates: PropTypes.func,
    startGetCities: PropTypes.func,
    startGetIndustry: PropTypes.func,
    startGetBusinessInfo: PropTypes.func,
    businessInfo: PropTypes.object,
    industry: PropTypes.array,
    states: PropTypes.array,
    cities: PropTypes.array,
    onBiSave: PropTypes.func
};

BusinessInfoForm.defaultProps = {
    businessInfo: {},
    industry: [],
    states: [],
    cities: []
};

export default connect(mapStateToProps, mapDispatchToProps)(BusinessInfoForm);
