import React, { useState } from 'react';
import PropTypes from 'prop-types';
import '../../asset/style/style.css';
import WorkflowWizard from '../common/WorkflowWizard';


const onSiteSteps = {
    1: {
        name: 'Order Creation',
        selected: true,
        disabled: false,
        showTable: false
    },
    2: {
        name: 'Order Submission',
        selected: false,
        disabled: true,
        showTable: false
    },
    3: {
        name: 'Quote Selection',
        selected: false,
        disabled: false,
        showTable: false
    },
    4: {
        name: 'Schedule Onsite Visit',
        selected: false,
        disabled: true,
        showTable: false
    },
    5: {
        name: 'Approval of Final Quote',
        selected: false,
        disabled: false,
        showTable: false
    },
    6: {
        name: 'Logistics',
        selected: false,
        disabled: true,
        showTable: false
    }
};

const RecyclingWorkflow = ({ workflows = [], isOnSite = true }) => {
    const [steps, setSteps] = useState(onSiteSteps);


    const onNextClick = (stepId) => {
        const newSteps = { ...steps };
        stepId = Number(stepId);
        if (stepId !== Object.keys(steps).length) {
            newSteps[stepId].selected = false;
            newSteps[stepId + 1].selected = true;
            newSteps[stepId + 1].disabled = false;
            setSteps(newSteps);
        }
    };

    if (workflows.length) {
        workflows.map((workflow) => {
            // eslint-disable-next-line camelcase
            const { process_stage_sequence, workflow_approvers, workflow_id } = workflow;
            const step = steps[process_stage_sequence];
            // eslint-disable-next-line camelcase
            step.approvers = workflow_approvers;
            step.showTable = true;
            // eslint-disable-next-line camelcase
            step.workflowId = workflow_id;
        });
    }

    return <WorkflowWizard steps={steps} processTypeId={'2'} onNextClick={onNextClick} />;
};

RecyclingWorkflow.propTypes = {
    workflows: PropTypes.array,
    isOnSite: PropTypes.bool
};

RecyclingWorkflow.defaultProps = {
    workflows: []
};

export default RecyclingWorkflow;
