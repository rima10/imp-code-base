import React, { useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import { ShellBar, Avatar, Popover, Button, Bar,
    NotificationListItem, List, Label } from '@ui5/webcomponents-react';
import { getNotificationInfo, readNotification } from '../../store/action/taskAction';
import { useHistory } from 'react-router-dom';
import { connect } from "react-redux";
import logo from '../../../public/favicon.ico';
const Header = ({ handleSideNavCollapse, userName, imageSrc,
    notificationList, startGetNotificationsInfo, startReadNotification }) => {
    const popoverRef = useRef(null);
    const onNotificationsClick = (e) => {
        popoverRef.current.openBy(e.detail.targetRef);
    };
    const onPopoverClose = () => {
        popoverRef.current.close();
    };
    useEffect(() => {
        startGetNotificationsInfo();
    }, []);
    const history = useHistory();
    const handleLogoClick = () => {
        history.push('/');
    };
    const getNotificationAge = (notificationTime) => {
        const startDate = new Date(notificationTime);
        const endDate = new Date();
        let difference = (endDate.getTime() - startDate.getTime());
        const daysDifference = Math.floor(difference / 1000 / 60 / 60 / 24);
        if (daysDifference) return `${daysDifference} Days Ago`;

        const hoursDifference = Math.floor(difference / 1000 / 60 / 60);
        if (hoursDifference) return `${hoursDifference} Hours Ago`;

        const minutesDifference = Math.floor(difference / 1000 / 60);
        if (minutesDifference) return `${minutesDifference} Minutes Ago`;
        else return 'Just Now';
    };

    const onNotificationRead = (event) => {
        const bpNotificationId = event.currentTarget.getAttribute("data-id");
        startReadNotification(bpNotificationId);
    };

    const getNotificationStyle = (isRead) => {
        if (!isRead) return { background: 'aliceblue' };
        else return {};
    };
    const renderAvatar = () => {
        if (imageSrc) {
            return <Avatar size="XS" imageFitType="Contain" image={imageSrc} />;
        } else if (userName) {
            let initials = userName
                .split(' ')
                .slice(0, 2)
                .map((word) => word.charAt(0))
                .join('');
            return <Avatar size="XS" initials={initials} />;
        } else {
            return <Avatar icon="employee" size="XS" />;
        }
    };

    return (
        <>
            <ShellBar
                logo={<img alt="EverLoop Logo" src={logo} />}
                primaryTitle="EverLoop by SAP"
                profile={renderAvatar()}
                showNotifications
                notificationCount={notificationList.length}
                onNotificationsClick={onNotificationsClick}
                onLogoClick={handleLogoClick}
                style = {{ position: 'fixed', top: '0', zIndex: '1000' }}
            >
                <Button slot="startButton" onClick={handleSideNavCollapse} icon="menu" />
            </ShellBar>
            <Popover headerText="Notifications"
                footer={<Bar style={{ background: 'var(--sapShellColor)' }}
                    endContent={<Button onClick={onPopoverClose}>Close</Button>} />}
                placementType="Bottom" horizontalAlign="Center"ref={popoverRef}><>
                    <List noDataText="No new notifications">
                        {notificationList.map(notification => {
                            const notificationItem = notification.notification;
                            return (<NotificationListItem
                                style={getNotificationStyle(notification.isRead)}
                                data-id={notification.bpNotificationId}
                                footnotes={<Label>{getNotificationAge(notificationItem.createdDate)}</Label>}
                                heading={notificationItem.notificationBody}
                                showClose={!notification.isRead}
                                onClose={onNotificationRead}
                            >
                                {notificationItem.notificationText}
                            </NotificationListItem>);
                        })}
                    </List></>
            </Popover>
        </>
    );
};

const mapStateToProps = state => {
    return {
        notificationList: state.notification
    };
};

const mapDispatchToProps = dispatch => {
    return {
        startGetNotificationsInfo: async () => dispatch(getNotificationInfo()),
        startReadNotification: async (bpNotificationId) => dispatch(readNotification(bpNotificationId))
    };
};

Header.propTypes = {
    handleSideNavCollapse: PropTypes.func,
    userName: PropTypes.string,
    imageSrc: PropTypes.string,
    notificationList: PropTypes.array,
    startGetNotificationsInfo: PropTypes.func,
    startReadNotification: PropTypes.func
};

Header.defaultProps = {
    notificationList: []
};

export default connect(mapStateToProps, mapDispatchToProps)(Header);
