import React, { useState } from 'react';
import { Card, Title, Button, FlexBox } from '@ui5/webcomponents-react';
import BusinessProfileWorkflow from './BusinessProfileWorkflow';
import SetupProfile from './SetupProfile';

const Home = () => {
    const [isHidden, setIsHidden] = useState(true);
    return (
        <>
            <Card heading="Home" />
            <FlexBox justifyContent="SpaceBetween" style={{ margin: '1rem' }}>
                <Title>
                    <b>Your Recycling Orders</b>
                </Title>
                <Button design="Emphasized" disabled>
                    New Order
                </Button>
            </FlexBox>
            {isHidden && <SetupProfile toggleHidden={() => setIsHidden()} />}
            {!isHidden && <BusinessProfileWorkflow />}
        </>
    );
};

export default Home;
