import React from 'react';
import PropTypes from 'prop-types';
import { Title, Button, Label, FlexBox } from '@ui5/webcomponents-react';
import bg from '../../asset/images/background-image.png';

const SetupProfile = ({ toggleHidden }) => {
    return (
        <FlexBox alignItems="Center" style={{ backgroundImage: `url(${bg})`, height: '270px' }} direction="Column">
            <Title
                style={{
                    fontSize: 'x-large',
                    textAlign: 'center',
                    marginTop: '60px',
                    color: '#000000'
                }}
            >
                <b>Welcome to EverLoop!</b>
            </Title>
            <Label
                wrap
                style={{
                    fontSize: 'large',
                    textAlign: 'center',
                    marginTop: '20px',
                    color: '#000000'
                }}
            >
                The marketplace for recycling and refurbishing your electronic assets.
            </Label>
            <br />
            <Label
                wrap
                style={{
                    fontSize: 'large',
                    textAlign: 'center',
                    color: '#000000'
                }}
            >
                In order to use the platform and be able to create orders, you have to pre-setup your account first.
            </Label>
            <Button
                design="Emphasized"
                onClick={toggleHidden}
                id="CreateNewOrder"
                style={{
                    marginTop: '25px'
                }}
            >
                Setup Profile
            </Button>
        </FlexBox>
    );
};

SetupProfile.propTypes = {
    toggleHidden: PropTypes.func
};

export default SetupProfile;
