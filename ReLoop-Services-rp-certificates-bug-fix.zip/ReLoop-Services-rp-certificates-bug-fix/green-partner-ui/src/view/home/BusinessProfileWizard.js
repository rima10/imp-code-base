import React from 'react';
import PropTypes from 'prop-types';
import { Wizard, WizardStep } from '@ui5/webcomponents-react';
import BusinessProfileStep from './BusinessProfile';
import PrivateNetworkStep from './PrivateNetworkStep';
import ApproverDataStep from './ApproverDataStep';
import ApprovalWorkflowStep from './ApprovalWorkflowStep';

const BusinessProfileWizard = ({ steps = [], onNextClick }) => {
    const getContent = (id) => {
        if (parseInt(id, 10) > steps.length) {
            return;
        }
        switch (id) {
            case '1':
                return <BusinessProfileStep onNextClick={onNextClick} />;
            case '2':
                return <PrivateNetworkStep onNextClick={onNextClick} />;
            case '3':
                return <ApproverDataStep onNextClick={onNextClick} />;
            case '4':
                return <ApprovalWorkflowStep />;
        }
    };

    return (
        <>
            <Wizard style={{ height: 'fit-content' }}>
                {Object.keys(steps).map((idx) => {
                    return (
                        <WizardStep
                            branching={false}
                            heading={steps[idx].name}
                            selected={steps[idx].selected}
                            disabled={steps[idx].disabled}
                            key={idx}
                        >
                            {getContent(idx)}
                        </WizardStep>
                    );
                })}
            </Wizard>
        </>
    );
};

BusinessProfileWizard.propTypes = {
    steps: PropTypes.object,
    onNextClick: PropTypes.func
};

export default BusinessProfileWizard;
