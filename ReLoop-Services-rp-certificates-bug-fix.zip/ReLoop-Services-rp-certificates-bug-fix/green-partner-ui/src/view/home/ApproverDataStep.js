import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Grid, Input, Button, Label, FlexBox, Title, Icon, Loader } from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';
import { useHistory } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import { registerBPApproverInfo } from '../../store/action/taskAction';
import validateInput from '../../validation/ApproverData';
import { isApproverInfoLoading } from '../../selectors/common';
import { camelCaseToSentence } from '../../utils/formatter';

const ApproverDataStep = ({ onNextClick, startRegisterBPApproverInfo, isLoading }) => {
    const [inputBox, setInputBox] = useState([
        {
            approverRole: {
                value: '',
                valueState: 'None',
                valueStateMessage: ''
            },
            approverName: {
                value: '',
                valueState: 'None',
                valueStateMessage: ''
            },
            emailAddress: {
                value: '',
                valueState: 'None',
                valueStateMessage: ''
            },
            phoneNumber: {
                value: '',
                valueState: 'None',
                valueStateMessage: ''
            }
        }
    ]);

    const history = useHistory();

    const onSave = () => {
        let isValid = true;
        let tempInputBox = [...inputBox];
        tempInputBox.map((input, idx) => {
            Object.keys(input).map((field) => {
                if (tempInputBox[idx][field]['value'] === '') {
                    let fieldName = camelCaseToSentence(field);
                    tempInputBox[idx][field]['valueState'] = 'Error';
                    tempInputBox[idx][field]['valueStateMessage'] = <span>{fieldName} is required</span>;
                    isValid = false;
                }
            });
        });
        if (isValid) {
            const payload = { approvers: [] };
            inputBox.map((input) => {
                payload.approvers.push({
                    approverEmailId: input.emailAddress.value,
                    approverName: input.approverName.value,
                    approverRole: input.approverRole.value
                });
            });
            startRegisterBPApproverInfo(payload)
                .then(() => onNextClick('4'))
                .catch(() => console.log('Something went wrong!'));
        } else {
            setInputBox(tempInputBox);
        }
    };

    const onInputChange = (event) => {
        let tempInputBox = [...inputBox];
        let id = event.target.id;
        let field = id.slice(0, -1);
        let idx = id.slice(-1);
        let { isValid, errorMessage } = validateInput(event.target.value, field);
        if (isValid) {
            tempInputBox[idx][field]['value'] = event.target.value;
            tempInputBox[idx][field]['valueState'] = 'None';
            tempInputBox[idx][field]['valueStateMessage'] = <span>{errorMessage}</span>;
        } else {
            tempInputBox[idx][field]['value'] = '';
            tempInputBox[idx][field]['valueState'] = 'Error';
            tempInputBox[idx][field]['valueStateMessage'] = <span>{errorMessage}</span>;
        }
        setInputBox(tempInputBox);
    };

    const onDeleteClick = (index) => {
        let tempInputBox = [...inputBox];
        tempInputBox = tempInputBox.filter((value, idx) => idx !== index);
        setInputBox(tempInputBox);
    };

    const onSkip = () => {
        history.push('/order/newOrder');
    };

    return (
        <>
            <FlexBox alignItems="Center" direction="Column">
                {isLoading && <Loader />}
                <Title style={{ fontSize: 'larger', marginTop: '2rem' }}>
                    <b>For Refurbishing requests only:</b> In order to create Approval Workflows please add all the
                    approver details.
                </Title>
                <Title style={{ fontSize: 'larger', marginTop: '0.5rem' }}>
                    This step could be skipped and set up later under
                    <b>Menu &gt; Account Management &gt; Approver’s Data.</b>
                </Title>
            </FlexBox>
            <Grid style={{ margin: '20px' }}>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label required style={{ fontSize: 'larger', marginTop: '2rem' }}>
                        Approver Role
                    </Label>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label style={{ fontSize: 'larger', marginTop: '2rem' }}>Approver Name</Label>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label style={{ fontSize: 'larger', marginTop: '2rem' }}>Email Address</Label>
                </div>
                <div data-layout-span="XL3 L3 M3 S3">
                    <Label style={{ fontSize: 'larger', marginTop: '2rem' }}>Phone Number</Label>
                </div>
                {inputBox.map((inputElements, index) =>
                    Object.keys(inputElements).map((inputElement, idx) => (
                        <div key={idx} data-layout-span="XL3 L3 M3 S3">
                            <Input
                                id={inputElement + index}
                                value={inputElements[inputElement].value}
                                valueState={inputElements[inputElement].valueState}
                                valueStateMessage={inputElements[inputElement].valueStateMessage}
                                onInput={onInputChange}
                            />
                            {idx === Object.keys(inputElements).length - 1 ? (
                                <Icon
                                    id={'delete' + index}
                                    name="delete"
                                    onClick={() => onDeleteClick(index)}
                                    tooltip="Delete Row"
                                    style={{ ...spacing.sapUiTinyMarginBegin, width: '1.5rem', cursor: 'pointer' }}
                                />
                            ) : null}
                        </div>
                    ))
                )}
            </Grid>
            <Button
                design="Transparent"
                style={{ color: 'blue', marginLeft: '15px' }}
                onClick={() => {
                    let tempInputBox = [...inputBox];
                    tempInputBox.push({
                        approverRole: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: ''
                        },
                        approverName: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: ''
                        },
                        emailAddress: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: ''
                        },
                        phoneNumber: {
                            value: '',
                            valueState: 'None',
                            valueStateMessage: ''
                        }
                    });

                    setInputBox(tempInputBox);
                }}
            >
                + Add Approver
            </Button>
            <Grid style={{ ...spacing.sapUiMediumMarginTop }}>
                <div data-layout-indent="XL8 L8 M8 S8" data-layout-span="XL4 L4 M4 S4">
                    <Button style={{ ...spacing.sapUiSmallMarginEnd }} onClick={() => onSkip()}>
                        Skip Steps 3 and 4
                    </Button>
                    <Button onClick={() => onSave()} design="Emphasized">
                        Save &amp; Go Next
                    </Button>
                </div>
            </Grid>
        </>
    );
};

const mapStateToProps = (state) => {
    return {
        isLoading: isApproverInfoLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startRegisterBPApproverInfo: (payload) => dispatch(registerBPApproverInfo(payload))
    };
};

ApproverDataStep.propTypes = {
    onNextClick: PropTypes.func,
    startRegisterBPApproverInfo: PropTypes.func,
    isLoading: PropTypes.bool
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(ApproverDataStep));
