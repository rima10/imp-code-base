import React, { useState } from 'react';
import PropTypes from 'prop-types';
import {
    Button,
    Dialog,
    FlexBox,
    Calendar,
    Label,
    Input,
    DurationPicker,
    Select,
    Option,
    TextArea
} from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from '@ui5/webcomponents-react-base';

const CalendarDialog = React.forwardRef(({ onCancel, onSubmit, headerText, showEstHours }, ref) => {
    const [payload, setPayload] = useState({});

    const onDateSelect = (event) => {
        event.preventDefault();
        const updatedPayload = { ...payload };
        updatedPayload.date = event.detail.values[0];
        setPayload(updatedPayload);
    };

    const onTimeSelect = (event) => {
        event.preventDefault();
        const updatedPayload = { ...payload };
        updatedPayload.time = event.detail.value;
        setPayload(updatedPayload);
    };

    const onEstimatedHoursSelect = (event) => {
        event.preventDefault();
        const updatedPayload = { ...payload };
        updatedPayload.estimatedTime = event.detail.selectedOption.textContent;
        setPayload(updatedPayload);
    };

    const onInputChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        const updatedPayload = { ...payload };
        updatedPayload[name] = value;
        setPayload(updatedPayload);
    };

    return (
        <Dialog
            ref={ref}
            footer={
                <div>
                    <Button style={spacing.sapUiTinyMargin} onClick={() => onSubmit(payload)}>
                        Submit
                    </Button>
                    <Button style={spacing.sapUiTinyMargin} onClick={onCancel}>
                        Close
                    </Button>
                </div>
            }
            headerText={headerText}
        >
            <FlexBox justifyContent="SpaceBetween">
                <Calendar
                    onSelectedDatesChange={onDateSelect}
                    primaryCalendarType="Gregorian"
                    selectionMode="Single"
                    format-pattern="yyyy-MM-dd"
                />
                <FlexBox style={spacing.sapUiSmallMargin} justifyContent="Center" direction="Column">
                    <Label style={spacing.sapUiSmallMarginTopBottom}>Date</Label>
                    <Input readonly placeholder="Date" value={payload.date} />
                    <Label style={spacing.sapUiSmallMarginTopBottom}>Time</Label>
                    <DurationPicker onChange={onTimeSelect} />
                    {showEstHours && (
                        <>
                            <Label style={spacing.sapUiSmallMarginTopBottom}>Estimated Hours</Label>
                            <Select onChange={onEstimatedHoursSelect}>
                                <Option>1 hour</Option>
                                <Option>2 hours</Option>
                                <Option>3 hours</Option>
                                <Option>4 hours</Option>
                                <Option>5 hours</Option>
                                <Option>6 hours</Option>
                            </Select>
                            <Label style={spacing.sapUiSmallMarginTopBottom}>Additional Comment</Label>
                            <TextArea name="comment"
                                onChange={onInputChange}/>
                        </>
                    )}
                    {!showEstHours && (
                        <>
                            <Label style={spacing.sapUiSmallMarginTopBottom}>Name (Order Responsible)</Label>
                            <Input name="logisticSpocName"
                                onChange={onInputChange}/>
                            <Label style={spacing.sapUiSmallMarginTopBottom}>Contact (Order Responsible)</Label>
                            <Input name="logisticSpocContactNumber"
                                onChange={onInputChange}/>
                        </>
                    )}

                </FlexBox>
            </FlexBox>
        </Dialog>
    );
});

CalendarDialog.propTypes = {
    onCancel: PropTypes.func,
    onSubmit: PropTypes.func,
    headerText: PropTypes.string,
    showEstHours: PropTypes.bool
};

CalendarDialog.defaultProps = {
    showEstHours: true
};

export default CalendarDialog;
