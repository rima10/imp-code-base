import React from 'react';
import PropTypes from 'prop-types';
import { Label } from '@ui5/webcomponents-react';

const ErrorComponent = ({ text }) => {
    return (
        <Label style={{ position: 'fixed', zIndex: 100, top: '50%', left: '50%' }}>{text}</Label>
    );
};

ErrorComponent.propTypes = {
    text: PropTypes.string
};

ErrorComponent.defaultProps = {
    text: 'Something went wrong, please refresh the page'
};

export default ErrorComponent;
