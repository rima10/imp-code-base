import React from 'react';
import PropTypes from 'prop-types';
import { Form, Button, FormItem, TextArea, Dialog } from '@ui5/webcomponents-react';
import '../../asset/style/style.css';
import { spacing } from '@ui5/webcomponents-react-base';

const CommentDialog = React.forwardRef(({ onCancel, onSubmit, headerText }, ref) => {
    return (
        <Dialog
            ref={ref}
            footer={
                <div style={spacing.sapUiSmallMargin}>
                    <Button style={spacing.sapUiTinyMargin} onClick={onCancel}>
                        Close
                    </Button>
                    <Button style={spacing.sapUiTinyMargin} onClick={onSubmit}>
                        Submit
                    </Button>
                </div>
            }
            headerText={headerText}
        >
            <Form>
                <FormItem label="Comments">
                    <TextArea />
                </FormItem>
            </Form>
        </Dialog>
    );
});

CommentDialog.propTypes = {
    onCancel: PropTypes.func,
    onSubmit: PropTypes.func,
    headerText: PropTypes.string
};

export default CommentDialog;
