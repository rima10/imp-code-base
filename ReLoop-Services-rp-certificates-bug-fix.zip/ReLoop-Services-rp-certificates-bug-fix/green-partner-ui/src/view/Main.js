import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Route, Switch, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import Home from './home/Home';
import BusinessInfo from './account/BusinessInfoRouter';
import PrivateRoute from './login/PrivateRoute';
import LoginSuccess from './login/loginSuccess';
import NetworkInfoView from './account/NetworkInfoView';
import ApproverInfoView from './account/ApproverInfoView';
import WorkflowInfo from './account/WorkflowInfo';
import Header from './header/Header';
import NavBar from './home/NavBar';
import ErrorComponent from './common/Error';
import MessageBar from './common/MessageBar';
import OrderComponent from './order/OrderComponent';
import OrderCreationForm from './order/OrderCreationForm';
import { spacing } from '@ui5/webcomponents-react-base';

const Main = ({ userInfo, toast }) => {
    const [isCollapsed, setIsCollapsed] = useState(false);
    const handleSideNavCollapse = (e) => {
        const sidebar = document.querySelector('.sidebar');
        const mainContent = document.querySelector('.main-content');
        sidebar.classList.toggle('sidebar_small');
        mainContent.classList.toggle('main-content_large');
        setIsCollapsed(!isCollapsed);
    };
    return (
        <div className="grid-container">
            <Header userName={userInfo.bp_username} handleSideNavCollapse={handleSideNavCollapse} />
            <div className="sidebar">
                <NavBar isCollapsed={isCollapsed} />
            </div>
            <div
                className="main-content"
                style={{ marginTop: '60px', ...spacing.sapUiLargeMarginBeginEnd, ...spacing.sapUiLargeMarginBottom }}
            >
                {toast.show && <MessageBar message={toast.message} type={toast.status} />}
                <Switch>
                    <Route path="/loginSuccessful">
                        <LoginSuccess />
                    </Route>
                    <PrivateRoute path="/order" component={OrderComponent} />
                    <PrivateRoute exact path="/account/businessInfo" component={BusinessInfo} />
                    <PrivateRoute exact path="/account/networkInfo" component={NetworkInfoView} />
                    <PrivateRoute exact path="/account/approverInfo" component={ApproverInfoView} />
                    <PrivateRoute exact path="/account/workflowInfo" component={WorkflowInfo} />
                    <PrivateRoute exact path="/dashboard" component={Home} />
                    <PrivateRoute exact path="/" component={OrderCreationForm} />
                    <PrivateRoute exact path="/404" component={() => <ErrorComponent text="Page Not Found" />} />
                    <Redirect from="/" to="/404" />
                </Switch>
            </div>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        userInfo: state.userInfo,
        toast: state.toast
    };
};

Main.propTypes = {
    userInfo: PropTypes.object,
    toast: PropTypes.object
};

export default connect(mapStateToProps)(Main);
