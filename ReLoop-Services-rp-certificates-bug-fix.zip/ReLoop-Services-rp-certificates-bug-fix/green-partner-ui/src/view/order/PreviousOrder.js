import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Panel, List, StandardListItem, Label } from '@ui5/webcomponents-react';
import { useHistory } from 'react-router-dom';


const PreviousOrder = ({ orderInfo }) => {
    const [isLoading, setLoading] = useState(true);
    useEffect(() => {
        setLoading(false);
    }, [orderInfo.length]);

    let history = useHistory();

    const onSelectionChange = (event) => {
        let orderNumber = event.detail.selectedItems[0].textContent;
        history.push({
            pathname: `/order/previousOrder/${orderNumber}`
        });
    };

    const getInfoState = (orderPosition) => {
        if (orderPosition === 'In Progress') {
            return 'Warning';
        }
        if (orderPosition === 'Completed') {
            return 'Success';
        }
        return 'Information';
    };

    const getDescription = (processTypeName, orderPosition, orderNetwork) => {
        if (processTypeName && orderPosition) {
            return `${processTypeName} |  ${orderNetwork} Network`;
        }
        return 'Description';
    };

    const getDataWithSpecificStatus = (status) => {
        return orderInfo.filter((order) => order.orderPosition === status);
    };

    const uniqueStatus = [...new Set(orderInfo.map((order) => order.orderPosition))];

    return (
        <>
            <Label style={{ fontSize: '1.3rem', fontWeight: 'Bold', marginBottom: '20px' }}>Previous Orders</Label>
            {uniqueStatus.map((status, index) => {
                let data = getDataWithSpecificStatus(status);
                return (
                    <Panel headerText={`${status} Orders (${data.length})`} key={index}>
                        <List
                            busy={isLoading}
                            noDataText="No Previous Orders"
                            mode="SingleSelect"
                            separators="All"
                            growing="Scroll"
                            onSelectionChange={onSelectionChange}
                        >
                            {data.map((order, idx) => (
                                <StandardListItem
                                    description={getDescription(
                                        order.orderProcessType.processTypeName,
                                        order.orderPosition,
                                        order.orderNetwork
                                    )}
                                    icon="order-status"
                                    info={order.orderPosition}
                                    infoState={getInfoState(order.orderPosition)}
                                    key={idx}
                                >
                                    {order.orderNumber}
                                </StandardListItem>
                            ))}
                        </List>
                    </Panel>
                );
            })}
        </>
    );
};

PreviousOrder.propTypes = {
    orderInfo: PropTypes.array,
    isLoading: PropTypes.bool
};

export default PreviousOrder;
