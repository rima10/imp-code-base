import React from 'react';
import PropTypes from 'prop-types';
import {
    Button, Dialog
} from '@ui5/webcomponents-react';
import { spacing } from '@ui5/webcomponents-react-base';

const DCDialog = React.forwardRef(({ onCancel, onSubmit, headerText, components }, ref) => {
    return (<Dialog
        className=""
        ref={ref}
        footer={<div style={spacing.sapUiSmallMargin}>
            <Button style={spacing.sapUiTinyMargin} onClick={onCancel}>Close</Button>
            <Button style={spacing.sapUiTinyMargin} onClick={onSubmit}>Generate</Button></div>}
        headerText={headerText}
        style={{ width: "20%" }}
    >
        <div style={{ display: "flex", justifyContent: "center" }}>
            {components}
        </div>
    </Dialog>);
});

DCDialog.propTypes = {
    onCancel: PropTypes.func,
    onSubmit: PropTypes.func,
    headerText: PropTypes.string,
    components: PropTypes.elementType
};

export default DCDialog;
