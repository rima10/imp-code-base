/* eslint-disable max-len */
import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { connect } from "react-redux";
import { useHistory } from "react-router-dom";
import { FileUploader, Button, Label, Text, Toolbar, Form, FormItem, TextArea, Option, Select, DateTimePicker, FormGroup, Input, MultiComboBox,
    MultiComboBoxItem, BusyIndicator } from '@ui5/webcomponents-react';
import { spacing } from "@ui5/webcomponents-react-base";
import '../../asset/style/style.css';
import AccountTable from '../common/Table';
import CommentDialog from '../common/Dialog';
import { updateOrderInfo, getWorkflowsInfo, readExcelInfo, updateDraftOrderInfo, downloadFile, getOrderType, getCategory, getSubCategory, getBusinessInfo, getNetworkInfo } from '../../store/action/taskAction';
import { clearPreviewOrderItems } from '../../store/action/type';
import MessageBar from '../common/MessageBar';
/**
 * @description moment is a date time handler which Parse, validate, manipulate,
    and display dates and times in JavaScript
 */
import moment from 'moment';

const OrderCreationForm = ({ businessInfo, startGetOrderType, startGetCategory, startGetSubCategory,
    startUpdateOrderInfo, startUpdateDraftOrderInfo, startGetWorkflowInfo, startReadExcelInfo,
    startGetBusinessInfo, startClearPreviewOrderItems, startGetPrivateNetworkRecyclers,
    orderInfo, workflowsInfo, previewOrderItemInfo, orderTypes, categories,
    subcategories, privateNetworkRecyclers, toast }) => {
    const columns = ['Approver Sequence', 'Approver Role', 'Approver Name'];
    const refurbishAssetColumns = ['Equipment No.', 'Asset No.', 'Location', 'Bond Status', 'Category', 'Make', 'Model', 'Manuf. Serial No.', 'Age in Years', 'Purchase Year', 'Description'];
    const recycleAssetColumns = ['Item', 'Quantity', 'Unit', 'Location', 'Remarks'];
    const [OrderFormFieldSpec, setOrderFormFieldSpec] = useState({
        assetExcel: {
            valueState: 'None',
            valueStateMessage: '',
            required: true
        }
    });
    const [rows, setRows] = useState([]);
    const [orderPayload, setOrderPayload] = useState({ orderType: '1', category: '1', subcategory: '1', network: 'Private', recyclerIds: [], recycleAssetType: 'Non-Fixed' });
    const [assetRows, setAssetRows] = useState([]);
    const [datePickervalueState, setDatePickerValueState] = useState('None');
    let history = useHistory();
    const [assetTableVisible, setAssetTableVisible] = useState(false);
    const dialogRef = useRef(null);
    const getWorkflowDetails = (workflowsInfo) => {
        const newRows = [];
        const workflowApprover = [];
        if (workflowsInfo.length !== 0) {
            const workflow = workflowsInfo.find(workflow => workflow.process_stage_sequence === '1' && workflow.process_type_id === orderPayload.orderType);
            if (workflow) {
                workflowApprover.push(workflow.workflow_approvers);
                workflowApprover[0].map(index => {
                    const row = [];
                    row.push({ name: 'approver_sequence', value: index.approver_sequence, type: 'text' });
                    row.push({ name: 'approver_role', value: index.approver.approver_role, type: 'text' });
                    row.push({ name: 'approver_name', value: index.approver.approver_name, type: 'text' });
                    newRows.push(row);
                });
                return newRows;
            }
        }
    };

    const getOrderItemDetails = (previewOrderItemInfo, limit) => {
        const newRows = [];
        const limitedRows = previewOrderItemInfo.slice(0, limit);
        if (orderPayload.orderType === '1') {
            limitedRows.map(asset => {
                const row = [];
                row.push({ name: 'Equipment No.', value: asset['Equipment No'], type: 'text' });
                row.push({ name: 'Asset No.', value: asset['Asset No'], type: 'text' });
                row.push({ name: 'Location', value: asset['Location'], type: 'text' });
                row.push({ name: 'Bond Status', value: asset['Bond Status'], type: 'text' });
                row.push({ name: 'Category', value: asset['Category'], type: 'text' });
                row.push({ name: 'Make', value: asset['Make'], type: 'text' });
                row.push({ name: 'Model', value: asset['Model'], type: 'text' });
                row.push({ name: 'Manuf. Serial No.', value: asset['Manuf. Serial No.'], type: 'text' });
                row.push({ name: 'Age in Years', value: asset['Age in Years'], type: 'text' });
                row.push({ name: 'Purchase Year', value: asset['Purchase Year'], type: 'text' });
                row.push({ name: 'Description', value: asset['Description'], type: 'text' });
                newRows.push(row);
            });
        } else {
            limitedRows.map(asset => {
                const row = [];
                row.push({ name: 'Item', value: asset.Item, type: 'text' });
                row.push({ name: 'Quantity', value: asset.Quantity || '-', type: 'text' });
                row.push({ name: 'Unit', value: asset.Unit || '-', type: 'text' });
                row.push({ name: 'Location', value: asset.Location, type: 'text' });
                row.push({ name: 'Remarks', value: asset.Remarks, type: 'text' });
                newRows.push(row);
            });
        }
        return newRows;
    };
    useEffect(() => {
        startGetBusinessInfo();
        startGetOrderType();
        startGetCategory();
        startGetSubCategory();
        startGetWorkflowInfo();
        startGetPrivateNetworkRecyclers();
    }, []);
    useEffect(() => {
        const rows = getWorkflowDetails(workflowsInfo);
        setRows(rows);
    }, [workflowsInfo.length, orderPayload.orderType]);

    useEffect(() => {
        const orderRecyclers = orderPayload.recyclerIds;
        const defaultState = { orderType: orderPayload.orderType,
            category: '1',
            subcategory: '1',
            network: 'Private',
            recyclerIds: orderRecyclers,
            recycleAssetType: 'Non-Fixed' };
        setOrderPayload(defaultState);
        setAssetRows([]);
        setAssetTableVisible(false);
    }, [orderPayload.orderType]);

    const minDisplayRows = 10;
    const minTableHeight = '400px';
    const loadMoreAssetList = () => {
        setAssetRows((previousRows) => [...getOrderItemDetails(previewOrderItemInfo, previousRows.length + minDisplayRows)]);
    };
    useEffect(() => {
        if (previewOrderItemInfo.length > 0) {
            const assetRows = getOrderItemDetails(previewOrderItemInfo, minDisplayRows);
            setAssetRows(assetRows);
            setAssetTableVisible(true);
        }
    }, [previewOrderItemInfo.length]);
    useEffect(() => {
        if (privateNetworkRecyclers.length !== 0) {
            const updatedPayload = { ...orderPayload };
            privateNetworkRecyclers.forEach((item) => {
                updatedPayload["recyclerIds"].push(item.nwk_member);
            });
            setOrderPayload(updatedPayload);
        }
    }, [privateNetworkRecyclers.length]);
    const onSelectChange = (e) => {
        const updatedPayload = { ...orderPayload };
        updatedPayload[e.target.name] = e.detail.selectedOption.value;
        setOrderPayload(updatedPayload);
    };
    const handleRecyclerSelection = (event) => {
        const updatedPayload = { ...orderPayload };
        updatedPayload["recyclerIds"] = [];
        if (event.detail.items && event.detail.items.length) {
            event.detail.items.forEach((selectedItem) => {
                updatedPayload["recyclerIds"].push(selectedItem.attributes.value.value);
            });
        }
        setOrderPayload(updatedPayload);
    };
    const onSelectCatChange = (e) => {
        const updatedPayload = { ...orderPayload };
        updatedPayload[e.target.name] = e.target.value;
        setOrderPayload(updatedPayload);
    };
    const inputChange = (event) => {
        const { name, value } = event.target;
        if (name === 'submissionDeadline' && value) {
            setDatePickerValueState('None');
        }
        const updatedPayload = { ...orderPayload };
        updatedPayload[name] = value;
        setOrderPayload(updatedPayload);
    };
    const validateAssetExcelUpload = (file) => {
        const oneMBinBytes = 1 * 1024 * 1024;
        let temp = { ... OrderFormFieldSpec };
        if (file.size > oneMBinBytes) {
            temp.assetExcel.valueState = 'Error';
            temp.assetExcel.valueStateMessage = <span> Cannot upload File of size above 1 MB </span>;
            setOrderFormFieldSpec(temp);
            return false;
        }
        if (file.type !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
            temp.assetExcel.valueState = 'Error';
            temp.assetExcel.valueStateMessage = <span> Only Excel (.xlsx) files are accepted </span>;
            setOrderFormFieldSpec(temp);
            return false;
        }
        return true;
    };
    const onFileChangeHandler = (event) => {
        const fileform = new FormData();
        const fileMeta = event.target.files[0];
        fileform.append(event.target.name, fileMeta);
        const updatedPayload = { ...orderPayload };
        updatedPayload[event.target.name] = fileform;
        setOrderPayload(updatedPayload);
        if (event.target.name === 'assetExcel') {
            if (validateAssetExcelUpload(fileMeta)) {
                startClearPreviewOrderItems();
                setAssetRows([]);
                startReadExcelInfo(fileform);
                setAssetTableVisible(true);
            }
        }
    };
    const onDeleteClick = async (event) => {
        setAssetTableVisible(false);
        const updatedPayload = { ...orderPayload };
        updatedPayload.assetExcel = '';
        setOrderPayload(updatedPayload);
    };
    const onDownloadBtnClick = () => {
        const orderType = orderPayload.orderType === "1" ? 'Refurbish' : 'Recycle';
        downloadFile(`${orderType}_Assetlist_Template.xlsx`);
    };
    const onCancel = () => {
        dialogRef.current.close();
    };
    const onSubmit = (event, draftVal) => {
        event.preventDefault();
        if (!orderPayload.submissionDeadline) {
            setDatePickerValueState('Error');
            dialogRef.current.close();
            return;
        }
        // Remove asset type flag for refurbishing order
        if (orderPayload.orderType === "1") {
            const updatedPayload = { ...orderPayload };
            Reflect.deleteProperty(updatedPayload, 'recycleAssetType');
            setOrderPayload(updatedPayload);
        }
        const formdata = new FormData();
        for (const [key, value] of Object.entries(orderPayload)) {
            if (key === 'assetExcel' || key === 'picture') {
                for (var pair of value.entries()) {
                    formdata.append(pair[0], pair[1]);
                }
            }
            formdata.append(`${key}`, `${value}`);
        }
        formdata.append('processStageSequence', '1');
        orderInfo = formdata;
        dialogRef.current.close();
        startClearPreviewOrderItems();

        let postPromise;
        if (draftVal === 'draft') {
            postPromise = startUpdateDraftOrderInfo(orderInfo);
        } else {
            postPromise = startUpdateOrderInfo(orderInfo);
        }
        postPromise.then((response) => {
            history.push("/order/previousOrder");
        });
    };
    const onSendAssetListClick = () => {
        dialogRef.current.open();
    };
    const getAssetListColumns = () => {
        return orderPayload.orderType === "1" ? refurbishAssetColumns : recycleAssetColumns;
    };

    const getTableHeight = () => {
        return orderPayload.orderType === "1" ? minTableHeight : "100%";
    };
    const { orderType, category, subcategory, network, orderLocCity, assetType } = orderInfo;
    const buttons = [{
        name: 'Delete',
        icon: 'delete',
        onClick: onDeleteClick
    }
    ];
    return (
        <div >
            <Label
                style={{ fontSize: '1.3rem', fontWeight: 'Bold', marginBottom: '20px' }}
            >
                Order Creation
            </Label>
            <Toolbar style={spacing.sapUiTinyMargin}
            >
                <Label style={{ fontSize: '1rem', fontWeight: 'bold' }}>
                    Order Details
                </Label>
            </Toolbar>
            <Form columnsL={2}
                columnsM={2}
                columnsS={2}
                labelSpanM={5}

                style={spacing.sapUiLargeMarginBottom}>
                <FormGroup>
                    <FormItem label={<Label required>This request is for</Label>}>
                        <Select style={spacing.sapUiTinyMargin} name="orderType" value = {orderType} onChange={(e) => { onSelectChange(e); }}>
                            { orderTypes.map((index) =>
                                (<Option key={index.processTypeId}
                                    value={index.processTypeId}>{index.processTypeName}</Option>))}
                        </Select>
                    </FormItem>
                    <FormItem label={<Label required>Category</Label>}>
                        <Select style={spacing.sapUiTinyMargin} name="category" value = {category} onChange={(e) => { onSelectCatChange(e); }}>
                            { categories.map((index) =>
                                (<Option selected={index.categoryId === '1'} key={index.categoryId} disabled={index.categoryId !== '1'}
                                    value={index.categoryId}>{index.categoryName}</Option>))}
                        </Select>
                    </FormItem>
                    <FormItem label={<Label required>Subcategory</Label>}>
                        <Select style={spacing.sapUiTinyMargin} name="subcategory" value={subcategory} onChange={(e) => { onSelectCatChange(e); }}>
                            { subcategories.map((index) =>
                                (<Option selected={index.subcategoryId === '1'} key={index.subcategoryId} disabled={index.subcategoryId !== '1'}
                                    value={index.subcategoryId}>{index.subcategoryName}</Option>))}
                        </Select>
                    </FormItem>
                    {orderPayload.orderType === "2" && <FormItem label={<Label required>Asset Type</Label>}>
                        <Select style={spacing.sapUiTinyMargin} name="recycleAssetType" value = {assetType} onChange={(e) => { onSelectChange(e); }}>

                            <Option key={0}
                                value="Fixed">Fixed</Option>
                            <Option key={1}
                                selected value="Non-Fixed">Non-Fixed</Option>
                        </Select>
                    </FormItem>}
                    {orderPayload.orderType === "1" && <FormItem label="City" required>
                        <Select style={spacing.sapUiTinyMargin} name="orderLocCity" value={orderLocCity} onChange={(e) => { onSelectChange(e); }} disabled>
                            <Option selected>
                                {businessInfo.location !== undefined ? businessInfo.location.city : ''}
                            </Option>
                        </Select>
                    </FormItem>}
                    <FormItem label="Company Code">
                        <Input style={spacing.sapUiTinyMargin} name="companyCode" readonly value ={businessInfo.companyCode}>{businessInfo.companyCode}</Input>
                    </FormItem>
                    {orderPayload.orderType === "2" && <FormItem label="Total Weight" required>
                        <Input value={orderPayload.totalWeight || ''} style={spacing.sapUiTinyMargin} name="totalWeight" placeholder="Enter weight in kgs" onChange={(e) => { inputChange(e); }}/>
                    </FormItem>}
                </FormGroup>
                <FormGroup>
                    <FormItem label={<Label required>Network</Label>}>
                        <Select disabled style={spacing.sapUiTinyMargin} name="network" value={network} onChange={(e) => { onSelectChange(e); }}>
                            <Option selected value="Private">
                                Private
                            </Option>
                            <Option value="Public" disabled>
                                Public
                            </Option>
                        </Select>
                    </FormItem>
                    <FormItem label={<Label required>Available Recyclers</Label>}>
                        <MultiComboBox
                            style={{ ...spacing.sapUiTinyMargin, width: '65%' }}
                            name="recyclerIds"
                            onSelectionChange={handleRecyclerSelection}
                            tooltip="Available Recyclers"
                        >
                            {privateNetworkRecyclers.map((item) =>
                                (<MultiComboBoxItem selected text={item.nwk_member_business_partner.bp_username} key={item.nwk_member} value={item.nwk_member}/>))}
                        </MultiComboBox>
                    </FormItem>
                    <FormItem label={<Label required wrap>Quote Submission Deadline</Label>}>
                        <DateTimePicker
                            name="submissionDeadline"
                            style={{ ...spacing.sapUiTinyMargin, width: '65%' }}
                            minDate={moment(new Date()).format("MMM D, y, h:mm:ss a")}
                            value={orderPayload.submissionDeadline || ''}
                            valueState={datePickervalueState}
                            onChange={(e) => { inputChange(e); }}
                        />
                    </FormItem>
                    <FormItem label={<Label >Additional Information</Label>}>
                        <TextArea
                            rows={3}
                            style={{
                                width: '210px',
                                margin: '0.5rem'
                            }}
                            name="additionalInfo"
                            value={orderPayload.additionalInfo || ''}
                            onChange={(e) => { inputChange(e); }}
                        />
                    </FormItem>
                    <FormItem label={<Label >Picture</Label>}>
                        <FileUploader style={spacing.sapUiTinyMargin} name="picture" value={orderPayload.picture || ''} onChange={onFileChangeHandler}>
                            <Button design="emphasized" icon="upload" />
                        </FileUploader>
                    </FormItem>
                    {orderPayload.orderType === "2" && <FormItem label="City" required>
                        <Select style={spacing.sapUiTinyMargin} name="orderLocCity" value={orderLocCity} onChange={(e) => { onSelectChange(e); }} disabled>
                            <Option selected>
                                {businessInfo.location !== undefined ? businessInfo.location.city : ''}
                            </Option>
                        </Select>
                    </FormItem>}
                </FormGroup>
            </Form>

            {assetTableVisible === true ?
                <div>
                    <BusyIndicator style={{ width: '100%' }}
                        active={!assetRows.length && !toast.show}>
                        <AccountTable columns={getAssetListColumns()} edit={false} text="Asset List" rows={assetRows}
                            buttons={buttons} lazyLoading={loadMoreAssetList} height={getTableHeight()} />
                    </BusyIndicator>
                </div> :
                <div>
                    <Toolbar>
                        <Label style={{ fontSize: '1rem', fontWeight: 'bold' }}>
                            Asset List
                        </Label>
                    </Toolbar>
                    <div style={{ display: "flex", flexDirection: "column", ...spacing.sapUiLargeMargin }}>
                        <Text>1. Please download the Excel template and fill the given columns with your asset data.</Text>
                        <Button data-layout-span="XL3" design = "Emphasized" icon="download" style={{ position: "absolute", ...spacing.sapUiMediumMargin }} width="20%" onClick={onDownloadBtnClick} >Download Excel Template</Button>
                    </div>
                    <div style={spacing.sapUiLargeMargin}>
                        <Text style={spacing.sapUiMediumMarginTop}>2. Then upload the Excel file here for the internal approval.</Text>
                        <div style ={spacing.sapUiMediumMargin}>
                            <FileUploader name="assetExcel"
                                placeholder="Upload Excel Asset list"
                                value={orderPayload.assetExcel || ''}
                                onChange={onFileChangeHandler}
                                accept=".xlsx"
                                valueState={OrderFormFieldSpec.assetExcel.valueState}
                                valueStateMessage={OrderFormFieldSpec.assetExcel.valueStateMessage}
                            >
                                <Button design="Emphasized">
                                    Upload file
                                </Button>
                            </FileUploader>
                        </div>
                    </div>
                </div>}
            <AccountTable columns={columns} edit={false} text="Internal Approval Workflow (Asset List)" rows={rows}/>
            <div style={spacing.sapUiTinyMargin}>
                <Button style= {{ float: "right", ...spacing.sapUiMediumMarginBegin }}
                    onClick={() => onSendAssetListClick()}
                    design="Emphasized"
                >Send Asset List for Internal Approval</Button>
                <Button style= {{ float: "right" }}
                    onClick={(e) => { onSubmit(e, 'draft'); }}
                    design="Emphasized"
                >Save as Draft</Button>
                <CommentDialog ref={dialogRef} onCancel={onCancel} onSubmit={onSubmit} headerText="Send Asset List for internal approval"/>
                { toast.show && <MessageBar message={toast.message} type={toast.type}/>}
            </div>
        </div>
    );
};
const mapStateToProps = state => {
    return {
        businessInfo: state.account.businessInfo,
        workflowsInfo: state.account.workflows,
        orderTypes: state.order.orderType,
        categories: state.order.category,
        subcategories: state.order.subcategory,
        previewOrderItemInfo: state.order.previewOrderItemInfo,
        privateNetworkRecyclers: state.account.networkInfo,
        toast: state.toast
    };
};

const mapDispatchToProps = dispatch => {
    return {
        startGetOrderType: () => dispatch(getOrderType()),
        startGetCategory: () => dispatch(getCategory()),
        startGetSubCategory: () => dispatch(getSubCategory()),
        startGetWorkflowInfo: () => dispatch(getWorkflowsInfo()),
        startUpdateOrderInfo: (payload) => dispatch(updateOrderInfo(payload)),
        startUpdateDraftOrderInfo: (payload) => dispatch(updateDraftOrderInfo(payload)),
        startReadExcelInfo: (payload) => dispatch(readExcelInfo(payload)),
        startGetBusinessInfo: () => dispatch(getBusinessInfo()),
        startClearPreviewOrderItems: () => dispatch(clearPreviewOrderItems()),
        startGetPrivateNetworkRecyclers: () => dispatch(getNetworkInfo())
    };
};

OrderCreationForm.propTypes = {
    businessInfo: PropTypes.object,
    orderInfo: PropTypes.object,
    workflowsInfo: PropTypes.array,
    previewOrderItemInfo: PropTypes.array,
    orderTypes: PropTypes.array,
    categories: PropTypes.array,
    subcategories: PropTypes.array,
    startGetOrderType: PropTypes.func,
    startGetCategory: PropTypes.func,
    startGetSubCategory: PropTypes.func,
    startUpdateOrderInfo: PropTypes.func,
    startUpdateDraftOrderInfo: PropTypes.func,
    startGetWorkflowInfo: PropTypes.func,
    startReadExcelInfo: PropTypes.func,
    startGetBusinessInfo: PropTypes.func,
    startClearPreviewOrderItems: PropTypes.func,
    startGetPrivateNetworkRecyclers: PropTypes.func,
    privateNetworkRecyclers: PropTypes.array,
    toast: PropTypes.object
};

OrderCreationForm.defaultProps = {
    businessInfo: {},
    orderInfo: {},
    workflowsInfo: [],
    previewOrderItemInfo: [],
    orderTypes: [],
    categories: [],
    subcategories: [],
    privateNetworkRecyclers: []
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderCreationForm);
