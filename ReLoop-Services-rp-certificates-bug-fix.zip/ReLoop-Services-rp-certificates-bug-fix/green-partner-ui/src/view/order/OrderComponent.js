import React, { useEffect } from 'react';
import { Route, Switch, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import PrivateRoute from '../login/PrivateRoute';
import PreviousOrder from './PreviousOrder';
import OrderCreationForm from './OrderCreationForm';
import OrderInfo from './OrderInfo';
import ErrorComponent from '../common/Error';
import { getOrderInfoState, isOrderInfoLoading } from '../../selectors/common';
import { getOrderInfo } from '../../store/action/order';
import LoadingIndicator from '../common/Loading';

const OrderComponent = ({ orderInfo, isLoading, startGetOrderInfo }) => {
    useEffect(() => {
        startGetOrderInfo();
    }, []);

    // eslint-disable-next-line react/prop-types
    const RenderOrderInfo = ({ match }) => {
        // eslint-disable-next-line react/prop-types
        let orderNumber = match.params.orderNumber;
        let orderId = orderInfo.find((order) => order.orderNumber === orderNumber).orderId;
        let orderType = orderInfo.find((order) => order.orderNumber === orderNumber).orderType;
        return <OrderInfo orderId={orderId} orderType = {orderType}/>;
    };

    if (isLoading) {
        return <LoadingIndicator/>;
    } else {
        return (
            <Switch>
                <PrivateRoute exact path="/order/newOrder" component={OrderCreationForm} />
                <PrivateRoute
                    exact
                    path="/order/previousOrder"
                    component={() => <PreviousOrder orderInfo={orderInfo} />}
                />
                <PrivateRoute
                    exact
                    path="/order/previousOrder/:orderNumber"
                    component={RenderOrderInfo}
                />
                <Route
                    exact
                    path="/404"
                    component={() => <ErrorComponent text="Page Not Found" />}
                />
                <Redirect from="/" to="/404" />
            </Switch>
        );
    }
};

const mapStateToProps = (state) => {
    return {
        orderInfo: getOrderInfoState(state),
        isLoading: isOrderInfoLoading(state)
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetOrderInfo: () => dispatch(getOrderInfo())
    };
};

OrderComponent.propTypes = {
    orderInfo: PropTypes.array,
    isLoading: PropTypes.bool,
    startGetOrderInfo: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderComponent);
