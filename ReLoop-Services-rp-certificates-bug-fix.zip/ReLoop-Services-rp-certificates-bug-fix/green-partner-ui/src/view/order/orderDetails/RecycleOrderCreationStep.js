import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Form, FormGroup, FormItem, Text, Button, Toolbar, ToolbarSpacer, Token } from '@ui5/webcomponents-react';
import AccountTable from '../../common/Table';
import { spacing } from '@ui5/webcomponents-react-base';
import { connect } from 'react-redux';
import { createOrderWorkflow } from '../../../store/action/order';

const RecycleOrderCreation = ({ orderItemInfo, onNextStep, startCreateOrderWorkflow }) => {
    const [assetRows, setAssetRows] = useState([]);
    const [approverRows, setApproverRows] = useState([]);

    const assetColumns = [
        'Item',
        'Quantity',
        'Unit',
        'Location',
        'Remarks'
    ];

    const approverColumns = ['Approver Sequence', 'Approver Name', 'Approver Role', 'Status'];

    const sendForApproval = () => {
        let payload = {
            orderId: orderItemInfo.orderId,
            processStageSequence: '1',
            processType: orderItemInfo.orderType
        };
        startCreateOrderWorkflow(payload);
    };

    const getOrderItemDetails = (orderItemInfo) => {
        const newRows = [];
        orderItemInfo.map((index) => {
            const row = [];
            row.push({ name: assetColumns[0], value: index.model, type: 'text' });
            row.push({ name: assetColumns[1], value: index.itemQuantity || '-', type: 'text' });
            row.push({ name: assetColumns[3], value: index.recycleItemUnit || '-', type: 'text' });
            row.push({ name: assetColumns[2], value: index.buildingLocation, type: 'text' });
            row.push({ name: assetColumns[4], value: index.description, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };

    useEffect(() => {
        if (orderItemInfo.orderItems) {
            let rows = getOrderItemDetails(orderItemInfo.orderItems);
            setAssetRows(rows);
        }
    }, [orderItemInfo.orderItems]);

    const getApproverDetails = (workflowApprovers) => {
        const newRows = [];
        workflowApprovers.map((workflowApprover) => {
            const row = [];
            row.push({
                name: approverColumns[0],
                value: workflowApprover.approverSequence,
                type: 'text'
            });
            row.push({
                name: approverColumns[1],
                value: workflowApprover.approverName,
                type: 'text'
            });
            row.push({
                name: approverColumns[2],
                value: workflowApprover.approverRole,
                type: 'text'
            });
            row.push({ name: approverColumns[3], value: workflowApprover.status, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };

    useEffect(() => {
        if (orderItemInfo.workflow) {
            let rows = getApproverDetails(orderItemInfo.workflow.workflowApprovers);
            setApproverRows(rows);
        }
    }, [orderItemInfo.workflow]);

    const getNextBtnDisabled = (workflow) => {
        if (!workflow) return false;
        const { workflowApprovers } = workflow;
        let isDisabled = false;
        for (let i = 0; i < workflowApprovers.length; i += 1) {
            if (workflowApprovers[i].status !== 'Approved') {
                isDisabled = true;
                break;
            }
        }
        return isDisabled;
    };

    const renderButton = () => {
        if (Number(orderItemInfo.currentSequence) === 1) {
            if (orderItemInfo.orderPosition !== 'Draft') {
                return (
                    <>
                        {' '}
                        <Toolbar>
                            <ToolbarSpacer />
                            <Button
                                design="Emphasized"
                                disabled={getNextBtnDisabled(orderItemInfo.workflow)}
                                onClick={() => onNextStep(1)}
                            >
                                Check Order Before Submission
                            </Button>
                        </Toolbar>
                    </>
                );
            } else {
                return (
                    <>
                        {' '}
                        <Toolbar toolbarStyle="Clear">
                            <ToolbarSpacer />
                            <Button design="Emphasized" onClick={() => sendForApproval()}>
                                Send Asset List for Internal Approval
                            </Button>
                        </Toolbar>
                    </>
                );
            }
        } else return <></>;
    };

    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <Form columnsL={2} columnsM={2} columnsS={2} labelSpanM={5} style={spacing.sapUiLargeMarginTopBottom}>
                <FormGroup>
                    <FormItem label="Order Type">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.processType}</Text>
                    </FormItem>
                    <FormItem label="Category">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.categoryName}</Text>
                    </FormItem>
                    <FormItem label="Subcategory">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.subCategoryName}</Text>
                    </FormItem>
                    <FormItem label="Asset Type ">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.recycleAssetType || '-'}</Text>
                    </FormItem>
                    <FormItem label="Total Weight ">
                        <Text style={spacing.sapUiTinyMargin}> {orderItemInfo.totalWeight ?
                            `${orderItemInfo.totalWeight} KG` : '-'}</Text>
                    </FormItem>
                </FormGroup>
                <FormGroup>
                    <FormItem label="Private/Public Network">
                        <Text style={spacing.sapUiTinyMargin}>Private Network</Text>
                    </FormItem>
                    <FormItem label="Recyclers">
                        <Text style={spacing.sapUiTinyMargin} >
                            {orderItemInfo.recyclers.map((item) => {
                                return <Token style={spacing.sapUiTinyMargin} readonly text={item.bpUsername}/>;
                            })}
                        </Text>
                    </FormItem>
                    <FormItem label="Quote Submission Deadline">
                        <Text style={spacing.sapUiTinyMargin}>
                            {new Date(orderItemInfo.submissionDeadline).toDateString()}
                        </Text>
                    </FormItem>
                    <FormItem label="Additional information">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.orderAdditionalInfo}</Text>
                    </FormItem>
                </FormGroup>
            </Form>
            <AccountTable columns={assetColumns} edit={false} text="Asset List" rows={assetRows} />
            <AccountTable columns={approverColumns} edit={false} text="Workflow Approver" rows={approverRows} />
            {renderButton()}
        </div>
    );
};

const mapStateToProps = (state) => {
    return {};
};

const mapDispatchToProps = (dispatch) => {
    return {
        startCreateOrderWorkflow: (payload) => dispatch(createOrderWorkflow(payload))
    };
};

RecycleOrderCreation.propTypes = {
    orderItemInfo: PropTypes.object,
    onNextStep: PropTypes.func,
    startCreateOrderWorkflow: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(RecycleOrderCreation);
