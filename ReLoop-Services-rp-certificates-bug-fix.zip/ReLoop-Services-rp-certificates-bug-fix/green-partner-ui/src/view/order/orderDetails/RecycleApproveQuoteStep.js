import React, { useRef, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import AccountTable from '../../common/Table';
import { Button, Toolbar, ToolbarSpacer } from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import {
    getApprover,
    getRecycleOrderItemLevelQuote,
    scheduleLogistics
} from '../../../store/action/order';
import CalendarDialog from '../../common/CalendarDialog';

const ApproveFinalQuote = ({
    approver,
    startGetApprover,
    orderItemQuotation,
    orderId,
    orderType,
    onSiteVisitDetails,
    startGetItemQuote,
    startScheduleLogistics
}) => {
    const dialogRef = useRef(null);
    const [recyclerInfoRows, setRecyclerInfoRows] = useState([]);
    const [assetRows, setAssetRows] = useState([]);
    const [approverRows, setApproverRows] = useState([]);
    const selectedRecyclerInfoColumns = ['Selected Recycler Company', 'Total Price'];
    const assetColumns = [
        'Item',
        'Final Quantity',
        'Unit',
        'Price/Unit (INR)',
        'Total Price (INR)'
    ];

    const approverColumns = ['Approver Role', 'Approver Name', 'Status'];
    const getVisitDetails = (onSiteVisitDetails) => {
        const newRows = [];
        const row = [];
        row.push({
            name: selectedRecyclerInfoColumns[0],
            value: onSiteVisitDetails.createdByBP.recyclerName,
            type: 'text',
            wrapping: true,
            style: { 'line-height': ' 1.5rem', '-webkit-line-clamp': 5 }
        });
        row.push({
            name: selectedRecyclerInfoColumns[1],
            value: orderItemQuotation.totalPrice,
            type: 'text'
        });
        newRows.push(row);
        return newRows;
    };

    useEffect(() => {
        if (Object.keys(onSiteVisitDetails).length !== 0) {
            const row = getVisitDetails(onSiteVisitDetails);
            setRecyclerInfoRows(row);
        }
    }, [onSiteVisitDetails, orderItemQuotation]);
    const getOrderItemQuoteDetails = (orderItemQuotation) => {
        const newRows = [];
        orderItemQuotation.map((orderItem) => {
            const row = [];
            row.push({ name: assetColumns[0], value: orderItem.item, type: 'text' });
            row.push({ name: assetColumns[1], value: orderItem.finalQty, type: 'text' });
            row.push({ name: assetColumns[2], value: orderItem.unit, type: 'text' });
            row.push({ name: assetColumns[3], value: orderItem.pricePerUnit, type: 'text' });
            row.push({ name: assetColumns[4], value: orderItem.totalPrice, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };
    const getApproverDetails = (approvers) => {
        const newRows = [];
        approvers.map((approver) => {
            const row = [];
            row.push({ name: approverColumns[0], value: approver.approverRole, type: 'text' });
            row.push({ name: approverColumns[1], value: approver.approverName, type: 'text' });
            row.push({ name: approverColumns[2], value: approver.status, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };
    useEffect(() => {
        startGetApprover(orderId, '2', '5');
        startGetItemQuote(orderId);
    }, []);

    useEffect(() => {
        if (approver.length !== 0) {
            const row = getApproverDetails(approver);
            setApproverRows(row);
        }
    }, [approver.length]);
    useEffect(() => {
        if (orderItemQuotation.orderQuoteItems) {
            const assetRows = getOrderItemQuoteDetails(orderItemQuotation.orderQuoteItems);
            setAssetRows(assetRows);
        }
    }, [orderItemQuotation]);
    const onCancel = () => {
        dialogRef.current.close();
    };
    const onSubmit = (calendarPayload) => {
        const { date, time, logisticSpocName, logisticSpocContactNumber } = calendarPayload;
        let formattedDate = new Date(`${date} ${time}`);
        formattedDate = formattedDate.toISOString();
        const payload = {
            scheduledLogisticDate: formattedDate,
            logisticSpocName,
            logisticSpocContactNumber
        };
        startScheduleLogistics(orderId, payload);
        dialogRef.current.close();
    };
    const onScheduleClick = () => {
        dialogRef.current.open();
    };

    const renderButton = () => {
        if (approver === []) {
            return (
                <>
                    {' '}
                    <Toolbar toolbarStyle="Clear">
                        <ToolbarSpacer />
                        <Button design="Emphasized" onClick={onScheduleClick}>
                            Schedule Pick up date
                        </Button>
                    </Toolbar>
                </>
            );
        } else {
            let isAllApproved = approver.filter((x) => x.status === 'Approved').length === approver.length;
            return (
                <>
                    {' '}
                    <Toolbar toolbarStyle="Clear">
                        <ToolbarSpacer />
                        <Button
                            design="Emphasized"
                            onClick={onScheduleClick}
                            disabled={!isAllApproved}
                        >
                            Schedule Pick up date
                        </Button>
                    </Toolbar>
                </>
            );
        }
    };

    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <AccountTable
                columns={selectedRecyclerInfoColumns}
                edit={false}
                text="Selected Recycler"
                rows={recyclerInfoRows}
            />
            <AccountTable columns={assetColumns} edit={false} text="Asset List" rows={assetRows} />
            <AccountTable
                columns={approverColumns}
                edit={false}
                text="Workflow Approver"
                rows={approverRows}
            />
            {renderButton()}
            <CalendarDialog
                ref={dialogRef}
                onCancel={onCancel}
                onSubmit={onSubmit}
                headerText="Schedule Pickup Date for your Assets"
                showEstHours={false}
            />
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        approver: state.order.approver['5'],
        orderItemQuotation: state.order.orderItemQuotation,
        onSiteVisitDetails: state.order.onSiteVisitDetails
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetApprover: (orderId, processType, sequenceNo) =>
            dispatch(getApprover(orderId, processType, sequenceNo)),
        startGetItemQuote: (orderId) => dispatch(getRecycleOrderItemLevelQuote(orderId)),
        startScheduleLogistics: (orderId, quoteId, payload) =>
            dispatch(scheduleLogistics(orderId, quoteId, payload))
    };
};

ApproveFinalQuote.propTypes = {
    approver: PropTypes.array,
    startGetApprover: PropTypes.func,
    startGetItemQuote: PropTypes.func,
    startScheduleLogistics: PropTypes.func,
    orderId: PropTypes.string,
    orderType: PropTypes.string,
    onSiteVisitDetails: PropTypes.object,
    orderItemQuotation: PropTypes.array
};

export default connect(mapStateToProps, mapDispatchToProps)(ApproveFinalQuote);
