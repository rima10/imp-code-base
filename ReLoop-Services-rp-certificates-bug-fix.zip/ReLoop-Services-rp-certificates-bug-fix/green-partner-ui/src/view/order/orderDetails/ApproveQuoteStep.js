import React, { useRef, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import AccountTable from '../../common/Table';
import { Button, Toolbar, ToolbarSpacer, Bar, Label } from '@ui5/webcomponents-react';
import { connect } from 'react-redux';
import {
    getApprover,
    getRefurbishOrderItemLevelQuote,
    scheduleLogistics,
    downloadAssetGradeList
} from '../../../store/action/order';
import CalendarDialog from '../../common/CalendarDialog';

const ApproveFinalQuote = ({
    approver,
    startGetApprover,
    orderItemQuotation,
    orderId,
    orderType,
    onSiteVisitDetails,
    startGetItemQuote,
    startScheduleLogistics,
    startDownloadAssetGradeList,
    orderQuotation
}) => {
    const dialogRef = useRef(null);
    const [recyclerInfoRows, setRecyclerInfoRows] = useState([]);
    const [assetRows, setAssetRows] = useState([]);
    const [approverRows, setApproverRows] = useState([]);
    const selectedRecyclerInfoColumns = ['Selected Recycler Company', 'Total Price'];

    const approverColumns = ['Approver Role', 'Approver Name', 'Status'];
    const getVisitDetails = (onSiteVisitDetails) => {
        const newRows = [];
        const row = [];
        row.push({
            name: selectedRecyclerInfoColumns[0],
            value: onSiteVisitDetails.createdByBP.recyclerName,
            type: 'text'
        });
        row.push({
            name: selectedRecyclerInfoColumns[1],
            value: onSiteVisitDetails.totalPrice,
            type: 'text'
        });
        newRows.push(row);
        return newRows;
    };

    useEffect(() => {
        if (Object.keys(onSiteVisitDetails).length !== 0) {
            const row = getVisitDetails(onSiteVisitDetails);
            setRecyclerInfoRows(row);
        }
    }, [onSiteVisitDetails]);

    const assetColumns = [{
        heading: 'Equipment No.',
        key: 'equipmentNumber'
    }, {
        heading: 'Asset No.',
        key: 'assetNumber'
    }, {
        heading: 'Location',
        key: 'buildingLocation',
        showOnDemand: true
    }, {
        heading: 'Bond Status',
        key: 'bondStatus',
        showOnDemand: true
    }, {
        heading: 'Item Type',
        key: 'itemType',
        showOnDemand: true
    }, {
        heading: 'Make',
        key: 'make',
        showOnDemand: true
    }, {
        heading: 'Model',
        key: 'model',
        showOnDemand: true
    }, {
        heading: 'Age in Years',
        key: 'ageInYear',
        showOnDemand: true
    }, {
        heading: 'Description',
        key: 'description',
        showOnDemand: true
    }, {
        heading: 'Grade',
        key: 'grade'
    }, {
        heading: 'Data wipe',
        key: 'dataWipeStatus',
        cellStyle: (value) => {
            switch (value) {
                case "Erased":
                    return { color: 'green' };
                case "In Progress":
                    return { color: 'orange' };
                case "Not Erased":
                    return { color: 'red' };
            }
        }
    }, {
        heading: 'Report status',
        key: 'reportStatus'
    }, {
        heading: 'Accessories',
        key: 'accessoriesStatus'
    }, {
        heading: 'List price',
        key: 'listPrice',
        cellStyle: (value) => {
            return {
                textAlign: 'right'
            };
        }
    }, {
        heading: 'To be invoiced',
        key: 'invoiceAmount',
        cellStyle: (value) => {
            return {
                textAlign: 'right'
            };
        }
    }, {
        heading: 'Service cost',
        key: 'serviceCost',
        cellStyle: (value) => {
            return {
                textAlign: 'right'
            };
        }
    }];
    const [assetColumnsHeader, setAssetColumnsHeader] = useState([]);
    const [totalRow, setTotalRows] = useState({ invoiceAmount: 0, serviceCost: 0 });
    const [showExtraColumns, setShowExtraColumns] = useState(false);
    const [tableBusyIndicator, setTableBusyIndicator] = useState(false);
    const calculateTotalAmount = (assetGradeListRows, field1, field2) => {
        const totalRowCopy = { ...totalRow };
        totalRowCopy[field1] = 0;
        if (field2) {
            totalRowCopy[field2] = 0;
        }
        assetGradeListRows.forEach((item) => {
            totalRowCopy[field1] += item[field1] ? Number(item[field1]) : 0;
            if (field2) {
                totalRowCopy[field2] += item[field2] ? Number(item[field2]) : 0;
            }
        });
        if (field1) {
            totalRowCopy[field1] = Math.round(totalRowCopy[field1] * 100) / 100;
        }
        if (field2) {
            totalRowCopy[field2] = Math.round(totalRowCopy[field2] * 100) / 100;
        }
        setTotalRows(totalRowCopy);
    };

    const getOrderItemQuoteDetails = (orderItemQuotation, limit, showExtraColumnsLocal = showExtraColumns) => {
        const newRows = [];
        const limitedRows = orderItemQuotation.slice(0, limit);
        limitedRows.map((orderItem) => {
            const row = [];
            assetColumns.forEach((colItem, colIndex) => {
                if (!showExtraColumnsLocal && colItem.showOnDemand) return;
                row.push({
                    name: colItem.heading,
                    value: orderItem[colItem.key],
                    type: 'text',
                    style: colItem.cellStyle ? colItem.cellStyle(orderItem[colItem.key]) : {}
                });
            });
            newRows.push(row);
        });
        return newRows;
    };

    const minDisplayRows = 7;
    const minTableHeight = '600px';
    const initColumnHeaders = (showExtraColumnsLocal = showExtraColumns) => {
        const headers = [];
        assetColumns.forEach((item) => {
            if (!showExtraColumnsLocal && item.showOnDemand) return;
            headers.push(item.heading);
        });
        setAssetColumnsHeader(headers);

        setAssetRows((previousRows) => {
            const limit = previousRows.length ? previousRows.length : minDisplayRows;
            return [...getOrderItemQuoteDetails(orderItemQuotation, limit, showExtraColumnsLocal)];
        });
    };

    const loadMoreAssetRows = () => {
        setTableBusyIndicator(true);
        setAssetRows((previousRows) => {
            if (orderItemQuotation.length <= previousRows.length) {
                return previousRows;
            }
            return [...getOrderItemQuoteDetails(orderItemQuotation.slice(0),
                previousRows.length + minDisplayRows)];
        });
        setTableBusyIndicator(false);
    };

    useEffect(() => {
        if (orderItemQuotation && Array.isArray(orderItemQuotation)) {
            calculateTotalAmount(orderItemQuotation, 'invoiceAmount', 'serviceCost');
            initColumnHeaders();
        }
    }, [orderItemQuotation]);

    const getApproverDetails = (approvers) => {
        const newRows = [];
        approvers.map((approver) => {
            const row = [];
            row.push({ name: approverColumns[0], value: approver.approverRole, type: 'text' });
            row.push({ name: approverColumns[1], value: approver.approverName, type: 'text' });
            row.push({ name: approverColumns[2], value: approver.status, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };
    useEffect(() => {
        startGetApprover(orderId, '1', '5');
        const acceptedOrderQuotation = orderQuotation.find((item) => item.quoteStatus === 'Accepted');
        if (acceptedOrderQuotation) {
            startGetItemQuote(orderId, acceptedOrderQuotation.quoteId);
        }
    }, []);

    useEffect(() => {
        if (approver.length !== 0) {
            const row = getApproverDetails(approver);
            setApproverRows(row);
        }
    }, [approver.length]);
    const onCancel = () => {
        dialogRef.current.close();
    };
    const onSubmit = (calendarPayload) => {
        const { date, time, logisticSpocName, logisticSpocContactNumber } = calendarPayload;
        let formattedDate = new Date(`${date} ${time} UTC`);
        formattedDate = formattedDate.toISOString();
        const payload = {
            scheduledLogisticDate: formattedDate,
            logisticSpocName,
            logisticSpocContactNumber
        };
        startScheduleLogistics(orderId, payload);
        dialogRef.current.close();
    };
    const onScheduleClick = () => {
        dialogRef.current.open();
    };

    const onDownloadAssetGradeList = (e) => {
        setTableBusyIndicator(true);
        const acceptedOrderQuotation = orderQuotation.find((item) => item.quoteStatus === 'Accepted');
        startDownloadAssetGradeList(orderId, acceptedOrderQuotation.quoteId)
            .then((response) => {
                setTableBusyIndicator(false);
                const responseBlob = new Blob([response.data]);
                const url = window.URL.createObjectURL(responseBlob);
                const a = document.createElement('a');
                a.href = url;
                a.target = "_blank";
                a.download = 'AssetGradeList.xlsx';
                a.click();
            })
            .catch((e) => {
                setTableBusyIndicator(false);
            });
    };

    const assetTableButtons = [{
        name: 'Show Asset Columns',
        icon: 'eye',
        hide: showExtraColumns,
        onClick: (e) => {
            setShowExtraColumns(true);
            initColumnHeaders(true);
        }
    }, {
        name: 'Hide Asset Columns',
        icon: 'eye-closed',
        hide: !showExtraColumns,
        onClick: (e) => {
            setShowExtraColumns(false);
            initColumnHeaders(false);
        }
    }, {
        name: 'Download as Excel',
        icon: 'download',
        onClick: onDownloadAssetGradeList,
        disabled: tableBusyIndicator
    }];
    const renderButton = () => {
        if (approver === []) {
            return (
                <>
                    {' '}
                    <Toolbar toolbarStyle="Clear">
                        <ToolbarSpacer />
                        <Button design="Emphasized" onClick={onScheduleClick}>
                            Schedule Pick up date
                        </Button>
                    </Toolbar>
                </>
            );
        } else {
            let isAllApproved = approver.filter((x) => x.status === 'Approved').length === approver.length;
            return (
                <>
                    {' '}
                    <Toolbar toolbarStyle="Clear">
                        <ToolbarSpacer />
                        <Button
                            design="Emphasized"
                            onClick={onScheduleClick}
                            disabled={!isAllApproved}
                        >
                            Schedule Pick up date
                        </Button>
                    </Toolbar>
                </>
            );
        }
    };

    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <AccountTable
                columns={selectedRecyclerInfoColumns}
                edit={false}
                text="Selected Recycler"
                rows={recyclerInfoRows}
            />
            <AccountTable
                isBusy={tableBusyIndicator}
                columns={assetColumnsHeader}
                rows={assetRows}
                buttons={assetTableButtons}
                edit={false}
                text="List of Verified Assets"
                lazyLoading={loadMoreAssetRows}
                height={minTableHeight} />
            <Bar
                startContent={
                    <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                        Total value to be Invoiced (exclude tax)</Label>
                }
                endContent={
                    <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                        {totalRow && totalRow.invoiceAmount} INR
                    </Label>
                }
                style={{ background: '#f2f2f2' }}
            />
            <Bar
                startContent={
                    <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                        Total service costs (exclude tax) </Label>
                }
                endContent={
                    <Label style={{ fontWeight: 'bold', fontSize: 'larger' }}>
                        {totalRow && totalRow.serviceCost} INR
                    </Label>
                }
                style={{ background: '#f2f2f2' }}
            />
            <AccountTable
                columns={approverColumns}
                edit={false}
                text="Workflow Approver"
                rows={approverRows}
            />
            {renderButton()}
            <CalendarDialog
                ref={dialogRef}
                onCancel={onCancel}
                onSubmit={onSubmit}
                headerText="Schedule Pickup Date for your Assets"
                showEstHours={false}
            />
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        approver: state.order.approver['5'],
        orderItemQuotation: state.order.orderItemQuotation,
        onSiteVisitDetails: state.order.onSiteVisitDetails,
        orderQuotation: state.order.orderQuotation.quotesData
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetApprover: (orderId, processType, sequenceNo) =>
            dispatch(getApprover(orderId, processType, sequenceNo)),
        startGetItemQuote: (orderId, quoteId) => dispatch(getRefurbishOrderItemLevelQuote(orderId, quoteId)),
        startScheduleLogistics: (orderId, quoteId, payload) =>
            dispatch(scheduleLogistics(orderId, quoteId, payload)),
        startDownloadAssetGradeList: (orderId, quoteId) => dispatch(downloadAssetGradeList(orderId, quoteId))
    };
};

ApproveFinalQuote.propTypes = {
    approver: PropTypes.array,
    startGetApprover: PropTypes.func,
    startGetItemQuote: PropTypes.func,
    startScheduleLogistics: PropTypes.func,
    orderId: PropTypes.string,
    orderType: PropTypes.string,
    onSiteVisitDetails: PropTypes.object,
    orderItemQuotation: PropTypes.array,
    orderQuotation: PropTypes.array,
    startDownloadAssetGradeList: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(ApproveFinalQuote);
