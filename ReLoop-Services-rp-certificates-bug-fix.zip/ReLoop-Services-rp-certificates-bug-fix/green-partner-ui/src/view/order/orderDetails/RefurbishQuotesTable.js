import React from 'react';
import PropTypes from 'prop-types';
import { AnalyticalTable, Button, ObjectStatus, Text } from '@ui5/webcomponents-react';
import { rejectQuote, temporaryAcceptQuote } from '../../../store/action/order';
import { connect } from 'react-redux';

const RecycleQuotesTable = ({
    orderId,
    orderType,
    orderQuotation,
    approverLength,
    startRejectQuote,
    startTemporaryAcceptQuote

}) => {
    const getValueState = (value) => {
        if (value === 'In Review') {
            return 'Warning';
        }
        if (value === 'Accepted' || value === 'Temporarily Accepted') {
            return 'Success';
        }
        if (value === 'Rejected') {
            return 'Error';
        }
        return 'Information';
    };
    const getQuoteStatus = (value) => {
        if (value === 'Accepted' || value === 'Temporarily Accepted') {
            return 'Accepted';
        }
        return value;
    };

    const onAcceptQuote = (quoteId) => {
        startTemporaryAcceptQuote(orderId, quoteId, orderType);
    };

    const onRejectQuote = (quoteId) => {
        startRejectQuote(orderId, quoteId, orderType);
    };

    const renderButton = (value) => {
        if (value) {
            let status = orderQuotation.quotesData.find((quote) => quote.quoteId === value).quoteStatus;
            if (status === 'Accepted' || status === 'Temporarily Accepted') {
                return (
                    <>
                        <Button onClick={() => onRejectQuote(value)} design="Negative">
                            Reject Quote
                        </Button>
                    </>
                );
            } else {
                if (
                    orderQuotation.quotesOverallStatus === 'Accepted' ||
                    orderQuotation.quotesOverallStatus === 'Temporarily Accepted'
                ) {
                    return <Button disabled>Accept Quote</Button>;
                }
                return (
                    <Button onClick={() => onAcceptQuote(value)} disabled={false}>
                        Accept Quote
                    </Button>
                );
            }
        }
        return null;
    };

    const renderName = (value) => {
        if (typeof value === 'object' && value !== null) {
            return (
                <Text>
                    {value.name} ({value.count})
                </Text>
            );
        }
        return <Text>{value}</Text>;
    };

    const renderPrice = (instance) => {
        const rowProps = instance.row.getRowProps();
        const rowKeyArr = rowProps.key.split('.');
        let price = instance.cell.value;
        if (price && rowKeyArr.length > 1) {
            return (<><Text>{price}</Text>
                <Text style={{ fontStyle: 'italic', fontSize: '1rem', margin: '2px' }}> / unit</Text></>);
        }
        return <Text>{price}</Text>;
    };

    const getQuotesTableColumns = () => {
        const columns = [
            {
                Header: 'Recycler Company',
                accessor: 'name',
                Cell: (instance) => renderName(instance.cell.value)
            },
            {
                Header: 'Price (INR)',
                accessor: 'totalPrice',
                Cell: (instance) => renderPrice(instance)
            },
            {
                Header: 'Additional Comments',
                accessor: 'quoteComments',
                Cell: (instance) => renderName(instance.cell.value)
            },
            {
                Header: 'Status',
                accessor: 'quoteStatus',
                Cell: (instance) => {
                    return (
                        <ObjectStatus state={getValueState(instance.cell.value)}>
                            {getQuoteStatus(instance.cell.value)}
                        </ObjectStatus>
                    );
                }
            }
        ];
        if (approverLength === 0) {
            columns.push(
                {
                    Header: 'Action',
                    accessor: 'quoteId',
                    Cell: (instance) => renderButton(instance.cell.value)
                });
        }
        return columns;
    };

    return (
        <AnalyticalTable
            columns={getQuotesTableColumns()}
            data={orderQuotation.quotesData}
            isTreeTable
            minRows={1}
            subRowsKey="data"
        />
    );
};

const mapStateToProps = (state) => {
    return {};
};

const mapDispatchToProps = (dispatch) => {
    return {
        startRejectQuote: (orderId, quoteId, orderType) => dispatch(rejectQuote(orderId, quoteId, orderType)),
        startTemporaryAcceptQuote: (orderId, quoteId, orderType) =>
            dispatch(temporaryAcceptQuote(orderId, quoteId, orderType))
    };
};

RecycleQuotesTable.propTypes = {
    orderQuotation: PropTypes.object,
    orderId: PropTypes.string,
    orderType: PropTypes.string,
    approverLength: PropTypes.number,
    startRejectQuote: PropTypes.func,
    startTemporaryAcceptQuote: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(RecycleQuotesTable);
