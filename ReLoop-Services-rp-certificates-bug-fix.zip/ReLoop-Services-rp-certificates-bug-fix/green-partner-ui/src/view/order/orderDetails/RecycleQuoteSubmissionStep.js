import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import {
    Form,
    FormGroup,
    FormItem,
    Text,
    Button,
    Toolbar,
    ToolbarSpacer,
    Token
} from '@ui5/webcomponents-react';
import AccountTable from '../../common/Table';
import { spacing } from '@ui5/webcomponents-react-base';
import { useHistory } from 'react-router-dom';
import { showMessage } from '../../../store/action/type';
import { connect } from 'react-redux';

const RecycleQuoteSubmission = ({
    onNextStep,
    orderItemInfo,
    currentSequence,
    startShowMessage
}) => {
    const [assetRows, setAssetRows] = useState([]);

    const history = useHistory();

    const onSubmit = () => {
        startShowMessage({
            // eslint-disable-next-line max-len
            message: `Your order ${orderItemInfo.orderNumber} has been successfully submitted to your ${orderItemInfo.orderNetwork} network`,
            status: 'Positive'
        });
        onNextStep(2, false);
        history.push('/order/previousOrder');
    };

    const assetColumns = [
        'Item',
        'Quantity',
        'Unit',
        'Location',
        'Remarks'
    ];
    const getOrderItemDetails = (orderItemInfo) => {
        const newRows = [];
        orderItemInfo.map((index) => {
            const row = [];
            row.push({ name: assetColumns[0], value: index.model, type: 'text' });
            row.push({ name: assetColumns[1], value: index.itemQuantity || '-', type: 'text' });
            row.push({ name: assetColumns[3], value: index.recycleItemUnit || '-', type: 'text' });
            row.push({ name: assetColumns[2], value: index.buildingLocation, type: 'text' });
            row.push({ name: assetColumns[4], value: index.description, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };

    useEffect(() => {
        if (orderItemInfo.orderItems) {
            let rows = getOrderItemDetails(orderItemInfo.orderItems);
            setAssetRows(rows);
        }
    }, [orderItemInfo.orderItems]);
    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <Form
                columnsL={2}
                columnsM={2}
                columnsS={2}
                labelSpanM={5}
                style={spacing.sapUiLargeMarginBottom}
            >
                <FormGroup>
                    <FormItem label="Order Type">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.processType}</Text>
                    </FormItem>
                    <FormItem label="Category">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.categoryName}</Text>
                    </FormItem>
                    <FormItem label="Subcategory">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.subCategoryName}</Text>
                    </FormItem>
                    <FormItem label="Asset Type ">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.recycleAssetType || '-'}</Text>
                    </FormItem>
                    <FormItem label="Total Weight ">
                        <Text style={spacing.sapUiTinyMargin}> {orderItemInfo.totalWeight ?
                            `${orderItemInfo.totalWeight} KG` : '-'}</Text>
                    </FormItem>
                </FormGroup>
                <FormGroup>
                    <FormItem label="Private/Public Network">
                        <Text style={spacing.sapUiTinyMargin}>Private Network</Text>
                    </FormItem>
                    <FormItem label="Recyclers">
                        <Text style={spacing.sapUiTinyMargin} >
                            {orderItemInfo.recyclers.map((item) => {
                                return <Token style={spacing.sapUiTinyMargin} readonly text={item.bpUsername}/>;
                            })}
                        </Text>
                    </FormItem>
                    <FormItem label="Quote Submission Deadline">
                        <Text style={spacing.sapUiTinyMargin}>
                            {new Date(orderItemInfo.submissionDeadline).toDateString()}
                        </Text>
                    </FormItem>
                    <FormItem label="Additional information">
                        <Text style={spacing.sapUiTinyMargin}>{orderItemInfo.orderAdditionalInfo}</Text>
                    </FormItem>
                </FormGroup>
            </Form>
            <AccountTable
                columns={assetColumns}
                edit={false}
                text="Asset List"
                rows={assetRows}
            />
            <Toolbar toolbarStyle="Clear">
                <ToolbarSpacer />
                <Button design="Emphasized" disabled={Number(currentSequence) > 2} onClick={() => onSubmit()}>
                    Submit Order
                </Button>
            </Toolbar>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {};
};

const mapDispatchToProps = (dispatch) => {
    return {
        startShowMessage: (payload) => dispatch(showMessage(payload))
    };
};

RecycleQuoteSubmission.propTypes = {
    orderItemInfo: PropTypes.object,
    currentSequence: PropTypes.string,
    onNextStep: PropTypes.func,
    startShowMessage: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(RecycleQuoteSubmission);
