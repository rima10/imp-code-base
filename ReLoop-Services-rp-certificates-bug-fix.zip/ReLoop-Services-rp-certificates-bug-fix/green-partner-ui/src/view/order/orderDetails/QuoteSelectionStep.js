import React, { useRef, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Button, Toolbar, ToolbarSpacer, Label } from '@ui5/webcomponents-react';
import CalendarDialog from '../../common/CalendarDialog';
import AccountTable from '../../common/Table';
import { acceptQuote, rejectQuote, temporaryAcceptQuote,
    getApprover, createOrderWorkflow } from '../../../store/action/order';
import { connect } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { showMessage } from '../../../store/action/type';
import RecycleQuotesTable from './RecycleQuotesTable';
import RefurbishQuotesTable from './RefurbishQuotesTable';

const QuoteSelection = ({
    approver,
    orderId,
    orderType,
    orderQuotation,
    totalWeight,
    startGetApprover,
    startAcceptQuote,
    startShowMessage,
    startCreateOrderWorkflow
}) => {
    const dialogRef = useRef(null);
    const history = useHistory();
    const [approverRows, setApproverRows] = useState([]);
    const approverColumns = ['Sequence', 'Approver Role', 'Approver Name', 'Approval Status'];

    const getApproverDetails = (approvers) => {
        const newRows = [];
        approvers.sort(function (a, b) {
            return a.approverSequence - b.approverSequence;
        });
        approvers.map((approver) => {
            const row = [];
            row.push({ name: approverColumns[0], value: approver.approverSequence, type: 'text' });
            row.push({ name: approverColumns[1], value: approver.approverRole, type: 'text' });
            row.push({ name: approverColumns[2], value: approver.approverName, type: 'text' });
            row.push({ name: approverColumns[3], value: approver.status, type: 'text' });
            newRows.push(row);
        });
        return newRows;
    };

    useEffect(() => {
        if (approver.length !== 0) {
            const row = getApproverDetails(approver);
            setApproverRows(row);
        }
    }, [approver]);

    useEffect(() => {
        startGetApprover(orderId, orderType, '3');
    }, []);

    const onCancel = () => {
        dialogRef.current.close();
    };

    const onSubmit = (calendarPayload) => {
        const { date, time, estimatedTime, comment } = calendarPayload;
        let formattedDate = new Date(`${date} ${time}`);
        formattedDate = formattedDate.toISOString();
        const payload = {
            scheduledOnsiteDate: formattedDate,
            estimatedTime,
            comment
        };
        startAcceptQuote(orderId, payload);
        dialogRef.current.close();
        startShowMessage({
            message: `A confirmation about the selected Quote has been sent to the recycler`,
            status: 'Positive'
        });
        history.push('/order/previousOrder');
    };

    const onAcceptClick = () => {
        dialogRef.current.open();
    };

    const onSubmitForInternalApproval = () => {
        const payload = {
            orderId: orderId,
            processStageSequence: 3,
            processType: orderType
        };
        startCreateOrderWorkflow(payload);
    };

    const renderFooterButton = () => {
        const btnData = {
            text: 'Schedule Onsite Visit',
            onClick: onAcceptClick,
            disabled: true
        };
        if (approver.length !== 0) {
            const notAssigned = approver.every(app => app.status === 'Not Assigned');
            const approved = approver.every(app => app.status === 'Approved');
            if (notAssigned) {
                btnData.text = 'Send Quotes for Internal Approval';
                btnData.onClick = onSubmitForInternalApproval;
                if (orderQuotation.quotesData && orderQuotation.quotesData.length) {
                    btnData.disabled = false;
                }
            } else if (approved && orderQuotation.quotesOverallStatus !== 'Accepted') {
                btnData.disabled = false;
            }
        } else {
            btnData.disabled = false;
        }
        return (<Button design="Emphasized" disabled={btnData.disabled} onClick={btnData.onClick}>
            {btnData.text}
        </Button>);
    };


    return (
        <div style={{ height: '100%', margin: '10px' }}>
            <Label style={{ fontSize: '1rem', fontWeight: 'bold', marginBottom: '10px' }}>Quotes From Recyclers</Label>
            {orderType === '1' ? <RefurbishQuotesTable orderType={orderType} orderId={orderId}
                orderQuotation={orderQuotation} approverLength={approverRows.length}/> :
                <RecycleQuotesTable orderType={orderType} orderId={orderId}
                    orderQuotation={orderQuotation} approverLength={approverRows.length} totalWeight={totalWeight}/>}
            <AccountTable
                columns={approverColumns}
                edit={false}
                text="Internal Approval Workflow (Pricing)"
                rows={approverRows}
            />
            <Toolbar toolbarStyle="Clear">
                <ToolbarSpacer />
                {renderFooterButton()}
            </Toolbar>
            <CalendarDialog
                ref={dialogRef}
                onCancel={onCancel}
                onSubmit={onSubmit}
                headerText="Schedule Onsite Visit"
            />
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        approver: state.order.approver['3'],
        orderItemQuotation: state.order.orderItemQuotation
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startAcceptQuote: (orderId, payload, orderType) => dispatch(acceptQuote(orderId, payload, orderType)),
        startRejectQuote: (orderId, quoteId, orderType) => dispatch(rejectQuote(orderId, quoteId, orderType)),
        startTemporaryAcceptQuote: (orderId, quoteId, orderType) =>
            dispatch(temporaryAcceptQuote(orderId, quoteId, orderType)),
        startGetApprover: (orderId, processType, sequenceNo) => dispatch(getApprover(orderId, processType, sequenceNo)),
        startShowMessage: (payload) => dispatch(showMessage(payload)),
        startCreateOrderWorkflow: (payload) => dispatch(createOrderWorkflow(payload))
    };
};

QuoteSelection.propTypes = {
    orderQuotation: PropTypes.object,
    currentSequence: PropTypes.string,
    approver: PropTypes.array,
    orderId: PropTypes.string,
    orderType: PropTypes.string,
    totalWeight: PropTypes.string,
    startGetApprover: PropTypes.func,
    startTemporaryAcceptQuote: PropTypes.func,
    startRejectQuote: PropTypes.func,
    startAcceptQuote: PropTypes.func,
    startShowMessage: PropTypes.func,
    startCreateOrderWorkflow: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(QuoteSelection);
