import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import { getAccessToken } from '../../store/action/taskAction';
import LoadingIndicator from '../common/Loading';

const LoginSuccess = ({ userInfo, isLoading = true, startGetAccessToken }) => {
    useEffect(() => {
        startGetAccessToken();
    }, []);

    const authFailedMessage = <div>Authentication Failed</div>;

    if (isLoading) {
        return <LoadingIndicator />;
    } else {
        return userInfo.isLoggedIn ? <Redirect to="/order/newOrder" /> : authFailedMessage;
    }
};

const mapStateToProps = (state) => {
    return {
        isLoading: state.isLoading,
        userInfo: state.userInfo
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        startGetAccessToken: () => dispatch(getAccessToken())
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(LoginSuccess);


